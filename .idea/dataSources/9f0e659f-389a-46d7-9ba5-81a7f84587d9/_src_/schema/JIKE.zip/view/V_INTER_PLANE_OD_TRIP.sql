create view V_INTER_PLANE_OD_TRIP as
SELECT
    A.PLANE_ORDER_ID,
    A.PLANE_OD_ID,
    B.DETAIL
FROM
    T_CC_INTER_PLANE_OD A
LEFT JOIN
    (
        SELECT
            PLANE_OD_ID,
            listagg(DEPART_CITY_NAME||','||ARRIVE_CITY_NAME||','||TO_CHAR(TAKE_OFF_TIME,
            'YYYY-MM-DD hh24:mi:ss')||','||TO_CHAR(ARRIVE_TIME,'YYYY-MM-DD hh24:mi:ss')||','||
            AIRLINE_CODE||FLIGHT_NO||','||DECODE(CABIN_CLASS,'F','头等舱','B','商务舱','Business','商务舱',
            'E','经济舱','Y','经济舱','Economy','经济舱','P','超级经济舱','其他'),'|') within GROUP (ORDER BY
            PLANE_TRIP_ID) DETAIL
        FROM
            T_CC_INTER_PLANE_TRIP
        WHERE
            PLANE_OD_ID IS NOT NULL
        GROUP BY
            PLANE_OD_ID) B
ON
    A.PLANE_OD_ID = B.PLANE_OD_ID WITH READ ONLY
