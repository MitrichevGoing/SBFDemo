create view V_CC_INSURANCE_ORDER as
SELECT
    t.PLANE_TICKET_ID,
    t.PLANE_ORDER_ID,
    t.SALE_PRICE - NVL(v.CUT_AMOUNT, 0) AS SALE_PRICE
FROM
    (
        SELECT
            PLANE_ORDER_ID,
            PLANE_TICKET_ID,
            SUM(NVL(SALE_PRICE, 0) * NUM) AS SALE_PRICE
        FROM
            JIKE.T_CC_INSURANCE_ORDER
        GROUP BY
            PLANE_ORDER_ID,
            PLANE_TICKET_ID) t
LEFT JOIN
    (
        SELECT
            PRODUCT_ID,
            ORDER_ID,
            ORDER_NO,
            SUM(NVL(CUT_AMOUNT, 0)) AS CUT_AMOUNT
        FROM
            JIKE.V_COUPON_INFO
        WHERE
            COUPON_TYPE = '0'
        GROUP BY
            PRODUCT_ID,
            ORDER_ID,
            ORDER_NO) v
ON
    t.PLANE_TICKET_ID = v.PRODUCT_ID
AND t.PLANE_ORDER_ID = v.ORDER_ID WITH READ ONLY
