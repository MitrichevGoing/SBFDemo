create view V_TRAIN_EQUAL_BILL as
SELECT
    'TRAIN'                 AS PRODUCT_TYPE,
    'TRAIN_REFUND'          AS PRODUCT_CODE,
    '火车票差额退款'               AS PRODUCT_NAME,
    A.TRAIN_REFUND_ID       AS PRODUCT_ID,
    ''                      AS PRODUCT_NO,
    A.TRAIN_REFUND_ID       AS ORDER_ID,
    A.TRAIN_REFUND_NO       AS ORDER_NO,
    to_number ('','999999') AS DEPT_ID,
    CAST('' AS VARCHAR(60)) AS DEPT_NAME,
    ''                      AS PASSENGER_NAME,
    C.DEPART_STATION||','||C.ARRIVE_STATION||','||TO_CHAR(C.DEPART_DATE,'YYYY-MM-DD hh24:mi:ss')||
    ','||TO_CHAR(C.ARRIVE_DATE,'YYYY-MM-DD hh24:mi:ss')||','||C.TRAIN_CODE||','||DECODE
    (C.SEAT_TYPE_CODE,'0','商务座','1','特等座','2','一等座','3','二等座','4','高级软卧','5','软卧','6','硬卧','7','软座'
    ,'8','硬座', '9','无座','其他')||',0,0' AS TRIP_DETAIL,
    NVL(B.FOR_PRIVATE, 0)             AS FOR_PRIVATE,
    A.IS_FILL_ORDER                   AS IS_FILL_ORDER,
    A.FILL_ORDER_TIME                 AS FILL_ORDER_TIME,
    to_number ('','999999')           AS COST_CENTER_ID,
    CAST('' AS VARCHAR(60))           AS COST_CENTER_NAME,
    A.COMPLETE_TIME                   AS APPLY_TIME,
    (
        SELECT
            NAME_CN
        FROM
            JIKE.T_BASE_USER
        WHERE
            USER_ID = A.APPLY_USER_ID) AS APPLY_USER,
    NVL(A.SALE_PRICE, 0)               AS SALE_PRICE,
    CASE A.STATE
        WHEN '3'
        THEN '0'
        WHEN '5'
        THEN '0'
        ELSE '1'
    END                       AS PUR_SETTLE_FLAG,
    NVL(A.PUR_SETTLE_TYPE, 2) AS PUR_SETTLE_TYPE,
    NVL(A.PUR_CHECK_STATE, 0) AS PUR_SETTLE_STATE,
    A.PUR_ID                  AS PUR_ID,
    '2'                       AS PUR_BILL_FLAG,
    NVL(A.FLOOR_PRICE, 0)     AS FLOOR_PRICE,
    CASE A.STATE
        WHEN '3'
        THEN '0'
        WHEN '5'
        THEN '0'
        ELSE '1'
    END      AS SUP_SETTLE_FLAG,
    A.SUP_ID AS SUP_ID,
    '1'      AS SUP_BILL_FLAG
FROM
    JIKE.T_CC_TRAIN_REFUND A
LEFT JOIN
    JIKE.T_CC_TRAIN_ORDER B
ON
    A.TRAIN_ORDER_ID = B.TRAIN_ORDER_ID
LEFT JOIN
    JIKE.T_CC_TRAIN_TRIP C
ON
    A.TRAIN_ORDER_ID = C.TRAIN_ORDER_ID
WHERE
    A.COMPLETE_REMARK = '差额退款' WITH READ ONLY
