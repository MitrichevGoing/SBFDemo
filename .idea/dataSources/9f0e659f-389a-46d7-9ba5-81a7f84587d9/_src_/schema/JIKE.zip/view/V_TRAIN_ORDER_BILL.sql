create view V_TRAIN_ORDER_BILL as
SELECT
    'TRAIN'                             AS PRODUCT_TYPE,
    'TRAIN_ORDER'                       AS PRODUCT_CODE,
    DECODE(B.STATE,'5','火车出票失败','火车订票') AS PRODUCT_NAME,
    A.TRAIN_TICKET_ID                   AS PRODUCT_ID,
    A.TRAIN_TICKET_NO                   AS PRODUCT_NO,
    A.TRAIN_ORDER_ID                    AS ORDER_ID,
    A.TRAIN_ORDER_NO                    AS ORDER_NO,
    E.DEPT_ID                           AS DEPT_ID,
    E.DEPT_NAME                         AS DEPT_NAME,
    A.IDC_NAME                          AS PASSENGER_NAME,
    C.DEPART_STATION||','||C.ARRIVE_STATION||','||TO_CHAR(C.DEPART_DATE,'YYYY-MM-DD hh24:mi:ss')||
    ','||TO_CHAR(C.ARRIVE_DATE,'YYYY-MM-DD hh24:mi:ss')||','||C.TRAIN_CODE||','||DECODE
    (C.SEAT_TYPE_CODE,'0','商务座','1','特等座','2','一等座','3','二等座','4','高级软卧','5','软卧','6','硬卧','7','软座'
    ,'8','硬座', '9','无座','其他')||','||NVL(A.FACE_PRICE, 0)||','||NVL(A.PUR_SERVICE_PRICE, 0) AS
                             TRIP_DETAIL,
    NVL(B.FOR_PRIVATE, 0) AS FOR_PRIVATE,
    B.IS_FILL_ORDER       AS IS_FILL_ORDER,
    B.FILL_ORDER_TIME     AS FILL_ORDER_TIME,
    A.COST_CENTER_ID      AS COST_CENTER_ID,
    F.COST_CENTER_NAME    AS COST_CENTER_NAME,
    B.CREATE_TIME         AS APPLY_TIME,
    (
        SELECT
            NAME_CN
        FROM
            JIKE.T_BASE_USER
        WHERE
            USER_ID = B.CREATE_USER_ID) AS APPLY_USER,
    CASE
        WHEN B.STATE = '5'
        AND B.PUR_SETTLE_TYPE = '1'
        THEN NVL(A.SALE_PRICE, 0) + NVL(G.SALE_PRICE, 0)
        ELSE NVL(A.SALE_PRICE, 0)
    END AS SALE_PRICE,
    CASE
        WHEN B.STATE = '4'
        OR  (B.STATE = '5'
            AND B.PUR_SETTLE_TYPE = '1')
        THEN '0'
        ELSE '1'
    END                                                 AS PUR_SETTLE_FLAG,
    NVL(A.PUR_SETTLE_TYPE, 2)                           AS PUR_SETTLE_TYPE,
    NVL(A.PUR_SETTLE_STATE, 0)                          AS PUR_SETTLE_STATE,
    A.PUR_ID                                            AS PUR_ID,
    '1'                                                 AS PUR_BILL_FLAG,
    NVL(A.FLOOR_PRICE, 0) - NVL(A.SUP_SERVICE_PRICE, 0) AS FLOOR_PRICE,
    CASE B.STATE
        WHEN '4'
        THEN '0'
        ELSE '1'
    END      AS SUP_SETTLE_FLAG,
    A.SUP_ID AS SUP_ID,
    '2'      AS SUP_BILL_FLAG
FROM
    JIKE.T_CC_TRAIN_TICKET A
LEFT JOIN
    JIKE.T_CC_TRAIN_ORDER B
ON
    A.TRAIN_ORDER_ID = B.TRAIN_ORDER_ID
LEFT JOIN
    JIKE.T_CC_TRAIN_TRIP C
ON
    A.TRAIN_ORDER_ID = C.TRAIN_ORDER_ID
LEFT JOIN
    JIKE.T_BASE_USER D
ON
    (
        A.PAX_ID IS NOT NULL
    AND A.PAX_SOURCE = '1'
    AND A.PAX_ID = D.USER_ID)
LEFT JOIN
    JIKE.T_BASE_DEPARTMENT E
ON
    D.DEPT_ID = E.DEPT_ID
LEFT JOIN
    JIKE.T_BASE_COST_CENTER F
ON
    A.COST_CENTER_ID = F.COST_CENTER_ID
LEFT JOIN
    JIKE.V_CC_INSURANCE_ORDER G
ON
    A.TRAIN_TICKET_ID = G.PLANE_TICKET_ID
AND A.TRAIN_ORDER_ID = G.PLANE_ORDER_ID WITH READ ONLY
