create view V_FLOW_PLANE_REFUND as
SELECT
    'PLANE'                           AS PRODUCT_TYPE,
    'PLANE_REFUND'                    AS PRODUCT_CODE,
    '国内退票'                            AS PRODUCT_NAME,
    ''                                AS PRODUCT_DESC,
    A.PLANE_TICKET_ID                 AS PRODUCT_ID,
    A.PLANE_TICKET_NO                 AS PRODUCT_NO,
    B.REFUND_ID                       AS ORDER_ID,
    B.REFUND_NO                       AS ORDER_NO,
    DECODE(C.PAX_SOURCE,'1',C.PAX_ID) AS USER_ID,
    C.IDC_NO                          AS PASSENGER_RELATION_ID,
    C.IDC_NAME                        AS PASSENGER_NAME,
    C.PLANE_ORDER_ID                  AS ORDER_RELATION_ID,
    C.PLANE_ORDER_NO                  AS ORDER_RELATION_NO,
    'PLANE_ORDER'                     AS ORDER_RELATION_CODE,
    B.REFUND_NO                       AS PAY_RELATION_NO,
    D.DETAIL                          AS TRIP_DETAIL,
    NVL(B.FOR_PRIVATE, 0)             AS FOR_PRIVATE,
    B.IS_FILL_ORDER                   AS IS_FILL_ORDER,
    B.FILL_ORDER_TIME                 AS FILL_ORDER_TIME,
    B.COST_CENTER_ID,
    B.APPLY_TIME                        AS APPLY_TIME,
    B.APPLY_USER                        AS APPLY_USER,
    B.COMPLETE_TIME                     AS CONFIRM_TIME,
    B.COMPLETE_EMPLOYEE                 AS CONFIRM_EMPLOYEE,
    NVL(A.SALE_PRICE, 0)                AS SALE_PRICE,
    DECODE(B.STATE,'3','0','5','0','1') AS PUR_SETTLE_FLAG,
    B.PUR_ID                            AS PUR_ID,
    '2'                                 AS PUR_BILL_FLAG,
    B.PUR_BANK_NO                       AS PUR_BANK_NO,
    B.PUR_BILL_NO                       AS PUR_BILL_NO,
    B.PUR_PAY_TYPE                      AS PUR_PAY_TYPE,
    B.PUR_REFUND_TIME                   AS PUR_PAY_TIME,
    NVL(B.PUR_SETTLE_TYPE, 2)           AS PUR_SETTLE_TYPE,
    NVL(B.PUR_CHECK_STATE, 0)           AS PUR_SETTLE_STATE,
    B.PUR_CHECK_EMPLOYEE                AS PUR_SETTLE_EMPLOYEE,
    B.PUR_CHECK_TIME                    AS PUR_SETTLE_TIME,
    NVL(A.FLOOR_PRICE, 0)               AS FLOOR_PRICE,
    DECODE(B.STATE,'3','0','5','0','1') AS SUP_SETTLE_FLAG,
    B.SUP_ID                            AS SUP_ID,
    '1'                                 AS SUP_BILL_FLAG,
    B.SUP_ORDER_NO                      AS SUP_ORDER_NO,
    B.SUP_BANK_NO                       AS SUP_BANK_NO,
    B.SUP_BILL_NO                       AS SUP_BILL_NO,
    B.SUP_PAY_TYPE                      AS SUP_PAY_TYPE,
    B.SUP_REFUND_TIME                   AS SUP_PAY_TIME,
    NVL(B.SUP_SETTLE_TYPE, 1)           AS SUP_SETTLE_TYPE,
    NVL(B.SUP_CHECK_STATE, 0)           AS SUP_SETTLE_STATE,
    B.SUP_CHECK_EMPLOYEE                AS SUP_SETTLE_EMPLOYEE,
    B.SUP_CHECK_TIME                    AS SUP_SETTLE_TIME
FROM
    JIKE.T_CC_REFUND_TICKET A
LEFT JOIN
    JIKE.T_CC_PLANE_REFUND B
ON
    A.REFUND_ID = B.REFUND_ID
LEFT JOIN
    JIKE.T_CC_TICKET_PASSENGER C
ON
    A.PLANE_TICKET_ID = C.PLANE_TICKET_ID
LEFT JOIN
    (
        SELECT
            REFUND_ID,
            listagg(DETAIL,'#') within GROUP (ORDER BY X.PLANE_OD_ID) DETAIL
        FROM
            JIKE.T_CC_PLANE_REFUND_OD X
        LEFT JOIN
            JIKE.V_PLANE_OD_TRIP Y
        ON
            X.PLANE_OD_ID = Y.PLANE_OD_ID
        GROUP BY
            REFUND_ID) D
ON
    A.REFUND_ID = D.REFUND_ID WITH READ ONLY
