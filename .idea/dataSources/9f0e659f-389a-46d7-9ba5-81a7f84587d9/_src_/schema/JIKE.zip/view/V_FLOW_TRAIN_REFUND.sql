create view V_FLOW_TRAIN_REFUND as
SELECT
    'TRAIN'                              AS PRODUCT_TYPE,
    'TRAIN_REFUND'                       AS PRODUCT_CODE,
    '火车退票'                               AS PRODUCT_NAME,
    ''                                   AS PRODUCT_DESC,
    A.TRAIN_TICKET_ID                    AS PRODUCT_ID,
    A.TRAIN_TICKET_NO                    AS PRODUCT_NO,
    B.TRAIN_REFUND_ID                    AS ORDER_ID,
    B.TRAIN_REFUND_NO                    AS ORDER_NO,
    DECODE(C.PAX_SOURCE,'1',C.PAX_ID,'') AS USER_ID,
    C.IDC_NO                             AS PASSENGER_RELATION_ID,
    C.IDC_NAME                           AS PASSENGER_NAME,
    C.TRAIN_ORDER_ID                     AS ORDER_RELATION_ID,
    C.TRAIN_ORDER_NO                     AS ORDER_RELATION_NO,
    'TRAIN_ORDER'                        AS ORDER_RELATION_CODE,
    B.TRAIN_REFUND_NO                    AS PAY_RELATION_NO,
    D.DEPART_STATION||','||D.ARRIVE_STATION||','||TO_CHAR(D.DEPART_DATE,'YYYY-MM-DD hh24:mi:ss')||
    ','||TO_CHAR(D.ARRIVE_DATE,'YYYY-MM-DD hh24:mi:ss')||','||D.TRAIN_CODE||','||DECODE
    (D.SEAT_TYPE_CODE,'0','商务座','1','特等座','2','一等座','3','二等座','4','高级软卧','5','软卧','6','硬卧','7','软座'
    ,'8','硬座', '9','无座','其他')||','||NVL(C.FACE_PRICE, 0)||','||(NVL(C.FACE_PRICE, 0) - NVL(A.SALE_PRICE, 0)) AS
                             TRIP_DETAIL,
    NVL(B.FOR_PRIVATE, 0) AS FOR_PRIVATE,
    B.IS_FILL_ORDER       AS IS_FILL_ORDER,
    B.FILL_ORDER_TIME     AS FILL_ORDER_TIME,
    B.COST_CENTER_ID,
    B.APPLY_TIME                        AS APPLY_TIME,
    B.APPLY_USER_ID                     AS APPLY_USER,
    B.COMPLETE_TIME                     AS CONFIRM_TIME,
    NVL(B.COMPLETE_EMPLOYEE_ID, 0)      AS CONFIRM_EMPLOYEE,
    NVL(A.SALE_PRICE, 0)                AS SALE_PRICE,
    DECODE(B.STATE,'3','0','5','0','1') AS PUR_SETTLE_FLAG,
    B.PUR_ID                            AS PUR_ID,
    '2'                                 AS PUR_BILL_FLAG,
    B.PUR_BANK_NO                       AS PUR_BANK_NO,
    B.PUR_TRADE_NO                      AS PUR_BILL_NO,
    B.PUR_PAY_TYPE                      AS PUR_PAY_TYPE,
    B.PUR_REFUND_TIME                   AS PUR_PAY_TIME,
    NVL(B.PUR_SETTLE_TYPE, 2)           AS PUR_SETTLE_TYPE,
    NVL(B.PUR_CHECK_STATE, 0)           AS PUR_SETTLE_STATE,
    B.PUR_CHECK_EMPLOYEE_ID             AS PUR_SETTLE_EMPLOYEE,
    B.PUR_CHECK_TIME                    AS PUR_SETTLE_TIME,
    NVL(A.FLOOR_PRICE, 0)               AS FLOOR_PRICE,
    DECODE(B.STATE,'3','0','5','0','1') AS SUP_SETTLE_FLAG,
    B.SUP_ID                            AS SUP_ID,
    '1'                                 AS SUP_BILL_FLAG,
    B.SUP_ORDER_NO                      AS SUP_ORDER_NO,
    B.SUP_BANK_NO                       AS SUP_BANK_NO,
    B.SUP_BILL_NO                       AS SUP_BILL_NO,
    B.SUP_PAY_TYPE                      AS SUP_PAY_TYPE,
    B.SUP_REFUND_TIME                   AS SUP_PAY_TIME,
    NVL(B.SUP_SETTLE_TYPE, 1)           AS SUP_SETTLE_TYPE,
    NVL(B.SUP_CHECK_STATE, 0)           AS SUP_SETTLE_STATE,
    B.SUP_CHECK_EMPLOYEE_ID             AS SUP_SETTLE_EMPLOYEE,
    B.SUP_CHECK_TIME                    AS SUP_SETTLE_TIME
FROM
    JIKE.T_CC_TRAIN_REFUND_TICKET A
LEFT JOIN
    JIKE.T_CC_TRAIN_REFUND B
ON
    A.TRAIN_REFUND_ID = B.TRAIN_REFUND_ID
LEFT JOIN
    JIKE.T_CC_TRAIN_TICKET C
ON
    A.TRAIN_TICKET_ID = C.TRAIN_TICKET_ID
LEFT JOIN
    JIKE.T_CC_TRAIN_TRIP D
ON
    B.TRAIN_ORDER_ID = D.TRAIN_ORDER_ID WITH READ ONLY
