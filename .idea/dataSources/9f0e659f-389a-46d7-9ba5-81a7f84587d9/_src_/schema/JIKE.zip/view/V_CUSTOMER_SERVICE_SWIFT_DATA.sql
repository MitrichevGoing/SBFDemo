create view V_CUSTOMER_SERVICE_SWIFT_DATA as
(SELECT  'PLANE'                                        AS SWIFT_TYPE,
         'PLANE_ORDER'                                  AS SWIFT_CODE,
          NVL(PO.SALE_PRICE,0)                          AS SALE_PRICE,
          PO.COMPANY_ID                                 AS COMPANY_ID,
          PO.CREATE_EMPLOYEE                            AS APPLY_EMPLOYEE,
          PO.CREATE_TIME                                AS APPLY_TIME,
          PO.PLANE_ORDER_ID                             AS ORDER_ID,
          PO.PLANE_ORDER_NO                             AS ORDER_NO,
          '1'                                           AS PUR_BILL_FLAG
    FROM JIKE.T_CC_PLANE_ORDER PO WHERE STATE='4')

UNION ALL
(SELECT  'PLANE'                                        AS SWIFT_TYPE,
         'PLANE_CHANGE'                                 AS SWIFT_CODE,
          NVL(PC.SALE_PRICE,0)                          AS SALE_PRICE,
          PC.COMPANY_ID                                 AS COMPANY_ID,
          PC.APPLY_EMPLOYEE                             AS APPLY_EMPLOYEE,
          PC.APPLY_TIME                                 AS APPLY_TIME,
          PC.CHANGE_ID                                  AS ORDER_ID,
          PC.CHANGE_NO                                  AS ORDER_NO,
          '1'                                           AS PUR_BILL_FLAG
    FROM JIKE.T_CC_PLANE_CHANGE PC WHERE STATE='3')

UNION ALL
(SELECT   'PLANE'                                       AS SWIFT_TYPE,
          'PLANE_REFUND'                                AS SWIFT_CODE,
           NVL(PR.SALE_PRICE,0)                         AS SALE_PRICE,
           PR.COMPANY_ID                                AS COMPANY_ID,
           PR.APPLY_EMPLOYEE                            AS APPLY_EMPLOYEE,
           PR.APPLY_TIME                                AS APPLY_TIME,
           PR.REFUND_ID                                 AS ORDER_ID,
           PR.REFUND_NO                                 AS ORDER_NO,
          '2'                                           AS PUR_BILL_FLAG
    FROM JIKE.T_CC_PLANE_REFUND PR WHERE STATE='3' OR STATE='5')
UNION ALL
(SELECT  'PLANE'                                        AS SWIFT_TYPE,
         'PLANE_ORDER'                                  AS SWIFT_CODE,
          NVL(IPO.SALE_PRICE,0)                         AS SALE_PRICE,
          IPO.COMPANY_ID                                AS COMPANY_ID,
          IPO.CREATE_EMPLOYEE                           AS APPLY_EMPLOYEE,
          IPO.CREATE_TIME                               AS APPLY_TIME,
          IPO.PLANE_ORDER_ID                            AS ORDER_ID,
          IPO.PLANE_ORDER_NO                            AS ORDER_NO,
          '1'                                           AS PUR_BILL_FLAG
    FROM JIKE.T_CC_INTER_PLANE_ORDER IPO WHERE STATE='4')

UNION ALL
(SELECT  'PLANE'                                        AS SWIFT_TYPE,
         'PLANE_CHANGE'                                 AS SWIFT_CODE,
          NVL(IPC.SALE_PRICE,0)                         AS SALE_PRICE,
          IPC.COMPANY_ID                                AS COMPANY_ID,
          IPC.APPLY_EMPLOYEE                            AS APPLY_EMPLOYEE,
          IPC.APPLY_TIME                                AS APPLY_TIME,
          IPC.CHANGE_ID                                 AS ORDER_ID,
          IPC.CHANGE_NO                                 AS ORDER_NO,
          '1'                                           AS PUR_BILL_FLAG
    FROM JIKE.T_CC_INTER_PLANE_CHANGE IPC WHERE STATE='3')

UNION ALL
(SELECT   'PLANE'                                       AS SWIFT_TYPE,
          'PLANE_REFUND'                                AS SWIFT_CODE,
           NVL(IPR.SALE_PRICE,0)                        AS SALE_PRICE,
           IPR.COMPANY_ID                               AS COMPANY_ID,
           IPR.APPLY_EMPLOYEE                           AS APPLY_EMPLOYEE,
           IPR.APPLY_TIME                               AS APPLY_TIME,
           IPR.REFUND_ID                                AS ORDER_ID,
           IPR.REFUND_NO                                AS ORDER_NO,
          '2'                                           AS PUR_BILL_FLAG
    FROM JIKE.T_CC_INTER_PLANE_REFUND IPR WHERE STATE='3' OR STATE='5')

UNION ALL
(SELECT    'HOTEL'                                      AS SWIFT_TYPE,
           'HOTEL_ORDER'                                AS SWIFT_CODE,
            NVL(HO.SALE_PRICE,0)                        AS SALE_PRICE,
            HO.COMPANY_ID                               AS COMPANY_ID,
            HO.CREATE_EMPLOYEE                          AS APPLY_EMPLOYEE,
            HO.CREATE_TIME                              AS APPLY_TIME,
            HO.HOTEL_ORDER_ID                           AS ORDER_ID,
            HO.HOTEL_ORDER_NO                           AS ORDER_NO,
           '1'                                          AS PUR_BILL_FLAG
    FROM JIKE.T_CH_HOTEL_ORDER_V2 HO WHERE HO.PAYMENT_TYPE = 'PrePay' AND HO.STATE = '3')

UNION ALL

(SELECT    'HOTEL'                                      AS SWIFT_TYPE,
           'HOTEL_REFUND'                               AS SWIFT_CODE,
            NVL(HOR.SALE_PRICE,0)                       AS SALE_PRICE,
            HOR.COMPANY_ID                              AS COMPANY_ID,
            HOR.APPLY_EMPLOYEE                          AS APPLY_EMPLOYEE,
            HOR.APPLY_TIME                              AS APPLY_TIME,
            HOR.HOTEL_REFUND_ID                         AS ORDER_ID,
            HOR.HOTEL_REFUND_NO                         AS ORDER_NO,
           '2'                                          AS PUR_BILL_FLAG

    FROM JIKE.T_CH_HOTEL_ORDER_REFUND_V2 HOR WHERE HOR.PAYMENT_TYPE = 'PrePay' AND HOR.STATE = '3')
UNION ALL
(SELECT    'TRAIN'                                      AS SWIFT_TYPE,
           'TRAIN_ORDER'                                AS SWIFT_CODE,
            NVL(TOO.SALE_PRICE,0)                       AS SALE_PRICE,
            TOO.COMPANY_ID                              AS COMPANY_ID,
            TOO.CREATE_EMPLOYEE_ID                      AS APPLY_EMPLOYEE,
            TOO.CREATE_TIME                             AS APPLY_TIME,
            TOO.TRAIN_ORDER_ID                          AS ORDER_ID,
            TOO.TRAIN_ORDER_NO                          AS ORDER_NO,
           '1'                                          AS PUR_BILL_FLAG
    FROM JIKE.T_CC_TRAIN_ORDER TOO WHERE STATE='4')

UNION ALL
(SELECT    'TRAIN'                                      AS SWIFT_TYPE,
           'TRAIN_CHANGE'                               AS SWIFT_CODE,
            NVL(TC.SALE_PRICE,0)                        AS SALE_PRICE,
            TC.COMPANY_ID                               AS COMPANY_ID,
            TC.APPLY_EMPLOYEE                           AS APPLY_EMPLOYEE,
            TC.APPLY_TIME                               AS APPLY_TIME,
            TC.TRAIN_ORDER_ID                           AS ORDER_ID,
            TC.TRAIN_ORDER_NO                           AS ORDER_NO,
           '1'                                          AS PUR_BILL_FLAG
    FROM JIKE.T_CC_TRAIN_CHANGE TC WHERE STATE='3')

UNION ALL
(SELECT    'TRAIN'                                      AS SWIFT_TYPE,
           'TRAIN_REFUND'                               AS SWIFT_CODE,
            NVL(TR.SALE_PRICE,0)                        AS SALE_PRICE,
            TR.COMPANY_ID                               AS COMPANY_ID,
            TR.APPLY_EMPLOYEE_ID                        AS APPLY_EMPLOYEE,
            TR.APPLY_TIME                               AS APPLY_TIME,
            TR.TRAIN_REFUND_ID                          AS ORDER_ID,
            TR.TRAIN_REFUND_NO                          AS ORDER_NO,
           '2'                                          AS PUR_BILL_FLAG

    FROM JIKE.T_CC_TRAIN_REFUND TR WHERE STATE='3' OR STATE='5')

WITH READ ONLY

