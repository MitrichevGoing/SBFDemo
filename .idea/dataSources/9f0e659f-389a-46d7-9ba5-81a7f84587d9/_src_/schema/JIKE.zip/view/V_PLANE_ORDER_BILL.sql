create view V_PLANE_ORDER_BILL as
SELECT
    'PLANE'                             AS PRODUCT_TYPE,
    'PLANE_ORDER'                       AS PRODUCT_CODE,
    DECODE(B.STATE,'5','国内出票失败','国内机票') AS PRODUCT_NAME,
    A.PLANE_TICKET_ID                   AS PRODUCT_ID,
    A.PLANE_TICKET_NO                   AS PRODUCT_NO,
    A.PLANE_ORDER_ID                    AS ORDER_ID,
    A.PLANE_ORDER_NO                    AS ORDER_NO,
    D.DEPT_ID                           AS DEPT_ID,
    D.DEPT_NAME                         AS DEPT_NAME,
    A.IDC_NAME                          AS PASSENGER_NAME,
    F.DETAIL                            AS TRIP_DETAIL,
    NVL(B.FOR_PRIVATE, 0)               AS FOR_PRIVATE,
    B.IS_FILL_ORDER                     AS IS_FILL_ORDER,
    B.FILL_ORDER_TIME                   AS FILL_ORDER_TIME,
    A.COST_CENTER_ID                    AS COST_CENTER_ID,
    E.COST_CENTER_NAME                  AS COST_CENTER_NAME,
    B.CREATE_TIME                       AS APPLY_TIME,
    (
        SELECT
            NAME_CN
        FROM
            JIKE.T_BASE_USER
        WHERE
            USER_ID = B.CREATE_USER) AS APPLY_USER,
    CASE
        WHEN B.STATE = '5'
        AND B.PUR_SETTLE_TYPE = '1'
        THEN NVL(A.SALE_PRICE, 0) + NVL(G.SALE_PRICE, 0)
        ELSE NVL(A.SALE_PRICE, 0)
    END AS SALE_PRICE,
    CASE
        WHEN B.STATE = '4'
        OR  (B.STATE = '5'
            AND B.PUR_SETTLE_TYPE = '1')
        THEN '0'
        ELSE '1'
    END                        AS PUR_SETTLE_FLAG,
    NVL(A.PUR_SETTLE_TYPE, 2)  AS PUR_SETTLE_TYPE,
    NVL(A.PUR_SETTLE_STATE, 0) AS PUR_SETTLE_STATE,
    A.PUR_ID                   AS PUR_ID,
    '1'                        AS PUR_BILL_FLAG,
    NVL(A.FLOOR_PRICE, 0)      AS FLOOR_PRICE,
    CASE B.STATE
        WHEN '4'
        THEN '0'
        ELSE '1'
    END      AS SUP_SETTLE_FLAG,
    A.SUP_ID AS SUP_ID,
    '2'      AS SUP_BILL_FLAG
FROM
    JIKE.T_CC_TICKET_PASSENGER A
LEFT JOIN
    JIKE.T_CC_PLANE_ORDER B
ON
    A.PLANE_ORDER_ID = B.PLANE_ORDER_ID
LEFT JOIN
    JIKE.T_BASE_USER C
ON
    (
        A.PAX_ID IS NOT NULL
    AND A.PAX_SOURCE = '1'
    AND A.PAX_ID = C.USER_ID)
LEFT JOIN
    JIKE.T_BASE_DEPARTMENT D
ON
    C.DEPT_ID = D.DEPT_ID
LEFT JOIN
    JIKE.T_BASE_COST_CENTER E
ON
    A.COST_CENTER_ID = E.COST_CENTER_ID
LEFT JOIN
    (
        SELECT
            PLANE_TICKET_ID,
            listagg(DETAIL,'#') within GROUP (ORDER BY X.PLANE_OD_ID) DETAIL
        FROM
            JIKE.T_CC_TICKET_OD X
        LEFT JOIN
            JIKE.V_PLANE_OD_TRIP Y
        ON
            X.PLANE_OD_ID = Y.PLANE_OD_ID
        GROUP BY
            PLANE_TICKET_ID) F
ON
    A.PLANE_TICKET_ID = F.PLANE_TICKET_ID
LEFT JOIN
    JIKE.V_CC_INSURANCE_ORDER G
ON
    A.PLANE_TICKET_ID = G.PLANE_TICKET_ID
AND A.PLANE_ORDER_ID = G.PLANE_ORDER_ID
WHERE
    A.PREV_PLANE_TICKET_ID IS NULL WITH READ ONLY
