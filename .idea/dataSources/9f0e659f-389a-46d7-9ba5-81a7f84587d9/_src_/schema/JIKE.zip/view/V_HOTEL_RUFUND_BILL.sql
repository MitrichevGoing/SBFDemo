create view V_HOTEL_RUFUND_BILL as
SELECT
    'HOTEL'                     AS PRODUCT_TYPE,
    'HOTEL_REFUND'              AS PRODUCT_CODE,
    '酒店退单'                      AS PRODUCT_NAME,
    B.PRODUCT_ID                AS PRODUCT_ID,
    CAST('' AS VARCHAR(20))     AS PRODUCT_NO,
    A.REFUND_ID                 AS ORDER_ID,
    A.AFFILIATE_CONFIRMATION_ID AS ORDER_NO,
    B.DEPT_ID                   AS DEPT_ID,
    B.DEPT_NAME                 AS DEPT_NAME,
    B.PASSENGER_NAME            AS PASSENGER_NAME,
    B.TRIP_DETAIL               AS TRIP_DETAIL,
    B.FOR_PRIVATE               AS FOR_PRIVATE,
    A.IS_FILL_ORDER             AS IS_FILL_ORDER,
    A.FILL_ORDER_TIME           AS FILL_ORDER_TIME,
    B.COST_CENTER_ID            AS COST_CENTER_ID,
    B.COST_CENTER_NAME          AS COST_CENTER_NAME,
    A.APPLY_TIME                AS APPLY_TIME,
    (
        SELECT
            NAME_CN
        FROM
            JIKE.T_BASE_USER
        WHERE
            USER_ID = A.APPLY_USER) AS APPLY_USER,
    A.SALE_PRICE                    AS SALE_PRICE,
    '0'                             AS PUR_SETTLE_FLAG,
    NVL(A.PUR_SETTLE_TYPE, 2)       AS PUR_SETTLE_TYPE,
    NVL(A.PUR_CHECK_STATE, 0)       AS PUR_SETTLE_STATE,
    A.PUR_ID                        AS PUR_ID,
    '2'                             AS PUR_BILL_FLAG,
    A.FLOOR_PRICE                   AS FLOOR_PRICE,
    '0'                             AS SUP_SETTLE_FLAG,
    A.SUP_ID                        AS SUP_ID,
    '1'                             AS SUP_BILL_FLAG
FROM
    JIKE.T_CH_HOTEL_REFUND A
LEFT JOIN
    JIKE.V_HOTEL_ORDER_BILL B
ON
    A.AFFILIATE_CONFIRMATION_ID = B.ORDER_NO WITH READ ONLY
