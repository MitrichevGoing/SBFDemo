create view V_HOTEL_ORDER_BILL as
SELECT
    'HOTEL'                                           AS PRODUCT_TYPE,
    'HOTEL_ORDER'                                     AS PRODUCT_CODE,
    '酒店订单'                                            AS PRODUCT_NAME,
    A.RATE_PLAN_ID                                    AS PRODUCT_ID,
    CAST('' AS VARCHAR(20))                           AS PRODUCT_NO,
    to_number(SUBSTR(A.AFFILIATE_CONFIRMATION_ID, 3)) AS ORDER_ID,
    A.AFFILIATE_CONFIRMATION_ID                       AS ORDER_NO,
    to_number ('')                                    AS DEPT_ID,
    CAST('' AS VARCHAR(60))                           AS DEPT_NAME,
    B.PASSENGER_NAME                                  AS PASSENGER_NAME,
    TO_CHAR(A.ARRIVAL_DATE,'YYYY-MM-DD hh24:mi:ss')||','||TO_CHAR(A.DEPARTURE_DATE,
    'YYYY-MM-DD hh24:mi:ss')||','||A.HOTEL_NAME AS TRIP_DETAIL,
    NVL(A.FOR_PRIVATE, 0)                       AS FOR_PRIVATE,
    A.IS_FILL_ORDER                             AS IS_FILL_ORDER,
    A.FILL_ORDER_TIME                           AS FILL_ORDER_TIME,
    to_number ('','999999')                     AS COST_CENTER_ID,
    CAST('' AS VARCHAR(60))                     AS COST_CENTER_NAME,
    A.CREATE_TIME                               AS APPLY_TIME,
    (
        SELECT
            NAME_CN
        FROM
            JIKE.T_BASE_USER
        WHERE
            USER_ID = A.CREATE_USER) AS APPLY_USER,
    NVL(A.SALE_TOTAL_PRICE, 0)       AS SALE_PRICE,
    CASE
        WHEN A.ORDER_TYPE = '2'
        AND ( A.LOCAL_STATUS = '1'
            OR  A.LOCAL_STATUS = '3'
            OR  ( A.LOCAL_STATUS = '4'
                AND A.PUR_PAY_STATE = '1' ) )
        THEN '0'
        ELSE '1'
    END                       AS PUR_SETTLE_FLAG,
    NVL(A.PUR_SETTLE_TYPE, 2) AS PUR_SETTLE_TYPE,
    NVL(A.PUR_CHECK_STATE, 0) AS PUR_SETTLE_STATE,
    A.PUR_ID                  AS PUR_ID,
    '1'                       AS PUR_BILL_FLAG,
    NVL(A.TOTAL_PRICE, 0)     AS FLOOR_PRICE,
    CASE
        WHEN A.ORDER_TYPE = '2'
        AND ( A.LOCAL_STATUS = '1'
            OR  A.LOCAL_STATUS = '3' )
        THEN '0'
        ELSE '1'
    END      AS SUP_SETTLE_FLAG,
    A.SUP_ID AS SUP_ID,
    '2'      AS SUP_BILL_FLAG
FROM
    JIKE.T_CH_HOTEL_ORDER A
LEFT JOIN
    (
        SELECT
            AFFILIATE_CONFIRMATION_ID                                          AS HOTEL_ORDER_NO,
            listagg(PASSENGER_NAME,',') within GROUP (ORDER BY PASSENGER_NAME) AS PASSENGER_NAME
        FROM
            (
                SELECT
                    T.*,
                    CASE NVL(T.IS_USER, 0)
                        WHEN 0
                        THEN
                            (
                                SELECT
                                    DECODE(NAME,NULL,LAST_NAME||'/'||FIRST_NAME,NAME)
                                FROM
                                    T_BASE_GENERAL_CONTACT
                                WHERE
                                    CONTACT_ID = T.FRE_ID)
                        ELSE
                              (
                              SELECT
                                  NAME_CN
                              FROM
                                  JIKE.T_BASE_USER
                              WHERE
                                  USER_ID = T.FRE_ID)
                    END AS PASSENGER_NAME
                FROM
                    JIKE.T_CH_ORDER_CUSTOMER T)
        GROUP BY
            AFFILIATE_CONFIRMATION_ID) B
ON
    A.AFFILIATE_CONFIRMATION_ID = B.HOTEL_ORDER_NO WITH READ ONLY
