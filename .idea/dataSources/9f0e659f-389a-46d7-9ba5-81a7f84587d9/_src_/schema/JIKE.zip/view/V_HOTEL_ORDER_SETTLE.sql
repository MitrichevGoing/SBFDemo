create view V_HOTEL_ORDER_SETTLE as
SELECT
    'HOTEL_ORDER'                       AS PRODUCT_CODE,
    DECODE(B.STATE,'2','酒店确认失败','酒店订单') AS PRODUCT_NAME,
    ''                                  AS PRODUCT_DESC,
    A.PRODUCT_ID,
    A.PRODUCT_NO,
    A.ORDER_ID,
    A.ORDER_NO,
    CAST('' AS VARCHAR(20)) AS PASSENGER_RELATION_ID,
    C.PASSENGER_NAME        AS PASSENGER_NAME,
    B.HOTEL_ORDER_ID        AS ORDER_RELATION_ID,
    B.HOTEL_ORDER_NO        AS ORDER_RELATION_NO,
    'HOTEL_ORDER'           AS ORDER_RELATION_CODE,
    B.HOTEL_ORDER_NO        AS PAY_RELATION_NO,
    NVL(B.FOR_PRIVATE, 0)   AS FOR_PRIVATE,
    B.IS_FILL_ORDER,
    B.FILL_ORDER_TIME,
    B.COMPANY_ID,
    A.COST_CENTER_ID,
    B.CREATE_TIME       AS APPLY_TIME,
    B.COMPLETE_TIME     AS CONFIRM_TIME,
    B.COMPLETE_EMPLOYEE AS CONFIRM_EMPLOYEE,
    A.SALE_PRICE,
    CASE
        WHEN B.PAYMENT_TYPE = 'PrePay'
        AND (B.STATE = '3'
            OR  (B.STATE = '2'
                AND B.PUR_SETTLE_TYPE = '1'))
        THEN '0'
        ELSE '1'
    END AS PUR_SETTLE_FLAG,
    A.PUR_ID,
    A.PUR_BILL_FLAG,
    A.PUR_BANK_NO,
    A.PUR_BILL_NO,
    A.PUR_PAY_TYPE,
    A.PUR_PAY_TIME,
    A.PUR_SETTLE_TYPE,
    A.PUR_SETTLE_STATE,
    A.PUR_SETTLE_EMPLOYEE,
    A.PUR_SETTLE_TIME,
    A.FLOOR_PRICE,
    CASE
        WHEN B.PAYMENT_TYPE = 'PrePay'
        AND B.STATE = '3'
        THEN '0'
        ELSE '1'
    END AS SUP_SETTLE_FLAG,
    A.SUP_ID,
    A.SUP_BILL_FLAG,
    B.SOURCE_ORDER_NO AS SUP_ORDER_NO,
    A.SUP_BANK_NO,
    A.SUP_BILL_NO,
    A.SUP_PAY_TYPE,
    A.SUP_PAY_TIME,
    A.SUP_SETTLE_TYPE,
    A.SUP_SETTLE_STATE,
    A.SUP_SETTLE_EMPLOYEE,
    A.SUP_SETTLE_TIME
FROM
    (
        SELECT
            T.ORDER_ROOM_ID         AS PRODUCT_ID,
            CAST('' AS VARCHAR(20)) AS PRODUCT_NO,
            T.HOTEL_ORDER_ID        AS ORDER_ID,
            T.HOTEL_ORDER_NO        AS ORDER_NO,
            T.COST_CENTER_ID,
            SUM(NVL(T.SALE_PRICE, 0)) AS SALE_PRICE,
            T.PUR_ID,
            '1' AS PUR_BILL_FLAG,
            T.PUR_BANK_NO,
            T.PUR_BILL_NO,
            T.PUR_PAY_TYPE,
            T.PUR_PAY_TIME,
            NVL(T.PUR_SETTLE_TYPE, 2)  AS PUR_SETTLE_TYPE,
            NVL(T.PUR_SETTLE_STATE, 0) AS PUR_SETTLE_STATE,
            T.PUR_SETTLE_EMPLOYEE,
            T.PUR_SETTLE_TIME,
            SUM(NVL(T.FLOOR_PRICE, 0)) AS FLOOR_PRICE,
            T.SUP_ID,
            '2' AS SUP_BILL_FLAG,
            T.SUP_BANK_NO,
            T.SUP_BILL_NO,
            T.SUP_PAY_TYPE,
            T.SUP_PAY_TIME,
            NVL(T.SUP_SETTLE_TYPE, 1)  AS SUP_SETTLE_TYPE,
            NVL(T.SUP_SETTLE_STATE, 0) AS SUP_SETTLE_STATE,
            T.SUP_SETTLE_EMPLOYEE,
            T.SUP_SETTLE_TIME
        FROM
            T_CH_ROOM_NIGHTLY_RATE_V2 T
        GROUP BY
            T.ORDER_ROOM_ID,
            T.HOTEL_ORDER_ID,
            T.HOTEL_ORDER_NO,
            T.COST_CENTER_ID,
            T.PUR_ID,
            T.PUR_BANK_NO,
            T.PUR_BILL_NO,
            T.PUR_PAY_TYPE,
            T.PUR_PAY_TIME,
            T.PUR_SETTLE_TYPE,
            T.PUR_SETTLE_STATE,
            T.PUR_SETTLE_EMPLOYEE,
            T.PUR_SETTLE_TIME,
            T.SUP_ID,
            T.SUP_BANK_NO,
            T.SUP_BILL_NO,
            T.SUP_PAY_TYPE,
            T.SUP_PAY_TIME,
            T.SUP_SETTLE_TYPE,
            T.SUP_SETTLE_STATE,
            T.SUP_SETTLE_EMPLOYEE,
            T.SUP_SETTLE_TIME) A
LEFT JOIN
    JIKE.T_CH_HOTEL_ORDER_V2 B
ON
    A.ORDER_ID = B.HOTEL_ORDER_ID
LEFT JOIN
    (
        SELECT
            T.ORDER_ROOM_ID,
            listagg(T.CUSTOMER_NAME,',') WITHIN GROUP (ORDER BY T.ID) PASSENGER_NAME
        FROM
            JIKE.T_CH_HOTEL_ORDER_CUSTOMER_V2 T
        GROUP BY
            T.ORDER_ROOM_ID) C
ON
    A.PRODUCT_ID = C.ORDER_ROOM_ID WITH READ ONLY
