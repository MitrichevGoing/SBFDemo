create view V_FLOW_PLANE_ORDER as
SELECT
    'PLANE'                             AS PRODUCT_TYPE,
    'PLANE_ORDER'                       AS PRODUCT_CODE,
    DECODE(B.STATE,'5','国内出票失败','国内机票') AS PRODUCT_NAME,
    ''                                  AS PRODUCT_DESC,
    A.PLANE_TICKET_ID                   AS PRODUCT_ID,
    A.PLANE_TICKET_NO                   AS PRODUCT_NO,
    B.PLANE_ORDER_ID                    AS ORDER_ID,
    B.PLANE_ORDER_NO                    AS ORDER_NO,
    DECODE(A.PAX_SOURCE,'1',A.PAX_ID)   AS USER_ID,
    A.IDC_NO                            AS PASSENGER_RELATION_ID,
    A.IDC_NAME                          AS PASSENGER_NAME,
    A.PLANE_ORDER_ID                    AS ORDER_RELATION_ID,
    A.PLANE_ORDER_NO                    AS ORDER_RELATION_NO,
    'PLANE_ORDER'                       AS ORDER_RELATION_CODE,
    A.PLANE_ORDER_NO                    AS PAY_RELATION_NO,
    D.DETAIL                            AS TRIP_DETAIL,
    NVL(B.FOR_PRIVATE, 0)               AS FOR_PRIVATE,
    B.IS_FILL_ORDER                     AS IS_FILL_ORDER,
    B.FILL_ORDER_TIME                   AS FILL_ORDER_TIME,
    A.COST_CENTER_ID                    AS COST_CENTER_ID,
    B.CREATE_TIME                       AS APPLY_TIME,
    B.CREATE_USER                       AS APPLY_USER,
    B.TICKETING_TIME                    AS CONFIRM_TIME,
    B.TICKETING_EMPLOYEE                AS CONFIRM_EMPLOYEE,
    CASE
        WHEN B.STATE = '5'
        AND B.PUR_SETTLE_TYPE = '1'
        THEN NVL(A.SALE_PRICE, 0) + NVL(C.SALE_PRICE, 0)
        ELSE NVL(A.SALE_PRICE, 0)
    END AS SALE_PRICE,
    CASE
        WHEN B.STATE = '4'
        OR  (B.STATE = '5'
            AND B.PUR_SETTLE_TYPE = '1')
        THEN '0'
        ELSE '1'
    END                         AS PUR_SETTLE_FLAG,
    A.PUR_ID                    AS PUR_ID,
    '1'                         AS PUR_BILL_FLAG,
    A.PUR_BANK_NO               AS PUR_BANK_NO,
    A.PUR_BILL_NO               AS PUR_BILL_NO,
    A.PUR_PAY_TYPE              AS PUR_PAY_TYPE,
    A.PUR_PAY_TIME              AS PUR_PAY_TIME,
    NVL(A.PUR_SETTLE_TYPE, 2)   AS PUR_SETTLE_TYPE,
    NVL(A.PUR_SETTLE_STATE, 0)  AS PUR_SETTLE_STATE,
    A.PUR_SETTLE_EMPLOYEE       AS PUR_SETTLE_EMPLOYEE,
    A.PUR_SETTLE_TIME           AS PUR_SETTLE_TIME,
    NVL(A.FLOOR_PRICE, 0)       AS FLOOR_PRICE,
    DECODE(B.STATE,'4','0','1') AS SUP_SETTLE_FLAG,
    A.SUP_ID                    AS SUP_ID,
    '2'                         AS SUP_BILL_FLAG,
    A.SUP_PLANE_ORDER_NO        AS SUP_ORDER_NO,
    A.SUP_BANK_NO               AS SUP_BANK_NO,
    A.SUP_BILL_NO               AS SUP_BILL_NO,
    A.SUP_PAY_TYPE              AS SUP_PAY_TYPE,
    A.SUP_PAY_TIME              AS SUP_PAY_TIME,
    NVL(A.SUP_SETTLE_TYPE, 1)   AS SUP_SETTLE_TYPE,
    NVL(A.SUP_SETTLE_STATE, 0)  AS SUP_SETTLE_STATE,
    A.SUP_SETTLE_EMPLOYEE       AS SUP_SETTLE_EMPLOYEE,
    A.SUP_SETTLE_TIME           AS SUP_SETTLE_TIME
FROM
    JIKE.T_CC_TICKET_PASSENGER A
LEFT JOIN
    JIKE.T_CC_PLANE_ORDER B
ON
    A.PLANE_ORDER_ID = B.PLANE_ORDER_ID
LEFT JOIN
    JIKE.V_CC_INSURANCE_ORDER C
ON
    A.PLANE_TICKET_ID = C.PLANE_TICKET_ID
AND A.PLANE_ORDER_ID = C.PLANE_ORDER_ID
LEFT JOIN
    (
        SELECT
            PLANE_TICKET_ID,
            listagg(DETAIL,'#') within GROUP (ORDER BY X.PLANE_OD_ID) DETAIL
        FROM
            JIKE.T_CC_TICKET_OD X
        LEFT JOIN
            JIKE.V_PLANE_OD_TRIP Y
        ON
            X.PLANE_OD_ID = Y.PLANE_OD_ID
        GROUP BY
            PLANE_TICKET_ID) D
ON
    A.PLANE_TICKET_ID = D.PLANE_TICKET_ID
WHERE
    A.PREV_PLANE_TICKET_ID IS NULL WITH READ ONLY
