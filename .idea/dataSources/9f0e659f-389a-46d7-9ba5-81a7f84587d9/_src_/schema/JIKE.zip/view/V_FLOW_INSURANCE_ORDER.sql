create view V_FLOW_INSURANCE_ORDER as
SELECT
    'INSURANCE'                                                        AS PRODUCT_TYPE,
    'INSURANCE_ORDER'                                                        AS PRODUCT_CODE,
    '保险订单'                                                                   AS PRODUCT_NAME,
    C.NAME                                                                   AS PRODUCT_DESC,
    A.INS_ORDER_DETAIL_ID                                                         AS PRODUCT_ID,
    A.SUP_INSURANCE_ORDER_NO                                                      AS PRODUCT_NO,
    A.INSURANCE_ORDER_ID                                                          AS ORDER_ID,
    B.INSURANCE_ORDER_NO                                                          AS ORDER_NO,
    to_number ('')                                                                AS USER_ID,
    A.IDC_NO                                                               AS PASSENGER_RELATION_ID,
    A.CONTRACT_NAME                                                               AS PASSENGER_NAME,
    A.PLANE_ORDER_ID                                                           AS ORDER_RELATION_ID,
    A.PLANE_ORDER_NO                                                           AS ORDER_RELATION_NO,
    DECODE(A.TYPE,'1','PLANE_ORDER','2','INTER_PLANE_ORDER','3','TRAIN_ORDER','') AS
                        ORDER_RELATION_CODE,
    A.PLANE_ORDER_NO          AS PAY_RELATION_NO,
    A.PLANE_TICKET_NO         AS TRIP_DETAIL,
    NVL(A.FOR_PRIVATE, 0)     AS FOR_PRIVATE,
    A.IS_FILL_ORDER           AS IS_FILL_ORDER,
    A.FILL_ORDER_TIME         AS FILL_ORDER_TIME,
    A.COST_CENTER_ID          AS COST_CENTER_ID,
    A.CREATE_TIME             AS APPLY_TIME,
    B.CREATE_USER             AS APPLY_USER,
    A.TICKETING_TIME          AS CONFIRM_TIME,
    0                         AS CONFIRM_EMPLOYEE,
    NVL(A.REAL_SALE_PRICE, 0) AS SALE_PRICE,
    CASE
        WHEN (A.STATE = '2'
            OR  A.STATE = '3'
            OR  A.STATE = '9')
        AND A.PREV_INS_ORDER_DETAIL_ID IS NULL
        THEN '0'
        ELSE '1'
    END                         AS PUR_SETTLE_FLAG,
    A.PUR_ID                    AS PUR_ID,
    '1'                         AS PUR_BILL_FLAG,
    A.PUR_BANK_NO               AS PUR_BANK_NO,
    A.PUR_BILL_NO               AS PUR_BILL_NO,
    A.PUR_PAY_TYPE              AS PUR_PAY_TYPE,
    A.PUR_PAY_TIME              AS PUR_PAY_TIME,
    NVL(A.PUR_SETTLE_TYPE, 2)   AS PUR_SETTLE_TYPE,
    NVL(A.PUR_SETTLE_STATE, 0)  AS PUR_SETTLE_STATE,
    A.PUR_SETTLE_EMPLOYEE       AS PUR_SETTLE_EMPLOYEE,
    A.PUR_SETTLE_TIME           AS PUR_SETTLE_TIME,
    NVL(A.FLOOR_PRICE, 0)       AS FLOOR_PRICE,
    DECODE(B.STATE,'2','0','1') AS SUP_SETTLE_FLAG,
    A.SUP_ID                    AS SUP_ID,
    '2'                         AS SUP_BILL_FLAG,
    A.SUP_INSURANCE_ORDER_ID    AS SUP_ORDER_NO,
    A.SUP_BANK_NO               AS SUP_BANK_NO,
    A.SUP_BILL_NO               AS SUP_BILL_NO,
    A.SUP_PAY_TYPE              AS SUP_PAY_TYPE,
    A.SUP_PAY_TIME              AS SUP_PAY_TIME,
    NVL(A.SUP_SETTLE_TYPE, 1)   AS SUP_SETTLE_TYPE,
    NVL(A.SUP_SETTLE_STATE, 0)  AS SUP_SETTLE_STATE,
    A.SUP_SETTLE_EMPLOYEE       AS SUP_SETTLE_EMPLOYEE,
    A.SUP_SETTLE_TIME           AS SUP_SETTLE_TIME
FROM
    JIKE.V_CC_INSURANCE_ORDER_DETAIL A
LEFT JOIN
    JIKE.T_CC_INSURANCE_ORDER B
ON
    A.INSURANCE_ORDER_ID = B.INSURANCE_ORDER_ID
LEFT JOIN
    JIKE.T_CC_BASE_INSURANCE C
ON
    A.INSURANCE_ID = C.ID WITH READ ONLY
