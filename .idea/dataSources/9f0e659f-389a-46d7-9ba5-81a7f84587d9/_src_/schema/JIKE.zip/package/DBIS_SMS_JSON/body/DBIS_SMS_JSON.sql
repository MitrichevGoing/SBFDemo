create PACKAGE BODY      DBIS_SMS_JSON IS
  TYPE ListString IS TABLE OF VARCHAR2(32000);
  --------------------------------------------------------------
  -- 通用函数：MD5加密
  --------------------------------------------------------------
  FUNCTION encodeMD5(myText IN VARCHAR2) RETURN VARCHAR2 AS
    RAW_INPUT     RAW(10240) := UTL_RAW.CAST_TO_RAW(UPPER(myText));
    DECRYPTED_RAW RAW(2048);
    ERROR_IN_INPUT_BUFFER_LENGTH EXCEPTION;
  BEGIN
    IF (Length(myText) <= 0) OR (myText IS NULL) THEN
      RETURN 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
    ELSE
      SYS.DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT    => RAW_INPUT,
                                       CHECKSUM => DECRYPTED_RAW);
      RETURN LOWER(RAWTOHEX(DECRYPTED_RAW));
    END IF;
  END;

  --------------------------------------------------------------
  -- 通用函数：字符串转换成整形
  --------------------------------------------------------------
  FUNCTION convertStrToInt(viString IN VARCHAR2, iiDefault IN INTEGER)
    RETURN INTEGER AS
    voRes varchar2(250);
    noRes number;
    ioRes integer;
  BEGIN
    ioRes := iiDefault;
    if LengthB(viString) > 18 then
      return ioRes;
    end if;
    voRes := Trim(viString);
    if substr(voRes, 1, 1) in ('-') then
      voRes := substr(voRes, 2);
    end if;

    voRes := Replace(voRes, '0');
    voRes := Replace(voRes, '1');
    voRes := Replace(voRes, '2');
    voRes := Replace(voRes, '3');
    voRes := Replace(voRes, '4');
    voRes := Replace(voRes, '5');
    voRes := Replace(voRes, '6');
    voRes := Replace(voRes, '7');
    voRes := Replace(voRes, '8');
    voRes := Replace(voRes, '9');
    if voRes is null then
      noRes := to_number(Trim(viString));
      if noRes between - 2147483648 and 2147483647 then
        ioRes := noRes;
      else
        ioRes := iiDefault;
      end if;
    else
      ioRes := iiDefault;
    end if;

    return ioRes;
  END;

  --------------------------------------------------------------
  -- 通用函数：解析JSON，获得值
  --------------------------------------------------------------
  Function queryJsonValueFromName(viName IN varchar2, viData IN varchar2)
    return varchar2 as
    voRes  varchar2(32000);
    vInput varchar2(32000);
    iPos1  integer;
    iPos2  integer;
    iPos3  integer;
  begin
    vInput := upper(viData);
    iPos1  := instr(vInput, '"' || Trim(Upper(viName)) || '"');
    iPos2  := instr(vInput, ':', iPos1);
    iPos3  := instr(vInput, ',', iPos2);
    if iPos3 = 0 then
      iPos3 := instr(vInput, '}', iPos2);
    end if;
    voRes := trim(substr(viData, iPos2 + 1, iPos3 - iPos2 - 1));
    if (substr(voRes, 1, 1) in ('"')) then
      voRes := substr(voRes, 2, Length(voRes) - 2);
    end if;
    return voRes;
  end;

  ----------------------------------------------------------------------------------------------
  -- 0.插入短信
  ----------------------------------------------------------------------------------------------
  function insertToQueue(viTempletId varchar2,
                         viID        varchar2,
                         viTemplet   varchar2,
                         viPhone     varchar2,
                         viModule varchar2,
                         viOrderNo varchar2,
                         viCompanyName varchar2

                         ) return varchar2 as
    vTemplet   varchar2(30000);
    vTelephone varchar2(500);
    vGuid      varchar2(500);
    dtNow      date;
    vResult    varchar2(14000);
    iNum1      integer;
  begin
    dtNow      := Sysdate;
    vTemplet   := viTemplet;
    vTelephone := viPhone;
    --插入短信列表
    if length(nvl(vTemplet, 'N')) > 5 then
      --ID+电话+短信内容+YYYYMM，防止重复
      vGuid := upper(encodeMD5(viID || vTelephone || vTemplet ||
                               TO_CHAR(dtNow, 'YYYYMMDD')));
      select count(0)
        into iNum1
        from T_BASE_MESSAGE_QUEUE
       where mq_guid = vGuid;
      if iNum1 < 1 then
        insert into T_BASE_MESSAGE_QUEUE
          (mq_id,
           mq_type,
           mq_text1,
           mq_text2,
           mq_text3,
           mq_object,
           mq_level,
           mq_state,
           mq_sender,
           mq_sendtime,
           mq_remark,
           create_time,
           create_user,
           create_remark,
           mq_guid,
           module,
           order_no,
           company_name
          )
        values
          (to_char(dtNow, 'YYMMDD') || seq_message_queue_id.nextval,
           '1',
           substr(vTemplet, 1, 1000),
           substr(vTemplet, 1001, 1000),
           substr(vTemplet, 2001, 1000),
           vTelephone,
           '1',
           '0',
           '10658303503',
           dtNow,
           '',
           dtNow,
           'SYSTEM',
           null,
           vGuid,
           viModule,
           viOrderNo,
           viCompanyName);
        --commit;
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   viTempletId || '","id":"' || viID || '"}';
      else
        vResult := '{"code":"0","message":"重复短信","memo":"N","templetid":"' ||
                   viTempletId || '","id":"' || viID || '"}';
      end if;
    else
      vResult := '{"code":"0","message":"短信内容过短","memo":"N","templetid":"' ||
                 viTempletId || '","id":"' || viID || '"}';
    end if;
    return vResult;
  end;

  ----------------------------------------------------------------------------------------------
  function insertToQueueRemark(viTempletId varchar2,
                         viID        varchar2,
                         viTemplet   varchar2,
                         viPhone     varchar2,
                         viModule varchar2,
                         viOrderNo varchar2,
                         viCompanyName varchar2,
                         viRemark varchar2

                         ) return varchar2 as
    vTemplet   varchar2(30000);
    vTelephone varchar2(500);
    vGuid      varchar2(500);
    dtNow      date;
    vResult    varchar2(14000);
    iNum1      integer;
  begin
    dtNow      := Sysdate;
    vTemplet   := viTemplet;
    vTelephone := viPhone;
    --插入短信列表
    if length(nvl(vTemplet, 'N')) > 5 then
      --ID+电话+短信内容+YYYYMM，防止重复
      vGuid := upper(encodeMD5(viID || vTelephone || vTemplet ||
                               TO_CHAR(dtNow, 'YYYYMMDD')));
      select count(0)
        into iNum1
        from T_BASE_MESSAGE_QUEUE
       where mq_guid = vGuid;
      if iNum1 < 1 then
        insert into T_BASE_MESSAGE_QUEUE
          (mq_id,
           mq_type,
           mq_text1,
           mq_text2,
           mq_text3,
           mq_object,
           mq_level,
           mq_state,
           mq_sender,
           mq_sendtime,
           mq_remark,
           create_time,
           create_user,
           create_remark,
           mq_guid,
           module,
           order_no,
           company_name
          )
        values
          (to_char(dtNow, 'YYMMDD') || seq_message_queue_id.nextval,
           '1',
           substr(vTemplet, 1, 1000),
           substr(vTemplet, 1001, 1000),
           substr(vTemplet, 2001, 1000),
           vTelephone,
           '1',
           '0',
           viRemark,
           dtNow,
           '',
           dtNow,
           'SYSTEM',
           null,
           vGuid,
           viModule,
           viOrderNo,
           viCompanyName);
        --commit;
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   viTempletId || '","id":"' || viID || '"}';
      else
        vResult := '{"code":"0","message":"重复短信","memo":"N","templetid":"' ||
                   viTempletId || '","id":"' || viID || '"}';
      end if;
    else
      vResult := '{"code":"0","message":"短信内容过短","memo":"N","templetid":"' ||
                 viTempletId || '","id":"' || viID || '"}';
    end if;
    return vResult;
  end;

  ----------------------------------------------------------------------------------------------
  -- 1.去生成短信 {"templetid":"TEMP_PASSWORD","id":"24","remark":"N","telphone":"17712613261"}
  ----------------------------------------------------------------------------------------------
  FUNCTION toCreate(viData IN VARCHAR2, viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    vWeek varchar2(20);--一周内星期几
    iNum1 Integer;
    iNum2 Integer;
    iNum3 Integer;
    iNum4 Integer;
    iNum5 Integer;

    vCon       varchar2(32000);
    vTempletId varchar2(500);
    vId        varchar2(20000);
    vRemark    varchar2(20000);
    vTelphone  varchar2(50);
    vTelphone1  varchar2(50);

    vTemplet  varchar2(32000);
    vTemplet1 varchar2(32000);
    vTemplet2 varchar2(32000);

    vHbxx varchar2(16000);
    vTemp varchar2(30000);
    vTemp1 varchar2(30000);
    vTemp2 varchar2(30000);
    vTemp3 varchar2(30000);
    vTemp4 varchar2(30000);
    vTemp5 varchar2(30000);

    --客户手机号，联系手机号，预订手机号
    vKhSjh  varchar2(500);
    vLxSjh  varchar2(500);
    vYdSjh  varchar2(500);

    vGuid varchar2(6000);

    vModule  varchar2(500);
    vOrderNo  varchar2(500);
    vCompanyName  varchar2(500);
    --审批提示码
    vPassCode varchar2(6000);
    vDeclineCode varchar2(6000);
    vEndTime varchar2(500);
    --客户经理、手机
    vCsrMan varchar2(500);
    vCsrManCell varchar2(500);
    --判断标识
    vFlag number(1,0);
    --补单标志
    vFillFlag number(1,0);

    --userBean rowtype%T_BASE_USER;
    --tempBean rowtype%T_BASE_TEMPLET;

    errorResult EXCEPTION;
  BEGIN
    dtNow := sysdate;

    vCon := viData;
    vId  := 'ERROR';

    ----------------------------------------
    -- 解析出条件
    ----------------------------------------
    vTempletId := upper(trim(queryJsonValueFromName('templetid', vCon)));
    vId        := trim(queryJsonValueFromName('id', vCon));
    vRemark    := trim(queryJsonValueFromName('remark', vCon));
    vTelphone  := trim(queryJsonValueFromName('telphone', vCon));

    ---------------------------------------
    -- 获得模板,如果为空或长度不符合则退出
    ---------------------------------------
    select nvl((select nvl(Text1, 'N') from t_base_templet where code like vTempletId||'%' and rownum <= 1),'N') into vTemplet from dual;
    if Length(vTemplet) < 5 then
      vResult := '{"code":"0","message":"短信模板缺失","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      raise errorResult;
    end if;

    ------------------------------------------------
    -- PLANE_CIVIL_CHANGE_SUCCESS_TO:国内机票改签成功
    -- 1.PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS:您好:您的改签已完成,原#FLIGHTNOOLD##AIRPORT#,改为:#FLIGHTNONEW#,#TIME#,改签费#CHANGEFEE#,#NAME#票号#ORDERNO#,祝您旅途愉快
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK:您好:您申请的改签已完成,原#FLIGHTNOOLD##AIRPORT#,改为:#FLIGHTNONEW#,#TIME#,已短信通知乘机人,#NAME##ORDERNO#,祝生活愉快
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_CIVIL_CHANGE_SUCCESS_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_CHANGE_SUCCESS_TO') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      ---------------------------------------
      --获得旧行程vTemp1，再获得新行程vTemp2
      ---------------------------------------
      vTemp1 := '';
      vTemp2 := '';
      for rsCo in (select * from t_cc_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
        --旧行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by take_off_time) loop
          vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || rsPt.airline_code||rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      for rsCo in (select * from t_cc_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
        --新行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by take_off_time) loop
          vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || rsPt.airline_code||rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      -------------------------------------------
      -- 获得联系人（申请人）手机和改签费用vTemp3
      -------------------------------------------
      for rsPc in (select * from t_cc_plane_change where change_id = vId) loop
        iNum1 := 1;
        select nvl((select mobilephone from t_base_user where user_id=rsPc.Apply_User),'AA') into vLxSjh from dual;
        --改签费用
        vTemp3 := '111.11';
        --是否为补单
        vFillFlag := rsPc.IS_FILL_ORDER;
      end loop;
      --------------------------------------
      -- 新行程，获得乘机人信息
      --------------------------------------
      vTemp4 := '';
      iNum2  := 0;
      iNum3  := 0;
      for rsCjr in (select * from T_CC_TICKET_PASSENGER a1 where exists (select 0 from t_cc_change_ticket a2 where a2.change_id=vId and a2.plane_ticket_no=a1.plane_ticket_no) and state = '3') loop
        iNum3  := iNum3+1;
        vKhSjh := NVL(Trim(rsCjr.Phone),'A');
        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
        vTemp4 := vTemp4||rsCjr.Idc_Name||'票号'||rsCjr.Plane_Ticket_No;
        ------------------------------
        --  获得乘机人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS';
        vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsCjr.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsCjr.Company_Id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          -------------------
          --　发送乘机人短信
          -------------------
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh,vModule,vOrderNo,vCompanyName);
          ------------------------------------------------
          --获得所有手机号，并分析
          --1.乘机人 ＝ 联系人(申请人)
          --2.乘机人!＝ 联系人(申请人)
          ------------------------------------------------
          if vKhSjh = vLxSjh then iNum2 := 1; end if ;
          if vKhSjh!= vLxSjh then iNum2 := 2; end if ;
        else
          --------------------------------------------------
          -- 相当于 2.乘机人!＝ 联系人
          --------------------------------------------------
           iNum2 := 2;
        end if;
      end loop;

      ------------------------------
      --  获得联系人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK';
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);
      vTemplet1 := Replace(vTemplet1, '#NAME##ORDERNO#',vTemp4);
      --------------------------------
      -- 判断乘机人数量
      -- 一位乘机人
      -- 二位乘机人及以上
      --------------------------------
      if iNum3=1 and vFillFlag = 0 or vFillFlag is null then
         -----------------------------
         -- 乘机人 !＝ 联系人(申请人)
         -----------------------------
         if iNum2 in (2) then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh,vModule,vOrderNo,vCompanyName);
         end if ;
      else
         if iNum3>1 and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh,vModule,vOrderNo,vCompanyName);
         else
            vResult := '{"code":"0","message":"国内机票改签,乘机人空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
         end if ;
      end if ;

      if Length(NVL(vResult, 'N')) < 10 then
        vResult := '{"code":"0","message":"国内机票改签,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票改签订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    ------------------------------------------------
    -- 酒店预订成功
    -- HOTEL_SUCCESS_TO_LINK3
    -- 您为#NAME#预订的#TWODATE#入住#HOTEL_NAME#，#ROOM_TYPE#，#ROOM_NUM#，已经预订成功！如有变动请在#LATEST_CANCELTIME#前通知，过时不入住将扣除#GUARANTEE_AMOUNT#。网上预订更方便，服务电话：4007239888
    -- #NAME#，#TWODATE#入住#HOTEL_NAME#(#HOTEL_ADD#，#HOTEL_PHONE#)，房间保留到#LATESTTIME#，如有变动请在#LATEST_CANCELTIME#前通知，过时不入住将扣除#GUARANTEE_AMOUNT#。请直接报#NAME#姓名办理入住，谢谢！网上预订更方便，服务电话：4007239888
    -- 小样，5/27-5/28入住三亚黎客国际酒店（三亚市河西区河西路115号(春园海鲜广场旁），大床房（无窗）,0898-38866888）,订单号3100005040，如有问题请致电4007239888
    -- {"templetid":"HOTEL_SUCCESS_TO","id":"OT3100015090","remark":"1","telphone":"N"}
    -- 联系人姓名
    -- 航班信息
    ------------------------------------------------
    if vTempletId in ('HOTEL_SUCCESS_TO') then
      iNum1 := 0;
      vId   := vId;
      for rsHotelOrder in (select * from T_CH_HOTEL_ORDER where affiliate_confirmation_id = vId) loop
          iNum1  := 1;
          --判断1=现付，2=预付，3=担保，存入iNum2
          --是否为补单
          vFillFlag := rsHotelOrder.IS_FILL_ORDER;

          if rsHotelOrder.Order_Type=1 then
             if Nvl(rsHotelOrder.Guarantee_Amount,0)>0 then
                iNum2 := 3;
             else
                iNum2 := 1;
             end if ;
          else
            if rsHotelOrder.Order_Type=2 then
             iNum2 := 2;
            else
              if rsHotelOrder.Order_Type=3 then
               iNum2 := 1;
              else
              iNum2 := 1;
                end if;
            end if;

          end if ;
          --获得联系人模板 vTemplet1
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='HOTEL_SUCCESS_TO_LINK'||iNum2;
          --获得入住人模板 vTemplet2
          select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='HOTEL_SUCCESS_TO_CUS' ||iNum2;
          --替换日期
          vTemplet1 := replace(vTemplet1,'#TWODATE#',to_char(rsHotelOrder.Arrival_Date, 'FMMM/DD') || '-' || to_char(rsHotelOrder.Departure_Date, 'FMMM/DD'));
          vTemplet2 := replace(vTemplet2,'#TWODATE#',to_char(rsHotelOrder.Arrival_Date, 'FMMM/DD') || '-' || to_char(rsHotelOrder.Departure_Date, 'FMMM/DD'));
          --替换酒店名称
          vTemplet1 := replace(vTemplet1,'#HOTEL_NAME#',rsHotelOrder.Hotel_Name);
          vTemplet2 := replace(vTemplet2,'#HOTEL_NAME#',rsHotelOrder.Hotel_Name);
          --替换户型
          vTemplet1 := replace(vTemplet1,'#ROOM_TYPE#',rsHotelOrder.Room_Type_Name);
          vTemplet2 := replace(vTemplet2,'#ROOM_TYPE#',rsHotelOrder.Room_Type_Name);
          --替换地址
          vTemplet1 := replace(vTemplet1,'#HOTEL_ADD#',rsHotelOrder.Hotel_Address);
          vTemplet2 := replace(vTemplet2,'#HOTEL_ADD#',rsHotelOrder.Hotel_Address);
          --替换酒店电话
          vTemplet1 := replace(vTemplet1,'#HOTEL_PHONE#',rsHotelOrder.Hotel_Phone);
          vTemplet2 := replace(vTemplet2,'#HOTEL_PHONE#',rsHotelOrder.Hotel_Phone);
          --替换酒店单数
          vTemplet1 := replace(vTemplet1,'#ROOM_NUM#',rsHotelOrder.Number_Of_Rooms||'间');
          vTemplet2 := replace(vTemplet2,'#ROOM_NUM#',rsHotelOrder.Number_Of_Rooms||'间');

          ------------------------------------------------
          -- HOTEL_SUCCESS_TO_LINK3
          -- HOTEL_SUCCESS_TO_CUS3
          -- 将短信模块内的“如有变动请在#LATEST_CANCELTIME#前通知，过时”替换成“#TEXT_CANCELTIME#”
          ------------------------------------------------
          if iNum2 in (3) then
             if nvl(rsHotelOrder.Cancel_Time,trunc(sysdate))<=trunc(sysdate) then
                --替换最晚取消时间
                vTemplet1 := replace(vTemplet1,'#TEXT_CANCELTIME#','');
                vTemplet2 := replace(vTemplet2,'#TEXT_CANCELTIME#','');
             else
                --替换最晚取消时间
                vTemplet1 := replace(vTemplet1,'#TEXT_CANCELTIME#','如有变动请在'||to_char(rsHotelOrder.Cancel_Time,'FMmm"月"dd"号"hh24"点"')||'前通知，过时');
                vTemplet2 := replace(vTemplet2,'#TEXT_CANCELTIME#','如有变动请在'||to_char(rsHotelOrder.Cancel_Time,'FMmm"月"dd"号"hh24"点"')||'前通知，过时');
             end if ;
          else
             --替换最晚取消时间
             vTemplet1 := replace(vTemplet1,'#LATEST_CANCELTIME#',to_char(rsHotelOrder.Cancel_Time,'FMmm"月"dd"号"hh24"点"'));
             vTemplet2 := replace(vTemplet2,'#LATEST_CANCELTIME#',to_char(rsHotelOrder.Cancel_Time,'FMmm"月"dd"号"hh24"点"'));
          end if ;
          --替换最晚保留时间
          vTemplet1 := replace(vTemplet1,'#LATESTTIME#',to_char(rsHotelOrder.Latest_Arrival_Time,'FMmm"月"dd"号"hh24"点"'));
          vTemplet2 := replace(vTemplet2,'#LATESTTIME#',to_char(rsHotelOrder.Latest_Arrival_Time,'FMmm"月"dd"号"hh24"点"'));
          --替换担保费用
          vTemplet1 := replace(vTemplet1,'#GUARANTEE_AMOUNT#',nvl(rsHotelOrder.Guarantee_Amount,0)||'元');
          vTemplet2 := replace(vTemplet2,'#GUARANTEE_AMOUNT#',nvl(rsHotelOrder.Guarantee_Amount,0)||'元');
          --替换订单号
          vTemplet1 := replace(vTemplet1,'#ID#',rsHotelOrder.Affiliate_Confirmation_Id);
          vTemplet2 := replace(vTemplet2,'#ID#',rsHotelOrder.Affiliate_Confirmation_Id);

          vModule := '3';
          vOrderNo := rsHotelOrder.Affiliate_Confirmation_Id;
          for rsCompany in (select * from T_base_company where company_id = rsHotelOrder.Company_Id and rownum <= 1) loop
            vCompanyName := rsCompany.company_name;
          end loop;

          --姓名叠加，格式：姓名1，姓名2，存放到vTemp1
          --常用联系人
          for rsHotelCus0 in (select * from T_CH_ORDER_CUSTOMER where affiliate_confirmation_id = rsHotelOrder.Affiliate_Confirmation_Id and is_user = 0) loop
            for rsHotelCus0User in (select * from T_BASE_GENERAL_CONTACT where contact_id = rsHotelCus0.Fre_Id) loop
              if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '，'; end if;
              vTemp1 := vTemp1||rsHotelCus0User.Name;

              vKhSjh := Trim(rsHotelCus0User.Phone);
              vTemplet2 := replace(vTemplet2,'#NAME#',rsHotelCus0User.Name);

              if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
                vResult := insertToQueue(vTempletId,vId,vTemplet2,vKhSjh,vModule,vOrderNo,vCompanyName);
              end if;
            end loop;
          end loop;
          --员工
          for rsHotelCus1 in (select * from T_CH_ORDER_CUSTOMER where affiliate_confirmation_id = rsHotelOrder.Affiliate_Confirmation_Id and is_user = 1) loop
            for rsHotelCus1User in (select * from T_BASE_USER where user_id = rsHotelCus1.Fre_Id) loop
              if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '，'; end if;
              vTemp1 := vTemp1||rsHotelCus1User.Name_Cn;

              vKhSjh := Trim(rsHotelCus1User.Mobilephone);
              vTemplet2 := replace(vTemplet2,'#NAME#',rsHotelCus1User.Name_Cn);
              if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
                vResult := insertToQueue(vTempletId, vId, vTemplet2, vKhSjh,vModule,vOrderNo,vCompanyName);
              end if;
            end loop;
          end loop;

          --联系人
          vLxSjh := Trim(rsHotelOrder.Contact_Mobile);
          vTemplet1 := replace(vTemplet1,'#NAME#',vTemp1);
          if vFillFlag = 0 or vFillFlag is null then
            vResult   := insertToQueue(vTempletId, vId, vTemplet1, vLxSjh,vModule,vOrderNo,vCompanyName);
          end if;

          --订阅人
          if vRemark in ('1')then
           vYdSjh := 'N';
           select nvl((select mobilephone from t_base_user where user_id=rsHotelOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
           if vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
             vResult := insertToQueue(vTempletId, vId, vTemplet1, vYdSjh,vModule,vOrderNo,vCompanyName);
           end if ;
          end if ;
          if Length(NVL(vResult, 'N')) < 10 then
            vResult := '{"code":"0","message":"国内酒店,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
          end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"酒店订单不存在","memo":"N","templetid":"' ||vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


  ------------------------------------------------
    -- 酒店取消成功
    -- HOTEL_CANCEL
    -- {"templetid":"HOTEL_CANCEL","id":"OT3100015090","remark":"1","telphone":"N"}
    -- 联系人姓名
    -- 航班信息
    ------------------------------------------------
    if vTempletId in ('HOTEL_CANCEL') then
      iNum1 := 0;
      vId   := vId;
      for rsHotelOrder in (select * from T_CH_HOTEL_ORDER where affiliate_confirmation_id = vId) loop
          --是否为补单
          vFillFlag := rsHotelOrder.IS_FILL_ORDER;
          --获得联系人模板 vTemplet1
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='HOTEL_CANCEL_TO_LINK';
          --获得入住人模板 vTemplet2
          select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='HOTEL_CANCEL_TO_CUS' ;
          --替换日期
          vTemplet1 := replace(vTemplet1,'#TWODATE#',to_char(rsHotelOrder.Arrival_Date, 'FMMM/DD') || '-' || to_char(rsHotelOrder.Departure_Date, 'FMMM/DD'));
          vTemplet2 := replace(vTemplet2,'#TWODATE#',to_char(rsHotelOrder.Arrival_Date, 'FMMM/DD') || '-' || to_char(rsHotelOrder.Departure_Date, 'FMMM/DD'));
          --替换酒店名称
          vTemplet1 := replace(vTemplet1,'#HOTEL_NAME#',rsHotelOrder.Hotel_Name);
          vTemplet2 := replace(vTemplet2,'#HOTEL_NAME#',rsHotelOrder.Hotel_Name);
          --替换户型
          vTemplet1 := replace(vTemplet1,'#ROOM_TYPE#',rsHotelOrder.Room_Type_Name);
          vTemplet2 := replace(vTemplet2,'#ROOM_TYPE#',rsHotelOrder.Room_Type_Name);
          --替换地址
          vTemplet1 := replace(vTemplet1,'#HOTEL_ADD#',rsHotelOrder.Hotel_Address);
          vTemplet2 := replace(vTemplet2,'#HOTEL_ADD#',rsHotelOrder.Hotel_Address);
          --替换酒店单数
          vTemplet1 := replace(vTemplet1,'#ROOM_NUM#',rsHotelOrder.Number_Of_Rooms||'间');
          vTemplet2 := replace(vTemplet2,'#ROOM_NUM#',rsHotelOrder.Number_Of_Rooms||'间');

          --替换订单号
          vTemplet1 := replace(vTemplet1,'#ID#',rsHotelOrder.Affiliate_Confirmation_Id);
          vTemplet2 := replace(vTemplet2,'#ID#',rsHotelOrder.Affiliate_Confirmation_Id);

          vModule := '3';
          vOrderNo := rsHotelOrder.Affiliate_Confirmation_Id;
          for rsCompany in (select * from T_base_company where company_id = rsHotelOrder.Company_Id and rownum <= 1) loop
            vCompanyName := rsCompany.company_name;
          end loop;

          --姓名叠加，格式：姓名1，姓名2，存放到vTemp1
          --常用联系人
          for rsHotelCus0 in (select * from T_CH_ORDER_CUSTOMER where affiliate_confirmation_id = rsHotelOrder.Affiliate_Confirmation_Id and is_user = 0) loop
            for rsHotelCus0User in (select * from T_BASE_GENERAL_CONTACT where contact_id = rsHotelCus0.Fre_Id) loop
              if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '，'; end if;
              vTemp1 := vTemp1||rsHotelCus0User.Name;

              vKhSjh := Trim(rsHotelCus0User.Phone);
              vTemplet2 := replace(vTemplet2,'#NAME#',rsHotelCus0User.Name);

              if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
                vResult := insertToQueue(vTempletId,vId,vTemplet2,vKhSjh,vModule,vOrderNo,vCompanyName);
              end if;
            end loop;
          end loop;
          --员工
          for rsHotelCus1 in (select * from T_CH_ORDER_CUSTOMER where affiliate_confirmation_id = rsHotelOrder.Affiliate_Confirmation_Id and is_user = 1) loop
            for rsHotelCus1User in (select * from T_BASE_USER where user_id = rsHotelCus1.Fre_Id) loop
              if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '，'; end if;
              vTemp1 := vTemp1||rsHotelCus1User.Name_Cn;

              vKhSjh := Trim(rsHotelCus1User.Mobilephone);
              vTemplet2 := replace(vTemplet2,'#NAME#',rsHotelCus1User.Name_Cn);
              if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
                vResult := insertToQueue(vTempletId, vId, vTemplet2, vKhSjh,vModule,vOrderNo,vCompanyName);
              end if;
            end loop;
          end loop;

          --联系人
          vLxSjh := Trim(rsHotelOrder.Contact_Mobile);
          vTemplet1 := replace(vTemplet1,'#NAME#',vTemp1);
          vResult   := insertToQueue(vTempletId, vId, vTemplet1, vLxSjh,vModule,vOrderNo,vCompanyName);

          --订阅人
          if vRemark in ('1')then
           vYdSjh := 'N';
           select nvl((select mobilephone from t_base_user where user_id=rsHotelOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
           if vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
             vResult := insertToQueue(vTempletId, vId, vTemplet1, vYdSjh,vModule,vOrderNo,vCompanyName);
           end if ;
          end if ;
          if Length(NVL(vResult, 'N')) < 10 then
            vResult := '{"code":"0","message":"国内酒店,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
          end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"酒店订单不存在","memo":"N","templetid":"' ||vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    ------------------------------------------------
    -- HOTEL_DAY_TIMEOUT_TO:酒店超时
    -- HOTEL_DAY_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"HOTEL_DAY_TIMEOUT_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('HOTEL_DAY_TIMEOUT_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;

      --获得姓名信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (SELECT R.Affiliate_Confirmation_Id,  R.Is_User, R.fre_id, (CASE WHEN R.IS_USER = 1 THEN U.NAME_CN WHEN R.IS_USER = 0 THEN F.NAME END) NAME
        FROM T_CH_ORDER_CUSTOMER R  LEFT JOIN T_BASE_USER U ON R.FRE_ID = U.USER_ID LEFT JOIN T_BASE_GENERAL_CONTACT F
        ON R.FRE_ID = F.CONTACT_ID
          where Affiliate_Confirmation_Id = vId
          ) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || ',';
        end if;
        vTemp3 := vTemp3 || rs.NAME;

      end loop;

      -------------------------------------------------------------------------------------------------

      for rsHotelOrder in (select * from T_CH_HOTEL_ORDER where AFFILIATE_CONFIRMATION_ID = vId and rownum <= 1) loop
        --是否为补单
        vFillFlag := rsHotelOrder.IS_FILL_ORDER;
        vModule := '3';
        vOrderNo := rsHotelOrder.AFFILIATE_CONFIRMATION_ID;
        for rsCompany in (select * from T_base_company where company_id = rsHotelOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsHotelOrder.CONTACT_MOBILE;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsHotelOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='HOTEL_DAY_TIMEOUT_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#HOTELNAME#', rsHotelOrder.HOTEL_NAME);
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp3);
        --------------------------------
        --发给联系人
        if length(vLxSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
         vResult := insertToQueue(vTempletId, vId, vTemplet1, vLxSjh, vModule, vOrderNo, vCompanyName);
         end if;

        --预订人 ！= 联系人
        vRemark := nvl(vRemark, '0');
        if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
            if length(vYdSjh) = 11 then
             vResult := insertToQueue(vTempletId, vId, vTemplet1, vYdSjh ,vModule, vOrderNo, vCompanyName);
             end if;
        end if ;


        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"jiudian,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"酒店订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- HOTEL_LIGHT_TIMEOUT_TO:酒店中班超时
    -- HOTEL_LIGHT_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"HOTEL_LIGHT_TIMEOUT_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('HOTEL_LIGHT_TIMEOUT_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;

      --获得姓名信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (SELECT R.Affiliate_Confirmation_Id,  R.Is_User, R.fre_id, (CASE WHEN R.IS_USER = 1 THEN U.NAME_CN WHEN R.IS_USER = 0 THEN F.NAME END) NAME
        FROM T_CH_ORDER_CUSTOMER R  LEFT JOIN T_BASE_USER U ON R.FRE_ID = U.USER_ID LEFT JOIN T_BASE_GENERAL_CONTACT F
        ON R.FRE_ID = F.CONTACT_ID
          where Affiliate_Confirmation_Id = vId
          ) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || ',';
        end if;
        vTemp3 := vTemp3 || rs.NAME;

      end loop;

      -------------------------------------------------------------------------------------------------

      for rsHotelOrder in (select * from T_CH_HOTEL_ORDER where AFFILIATE_CONFIRMATION_ID = vId and rownum <= 1) loop
        -- 是否为补单
        vFillFlag := rsHotelOrder.IS_FILL_ORDER;
        vModule := '3';
        vOrderNo := rsHotelOrder.AFFILIATE_CONFIRMATION_ID;
        for rsCompany in (select * from T_base_company where company_id = rsHotelOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsHotelOrder.CONTACT_MOBILE;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsHotelOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='HOTEL_LIGHT_TIMEOUT_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#HOTELNAME#', rsHotelOrder.HOTEL_NAME);
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp3);
        --------------------------------
        --发给联系人
        if length(vLxSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
         vResult := insertToQueue(vTempletId, vId, vTemplet1, vLxSjh, vModule, vOrderNo, vCompanyName);
         end if;

        --预订人 ！= 联系人
        if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
           if length(vYdSjh) = 11 then
             vResult := insertToQueue(vTempletId, vId, vTemplet1, vYdSjh, vModule, vOrderNo, vCompanyName);
             end if;
        end if ;


        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"jiudian,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"酒店订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_CIVIL_SUCCESS_TO:国内机票出票成功
    -- 1.PLANE_CIVIL_SUCCESS_TO_PASS:#TIME##FLIGHTNO##AIRPORT#，已经出票成功，#NAME#票号#ORDERNO#,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_CIVIL_SUCCESS_TO_LINK:您预定的#TIME##FLIGHTNO##AIRPORT#，出票成功并已短信通知乘客，#NAME##ORDERNO#,感谢您的预订！网上退改更方便的，有问题请致电：4007239888
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_CIVIL_SUCCESS_TO","id":"610","remark":"1","telphone":"N"}
    -- 两者都发送
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_SUCCESS_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        vTemp4 := vTemp || '(' || rs.airline_code || ')';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_SUCCESS_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_CIVIL_SUCCESS_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;

        vTemp2 := '';
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsPlaneOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vId and state = '3') loop
          iNum3  := iNum3+1;
          vKhSjh := NVL(Trim(rsCjr.Phone),'A');
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name||'票号'||rsCjr.Plane_Ticket_No;
          ------------------------------
          --  获得乘机人模板并替换信息
          ------------------------------
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_SUCCESS_TO_PASS';
          vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
          vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
          vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

          if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
            -------------------
            --　发送乘机人短信
            -------------------
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
            ------------------------------------------------
            --获得所有手机号，并分析
            --1.乘机人 ＝ 联系人　乘机人 ＝ 预订人
            --2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --3.乘机人 ＝ 联系人　乘机人!＝ 预订人
            --4.乘机人!＝ 联系人　乘机人 ＝ 预订人
            ------------------------------------------------
            if vKhSjh = vLxSjh and vKhSjh = vYdSjh then iNum2 := 1; end if ;
            if vKhSjh!= vLxSjh and vKhSjh!= vYdSjh then iNum2 := 2; end if ;
            if vKhSjh = vLxSjh and vKhSjh!= vYdSjh then iNum2 := 3; end if ;
            if vKhSjh!= vLxSjh and vKhSjh = vYdSjh then iNum2 := 4; end if ;
          else
            --------------------------------------------------
            -- 相当于 2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --------------------------------------------------
             iNum2 := 2;
          end if;
        end loop;

        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_SUCCESS_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME##ORDERNO#',vTemp2);
        --如果乘机人不是联系人，也不是预订人，则去掉票价
        if iNum2 in (1,3,4) then
          vTemplet1 := Replace(vTemplet1, '#PRICE#',rsPlaneOrder.sale_price);
        else
          vTemplet1 := Replace(vTemplet1, '订单金额#PRICE#，','');
        end if;
        vTemplet1 := Replace(vTemplet1, '#AIRINFO#',vTemp4);

        --------------------------------
        -- 判断乘机人数量
        -- 一位乘机人
        -- 二位乘机人及以上
        --------------------------------
        if iNum3=1 and vFillFlag = 0 or vFillFlag is null then
           -----------------------
           -- 乘机人 !＝ 联系人
           -----------------------
           if iNum2 in (2,4) then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
           end if ;
           -----------------------
           -- 乘机人 !＝ 预订人
           -----------------------
           if vRemark in ('1') and vLxSjh!=vYdSjh then
             if iNum2 in (2,3) then
                vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
             end if ;
           end if ;
        else
           if iNum3>1 and vFillFlag = 0 or vFillFlag is null then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
              if vRemark in ('1') and vLxSjh!=vYdSjh then
                 vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
              end if ;
           else
              vResult := '{"code":"0","message":"国内机票,乘机人空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
           end if ;
        end if ;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国内机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

      ------------------------------------------------
    -- PLANE_CIVIL_PAY_REMIND:国内机票支付成功
    -- 发送给预订人
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_PAY_REMIND') then
      vId   := convertStrToInt(vId, -1);
      iNum1 := 0;
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId order by take_off_time) loop

        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------

      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        iNum1 := 1;
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --------------------------------------
        -- 获得预订人的手机号码
        --------------------------------------
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vId) loop
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name;

        end loop;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_PAY_REMIND';
       -- vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
       -- vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
        if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

         ------------------------------
        --  给客服发送短信通知 周一到周五 8点－19点  不发
        ------------------------------
        ------------------------------
        vWeek := to_char(sysdate-1,'D');
        if vWeek='6' or vWeek='0' then
          vFlag := 1;
        elsif to_char(sysdate,'hh24') <= '07' or to_char(sysdate,'hh24') >= '18' then
          vFlag := 1;
        else
          vFlag := 0;
        end if;
        --如果符合发送标准，则发送给客服
        if vFlag=1 and vFillFlag = 0 or vFillFlag is null then

              select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
              vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国内机票');
              vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
              vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
              vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);

              --给客服短信
              select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PLANE';
              --开始循环分割字段
              while(length(vTemp)>0) loop
              --如果有逗号，以逗号进行分割
                if INSTR(vTemp,',' ) > 0 then
                  vLxsjh := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
              --取到第n个逗号(也就是第n次循环)后面的剩余字符串
                  vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
                  vResult := insertToQueue(null, null, vTemplet2, vLxsjh, '7', null, null);
              --没有逗号，说明不需要分割
              else
                vResult := insertToQueue(null, null, vTemplet2, vTemp, '7', null, null);
                exit;
              end if;
            end loop;

        end if;

    end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_INTER_PAY_REMIND:国际机票支付成功
    -- 发送给预订人
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_PAY_REMIND') then
      vId   := convertStrToInt(vId, -1);
      iNum1 := 0;
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vId order by take_off_time) loop

        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------

      for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        iNum1 := 1;
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --------------------------------------
        -- 获得预订人的手机号码
        --------------------------------------
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vId ) loop
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.last_name || ' '|| rsCjr.first_name;

        end loop;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_PAY_REMIND';
        --vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        --vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
        if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
        vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

        ------------------------------
        --  给客服发送短信通知 周一到周五 早上8点－晚上7点 不发
        ------------------------------
        vWeek := to_char(sysdate-1,'D');
        if vWeek='6' or vWeek='0' then
          vFlag := 1;
        elsif to_char(sysdate,'hh24') <= '07' or to_char(sysdate,'hh24') >= '18' then
          vFlag := 1;
        else
          vFlag := 0;
        end if;
        --如果符合发送标准，则发送给客服
        if vFlag=1 and vFillFlag = 0 or vFillFlag is null then

              select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
              vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国际机票');
              vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
              vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
              vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);

              --给客服短信
              select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PLANE';
               --开始循环分割字段
            while(length(vTemp)>0)
              loop
                --如果有逗号，以逗号进行分割
                if INSTR(vTemp,',' ) > 0 then
                    vLxsjh := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
                   --取到第n个逗号(也就是第n次循环)后面的剩余字符串
                   vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
                   vResult := insertToQueue(null, null, vTemplet2, vLxsjh, '7', null, null);
                --没有逗号，说明不需要分割
                else
                    vResult := insertToQueue(null, null, vTemplet2, vTemp, '7', null, null);
                    exit;
                end if;

            end loop;

        end if;

    end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- TRAIN_CIVIL_PAY_REMIND:火车票支付成功

    -- 输入参数：{"templetid":"TRAIN_CIVIL_PAY_REMIND","id":"610","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('TRAIN_CIVIL_PAY_REMIND') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_train_trip where train_order_id = vId) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.depart_date, 'FMMM"月"DD"日"');

        vTemp3 := vTemp3 || rs.train_code || '次';
        vTemp3 := vTemp3 || rs.depart_time || rs.depart_station || '-';
        vTemp3 := vTemp3 || rs.arrive_time || rs.arrive_station ;
      end loop;
      -------------------------------------------------------------------------------------------------

      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsTrainOrder in (select * from T_CC_TRAIN_ORDER where train_order_id = vId and rownum <= 1) loop
        iNum1 := 1;
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsTrainOrder.IS_FILL_ORDER;

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '4';
        vOrderNo := rsTrainOrder.train_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsTrainOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------

        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsTrainOrder.Create_User_Id and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TRAIN_TICKET where train_order_id = vId ) loop

          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2 || rsCjr.Idc_Name ;
          ------------------------------

        end loop;
        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='TRAIN_CIVIL_PAY_REMIND';
       -- vTemplet1 := Replace(vTemplet1, '#DATE##CODE##TRIP#', vTemp3);
        --vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
         if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

        ------------------------------
        --  给客服发送短信通知
        ------------------------------
        select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','火车票');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);
        if vFillFlag = 0 or vFillFlag is null then
         --给客服小米短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
          vResult := insertToQueue(null,null,vTemplet2,vLxSjh, '7', null, null);
          --给客服火车票短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_HT';
          vResult := insertToQueue(null, null, vTemplet2, vLxSjh, '7', null, null);
        end if;
      end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"火车票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- HOTEL_CIVIL_PAY_REMIND:国内酒店支付完成
    -- 输入参数：{"templetid":"HOTEL_CIVIL_PAY_REMIND","id":"610","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('HOTEL_CIVIL_PAY_REMIND') then
      iNum1 := 0;
      vId   := vId;
      for rsHotelOrder in (select *
                             from T_CH_HOTEL_ORDER
                            where affiliate_confirmation_id = vId) loop
        --------------------------------------
        -- 获得模块&订单号&企业名称
        --------------------------------------
        --是否为补单
        vFillFlag := rsHotelOrder.IS_FILL_ORDER;

        vModule := '4';
        vOrderNo := rsHotelOrder.affiliate_confirmation_id;
        for rsCompany in (select * from T_base_company where company_id = rsHotelOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得预订人手机号
        --------------------------------------

        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsHotelOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='HOTEL_CIVIL_PAY_REMIND';

        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

         ------------------------------
        --  给客服发送短信通知
        ------------------------------
        select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','酒店');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);
        if vFillFlag = 0 or vFillFlag is null then
          --给客服小米短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
          vResult := insertToQueue(null,null,vTemplet2,vLxSjh, '7', null, null);
          --给客服酒店短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_HT';
          vResult := insertToQueue(null, null, vTemplet2, vLxSjh, '7', null, null);
        end if;
      end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"酒店订单不存在","memo":"N","templetid":"' ||vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;




     ------------------------------------------------
    -- PICK_UP_SB:接送客人
    -- 输入参数：{"templetid":"PICK_UP_SB","id":"610","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PICK_UP_SB') then
      vId   := vId;
      vTemp3 := '';
      for rs in (select * from T_CC_AIRPORT_SHUTTLE where SERVICE_ID = vId) loop

       select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PICK_UP_SB';
       vTemplet1 := Replace(vTemplet1, '#ORDERNO#', rs.plane_order_no);
       vLxSjh := rs.PHONE;
       vModule := '7';
       vOrderNo := rs.plane_order_no;
       --判断是否为补单，补单停止发送短信
       for rsPlaneOrder IN (select * from T_CC_PLANE_ORDER WHERE PLANE_ORDER_NO = vOrderNo) loop
          vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
       end loop;

       for rsCompany in (select * from T_base_company where company_id = rs.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        if vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
        end if;
      end loop;
      if vFillFlag = 0 or vFillFlag is null then
        update T_CC_AIRPORT_SHUTTLE t set t.notice_flag='1', t.notice_time = sysdate where t.SERVICE_ID = vId;
      end if;

    end if;


     ------------------------------------------------
    -- PLANE_CIVIL_CHANGE_REMIND:国内机票改签申请提醒

    -- 输入参数：{"templetid":"PLANE_CIVIL_CHANGE_REMIND","id":"changeId","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_CHANGE_REMIND') then

      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      -------------------------------------------------------------------------------------------------

      iNum1 := 1;

      for rsPlaneChange in (
        select t.change_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_PLANE_CHANGE t
          left join t_cc_plane_order m on t.plane_order_id = m.plane_order_id
            where change_id = vId and rownum <= 1) loop
        iNum1 := 1;
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneChange.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneChange.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneChange.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得申请人的手机号码
        --------------------------------------

        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneChange.apply_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_REMIND';

        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
         if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

         ------------------------------
        --  给客服发送短信通知
        ------------------------------
        select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国内机票改签');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);
        if vFillFlag = 0 or vFillFlag is null then
          --给客服小米短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
          vResult := insertToQueue(null,null,vTemplet2,vLxSjh, '7', null, null);
          --给客服火车票短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PL';
          vResult := insertToQueue(null, null, vTemplet2, vLxSjh, '7', null, null);
        end if;

      end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"改签申请不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_INTER_CHANGE_REMIND:国际机票改签申请提醒

    -- 输入参数：{"templetid":"PLANE_INTER_CHANGE_REMIND","id":"changeId","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_CHANGE_REMIND') then

      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      -------------------------------------------------------------------------------------------------

      iNum1 := 1;

      for rsPlaneChange in (
      select t.change_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id ,t.is_fill_order from T_CC_INTER_PLANE_CHANGE t
          left join t_cc_inter_plane_order m on t.plane_order_id = m.plane_order_id where change_id = vId and rownum <= 1
      ) loop
        iNum1 := 1;
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneChange.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneChange.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneChange.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得申请人的手机号码
        --------------------------------------

        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneChange.apply_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_CHANGE_REMIND';

        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
         if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

         ------------------------------
        --  给客服发送短信通知
        ------------------------------
        select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国际机票改签');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);
        if vFillFlag = 0 or vFillFlag is null then
          --给客服小米短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
          vResult := insertToQueue(null,null,vTemplet2,vLxSjh, '7', null, null);
          --给客服机票短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PL';
          vResult := insertToQueue(null, null, vTemplet2, vLxSjh, '7', null, null);
        end if;

      end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"改签申请不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


     ------------------------------------------------
    -- PLANE_CIVIL_REFUND_REMIND:国内机票退票申请提醒

    -- 输入参数：{"templetid":"PLANE_CIVIL_REFUND_REMIND","id":"refundId","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_REFUND_REMIND') then

      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      -------------------------------------------------------------------------------------------------

      iNum1 := 1;

      for rsPlaneRefund in (
      select t.refund_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_PLANE_REFUND t
          left join t_cc_plane_order m on t.plane_order_id = m.plane_order_id where refund_id = vId and rownum <= 1
      ) loop
        iNum1 := 1;
        vTemp2 := '';
        -- 是否为补单
        vFillFlag := rsPlaneRefund.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneRefund.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneRefund.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得申请人的手机号码
        --------------------------------------

        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneRefund.apply_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_REFUND_REMIND';

        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
         if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

         ------------------------------
        --  给客服发送短信通知
        ------------------------------
        select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国内机票退票');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);
        if vFillFlag = 0 or vFillFlag is null then
          --给客服小米短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
          vResult := insertToQueue(null,null,vTemplet2,vLxSjh, '7', null, null);
          --给客服火车票短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PL';
          vResult := insertToQueue(null, null, vTemplet2, vLxSjh, '7', null, null);
        end if;

      end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"退票申请不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_INTER_REFUND_REMIND:国际机票退票申请提醒

    -- 输入参数：{"templetid":"PLANE_INTER_REFUND_REMIND","id":"refundId","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_REFUND_REMIND') then

      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      -------------------------------------------------------------------------------------------------

      iNum1 := 1;

      for rsPlaneRefund in (
      select t.refund_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_INTER_PLANE_REFUND t
          left join t_cc_inter_plane_order m on t.plane_order_id = m.plane_order_id where refund_id = vId and rownum <= 1
      ) loop
        iNum1 := 1;
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneRefund.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneRefund.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneRefund.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得申请人的手机号码
        --------------------------------------

        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneRefund.apply_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_REFUND_REMIND';

        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
         if length(vYdSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);

        end if;

         ------------------------------
        --  给客服发送短信通知
        ------------------------------
        select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='REMIND_TO_US_PAY';
        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国际机票退票');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vYdSjh);
        if vFillFlag = 0 or vFillFlag is null then
          --给客服小米短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
          vResult := insertToQueue(null,null,vTemplet2,vLxSjh, '7', null, null);
          --给客服机票短信
          select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PL';
          vResult := insertToQueue(null, null, vTemplet2, vLxSjh, '7', null, null);
        end if;


      end loop;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"退票申请不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    ------------------------------------------------
    -- PLANE_CIVIL_FAIL_TO:国内机票出票失败
    -- 1.NO_PLANE_CIVIL_FAIL_TO_PASS:#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您火速预订其他航班啦，订单已经取消，谢谢您的支持！网上预订更方便，服务电话：4007239888
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_CIVIL_FAIL_TO_LINK:您预订的#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您为您的旅客火速预订其他航班，订单已经取消，谢谢您的支持！网上预订更方便，服务电话：4007239888
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_CIVIL_FAIL_TO","id":"610","remark":"1","telphone":"N"}
     -- 只需要发送给联系人/预订人
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_FAIL_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='NO_PLANE_CIVIL_FAIL_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_CIVIL_FAIL_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneOrder.plane_order_no;
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;

        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsPlaneOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vId and state = '4') loop
          iNum3  := iNum3+1;
          vKhSjh := NVL(Trim(rsCjr.Phone),'A');
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name||'票号'||rsCjr.Plane_Ticket_No;
          ------------------------------
          --  获得乘机人模板并替换信息
          ------------------------------
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='NO_PLANE_CIVIL_FAIL_TO_PASS';
         -- vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
         -- vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
         -- vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

          if Length(vKhSjh) = 11 then
            -------------------
            --　发送乘机人短信
            -------------------
           -- vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh);
            ------------------------------------------------
            --获得所有手机号，并分析
            --1.乘机人 ＝ 联系人　乘机人 ＝ 预订人
            --2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --3.乘机人 ＝ 联系人　乘机人!＝ 预订人
            --4.乘机人!＝ 联系人　乘机人 ＝ 预订人
            ------------------------------------------------
            if vKhSjh = vLxSjh and vKhSjh = vYdSjh then iNum2 := 1; end if ;
            if vKhSjh!= vLxSjh and vKhSjh!= vYdSjh then iNum2 := 2; end if ;
            if vKhSjh = vLxSjh and vKhSjh!= vYdSjh then iNum2 := 3; end if ;
            if vKhSjh!= vLxSjh and vKhSjh = vYdSjh then iNum2 := 4; end if ;
          else
            --------------------------------------------------
            -- 相当于 2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --------------------------------------------------
             iNum2 := 2;
          end if;
        end loop;
        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_FAIL_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#TOTAL#', rsPlaneOrder.SALE_PRICE);
       -- vTemplet1 := Replace(vTemplet1, '#NAME##ORDERNO#',vTemp2);
        --------------------------------
        if vFillFlag = 0 or vFillFlag is null then
              --发送联系手机--
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
        end if;
         -----------------------
         -- 预订人 !＝联系人
         -- 发送预订人
         -----------------------
         if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
         end if ;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国内机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_CIVIL_TIMEOUT_TO:国内机票出票超时
    -- 1.NO_PLANE_CIVIL_TIMEOUTL_TO_PASS:
    --
    -- 2.PLANE_CIVIL_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"PLANE_TIMEOUT_FAIL_TO","id":"610","remark":"1","telphone":"N"}
    --只需发给联系人/预订人
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_TIMEOUT_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='NO_PLANE_CIVIL_TIMEOUT_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_CIVIL_TIMEOUT_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsPlaneOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;

        ----------------------------------------------------------------
        -- 组合姓名,格式:姓名,姓名，存入vTemp2
        ----------------------------------------------------------------
        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vId ) loop
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name;
        end loop;

        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_TIMEOUT_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        --------------------------------
        if vFillFlag = 0 or vFillFlag is null then
          --发送联系手机--
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
        end if;
       -----------------------
       -- 预订人 !＝联系人
       -- 发送预订人
       -----------------------
       if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
       end if ;


        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国内机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;




    ------------------------------------------------
    -- PLANE_INTER_TIMEOUT_TO:国际机票出票超时
    -- 1.NO_PLANE_INTER_TIMEOUTL_TO_PASS:
    --
    -- 2.PLANE_INTER_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"PLANE_INTER_TIMEOUT_TO","id":"610","remark":"1","telphone":"N"}
    --只需发给联系人/预订人
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_TIMEOUT_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='NO_PLANE_INTER_TIMEOUT_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_INTER_TIMEOUT_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --判断是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '2';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vId ) loop
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.last_name || ' ' || rsCjr.First_Name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsPlaneOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_TIMEOUT_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        --------------------------------
        if vFillFlag = 0 or vFillFlag is null then
          --发送联系手机--
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
        end if;
       -----------------------
       -- 预订人 !＝联系人
       -- 发送预订人
       -----------------------
       if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
       end if ;


        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国际机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


     ------------------------------------------------
    -- PLANE_INTER_SUCCESS_TO:国际机票出票成功
    -- 1.PLANE_INTER_SUCCESS_TO_PASS:#TIME##FLIGHTNO##AIRPORT#，已经出票成功，#NAME#票号#ORDERNO#,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_INTER_SUCCESS_TO_LINK:您预定的#TIME##FLIGHTNO##AIRPORT#，出票成功并已短信通知乘客，#NAME##ORDERNO#,感谢您的预订！网上退改更方便的，有问题请致电：4007239888
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_INTER_SUCCESS_TO_PASS","id":"610","remark":"1","telphone":"N"}
    --两者都发
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_SUCCESS_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code||rs.flight_no || ' ';
        vTemp4 := vTemp || '(' || rs.airline_code || ')';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_SUCCESS_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_INTER_SUCCESS_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '2';
        vOrderNo := rsPlaneOrder.plane_order_no;
        --是否为补单，补单不发短信
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;

        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsPlaneOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vId and state = '3') loop
          iNum3  := iNum3+1;
          vKhSjh := NVL(Trim(rsCjr.Phone),'A');
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.last_Name|| ' '|| rsCjr.first_Name||'票号'||rsCjr.Plane_Ticket_No;
          ------------------------------
          --  获得乘机人模板并替换信息
          ------------------------------
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_SUCCESS_TO_PASS';
          vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.last_Name|| ' '|| rsCjr.first_Name);
          vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
          vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

          if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
            -------------------
            --　发送乘机人短信
            -------------------
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
            ------------------------------------------------
            --获得所有手机号，并分析
            --1.乘机人 ＝ 联系人　乘机人 ＝ 预订人
            --2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --3.乘机人 ＝ 联系人　乘机人!＝ 预订人
            --4.乘机人!＝ 联系人　乘机人 ＝ 预订人
            ------------------------------------------------
            if vKhSjh = vLxSjh and vKhSjh = vYdSjh then iNum2 := 1; end if ;
            if vKhSjh!= vLxSjh and vKhSjh!= vYdSjh then iNum2 := 2; end if ;
            if vKhSjh = vLxSjh and vKhSjh!= vYdSjh then iNum2 := 3; end if ;
            if vKhSjh!= vLxSjh and vKhSjh = vYdSjh then iNum2 := 4; end if ;
          else
            --------------------------------------------------
            -- 相当于 2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --------------------------------------------------
             iNum2 := 2;
          end if;
        end loop;
        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_SUCCESS_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME##ORDERNO#',vTemp2);
        if iNum2 =2 then
          vTemplet1 := Replace(vTemplet1, '订单金额#PRICE#,','');
        else
          vTemplet1 := Replace(vTemplet1, '#PRICE#',rsPlaneOrder.sale_price);
        end if;
        vTemplet1 := Replace(vTemplet1, '#AIRINFO#',vTemp4);
        --------------------------------
        -- 判断乘机人数量
        -- 一位乘机人
        -- 二位乘机人及以上
        --------------------------------
        if iNum3=1 and vFillFlag = 0 or vFillFlag is null then
           -----------------------
           -- 乘机人 !＝ 联系人
           -----------------------
           if iNum2 in (2,4) then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
           end if ;
           -----------------------
           -- 乘机人 !＝ 预订人
           -----------------------
           if vRemark in ('1') and vLxSjh!=vYdSjh then
             if iNum2 in (2,3) then
                vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
             end if ;
           end if ;
        else
           if iNum3>1 and vFillFlag = 0 or vFillFlag is null then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
              if vRemark in ('1') and vLxSjh!=vYdSjh then
                 vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
              end if ;
           else
              vResult := '{"code":"0","message":"国际机票,乘机人空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
           end if ;
        end if ;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国际机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

   ------------------------------------------------
    -- PLANE_INTER_FAIL_TO：国际机票出票失败
    -- 1.NO_PLANE_INTER_FAIL_TO_PASS:#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您火速预订其他航班啦，订单已经取消，谢谢您的支持！网上预订更方便，服务电话：4007239888
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_INTER_FAIL_TO_LINK:您预订的#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您为您的旅客火速预订其他航班，订单已经取消，谢谢您的支持！网上预订更方便，服务电话：4007239888
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_INTER_FAIL_TO","id":"610","remark":"1","telphone":"N"}
    --  只需发给联系人/预订人
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_FAIL_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------

      --联系人模板
    --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_INTER_FAIL_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------

      for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;

        vModule := '2';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsPlaneOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vYdSjh from dual;

        ------------------------------

        --发送联系手机--
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_FAIL_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#TOTAL#', rsPlaneOrder.SALE_PRICE);
        if vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
        end if;
        -----------------------
         -- 预订人 !＝联系人
         -- 发送预订人
        -----------------------
        if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
        end if ;

      end loop;

    end if;


     ------------------------------------------------
    -- PLANE_CIVIL_CHANGE_SUCCESS_TO:国内机票改签成功
    -- 1.PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS:您好:您的改签已完成,原#FLIGHTNOOLD##AIRPORT#,改为:#FLIGHTNONEW#,#TIME#,改签费#CHANGEFEE#,#NAME#票号#ORDERNO#,祝您旅途愉快
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK:您好:您申请的改签已完成,原#FLIGHTNOOLD##AIRPORT#,改为:#FLIGHTNONEW#,#TIME#,已短信通知乘机人,#NAME##ORDERNO#,祝生活愉快
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_CIVIL_CHANGE_SUCCESS_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_CHANGE_SUCCESS_TO') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      ---------------------------------------
      --获得旧行程vTemp1，再获得新行程vTemp2
      ---------------------------------------
      vTemp1 := '';
      vTemp2 := '';
      for rsCo in (select * from t_cc_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
        --旧行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by take_off_time) loop
          vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || rsPt.airline_code || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      for rsCo in (select * from t_cc_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
        --新行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by take_off_time) loop
          vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      -------------------------------------------
      -- 获得联系人（申请人）手机和改签费用vTemp3
      -------------------------------------------
      for rsPc in (select * from t_cc_plane_change where change_id = vId and state='3') loop
        iNum1 := 1;
        select nvl((select mobilephone from t_base_user where user_id=rsPc.Apply_User),'AA') into vLxSjh from dual;
        --改签费用
        vTemp3 := rsPc.sale_price;
        --是否为补单
        vFillFlag := rsPc.IS_FILL_ORDER;

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPc.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPc.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;
      --------------------------------------
      -- 新行程，获得乘机人信息
      --------------------------------------
      vTemp4 := '';
      iNum2  := 0;
      iNum3  := 0;
      for rsCjr in (select * from T_CC_TICKET_PASSENGER a1 where exists (select 0 from t_cc_change_ticket a2 where a2.change_id=vId and a2.plane_ticket_no=a1.plane_ticket_no) and state = '3') loop
        iNum3  := iNum3+1;
        vKhSjh := NVL(Trim(rsCjr.Phone),'A');
        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
        vTemp4 := vTemp4||rsCjr.Idc_Name||'票号'||rsCjr.Plane_Ticket_No;
        ------------------------------
        --  获得乘机人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS';
        vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);

        if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          -------------------
          --　发送乘机人短信
          -------------------
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
          ------------------------------------------------
          --获得所有手机号，并分析
          --1.乘机人 ＝ 联系人(申请人)
          --2.乘机人!＝ 联系人(申请人)
          ------------------------------------------------
          if vKhSjh = vLxSjh then iNum2 := 1; end if ;
          if vKhSjh!= vLxSjh then iNum2 := 2; end if ;
        else
          --------------------------------------------------
          -- 相当于 2.乘机人!＝ 联系人
          --------------------------------------------------
           iNum2 := 2;
        end if;
      end loop;

      ------------------------------
      --  获得联系人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK';
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);
      vTemplet1 := Replace(vTemplet1, '#NAME##ORDERNO#',vTemp4);
      if iNum2 = 2 then
        vTemplet1 := Replace(vTemplet1, '改签费用#PRICE#,','');
      else
        vTemplet1 := Replace(vTemplet1, '#PRICE#',vTemp3);
      end if;
      --------------------------------
      -- 判断乘机人数量
      -- 一位乘机人
      -- 二位乘机人及以上
      --------------------------------
      if iNum3=1 and vFillFlag = 0 or vFillFlag is null then
         -----------------------------
         -- 乘机人 !＝ 联系人(申请人)
         -----------------------------
         if iNum2 in (2) then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
         end if ;
      else
         if iNum3>1 and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
         else
            vResult := '{"code":"0","message":"国内机票改签,乘机人空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
         end if ;
      end if ;

      if Length(NVL(vResult, 'N')) < 10 then
        vResult := '{"code":"0","message":"国内机票改签,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票改签订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

     ------------------------------------------------
    -- PLANE_INTER_CHANGE_SUCCESS_TO:国际机票改签成功
    -- 1.PLANE_INTER_CHANGE_SUCCESS_TO_PASS:您好:您的改签已完成,原#FLIGHTNOOLD##AIRPORT#,改为:#FLIGHTNONEW#,#TIME#,改签费#CHANGEFEE#,#NAME#票号#ORDERNO#,祝您旅途愉快
    --   1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，已经出票成功，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 2.PLANE_INTER_CHANGE_SUCCESS_TO_LINK:您好:您申请的改签已完成,原#FLIGHTNOOLD##AIRPORT#,改为:#FLIGHTNONEW#,#TIME#,已短信通知乘机人,#NAME##ORDERNO#,祝生活愉快
    --   您预定的1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，出票成功并已短信通知乘客，李敏票号123-4567890123,感谢您的预订！祝您旅途愉快！网上退改更方便的，有问题请致电：4007239888
    -- 输入参数：{"templetid":"PLANE_INTER_CHANGE_SUCCESS_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_CHANGE_SUCCESS_TO') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      ---------------------------------------
      --获得旧行程vTemp1，再获得新行程vTemp2
      ---------------------------------------
      vTemp1 := '';
      vTemp2 := '';
      for rsCo in (select * from t_cc_inter_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
        --旧行程
        for rsPt in (select * from t_cc_inter_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by flight_index) loop
          vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || rsPt.airline_code || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      for rsCo in (select * from t_cc_inter_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
        --新行程
        for rsPt in (select * from t_cc_inter_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by flight_index) loop
          vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      -------------------------------------------
      -- 获得联系人（申请人）手机和改签费用vTemp3
      -------------------------------------------
      for rsPc in (select * from t_cc_inter_plane_change where change_id = vId ) loop
        iNum1 := 1;
        select nvl((select mobilephone from t_base_user where user_id=rsPc.Apply_User),'AA') into vLxSjh from dual;
        --改签费用
        vTemp3 := rsPc.sale_price;
        --是否为补单
        vFillFlag := rsPc.IS_FILL_ORDER;

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPc.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPc.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;
      --------------------------------------
      -- 新行程，获得乘机人信息
      --------------------------------------
      vTemp4 := '';
      iNum2  := 0;
      iNum3  := 0;
      for rsCjr in (select * from T_CC_inter_TICKET_PASSENGER a1 where exists (select 0 from t_cc_inter_change_ticket a2 where a2.change_id=vId and a2.plane_ticket_no=a1.plane_ticket_no) and state = '3') loop
        iNum3  := iNum3+1;
        vKhSjh := NVL(Trim(rsCjr.Phone),'A');
        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
        vTemp4 := vTemp4||rsCjr.Idc_Name||'票号'||rsCjr.Plane_Ticket_No;
        ------------------------------
        --  获得乘机人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS';
        vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);

        if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          -------------------
          --　发送乘机人短信
          -------------------
          vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
          ------------------------------------------------
          --获得所有手机号，并分析
          --1.乘机人 ＝ 联系人(申请人)
          --2.乘机人!＝ 联系人(申请人)
          ------------------------------------------------
          if vKhSjh = vLxSjh then iNum2 := 1; end if ;
          if vKhSjh!= vLxSjh then iNum2 := 2; end if ;
        else
          --------------------------------------------------
          -- 相当于 2.乘机人!＝ 联系人
          --------------------------------------------------
           iNum2 := 2;
        end if;
      end loop;

      ------------------------------
      --  获得联系人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK';
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);
      vTemplet1 := Replace(vTemplet1, '#NAME##ORDERNO#',vTemp4);
      if iNum2 = 2 then
        vTemplet1 := Replace(vTemplet1, '改签费用#PRICE#,','');
      else
        vTemplet1 := Replace(vTemplet1, '#PRICE#',vTemp3);
      end if;
      --------------------------------
      -- 判断乘机人数量
      -- 一位乘机人
      -- 二位乘机人及以上
      --------------------------------
      if iNum3=1 and vFillFlag = 0 or vFillFlag is null then
         -----------------------------
         -- 乘机人 !＝ 联系人(申请人)
         -----------------------------
         if iNum2 in (2) then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
         end if ;
      else
         if iNum3>1 and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
         else
            vResult := '{"code":"0","message":"国际机票改签,乘机人空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
         end if ;
      end if ;

      if Length(NVL(vResult, 'N')) < 10 then
        vResult := '{"code":"0","message":"国际机票改签,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票改签订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_CIVIL_CHANGE_TIMEOUT_TO:国内机票改签超时
    -- 1.NO_PLANE_CIVIL_CHANGE_TIMEOUT_TO_PASS:
    --
    -- 2.PLANE_CIVIL_CHANGE_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"PLANE_CIVIL_CHANGE_TIMEOUT_TO","id":"610","remark":"N","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_CHANGE_TIMEOUT_TO') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      ---------------------------------------
      --获得旧行程vTemp1，再获得新行程vTemp2
      ---------------------------------------
      vTemp1 := '';
      vTemp2 := '';
      for rsCo in (select * from t_cc_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
        --旧行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by take_off_time) loop
          vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || rsPt.airline_code || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      for rsCo in (select * from t_cc_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
        --新行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by take_off_time) loop
          vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      -------------------------------------------
      -- 获得联系人（申请人）手机和改签费用vTemp3
      -------------------------------------------
      for rsPc in (select * from t_cc_plane_change where change_id = vId ) loop
        iNum1 := 1;
        select nvl((select mobilephone from t_base_user where user_id=rsPc.Apply_User),'AA') into vLxSjh from dual;
        --改签费用
        vTemp3 := '111.11';
        --是否为补单
        vFillFlag := rsPc.IS_FILL_ORDER;

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '1';
        vOrderNo := rsPc.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPc.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;
      --------------------------------------
      -- 新行程，获得乘机人信息
      --------------------------------------
      vTemp4 := '';
      iNum2  := 0;
      iNum3  := 0;
      for rsCjr in (select * from T_CC_TICKET_PASSENGER a1 where exists (select 0 from t_cc_change_ticket a2 where a2.change_id=vId and a2.orig_plane_ticket_id=a1.plane_ticket_id) and state = '3') loop
        iNum3  := iNum3+1;
        vKhSjh := NVL(Trim(rsCjr.Phone),'A');
        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
        vTemp4 := vTemp4||rsCjr.Idc_Name;
        ------------------------------


      end loop;

      ------------------------------
      --  获得联系人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_CHANGE_TIMEOUT_TO_LINK';
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);
      vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp4);
      --------------------------------
      if vFillFlag = 0 or vFillFlag is null then
        vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
      end if;

      if Length(NVL(vResult, 'N')) < 10 then
        vResult := '{"code":"0","message":"国内机票改签,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票改签订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    -----------------------------------------------------------------------------------
     -- PLANE_CIVIL_REFUND_SUCCESS_TO:国内机票退票成功
    -- 1.PLANE_CIVIL_REFUND_SUCCESS_TO_PASS:您好，您的退票已完成，1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，李敏票号123-0123456，退票费：250。祝您生活愉快！网上退改更方便，服务电话：4007239888
    -- 2.PLANE_CIVIL_REFUND_SUCCESS_TO_LINK:您好，您申请的退票已完成，1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，李敏票号123-0123456（多个）。祝您生活愉快！网上退改更方便，服务电话：4007239888
    -- 输入参数：{"templetid":"PLANE_CIVIL_REFUND_SUCCESS_TO","id":"741","remark":"N","telphone":"N"}
    -- 有票号，两者都发（针对退票申请人link + 乘客）
    ------------------------------------------------
     if vTempletId in ('PLANE_CIVIL_REFUND_SUCCESS_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      iNum2 := 0;
      vId   := convertStrToInt(vId, -1);

      for rsRefundTicket in (
                  select DISTINCT a.plane_ticket_id,a.idc_name,a.phone,a.plane_ticket_no,a.apply_user,a.refund_no,a.company_id, a.plane_order_no ,a.IS_FILL_ORDER from (
          select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.apply_user,t1.refund_no,
          t1.plane_order_no,t1.company_id,t1.IS_FILL_ORDER,
          t6.plane_trip_id,t6.plane_od_id,t6.plane_order_id,t6.depart_city,t6.depart_city_code,
          t6.arrive_city,t6.arrive_city_code,t6.depart_airport,t6.depart_airport_code,t6.arrive_airport,t6.arrive_airport_code,
          t6.depart_airport_tower,t6.arrive_airport_tower,t6.take_off_time,t6.arrive_time,t6.flight_no

            from t_cc_plane_refund     t1,
                 t_cc_refund_ticket    t2,
                 t_cc_ticket_passenger t3,
                 t_cc_ticket_od        t4,
                 t_cc_plane_od         t5,
                 t_cc_plane_trip       t6
           where t1.refund_id = t2.refund_id
             and t2.plane_ticket_id = t3.plane_ticket_id
             and t3.plane_ticket_id = t4.plane_ticket_id
             and t4.plane_od_id = t5.plane_od_id
             and t5.plane_od_id = t6.plane_od_id
             and t1.refund_id = vId
           order by t3.plane_ticket_id, t6.take_off_time asc
           )a
      ) loop

      vLxSjh := rsRefundTicket.apply_user;
      iNum1 := iNum1 + 1 ;
      --是否为补单
      vFillFlag := rsRefundTicket.IS_FILL_ORDER;

      ----------------------------------------------------------------
      -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2 || rsRefundTicket.idc_name || '票号' || rsRefundTicket.Plane_Ticket_No;

       if iNum2 < 1 then
          --查询一张票的多个行程
          for rsRefundTrip in(
                      select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.APPLY_USER,t6.*
              from t_cc_plane_refund     t1,
                   t_cc_refund_ticket    t2,
                   t_cc_ticket_passenger t3,
                   t_cc_ticket_od        t4,
                   t_cc_plane_od         t5,
                   t_cc_plane_trip       t6
             where t1.refund_id = t2.refund_id
               and t2.plane_ticket_id = t3.plane_ticket_id
               and t3.plane_ticket_id = t4.plane_ticket_id
               and t4.plane_od_id = t5.plane_od_id
               and t5.plane_od_id = t6.plane_od_id
               and t1.refund_id = vId
               and t3.plane_ticket_id = rsRefundTicket.plane_ticket_id
             order by t3.plane_ticket_id, t6.take_off_time asc
          ) loop

            if NVL(vTemp3, 'N') != 'N' then
            vTemp3 := vTemp3 || '；';
            end if;
            vTemp3 := vTemp3 || to_char(rsRefundTrip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') ;
            --vTemp3 := vTemp3 || rsRefundTrip.depart_airport_name || '-' || rsRefundTrip.arrive_airport_name;
            select nvl((select city_name_cn from t_Base_City where city_code = rsRefundTrip.depart_city_code and rownum <= 1),rsRefundTrip.depart_city_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp || '-';
            select nvl((select city_name_cn from t_Base_City where city_code = rsRefundTrip.arrive_city_code and rownum <= 1),rsRefundTrip.arrive_city_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp  ;


          end loop;

          iNum2 := iNum2 + 1;
          end if;

        ------------------------------
        --  获得乘机人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_CIVIL_REFUND_SUCCESS_TO_PASS';
        vTemplet1 := Replace(vTemplet1, '#NAME#', rsRefundTicket.Idc_Name);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsRefundTicket.plane_ticket_no);
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

        vKhSjh := NVL(rsRefundTicket.phone,'N');
        vModule := '1';
        vOrderNo := rsRefundTicket.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsRefundTicket.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --给pass发送短信
        if length(NVL(vKhSjh, 'N')) = 11 and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
        end if;

      end loop;

      --pass超过1个人，给applyUser发送短信
      for rsUser in(select * from t_base_user where user_id = vLxSjh and rownum <= 1) loop
           vLxSjh := rsUser.mobilephone;
      end loop;
      --联系人模板
      select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_CIVIL_REFUND_SUCCESS_TO_LINK';
        vTemplet2 := Replace(vTemplet2, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
         vTemplet2 := Replace(vTemplet2, '#NAME##ORDERNO#', vTemp2);
         for rsSalePrice in (select sale_price from t_cc_plane_refund where refund_id = vId and rownum <= 1)loop
          vTemplet2 := Replace(vTemplet2, '#REFUNDFEE#', rsSalePrice.sale_price);
         end loop;

        if(iNum1 > 1) then

          if length(vLxSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
              vResult := insertToQueue(vTempletId,vId,vTemplet2,vLxSjh, vModule, vOrderNo, vCompanyName);
          end if;
        else --pass 1ren,给乘客+申请人发送
             --if vLxSjh != vKhSjh then
             if vFillFlag = 0 or vFillFlag is null then
                vResult := insertToQueue(vTempletId,vId,vTemplet2,vLxSjh, vModule, vOrderNo, vCompanyName);
            end if;
             -- end if;

        end if;

    end if;


    ------------------------------------------------
    -- PLANE_CIVIL_REFUND_TIMEOUT_TO:国内机票退票超时
    -- 1.NO_PLANE_CIVIL_REFUND_TIMEOUT_TO:
    --
    -- 2.PLANE_CIVIL_REFUND_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"PLANE_CIVIL_REFUND_TIMEOUT_TO","id":"refundId","remark":"N","telphone":"N"}
    -- 只需发给联系人（即退票申请人）
    ------------------------------------------------
   if vTempletId in ('PLANE_CIVIL_REFUND_TIMEOUT_TO') then
      iNum1 := 0;
      iNum2 := 0;

      vId   := convertStrToInt(vId, -1);

      for rsRefundTicket in (
                  select DISTINCT a.plane_ticket_id,a.idc_name,a.phone,a.plane_ticket_no,a.apply_user,a.refund_no,a.company_id, a.plane_order_no,a.IS_FILL_ORDER from (
          select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.apply_user,t1.refund_no,t6.*,t1.IS_FILL_ORDER
            from t_cc_plane_refund     t1,
                 t_cc_refund_ticket    t2,
                 t_cc_ticket_passenger t3,
                 t_cc_ticket_od        t4,
                 t_cc_plane_od         t5,
                 t_cc_plane_trip       t6
           where t1.refund_id = t2.refund_id
             and t2.plane_ticket_id = t3.plane_ticket_id
             and t3.plane_ticket_id = t4.plane_ticket_id
             and t4.plane_od_id = t5.plane_od_id
             and t5.plane_od_id = t6.plane_od_id
             and t1.refund_id = vId
           order by t3.plane_ticket_id, t6.take_off_time asc
           )a
      ) loop

      vLxSjh := rsRefundTicket.apply_user;
      --判断是否为补单
      vFillFlag := rsRefundTicket.IS_FILL_ORDER;
      iNum1 := iNum1 + 1 ;
      ----------------------------------------------------------------
      -- 组合姓名
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2 || rsRefundTicket.Idc_Name;
      ------------------------------
      if iNum2 < 1 then
          --查询一张票的多个行程
          for rsRefundTrip in(
                      select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.APPLY_USER,t6.*
              from t_cc_plane_refund     t1,
                   t_cc_refund_ticket    t2,
                   t_cc_ticket_passenger t3,
                   t_cc_ticket_od        t4,
                   t_cc_plane_od         t5,
                   t_cc_plane_trip       t6
             where t1.refund_id = t2.refund_id
               and t2.plane_ticket_id = t3.plane_ticket_id
               and t3.plane_ticket_id = t4.plane_ticket_id
               and t4.plane_od_id = t5.plane_od_id
               and t5.plane_od_id = t6.plane_od_id
               and t1.refund_id = vId
               and t3.plane_ticket_id = rsRefundTicket.plane_ticket_id
             order by t3.plane_ticket_id, t6.take_off_time asc
          ) loop

            if NVL(vTemp3, 'N') != 'N' then
            vTemp3 := vTemp3 || '；';
            end if;
            vTemp3 := vTemp3 || to_char(rsRefundTrip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') ;
            --vTemp3 := vTemp3 || rsRefundTrip.depart_airport_name || '-' || rsRefundTrip.arrive_airport_name;
            select nvl((select city_name_cn from t_Base_City where city_code = rsRefundTrip.depart_city_code and rownum <= 1),rsRefundTrip.depart_city_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp || '-';
            select nvl((select city_name_cn from t_Base_City where city_code = rsRefundTrip.arrive_city_code and rownum <= 1),rsRefundTrip.arrive_city_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp  ;

          end loop;

          iNum2 := iNum2 + 1;
        end if;

        vModule := '1';
        vOrderNo := rsRefundTicket.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsRefundTicket.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;

      for rsUser in(select * from t_base_user where user_id = vLxSjh and rownum <= 1) loop
           vLxSjh := rsUser.mobilephone;
        end loop;
      if length(vLxSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
            --联系人模板
          select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_CIVIL_REFUND_TIMEOUT_TO_LINK';
            vTemplet2 := Replace(vTemplet2, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
            vTemplet2 := Replace(vTemplet2, '#NAME#', vTemp2);
            vResult := insertToQueue(vTempletId,vId,vTemplet2,vLxSjh, vModule, vOrderNo, vCompanyName);
      end if;

    end if;

    ------------------------------------------------
    -- PLANE_INTER_REFUND_TIMEOUT_TO:国际机票退票超时
    -- 1.NO_PLANE_INTER_REFUND_TIMEOUT_TO:
    --
    -- 2.PLANE_INTER_REFUND_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"PLANE_INTER_REFUND_TIMEOUT_TO","id":"610","remark":"1","telphone":"N"}
    -- 只需发给联系人（退票申请人）
    ------------------------------------------------
   if vTempletId in ('PLANE_INTER_REFUND_TIMEOUT_TO') then
      iNum1 := 0;
      iNum2 := 0;

      vId   := convertStrToInt(vId, -1);

      for rsRefundTicket in (
                 select DISTINCT a.plane_ticket_id,a.last_name, a.first_name,a.phone,a.plane_ticket_no,a.apply_user,a.refund_no,a.company_id ,a.plane_order_no,a.IS_FILL_ORDER from (
          select t3.plane_ticket_id, t3.last_name,t3.first_name, t3.phone,t3.plane_ticket_no, t1.apply_user,t1.refund_no,t6.*,t1.IS_FILL_ORDER
            from t_cc_inter_plane_refund     t1,
                 t_cc_inter_refund_ticket    t2,
                 t_cc_inter_ticket_passenger t3,
                 t_cc_inter_ticket_od        t4,
                 t_cc_inter_plane_od         t5,
                 t_cc_inter_plane_trip       t6
           where t1.refund_id = t2.refund_id
             and t2.plane_ticket_id = t3.plane_ticket_id
             and t3.plane_ticket_id = t4.plane_ticket_id
             and t4.plane_od_id = t5.plane_od_id
             and t5.plane_od_id = t6.plane_od_id
             and t1.refund_id = vId
           order by t3.plane_ticket_id, t6.take_off_time asc
           )a
      ) loop

      vLxSjh := rsRefundTicket.apply_user;
      --判断是否为补单
      vFillFlag := rsRefundTicket.IS_FILL_ORDER;

      iNum1 := iNum1 + 1 ;
      ----------------------------------------------------------------
      -- 组合姓名
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2 || rsRefundTicket.last_name || ' '|| rsRefundTicket.first_name;
      ------------------------------
      if iNum2 < 1 then
          --查询一张票的多个行程
          for rsRefundTrip in(
                      select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.APPLY_USER,t6.*
              from t_cc_inter_plane_refund     t1,
                   t_cc_inter_refund_ticket    t2,
                   t_cc_inter_ticket_passenger t3,
                   t_cc_inter_ticket_od        t4,
                   t_cc_inter_plane_od         t5,
                   t_cc_inter_plane_trip       t6
             where t1.refund_id = t2.refund_id
               and t2.plane_ticket_id = t3.plane_ticket_id
               and t3.plane_ticket_id = t4.plane_ticket_id
               and t4.plane_od_id = t5.plane_od_id
               and t5.plane_od_id = t6.plane_od_id
               and t1.refund_id = vId
               and t3.plane_ticket_id = rsRefundTicket.plane_ticket_id
             order by t3.plane_ticket_id, t6.take_off_time asc
          ) loop

            if NVL(vTemp3, 'N') != 'N' then
            vTemp3 := vTemp3 || '；';
            end if;
            vTemp3 := vTemp3 || to_char(rsRefundTrip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') ;
            --vTemp3 := vTemp3 || rsRefundTrip.depart_airport_name || '-' || rsRefundTrip.arrive_airport_name;
            select nvl((select city_name_cn from t_Base_City where city_code = rsRefundTrip.depart_city_code and rownum <= 1),rsRefundTrip.depart_city_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp || '-';
            select nvl((select city_name_cn from t_Base_City where city_code = rsRefundTrip.arrive_city_code and rownum <= 1),rsRefundTrip.arrive_city_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp  ;

          end loop;

          iNum2 := iNum2 + 1;
        end if;

        vModule := '1';
        vOrderNo := rsRefundTicket.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsRefundTicket.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;

      for rsUser in(select * from t_base_user where user_id = vLxSjh and rownum <= 1) loop
           vLxSjh := rsUser.mobilephone;
        end loop;
      if length(vLxSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
            --联系人模板
          select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_INTER_REFUND_TIMEOUT_TO_LINK';
            vTemplet2 := Replace(vTemplet2, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
            vTemplet2 := Replace(vTemplet2, '#NAME#', vTemp2);
            vResult := insertToQueue(vTempletId,vId,vTemplet2,vLxSjh, vModule, vOrderNo, vCompanyName);
      end if;

    end if;


     -----------------------------------------------------------------------------------
     -- PLANE_INTER_REFUND_SUCCESS_TO:国际机票退票成功
    -- 1.PLANE_INTER_REFUND_SUCCESS_TO_PASS:您好，您的退票已完成，1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，李敏票号123-0123456，退票费：250。祝您生活愉快！网上退改更方便，服务电话：4007239888
    -- 2.PLANE_INTER_REFUND_SUCCESS_TO_LINK:您好，您申请的退票已完成，1月14日6:40-7:40中国国航CA1285北京首都T3-朝阳，李敏票号123-0123456（多个）。祝您生活愉快！网上退改更方便，服务电话：4007239888
    -- 输入参数：{"templetid":"PLANE_INTER_REFUND_SUCCESS_TO","id":"610","remark":"N","telphone":"N"}
    -- 两者都发（PASS + 退票申请人）
    ------------------------------------------------
     if vTempletId in ('PLANE_INTER_REFUND_SUCCESS_TO') then
      iNum1 := 0;
      iNum2 := 0;
      vId   := convertStrToInt(vId, -1);

      for rsRefundTicket in (
                  select DISTINCT a.plane_ticket_id,a.last_name,a.first_name,a.phone,a.plane_ticket_no,a.apply_user,a.refund_no,a.company_id, a.plane_order_no,a.IS_FILL_ORDER from (
          select t3.plane_ticket_id, t3.last_name,t3.first_name, t3.phone,t3.plane_ticket_no, t1.apply_user,t1.refund_no,
          t1.plane_order_no,t1.company_id,t1.IS_FILL_ORDER,
          t6.plane_trip_id,t6.plane_od_id,t6.plane_order_id,t6.depart_city,t6.depart_city_code,
          t6.arrive_city,t6.arrive_city_code,t6.depart_airport,t6.depart_airport_code,t6.arrive_airport,t6.arrive_airport_code,
          t6.depart_airport_tower,t6.arrive_airport_tower,t6.take_off_time,t6.arrive_time,t6.flight_no
            from t_cc_inter_plane_refund     t1,
                 t_cc_inter_refund_ticket    t2,
                 t_cc_inter_ticket_passenger t3,
                 t_cc_inter_ticket_od        t4,
                 t_cc_inter_plane_od         t5,
                 t_cc_inter_plane_trip       t6
           where t1.refund_id = t2.refund_id
             and t2.plane_ticket_id = t3.plane_ticket_id
             and t3.plane_ticket_id = t4.plane_ticket_id
             and t4.plane_od_id = t5.plane_od_id
             and t5.plane_od_id = t6.plane_od_id
             and t1.refund_id = vId
           order by t3.plane_ticket_id, t6.take_off_time asc
           )a
      ) loop

      vLxSjh := rsRefundTicket.apply_user;
      iNum1 := iNum1 + 1 ;
      --判断是否为补单
      vFillFlag := rsRefundTicket.IS_FILL_ORDER;
      ----------------------------------------------------------------
      -- ×éo?D???oí?±o?,??ê?:D???010-0001,D???010-0001￡?′?è?vTemp2
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2 || rsRefundTicket.last_name || ' '|| rsRefundTicket.first_name || '票号' || rsRefundTicket.Plane_Ticket_No;

      if iNum2 < 1 then
        --2é?ˉò????±μ??à??DD3ì
          for rsRefundTrip in(
                       select t3.plane_ticket_id, t6.*
                  from t_cc_inter_plane_refund     t1,
                       t_cc_inter_refund_ticket    t2,
                       t_cc_inter_ticket_passenger t3,
                       t_cc_inter_ticket_od        t4,
                       t_cc_inter_plane_od         t5,
                       t_cc_inter_plane_trip       t6
                 where t1.refund_id = t2.refund_id
                   and t2.plane_ticket_id = t3.plane_ticket_id
                   and t3.plane_ticket_id = t4.plane_ticket_id
                   and t4.plane_od_id = t5.plane_od_id
                   and t5.plane_od_id = t6.plane_od_id
                   and t1.refund_id = vId
                   and t3.plane_ticket_id = rsRefundTicket.plane_ticket_id
                 order by t3.plane_ticket_id, t6.take_off_time asc

          ) loop


          if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
          end if;
          vTemp3 := vTemp3 || to_char(rsRefundTrip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') ;
          select nvl((select city_name_cn from T_BASE_city where city_code = rsRefundTrip.depart_city_code and rownum <= 1),rsRefundTrip.depart_city_code) into vTemp from dual;
          vTemp3 := vTemp3 || vTemp || '-' ;
          select nvl((select city_name_cn from T_BASE_city where city_code = rsRefundTrip.arrive_city_code and rownum <= 1),rsRefundTrip.arrive_city_code) into vTemp from dual;
          vTemp3 := vTemp3 || vTemp  ;

          end loop;

        iNum2 := iNum2+1;
        end if;

        ------------------------------
        --  ??μ?3??úè??￡°?2￠ì???D??￠
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_REFUND_SUCCESS_TO_PASS';
        vTemplet1 := Replace(vTemplet1, '#NAME#', rsRefundTicket.last_name || ' ' || rsRefundTicket.first_name);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsRefundTicket.plane_order_no);
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

        vKhSjh := NVL(rsRefundTicket.phone,'N');
        vModule := '2';
        vOrderNo := rsRefundTicket.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsRefundTicket.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --??pass?￠?í?ìD?
        if length(NVL(vKhSjh, 'N')) = 11 and vFillFlag = 0 or vFillFlag is null then
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
        end if;

      end loop;

      --pass3?1y1??è?￡???applyUser?￠?í?ìD?
      for rsUser in(select * from t_base_user where user_id = vLxSjh and rownum <= 1) loop
           vLxSjh := rsUser.mobilephone;
      end loop;
      --áa?μè??￡°?
      select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='PLANE_INTER_REFUND_SUCCESS_TO_LINK';
        vTemplet2 := Replace(vTemplet2, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
         vTemplet2 := Replace(vTemplet2, '#NAME##ORDERNO#', vTemp2);
           for rsSalePrice in (select sale_price from t_cc_inter_plane_refund where refund_id = vId and rownum <= 1)loop
          vTemplet2 := Replace(vTemplet2, '#REFUNDFEE#', rsSalePrice.sale_price);
         end loop;
        if(iNum1 > 1) and vFillFlag = 0 or vFillFlag is null then

          if length(vLxSjh) = 11 then
              vResult := insertToQueue(vTempletId,vId,vTemplet2,vLxSjh, vModule, vOrderNo, vCompanyName);
          end if;
        else --pass 1ren
             if vLxSjh != vKhSjh and vFillFlag = 0 or vFillFlag is null then
              vResult := insertToQueue(vTempletId,vId,vTemplet2,vLxSjh, vModule, vOrderNo, vCompanyName);
              end if;

        end if;
    end if;


/*     ------------------------------------------------
    -- HOTEL_SUCCESS_TO:国内酒店订单
    -- 1.HOTEL_SUCCESS_TO_PASS:#NAME#，#TWODATE#入住#HOTEL_NAME#(#HOTEL_ADD#，#HOTEL_PHONE#)，房间保留到#LATESTTIME#，订单号#ID#。此单通过代理商预订，请直接报#NAME#姓名办理入住，谢谢！网上预订更方便，服务电话：4007239888
    -- 2.HOTEL_SUCCESS_TO_LINK:
    -- 输入参数：{"templetid":"HOTEL_SUCCESS_TO_PASS","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('HOTEL_SUCCESS_TO') then
      iNum1 := 0;
      vId   := vId;
      for rsHotelOrder in (select *
                             from T_CH_HOTEL_ORDER
                            where affiliate_confirmation_id = vId) loop
        iNum1    := 1;
        vTemplet := replace(vTemplet,
                            '#TWODATE#',
                            to_char(rsHotelOrder.Arrival_Date, 'FMMM/DD') || '-' ||
                            to_char(rsHotelOrder.Departure_Date, 'FMMM/DD'));
        vTemplet := replace(vTemplet,
                            '#HOTEL_NAME#',
                            rsHotelOrder.Hotel_Name);
        if length(nvl(trim(rsHotelOrder.Room_Type_Name), 'N')) > 2 then
           if nvl(rsHotelOrder.Number_Of_Rooms,1)>1 then
              vTemplet := replace(vTemplet,'#HOTEL_ADD#',rsHotelOrder.Hotel_Address||','||rsHotelOrder.Room_Type_Name||','||rsHotelOrder.Number_Of_Rooms||'间');
           else
              vTemplet := replace(vTemplet,'#HOTEL_ADD#',rsHotelOrder.Hotel_Address||','||rsHotelOrder.Room_Type_Name);
           end if ;
        else
          vTemplet := replace(vTemplet,
                              '#HOTEL_ADD#',
                              rsHotelOrder.Hotel_Address);
        end if;
        vTemplet := replace(vTemplet,
                            '#HOTEL_PHONE#',
                            rsHotelOrder.Hotel_Phone);
        vTemplet := replace(vTemplet,
                            '#ID#',
                            rsHotelOrder.Affiliate_Confirmation_Id);
        vTemplet := replace(vTemplet,
                            '#LATESTTIME#',
                            to_char(rsHotelOrder.Latest_Arrival_Time, 'hh24'));

        --入住人
        vTemplet1 := '';
        --订票人
        vTemplet2 := '';
        --常用联系人
        for rsHotelCus0 in (select * from T_CH_ORDER_CUSTOMER where affiliate_confirmation_id = rsHotelOrder.Affiliate_Confirmation_Id and is_user = 0) loop
          for rsHotelCus0User in (select * from T_BASE_GENERAL_CONTACT where contact_id = rsHotelCus0.Fre_Id) loop
            vTelphone := Trim(rsHotelCus0User.Phone);
            vTemplet1 := vTemplet;
            vTemplet1 := replace(vTemplet1,'#NAME#',rsHotelCus0User.Name);
            if Length(vTelphone) = 11 then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vTelphone, vModule, vOrderNo, vCompanyName);
              if vTelphone != rsHotelOrder.Contact_Mobile then
                 vResult := insertToQueue(vTempletId,vId,vTemplet1,rsHotelOrder.Contact_Mobile, vModule, vOrderNo, vCompanyName);
              end if ;
            else
              vResult := insertToQueue(vTempletId,vId,vTemplet1,rsHotelOrder.Contact_Mobile, vModule, vOrderNo, vCompanyName);
            end if;
          end loop;
        end loop;
        --员工
        for rsHotelCus1 in (select * from T_CH_ORDER_CUSTOMER where affiliate_confirmation_id = rsHotelOrder.Affiliate_Confirmation_Id and is_user = 1) loop
          for rsHotelCus1User in (select * from T_BASE_USER where user_id = rsHotelCus1.Fre_Id) loop
            vTelphone := Trim(rsHotelCus1User.Mobilephone);
            vTemplet1 := vTemplet;
            vTemplet1 := replace(vTemplet1,'#NAME#',rsHotelCus1User.Name_Cn);
            if Length(vTelphone) = 11 then
              vResult := insertToQueue(vTempletId, vId, vTemplet1, vTelphone, vModule, vOrderNo, vCompanyName);
              if vTelphone != rsHotelOrder.Contact_Mobile then
                 vResult := insertToQueue(vTempletId, vId, vTemplet1, vTelphone, vModule, vOrderNo, vCompanyName);
              end if ;
            else
              vResult := insertToQueue(vTempletId, vId, vTemplet1, vTelphone, vModule, vOrderNo, vCompanyName);
            end if;
          end loop;
        end loop;



        --是否发联系人
        --if iNum1 = 1 then
        --  vTelphone := Trim(rsHotelOrder.Contact_Mobile);
        --  if Length(vTelphone) = 11 then
        --    vTemplet1 := vTemplet;
        --    vTemplet1 := replace(vTemplet1, '#NAME#',rsHotelOrder.Contact_Name);
        --    vResult   := insertToQueue(vTempletId, vId, vTemplet1, vTelphone);
        --  end if;
        --end if;
        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国内酒店,手机号空导致未生成短信","memo":"N","templetid":"' ||vTempletId || '","id":"' || vId || '"}';
        end if;
        --vResult := '{"code":"1","message":"OK","memo":"N","templetid":"'||vTempletId||'","id":"'||vId||'"}';
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"酒店订单不存在","memo":"N","templetid":"' ||vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;
    */



    ------------------------------------------------
    -- TRAIN_SUCCESS_TO:火车票出票成功
    -- 1.TRAIN_SUCCESS_TO_PASS:
    --
    -- 2.TRAIN_SUCCESS_TO_LINK:
    --
    -- 输入参数：{"templetid":"TRAIN_SUCCESS_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('TRAIN_SUCCESS_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_train_trip where train_order_id = vId) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.depart_date, 'FMMM"月"DD"日"');

        vTemp3 := vTemp3 || rs.train_code || '次';
        vTemp3 := vTemp3 || rs.depart_time || rs.depart_station || '-';
        vTemp3 := vTemp3 || rs.arrive_time || rs.arrive_station ;
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='TRAIN_SUCCESS_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='TRAIN_SUCCESS_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsTrainOrder in (select * from T_CC_TRAIN_ORDER where train_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --判断是否为补单
        vFillFlag := rsTrainOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '4';
        vOrderNo := rsTrainOrder.train_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsTrainOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsTrainOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsTrainOrder.Create_User_Id and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TRAIN_TICKET where train_order_id = vId and state = '3') loop
          iNum3  := iNum3+1;
          vKhSjh := NVL(Trim(rsCjr.Phone),'A');
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2 || rsCjr.Idc_Name || rsCjr.Train_Box || '车' || rsCjr.Seat_No || '座';
          ------------------------------
          --  获得乘机人模板并替换信息
          ------------------------------
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='TRAIN_SUCCESS_TO_PASS';
          vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
          vTemplet1 := Replace(vTemplet1, '#SEAT#',rsCjr.Train_Box || '车' || rsCjr.Seat_No || '座');
          vTemplet1 := Replace(vTemplet1, '#DATE##CODE##TRIP#', vTemp3);
          vTemplet1 := Replace(vTemplet1, '#SUP_BILL_NO#', rsTrainOrder.SUP_BILL_NO);

          if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
            -------------------
            --　发送乘机人短信
            -------------------
            vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh, vModule, vOrderNo, vCompanyName);
            ------------------------------------------------
            --获得所有手机号，并分析
            --1.乘机人 ＝ 联系人　乘机人 ＝ 预订人
            --2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --3.乘机人 ＝ 联系人　乘机人!＝ 预订人
            --4.乘机人!＝ 联系人　乘机人 ＝ 预订人
            ------------------------------------------------
            if vKhSjh = vLxSjh and vKhSjh = vYdSjh then iNum2 := 1; end if ;
            if vKhSjh!= vLxSjh and vKhSjh!= vYdSjh then iNum2 := 2; end if ;
            if vKhSjh = vLxSjh and vKhSjh!= vYdSjh then iNum2 := 3; end if ;
            if vKhSjh!= vLxSjh and vKhSjh = vYdSjh then iNum2 := 4; end if ;
          else
            --------------------------------------------------
            -- 相当于 2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --------------------------------------------------
             iNum2 := 2;
          end if;
        end loop;
        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='TRAIN_SUCCESS_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#DATE##CODE##TRIP#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME##SEAT#',vTemp2);
         vTemplet1 := Replace(vTemplet1, '#SUP_BILL_NO#', rsTrainOrder.SUP_BILL_NO);
        --------------------------------
        -- 判断乘机人数量
        -- 一位乘机人
        -- 二位乘机人及以上
        --------------------------------
        if iNum3=1 and vFillFlag = 0 or vFillFlag is null  then
           -----------------------
           -- 乘机人 !＝ 联系人
           -----------------------
           if iNum2 in (2,4) then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
           end if ;
           -----------------------
           -- 乘机人 !＝ 预订人
           -----------------------
           if vRemark in ('1') and vLxSjh!=vYdSjh then
             if iNum2 in (2,3) then
                vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
             end if ;
           end if ;
        else
           if iNum3>1 and vFillFlag = 0 or vFillFlag is null then
              vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
              if vRemark in ('1') and vLxSjh!=vYdSjh then
                 vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
              end if ;
           else
              vResult := '{"code":"0","message":"火车票，乘机人空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
           end if ;
        end if ;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"火车票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"火车票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

      ------------------------------------------------
    -- TRAIN_FAIL_TO:火车票出票失败
    -- 1.TRAIN_FAIL_TO_PASS:
    --
    -- 2.TRAIN_FAIL_TO_LINK:
    --
    -- 输入参数：{"templetid":"TRAIN_FAIL_TO","id":"610","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('TRAIN_FAIL_TO') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_train_trip where train_order_id = vId) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.depart_date, 'FMMM"月"DD"日"HH24:FMMI');

        vTemp3 := vTemp3 || rs.train_code || '次';
        vTemp3 := vTemp3 || rs.depart_time || rs.depart_station || '-';
        vTemp3 := vTemp3 || rs.arrive_time || rs.arrive_station ;
      end loop;
      -------------------------------------------------------------------------------------------------
      --乘机人模板
      --select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='TRAIN_FAIL_TO_PASS';
      --联系人模板
      --select nvl(Text1, 'N') into vTemplet2 from t_base_templet where code='TRAIN_FAIL_TO_LINK';
      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsTrainOrder in (select * from T_CC_TRAIN_ORDER where train_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsTrainOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '4';
        vOrderNo := rsTrainOrder.train_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsTrainOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        --------------------------------------
        -- 获得联系和预订人的手机号码
        --------------------------------------
        vLxSjh := rsTrainOrder.Contact_Phone;
        vYdSjh := 'N';
        select nvl((select mobilephone from t_base_user where user_id=rsTrainOrder.Create_User_Id and rownum<=1),'N') into vYdSjh from dual;
        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TRAIN_TICKET where train_order_id = vId and state = '4') loop
          iNum3  := iNum3+1;
          vKhSjh := NVL(Trim(rsCjr.Phone),'A');
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2 || rsCjr.Idc_Name || rsCjr.Train_Box || '车' || rsCjr.Seat_No || '座';
          ------------------------------
          --  获得乘机人模板并替换信息
          ------------------------------
          select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='NO_TRAIN_FAIL_TO_PASS';
         -- vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
         -- vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
         -- vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

          if Length(vKhSjh) = 11 then
            -------------------
            --　发送乘机人短信
            -------------------
           -- vResult := insertToQueue(vTempletId,vId,vTemplet1,vKhSjh);
            ------------------------------------------------
            --获得所有手机号，并分析
            --1.乘机人 ＝ 联系人　乘机人 ＝ 预订人
            --2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --3.乘机人 ＝ 联系人　乘机人!＝ 预订人
            --4.乘机人!＝ 联系人　乘机人 ＝ 预订人
            ------------------------------------------------
            if vKhSjh = vLxSjh and vKhSjh = vYdSjh then iNum2 := 1; end if ;
            if vKhSjh!= vLxSjh and vKhSjh!= vYdSjh then iNum2 := 2; end if ;
            if vKhSjh = vLxSjh and vKhSjh!= vYdSjh then iNum2 := 3; end if ;
            if vKhSjh!= vLxSjh and vKhSjh = vYdSjh then iNum2 := 4; end if ;
          else
            --------------------------------------------------
            -- 相当于 2.乘机人!＝ 联系人　乘机人!＝ 预订人
            --------------------------------------------------
             iNum2 := 2;
          end if;
        end loop;
        ------------------------------
        --  获得联系人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='TRAIN_FAIL_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#DATE##CODE##TRIP#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#TOTAL#', rsTrainOrder.SALE_PRICE);
         if Length(rsTrainOrder.ticketing_remark) > 0 and vFillFlag = 0 or vFillFlag is null then

            if(instr(rsTrainOrder.ticketing_remark, '余额不足') > 0 ) then

               --由于我司余额不足，需发送短信给客服+徐博仁+财务+等等
              select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'REMIND_TRAIN_YEBZ';
              vTemplet2 := '合作商余额不足，暂时停用，请充值后通知服务商重新启用！';
               --开始循环分割字段
            while(length(vTemp)>0)
              loop
                --如果有逗号，以逗号进行分割
                if INSTR(vTemp,',' ) > 0 then
                    vLxsjh := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
                   --取到第n个逗号(也就是第n次循环)后面的剩余字符串
                   vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
                   vResult := insertToQueue(null, null, vTemplet2, vLxsjh, '7', null, null);
                --没有逗号，说明不需要分割
                else
                    vResult := insertToQueue(null, null, vTemplet2, vTemp, '7', null, null);
                    exit;
                end if;

            end loop;

                --并且发送短信给客户'出票失败'
                 vTemplet1 := Replace(vTemplet1, '#REASON#', '');

            else
                --把原因发送给客户
                vTemplet1 := Replace(vTemplet1, '#REASON#', '(' || rsTrainOrder.ticketing_remark || ')');
            end if;


           ELSE
           vTemplet1 := Replace(vTemplet1, '#REASON#', '');
        end if;



        ------------------------------
        --发送给联系人
        ------------------------------
        vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
        if vRemark in ('1') and vLxSjh!=vYdSjh and vFillFlag = 0 or vFillFlag is null then
           vResult := insertToQueue(vTempletId,vId,vTemplet1,vYdSjh, vModule, vOrderNo, vCompanyName);
        end if ;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"火车票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"火车票","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    ------------------------------------------------
    -- TRAIN_FAIL_TO:火车票出票失败  只发给客服
    -- 1.TRAIN_FAIL_SUSPENDING:
    --
    -- 输入参数：{"templetid":"TRAIN_FAIL_SUSPENDING","id":"610
    --------------------------------------------------

    if vTempletId in ('TRAIN_FAIL_SUSPENDING') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
       for rsTrainOrder in (select * from T_CC_TRAIN_ORDER where train_order_id = vId and rownum <= 1) loop
        iNum1 := 1;
        vModule :='4';
        vTelphone := '13285110079';
        --是否为补单
        vFillFlag := rsTrainOrder.IS_FILL_ORDER;
        --获得乘机人模版
        select nvl(Text1, 'N') into vTemplet from t_base_templet where code='TRAIN_FAIL_SUSPENDING';

        vTemplet := replace(vTemplet, '#TRAINORDER#', rsTrainOrder.train_order_no);
        if vFillFlag  = 0 then
          --插入短信
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
          vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
    end if;





    -----------------------------------------------------------------------------------
    -- 获得临时密码的消息模板 TEMP_PASSWORD
    -- 1.传递用户ID
    -- 2.其他为N
    -- 3.{"templetid":"TEMP_PASSWORD","id":"221","remark":"N1234567","telphone":"17712613261"}
    -- 亲爱的用户：您好！您已经成功获得临时密码了！密码为#PASSWORD#，请在#MINUTE#分钟之内用此密码登录，否则失效！
    -- 由于临时密码已经加密，密码通过remark字段传递，非rsUser.temp_password
    -----------------------------------------------------------------------------------
    if vTempletId in ('TEMP_PASSWORD') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        if Length(nvl(rsUser.temp_password, 'N')) < 3 then
          vResult := '{"code":"0","message":"临时密码错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        if length(vRemark) != 8 then
          vResult := '{"code":"0","message":"临时密码长度非8个字符","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTemplet := replace(vTemplet, '#PASSWORD#', vRemark);
        select nvl((select value
                     from t_base_config_const
                    where name = 'LOGIN_FALSE_LATER_TIME'
                      and rownum <= 1),
                   '30')
          into vTemp
          from dual;
        vTemplet := replace(vTemplet, '#MINUTE#', vTemp);
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    -----------------------------------------------------------------------------------
    -- 获得临时交易密码的消息模板 TEMP_PAYPASSWORD
    -- 1.传递用户ID
    -- 2.其他为N
    -- 3.{"templetid":"TEMP_PAYPASSWORD","id":"221","remark":"N1234567","telphone":"17712613261"}
    -- 尊敬的客户：您的临时交易密码为#PAYPASSWORD#，#MINUTE#分钟内使用即有效
    -- 由于临时密码已经加密，密码通过remark字段传递，非rsUser.temp_password
    -----------------------------------------------------------------------------------
    if vTempletId in ('TEMP_PAYPASSWORD') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        if Length(nvl(rsUser.TEMP_PAY_PASSWORD, 'N')) < 3 then
          vResult := '{"code":"0","message":"临时交易密码错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        if length(vRemark) != 6 then
          vResult := '{"code":"0","message":"临时交易密码长度非6个数字","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTemplet := replace(vTemplet, '#PAYPASSWORD#', vRemark);
        select nvl((select value
                     from t_base_config_const
                    where name = 'LOGIN_FALSE_LATER_TIME'
                      and rownum <= 1),
                   '30')
          into vTemp
          from dual;
        vTemplet := replace(vTemplet, '#MINUTE#', vTemp);
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    -----------------------------------------------------------------------------------
    -- 初始化密码的消息模板 INIT_PASSWORD
    -- 1.传递用户ID
    -- 2.其他为N
    -- 3.-- 尊敬的客户，欢迎注册罗盘智慧差旅！您的登录帐号为您的手机号码，登录密码为#PASSWORD#，
    --请尽快访问www.luopan88.com修改密码并开启您的智慧差旅。如有疑问请联系您的专属客户经：#CUSTOMERMAN#(联系电话：#CSRMANPHONE#)，谢谢！
    -- 4.{"templetid":"INIT_PASSWORD","id":"用户ID","remark":"密码","telphone":"手机号"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('INIT_PASSWORD') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        if Length(nvl(rsUser.Password, 'N')) < 3 then
          vResult := '{"code":"0","message":"密码长度错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        if length(vRemark) != 8 then
          vResult := '{"code":"0","message":"初始密码长度非8个字符","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTemplet := replace(vTemplet, '#PASSWORD#', vRemark);

         --大客户经理
        if rsUser.COMPANY_ID IS NOT NULL then
          SELECT CUSTOMER_MANAGER,CUSTOMER_MANAGER_PHONE into vCsrMan,vCsrManCell
            FROM T_BASE_COMPANY
              WHERE COMPANY_ID=rsUser.COMPANY_ID;
                if LENGTH(vCsrMan)<>0 AND LENGTH(vCsrManCell)<>0 THEN
                  vTemplet := replace(vTemplet, '#CUSTOMERMAN#',vCsrMan);
                  vTemplet := replace(vTemplet, '#CSRMANPHONE#',vCsrManCell);
                ELSE
                  vTemplet := replace(vTemplet, '若有问题请联系您的专属客户经理：#CUSTOMERMAN#(联系电话：#CSRMANPHONE#)，谢谢！','');
                end if;
        end if;
      end loop;
      if iNum1 = 1 then
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    -----------------------------------------------------------------------------------
    -- 初始化密码的消息模板 INIT_PASSWORD_NEW

    -- 暂时跟INIT_PASSWORD 内容一致，以后更换模块记得修改
    -----------------------------------------------------------------------------------
    if vTempletId in ('INIT_PASSWORD_NEW') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        if Length(nvl(rsUser.Password, 'N')) < 3 then
          vResult := '{"code":"0","message":"密码长度错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        if length(vRemark) != 8 then
          vResult := '{"code":"0","message":"初始密码长度非8个字符","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        select nvl(Text1, 'N') into vTemplet from t_base_templet where code='INIT_PASSWORD';
        vTemplet := replace(vTemplet, '#PASSWORD#', vRemark);


      end loop;
      if iNum1 = 1 then
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    -----------------------------------------------------------------------------------
    -- 管理员重置密码的消息模板 RESET_PAYPASSWORD_NEW
    -- 1.传递用户ID
    -- 2.其他为N
    -- 3.尊敬的客户：您所在企业#COMPANYNAME#的管理员重置了您的交易密码为#PAYPASSWORD#，请尽快登录罗盘智慧差旅系统进行修改
    -- 4.{"templetid":"RESET_PAYPASSWORD_NEW","id":"用户ID","remark":"密码","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('RESET_PAYPASSWORD_NEW') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        for rsCompany in (select *
                       from T_BASE_COMPANY
                      where company_id = rsUser.company_id
                        and rownum <= 1) loop
              vCompanyName := rsCompany.company_name;
        end loop;
        if length(vRemark) < 6 then
          vResult := '{"code":"0","message":"交易密码长度小于6个字符","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTemplet := replace(vTemplet, '#PAYPASSWORD#', vRemark);
        vTemplet := replace(vTemplet, '#COMPANYNAME#', vCompanyName);
      end loop;
      if iNum1 = 1 then
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    -----------------------------------------------------------------------------------
    -- 管理员重置密码的消息模板 RESET_PASSWORD_NEW
    -- 1.传递用户ID
    -- 2.其他为N
    -- 3.尊敬的客户：您所在企业#COMPANYNAME#的管理员重置了您的登录密码为#PASSWORD#，请尽快登录罗盘智慧差旅系统进行修改
    -- 4.{"templetid":"RESET_PASSWORD_NEW","id":"用户ID","remark":"密码","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('RESET_PASSWORD_NEW') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        if Length(nvl(rsUser.Password, 'N')) < 3 then
          vResult := '{"code":"0","message":"密码长度错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        for rsCompany in (select *
                       from T_BASE_COMPANY
                      where company_id = rsUser.company_id
                        and rownum <= 1) loop
              vCompanyName := rsCompany.company_name;
        end loop;
        if length(vRemark) < 8 then
          vResult := '{"code":"0","message":"密码长度小于8个字符","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTemplet := replace(vTemplet, '#PASSWORD#', vRemark);
        vTemplet := replace(vTemplet, '#COMPANYNAME#', vCompanyName);
      end loop;
      if iNum1 = 1 then
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    -----------------------------------------------------------------------------------
    -- 管理员重置密码的消息模板 RESET_PASSWORD
    -- 1.传递用户ID
    -- 2.其他为N
    -- 3.尊敬的客户：管理员将您的登录密码重置为#PASSWORD#，请尽快访问www.luopan88.com修改密码【罗盘】
    -- 4.{"templetid":"RESET_PASSWORD","id":"用户ID","remark":"密码","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('RESET_PASSWORD') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for rsUser in (select *
                       from T_BASE_USER
                      where user_id = vId
                        and state = '1'
                        and rownum <= 1) loop
        iNum1 := 1;
        if Length(nvl(rsUser.Password, 'N')) < 3 then
          vResult := '{"code":"0","message":"密码长度错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTelphone := rsUser.Mobilephone;
        vRemark   := UPPER(TRIM(vRemark));
        if length(vRemark) < 8 then
          vResult := '{"code":"0","message":"密码长度小于8个字符","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
          Raise errorResult;
        end if;
        vTemplet := replace(vTemplet, '#PASSWORD#', vRemark);
      end loop;
      if iNum1 = 1 then
        --插入短信
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        vResult := '{"code":"0","message":"用户不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    -----------------------------------------------------------------------------------
    -- 初始化密码的消息模板 SEND_IDENTIFY_CODE
    -- 尊敬的客户，我公司向您发来邀请码【#IDENTIFY_CODE#】，您可以使用邀请码进行登录，欢迎体验罗盘智慧差旅
    -- {"templetid":"SEND_IDENTIFY_CODE","id":"NULL","remark":"动态验证码","telphone":"手机号"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('SEND_IDENTIFY_CODE') then
      vModule := '7';
      select nvl(Text1, 'N') into vTemplet from t_base_templet where code='SEND_IDENTIFY_CODE';
      vTemplet := replace(vTemplet, '#IDENTIFY_CODE#', vRemark);

      --插入短信
      vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);


    end if;

     -----------------------------------------------------------------------------------
    -- 初始化密码的消息模板 KFZG_MODIFY_PRICE

    -- 4.{"templetid":"KFZG_MODIFY_PRICE","id":"记录ID","remark":"identifyCode","telphone":"手机号"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('KFZG_MODIFY_PRICE') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for msg in (select * from T_CS_APPLY_MODIFY_MSG where id = vId ) loop
        vTemplet := replace(vTemplet, '#EMPLOYEE#', msg.apply_name);
        if (msg.order_type = '1') then
          vTemp2 := '国内机票';
        else
          if(msg.order_type = '2') then
          vTemp2 := '国际机票';
          else
          vTemp2 := '订单类型';
          end if;
        end if;
        vTemplet := replace(vTemplet, '#ORDERTYPE#', vTemp2);
        vTemplet := replace(vTemplet, '#REASON#', msg.modify_Reason);
        vTemplet := replace(vTemplet, '#IDENTIFYCODE#', msg.IDENTIFY_CODE);
        vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
        vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';

      end loop;
     end if;



    -----------------------------------------------------------------------------------
    -- 申请单审批短信模板 TRIP_FOR_APPROVAL
    -- 1.传申请单ID
    -- 2.其他为N
    -- 3.尊敬的客户：您好！#APPLY#于#APPLYTIME#填写的出差申请单需要您审批
    -- 4.{"templetid":"TRIP_FOR_APPROVAL","id":"277","remark":"N","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('TRIP_FOR_APPROVAL') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      for rsBtrip in (select *
                        from t_cc_business_trip
                       where biz_trip_id = to_number(vId)
                         and state = '1'
                         and rownum <= 1) loop
        iNum1    := 1;
        vTemplet := replace(vTemplet,
                            '#APPLYTIME#',
                            to_char(rsBtrip.Apply_Time,
                                    'FMMM"月"DD"日"HH24:FMMI'));
        vTemplet := replace(vTemplet, '#TRIP_ID#', rsBtrip.Biz_Trip_Id);
      end loop;
      vTelphone := '';
      --??以后增加审批等级，则需要排序
      for rsBtripUser in (select *
                            from T_CC_BIZTRIP_AUDIT_USER
                           where BIZ_TRIP_ID = to_number(vId)) loop
        for rsUser in (select *
                         from T_BASE_USER
                        where user_id = rsBtripUser.Audit_User_Id
                          and state = '1'
                          and rownum <= 1) loop
          vTelphone := rsUser.Mobilephone;
          vTemplet  := replace(vTemplet, '#APPLY#', rsUser.Name_Cn);
        end loop;
      end loop;
      --获得审批人手机号
      --获得申请人姓名
      --获得申请时间

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"出差申请单未找到","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        if Length(nvl(vTelphone, 'N')) != 11 then
          vResult := '{"code":"0","message":"手机号码格式错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        else
          --插入短信
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
          vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        end if;
      end if;
    end if;

     -----------------------------------------------------------------------------------
    -- 申请单审批短信模 BIZ_TRIP_FOR_APPROVAL
    -- 1.传申请单ID
    -- 2.其他为N
    -- 3.尊敬的客户：您有新的差旅申请单需要审核,出差单号：#BIZTRIPID#，申请人：#APPLYUSER#，出差事由：#REASON#，预估费用：#BUDGET#，审核通过请回复0+申请单号，审核不通过请回复1+申请单号谢谢您！
    -- 4.{"templetid":"BIZ_TRIP_FOR_APPROVAL","id":"277","remark":"N","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('BIZ_TRIP_FOR_APPROVAL') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      for rsBtrip in (select *
                        from t_cc_business_trip
                       where biz_trip_id = to_number(vId)
                         and state = '1'
                         and rownum <= 1) loop
        iNum1    := 1;
        vTemplet := replace(vTemplet, '#BIZTRIPID#', rsBtrip.Biz_Trip_Id);
        vTemplet := replace(vTemplet, '#REASON#', rsBtrip.Reason);
        vTemplet := replace(vTemplet, '#BUDGET#', rsBtrip.Budget);
  vTemplet :=replace(vTemplet,'#PASSCODE#',rsBtrip.Pass_Code);
        vTemplet :=replace(vTemplet,'#DECLINECODE#',rsBtrip.Decline_Code);
        vTemplet :=replace(vTemplet,'#ENDTIME#',to_char(rsBtrip.Trip_Endtime, 'YYYY-MM-DD HH24:MI:SS'));
         --获取申请人姓名
        for rsUser in(select * from T_BASE_USER
                        where user_id = rsBtrip.Apply_User) loop
          vTemplet  := replace(vTemplet, '#APPLYUSER#', rsUser.Name_Cn);
        end loop;

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '5';
        for rsCompany in (select * from T_base_company where company_id = rsBtrip.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;

      vTelphone := '';
      --??以后增加审批等级，则需要排序
      for rsBtripAuditUser in (select *
                            from T_CC_BIZTRIP_AUDIT_USER
                           where BIZ_TRIP_ID = to_number(vId)) loop
        for rsUser in (select *
                         from T_BASE_USER
                        where user_id = rsBtripAuditUser.Audit_User_Id
                          and state = '1'
                          and rownum <= 1) loop
          vTelphone := rsUser.Mobilephone;
        end loop;
      end loop;
      --获得审批人手机号
      --获得申请人姓名
      --获得申请时间

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"出差申请单未找到","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      else
        if Length(nvl(vTelphone, 'N')) != 11 then
          vResult := '{"code":"0","message":"手机号码格式错误","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        else
          --插入短信
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
          vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        end if;
      end if;
    end if;

    -----------------------------------------------------------------------------------

    -- 出差申请单回复短信模 BIZ_TRIP_FOR_REPLY
    -- 1.传申请单ID
    -- 2.remark ：0审核驳回，1审核通过
    -- 3.审核驳回-发给apply_user 审核通过--发给apply_user和book_user
    -- 4.{"templetid":"BIZ_TRIP_FOR_REPLY","id":"277","remark":"1","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('BIZ_TRIP_FOR_REPLY') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      for tripRs in(SELECT T.BIZ_TRIP_ID,T.APPLY_USER,U.MOBILEPHONE ,T.BOOKING_USER ,T.COMPANY_ID
                    FROM T_CC_BUSINESS_TRIP T LEFT JOIN T_BASE_USER U ON T.APPLY_USER = U.USER_ID WHERE T.BIZ_TRIP_ID = vId) loop

        vTelphone := tripRs.MOBILEPHONE;--申请人
        vModule := '5';
        for rsCompany in (select * from T_base_company where company_id = tripRs.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        if vRemark in('0') then
          --插入短信

          select nvl(Text1, 'N') into vTemplet from t_base_templet where code='BIZ_TRIP_FOR_REPLY';
          vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
          vTemplet := Replace(vTemplet, '#BIZTRIPID#',vId);
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);

        else
          select nvl(Text1, 'N') into vTemplet from t_base_templet where code='BIZ_TRIP_FOR_REPLY';
          vTemplet := Replace(vTemplet, '#RESULT#', '通过');
          vTemplet := Replace(vTemplet, '#BIZTRIPID#',vId);
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);

          if tripRs.BOOKING_USER is not null then
            select nvl(Text1, 'N') into vTemplet from t_base_templet where code='BIZ_TRIP_FOR_REPLY_BOOK';

            for bookRs in( select u.* from t_base_user u where u.user_id = substr( tripRs.BOOKING_USER, 1,instr(tripRs.BOOKING_USER,',')-1)) loop
                vTemplet := Replace(vTemplet, '#BIZTRIPID#',vId);
                vResult := insertToQueue(vTempletId, vId, vTemplet, bookRs.MOBILEPHONE, vModule, vOrderNo, vCompanyName);
            end loop;


          end if;

        end if;

      end loop;

    end if;

    -----------------------------------------------------------------------------------

    -- 订单申请单回复短信模 ORDER_FOR_APPROVAL_PLANE_CIVIL
    -- 1.传申请单ID
    -- 2.remark ：0审核驳回，1审核通过
    -- 3.审核驳回-发给apply_user 审核通过--发给apply_user
    -- 4.{"templetid":"ORDER_FOR_APPROVAL_PLANE_CIVIL","id":"277","remark":"N","telphone":"18862116680"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('ORDER_FOR_APPROVAL_PLANE_CIVIL') then

      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code||rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '6';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        ----------------------------------------------------------------
        -- 组合姓名,格式:姓名,姓名，存入vTemp2
        ----------------------------------------------------------------
        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vId ) loop
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name;
        end loop;
        --------------------------------------
        -- 短信审批码
        for rsOrder in (select * from t_cc_order_audit where order_id = vId and rownum <=1) loop
            vPassCode :=rsOrder.Pass_Code;
            vDeclineCode :=rsOrder.Decline_Code;
            vEndTime :=to_char(rsOrder.Order_Endtime, 'YYYY-MM-DD HH24:MI:SS');
        end loop;

        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='ORDER_FOR_APPROVAL_PLANE_CIVIL';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);
        vTemplet1 := Replace(vTemplet1, '#TOTAL#',rsPlaneOrder.sale_price);
        vTemplet1 :=Replace(vTemplet1,'#PASSCODE#',vPassCode);
        vTempLet1 :=Replace(vTemplet1,'#DECLINECODE#',vDeclineCode);
        vTemplet1 :=Replace(vTemplet1,'#ENDTIME#',vEndTime);
        --------------------------------
        --发送dao审核人手机--
        if vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueueRemark(vTempletId, vId, vTemplet1, vTelphone, vModule, vOrderNo, vCompanyName,vRemark);
        end if;
       --vResult := insertToQueue(vTempletId,vId,vTemplet1,vTelphone, vModule, vOrderNo, vCompanyName);

      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    -----------------------------------------------------------------------------------

    -- 国内机票订单回复短信模 ORDER_FOR_REPLY_PLANE_CIVIL
    -- 1.传订单id
    -- 2.remark ：0审核驳回，1审核通过
    -- 3.审核驳回-发给apply_user 审核通过--发给apply_user
    -- 4.{"templetid":"ORDER_FOR_REPLY_PLANE_CIVIL","id":"403","remark":"1","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('ORDER_FOR_REPLY_PLANE_CIVIL') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code||rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '6';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --申请人手机号
        for rsUser in (select *
                         from t_base_user
                        where user_id = rsPlaneOrder.create_user and rownum <=1) loop
          vTelphone := Trim(rsUser.Mobilephone);
        end loop;
   --短信审批码
        for rsOrder in (select * from t_cc_order_audit where order_id = vId and rownum <=1) loop
            vPassCode :=rsOrder.Pass_Code;
            vDeclineCode :=rsOrder.Decline_Code;
            vEndTime :=to_char(rsOrder.Order_Endtime, 'YYYY-MM-DD HH24:MI:SS');
        end loop;

        select nvl(Text1, 'N') into vTemplet from t_base_templet where code='ORDER_FOR_REPLY_PLANE_CIVIL';
        vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);
  vTemplet :=Replace(vTemplet,'#PASSCODE#',vPassCode);
        vTemplet :=Replace(vTemplet,'#DECLINECODE#',vDeclineCode);
        vTemplet :=Replace(vTemplet,'#ENDTIME#',vEndTime);

        if vRemark in('1') and vFillFlag = 0 or vFillFlag is null then
          --插入短信
          vTemplet := Replace(vTemplet, '#RESULT#', '通过');
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);

        else
          if vFillFlag = 0 or vFillFlag is null then
            vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
            vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
          end if;
        end if;

      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

    end if;



-- 订单申请单回复短信模 ORDER_FOR_APPROVAL_PLANE_INTER
    -- 1.传申请单ID
    -- 2.remark ：0审核驳回，1审核通过
    -- 3.审核驳回-发给apply_user 审核通过--发给apply_user
    -- 4.{"templetid":"ORDER_FOR_APPROVAL_PLANE_INTER","id":"277","remark":"N","telphone":"18862116680"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('ORDER_FOR_APPROVAL_PLANE_INTER') then
      --多程的，国内可以用起飞时间排序，国际通过flight_index排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vId order by flight_index) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code||rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '6';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        ----------------------------------------------------------------
        -- 组合姓名,格式:姓名,姓名，存入vTemp2
        ----------------------------------------------------------------
        for rsCjr in (select * from T_CC_inter_TICKET_PASSENGER where plane_order_id = vId ) loop
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name;
        end loop;
        --------------------------------------

         --短信审批码
        for rsOrder in (select * from t_cc_order_audit where order_id = vId and rownum <=1) loop
            vPassCode :=rsOrder.Pass_Code;
            vDeclineCode :=rsOrder.Decline_Code;
            vEndTime :=to_char(rsOrder.Order_Endtime, 'YYYY-MM-DD HH24:MI:SS');
        end loop;

        select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='ORDER_FOR_APPROVAL_PLANE_INTER';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);
        vTemplet1 := Replace(vTemplet1, '#TOTAL#',rsPlaneOrder.sale_price);
        vTemplet1 := Replace(vTemplet1, '#PASSCODE#',vPassCode);
        vTemplet1 := Replace(vTemplet1, '#DECLINECODE#',vDeclineCode);
        vTemplet1 := Replace(vTemplet1, '#ENDTIME#',vEndTime);
        --------------------------------
        --发送dao审核人手机--
        if vFillFlag = 0 or vFillFlag is null then
          vResult := insertToQueueRemark(vTempletId,vId,vTemplet1,vTelphone, vModule, vOrderNo, vCompanyName, vRemark);
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

    end if;

  -----------------------------------------------------------------------------------

    -- 国际机票订单回复短信模 ORDER_FOR_REPLY_PLANE_INTER
    -- 1.传订单id
    -- 2.remark ：0审核驳回，1审核通过
    -- 3.审核驳回-发给apply_user 审核通过--发给apply_user
    -- 4.{"templetid":"ORDER_FOR_REPLY_PLANE_INTER","id":"27700000","remark":"1","telphone":"N"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('ORDER_FOR_REPLY_PLANE_INTER') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);

      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vId order by take_off_time) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code||rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------
      iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '6';
        vOrderNo := rsPlaneOrder.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
        ----------------------------------------------------------------
         --申请人手机号
        for rsUser in (select *
                         from t_base_user
                        where user_id = rsPlaneOrder.create_user and rownum <=1) loop
          vTelphone := Trim(rsUser.Mobilephone);
        end loop;
         ----------------------------------------------------------------

        select nvl(Text1, 'N') into vTemplet from t_base_templet where code='ORDER_FOR_REPLY_PLANE_INTER';
        vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);

        if vRemark in('1') and vFillFlag = 0 or vFillFlag is null then
          --插入短信
          vTemplet := Replace(vTemplet, '#RESULT#', '通过');
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);

        else
          if vFillFlag = 0 or vFillFlag is null then
            vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
            vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
          end if;
        end if;

      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

    end if;




   -----------------------------------------------------------------------------------

   -- 订单申请单回复短信模 ORDER_FOR_REPLY_TRAIN_CIVIL
    -- 1.传申请单ID
    -- 2.remark ：0审核驳回，1审核通过
    -- 3.审核驳回-发给apply_user 审核通过--发给apply_user
    -- 4.{"templetid":"ORDER_FOR_REPLY_TRAIN_CIVIL","id":"277","remark":"N","telphone":"18862116680"}
    -----------------------------------------------------------------------------------
    if vTempletId in ('ORDER_FOR_REPLY_TRAIN_CIVIL') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_train_trip where train_order_id = vId) loop
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.depart_date, 'FMMM"月"DD"日"HH24:FMMI');

        vTemp3 := vTemp3 || rs.train_code || '次';
        vTemp3 := vTemp3 || rs.depart_time || rs.depart_station || '-';
        vTemp3 := vTemp3 || rs.arrive_time || rs.arrive_station ;
      end loop;
      -------------------------------------------------------------------------------------------------
       iNum1 := 1;
      iNum2 := 0;
      iNum3 := 0;
      for rsTrainOrder in (select * from T_CC_TRAIN_ORDER where train_order_id = vId and rownum <= 1) loop
        vTemp2 := '';
        --是否为补单
        vFillFlag := rsTrainOrder.IS_FILL_ORDER;
        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '5';
        vOrderNo := rsTrainOrder.train_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsTrainOrder.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        --------------------------------------
        --申请人手机号
        for rsUser in (select *
                         from t_base_user
                        where user_id = rsTrainOrder.create_user_id and rownum <=1) loop
          vTelphone := Trim(rsUser.Mobilephone);
        end loop;
         --------------------------------------

        select nvl(Text1, 'N') into vTemplet from t_base_templet where code='ORDER_FOR_REPLY_TRAIN_CIVIL';

        vTemplet := Replace(vTemplet, '#DATE##CODE##TRIP#', vTemp3);
        vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);

        if vRemark in('1') and vFillFlag = 0 or vFillFlag is null then
          --插入短信
          vTemplet := Replace(vTemplet, '#RESULT#', '通过');
          vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);

        else
          if vFillFlag = 0 or vFillFlag is null then
            vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
            vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
          end if;
        end if;

      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"火车票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;


    -----------------------------------------------------------------------------------

    -- 授权码短信模板 SEND_PAY_LICENSE
    -- 1.传申请单ID
    -- 2.其他为N
    -- 3.尊敬的客户，您的授权码为#LICENSECODE#，请尽快输入，工作人员不会向您索取，请勿泄露【罗盘】
    -- 4.{"templetid":"SEND_PAY_LICENSE","id":"666666","remark":"N","telphone":"17712613261"}
    -----------------------------------------------------------------------------------
    -- LICENSE_PLANEORDER_CIVIL 授权交易-国内机票下订单  尊敬的客户，您的国内机票订单授权码为#LICENSECODE#，请尽快输入，工作人员不会向您索取，请勿泄露【罗盘】             AAAX5FAAHAAAAmeAAA
    -- LICENSE_PLANEORDER_INTER 授权交易-国际机票下订单  尊敬的客户，您的国际机票订单授权码为#LICENSECODE#，请尽快输入，工作人员不会向您索取，请勿泄露【罗盘】             AAAX5FAAHAAAAmbAAH
    -- LICENSE_PLANECHANGE_CIVIL  授权交易-国内机票改签 尊敬的客户，您的国内机票改签订单授权码为#LICENSECODE#，请尽快输入，工作人员不会向您索取，请勿泄露【罗盘】             AAAX5FAAHAAAAmbAAI
    -- LICENSE_PLANECHANGE_INTER  授权交易-国际机票改签 尊敬的客户，您的国际机票改签订单授权码为#LICENSECODE#，请尽快输入，工作人员不会向您索取，请勿泄露【罗盘】
    -- 国内机票下订单  1 LICENSE_PLANEORDER_CIVIL
    -- 国际机票下订单  2 LICENSE_PLANEORDER_INTER
    -- 国内机票改签  3 LICENSE_PLANECHANGE_CIVIL
    -- 国际机票改签  4 LICENSE_PLANECHANGE_INTER
    -----------------------------------------------------------------------------------
    if vTempletId in ('LICENSE_PLANEORDER_CIVIL',
                      'LICENSE_PLANEORDER_INTER',
                      'LICENSE_PLANECHANGE_CIVIL',
                      'LICENSE_PLANECHANGE_INTER') then
      vTemplet  := replace(vTemplet, '#LICENSECODE#', vId);
      vTelphone := vTelphone;
      --授权码无需验证重复，生成一个惟一码，避过验证
      select sys_guid() into vId from dual;
      --插入短信
      vResult := insertToQueue(vTempletId, vId, vTemplet, vTelphone, vModule, vOrderNo, vCompanyName);
      vResult := '{"code":"1","message":"OK","memo":"N","templetid":"' ||
                 vTempletId || '","id":"' || vId || '"}';
    end if;

    ------------------------------------------------
    -- 国内机票出票成功
    -- PLANE_CIVIL_SUCCESS
    -- 【#NAME#】#AIRINFO#,票号：##【罗盘】
    -- 【陈XX】XX月XX日xx:xx飞xx:xx降 上海航空FM9353 上海浦东T1-长春龙嘉，票号：781-2169178540【罗盘】
    -- {"templetid":"PLANE_CIVIL_SUCCESS","id":"610","remark":"N","telphone":"N"}
    -- 联系人姓名
    -- 航班信息
    ------------------------------------------------
    if vTempletId in ('PLANE_CIVIL_SUCCESS') then
      --多程的，国内可以用起飞时间排序，国际需要一个flight_index，否则无法排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      vHbxx := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vId) loop
        if NVL(vHbxx, 'N') != 'N' then
          vHbxx := vHbxx || '；';
        end if;
        vHbxx := vHbxx ||
                 to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '飞';
        vHbxx := vHbxx || to_char(rs.arrive_time, 'FMHH24:FMMI') || '降 ';
        select nvl((select airline_name_abbr
                     from T_BASE_AIRLINE
                    where airline_code = rs.airline_code
                      and rownum <= 1),
                   rs.airline_code)
          into vTemp
          from dual;
        vHbxx := vHbxx || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn
                     from T_BASE_AIRPORT
                    where airport_code = rs.depart_airport_code
                      and rownum <= 1),
                   rs.depart_airport_code)
          into vTemp
          from dual;
        vHbxx := vHbxx || vTemp ||
                 replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn
                     from T_BASE_AIRPORT
                    where airport_code = rs.arrive_airport_code
                      and rownum <= 1),
                   rs.arrive_airport_code)
          into vTemp
          from dual;
        vHbxx := vHbxx || vTemp ||
                 replace(rs.arrive_airport_tower, '-', '');
      end loop;

      --乘机人
      vTemplet1 := '';
      --订票人
      vTemplet2 := '';

      ----------------------------------------------
      --获得乘机人
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      ----------------------------------------------
      --获得订票人，如果属于乘机人，则不发送
      --规则变更：将所有乘机人短信发给订票人一份，2015-06-30
      for rsPlaneOrder in (select *
                             from T_CC_PLANE_ORDER
                            where plane_order_id = vId
                              and rownum <= 1) loop
        iNum1 := 1;
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;

        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vId and state = '3') loop
          vTemplet1 := vTemplet;
          vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
          vTemplet1 := Replace(vTemplet1, '#INFO#', vHbxx || '，票号：' || rsCjr.Plane_Ticket_No);
          if Length(rsCjr.Phone) = 11 and vFillFlag = 0 or vFillFlag is null then
            --发送乘机人
            vResult := insertToQueue(vTempletId,vId,vTemplet1,rsCjr.Phone, vModule, vOrderNo, vCompanyName);
            if rsCjr.Phone != rsPlaneOrder.Contact_Phone then
               --发送订票人
               vResult := insertToQueue(vTempletId,vId,vTemplet1,rsPlaneOrder.Contact_Phone, vModule, vOrderNo, vCompanyName);
            end if;
          else
            if vFillFlag = 0 or vFillFlag is null then
             --发送订票人
             vResult := insertToQueue(vTempletId,vId,vTemplet1,rsPlaneOrder.Contact_Phone, vModule, vOrderNo, vCompanyName);
            end if;
          end if;
        end loop;
        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国内机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国内机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    --改签申请受理

    --退票申请受理

    ------------------------------------------------
    -- 国际票出票成功
    -- PLANE_INTER_SUCCESS
    -- 【#NAME#】#AIRINFO#,票号：##【罗盘】
    -- 【陈XX】XX月XX日xx:xx飞xx:xx降 上海航空FM9353 上海浦东T1-长春龙嘉，票号：781-2169178540【罗盘】
    -- {"templetid":"PLANE_INTER_SUCCESS","id":"1020080","remark":"N","telphone":"N"}
    -- 联系人姓名
    -- 航班信息
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_SUCCESS') then
      --多程的，国内可以用起飞时间排序，国际需要一个flight_index，否则无法排序
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      vHbxx := '';
      for rs in (select *
                   from T_CC_INTER_PLANE_TRIP
                  where plane_order_id = vId
                  order by take_off_time) loop
        if NVL(vHbxx, 'N') != 'N' then
          vHbxx := vHbxx || '；';
        end if;
        vHbxx := vHbxx ||
                 to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '飞';
        vHbxx := vHbxx || to_char(rs.arrive_time, 'FMHH24:FMMI') || '降 ';
        select nvl((select airline_name_abbr
                     from T_BASE_AIRLINE
                    where airline_code = rs.airline_code
                      and rownum <= 1),
                   rs.airline_code)
          into vTemp
          from dual;
        vHbxx := vHbxx || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn
                     from T_BASE_AIRPORT
                    where airport_code = rs.depart_airport_code
                      and rownum <= 1),
                   rs.depart_airport_code)
          into vTemp
          from dual;
        vHbxx := vHbxx || vTemp ||
                 replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn
                     from T_BASE_AIRPORT
                    where airport_code = rs.arrive_airport_code
                      and rownum <= 1),
                   rs.arrive_airport_code)
          into vTemp
          from dual;
        vHbxx := vHbxx || vTemp ||
                 replace(rs.arrive_airport_tower, '-', '');
      end loop;

      --乘机人
      vTemplet1 := '';
      --订票人
      vTemplet2 := '';

      ----------------------------------------------
      --获得乘机人
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      ----------------------------------------------
      --获得订票人，如果属于乘机人，则不发送
      for rsPlaneOrder in (select *
                             from T_CC_INTER_PLANE_ORDER
                            where plane_order_id = vId
                              and rownum <= 1) loop
        iNum1 := 1;
        --是否为补单
        vFillFlag := rsPlaneOrder.IS_FILL_ORDER;

        for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vId and state = '3') loop
          vTemplet1 := vTemplet;
          vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Last_Name||'/'||rsCjr.First_Name);
          vTemplet1 := Replace(vTemplet1, '#INFO#', vHbxx || '，票号：' || rsCjr.Plane_Ticket_No);

          if Length(rsCjr.Phone) = 11 and vFillFlag = 0 or vFillFlag is null then
            --发送乘机人
            vResult := insertToQueue(vTempletId, vId, vTemplet1, rsCjr.Phone, vModule, vOrderNo, vCompanyName);
            if rsCjr.Phone != rsPlaneOrder.Contact_Phone then
               --发送订票人
               vResult := insertToQueue(vTempletId, vId, vTemplet1,rsPlaneOrder.Contact_Phone, vModule, vOrderNo, vCompanyName);
            end if;
          else
            if vFillFlag = 0 or vFillFlag is null then
             --发送订票人
             vResult := insertToQueue(vTempletId, vId, vTemplet1,rsPlaneOrder.Contact_Phone, vModule, vOrderNo, vCompanyName);
            end if;
          end if;
        end loop;
        --联系人未发送过，则发送
        --if iNum1 = 1 then
        --  if Length(Trim(rsPlaneOrder.Contact_Phone)) = 11 then
        --    vTemplet2 := vTemplet;
        --    vTemplet2 := Replace(vTemplet2,
        --                        '#NAME#',
        --                         rsPlaneOrder.Contact_First_Name || '/' ||
        --                         rsPlaneOrder.Contact_Last_Name);
        --    vTemplet2 := Replace(vTemplet2, '#INFO#', vHbxx);
        --    --发送
        --    vResult := insertToQueue(vTempletId,
        --                             vId,
        --                             vTemplet2,
        --                             Trim(rsPlaneOrder.Contact_Phone));
        --  end if;
        --end if;
        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"国际机票,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- PLANE_INTER_CHANGE_TIMEOUT_TO:国际机票改签超时
    -- 1.NO_PLANE_INTER_CHANGE_TIMEOUT_TO_PASS:
    --
    -- 2.PLANE_INTER_CHANGE_TIMEOUT_TO_LINK:
    --
    -- 输入参数：{"templetid":"PLANE_INTER_CHANGE_TIMEOUT_TO","id":"changeId","remark":"1","telphone":"N"}
    ------------------------------------------------
    if vTempletId in ('PLANE_INTER_CHANGE_TIMEOUT_TO') then
      iNum1 := 0;
      vId   := convertStrToInt(vId, -1);
      ---------------------------------------
      --获得旧行程vTemp1，再获得新行程vTemp2
      ---------------------------------------
      vTemp1 := '';
      vTemp2 := '';
      for rsCo in (select * from t_cc_inter_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
        --旧行程
        for rsPt in (select * from t_cc_inter_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by flight_index) loop
          vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || rsPt.airline_code || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp1 := vTemp1 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      for rsCo in (select * from t_cc_inter_change_od t where  change_id=vId order by orig_od_id) loop
        --多行程时用"；"分开
        if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
        --新行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by flight_index) loop
          vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rsPt.airline_code and rownum <= 1),rsPt.airline_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || rsPt.flight_no || ' ';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.depart_airport_code and rownum <= 1),rsPt.depart_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.depart_airport_tower, '-', '') || '-';
          select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rsPt.arrive_airport_code and rownum <= 1),rsPt.arrive_airport_code) into vTemp from dual;
          vTemp2 := vTemp2 || vTemp || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
      end loop ;
      -------------------------------------------
      -- 获得联系人（申请人）手机和改签费用vTemp3
      -------------------------------------------
      for rsPc in (select * from t_cc_inter_plane_change where change_id = vId ) loop
        iNum1 := 1;
        select nvl((select mobilephone from t_base_user where user_id=rsPc.Apply_User),'AA') into vLxSjh from dual;
        --改签费用
        vTemp3 := '111.11';
        --是否为补单
        vFillFlag := rsPc.IS_FILL_ORDER;

        --------------------------------------
        -- 获得所属模块+订单号+企业名称
        --------------------------------------
        vModule := '2';
        vOrderNo := rsPc.plane_order_no;
        for rsCompany in (select * from T_base_company where company_id = rsPc.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;
      end loop;
      --------------------------------------
      -- 新行程，获得乘机人信息
      --------------------------------------
      vTemp4 := '';
      iNum2  := 0;
      iNum3  := 0;
      for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER a1 where exists (select 0 from t_cc_inter_change_ticket a2 where a2.change_id=vId and a2.orig_plane_ticket_id=a1.plane_ticket_id) and state = '3') loop
        iNum3  := iNum3+1;
        vKhSjh := NVL(Trim(rsCjr.Phone),'A');
        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
        vTemp4 := vTemp4||rsCjr.last_name || ' ' || rsCjr.first_name;
        ------------------------------


      end loop;

      ------------------------------
      --  获得联系人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='PLANE_INTER_CHANGE_TIMEOUT_TO_LINK';
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
      vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);
      vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp4);
      --------------------------------
      if vFillFlag = 0 or vFillFlag is null then
        vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, vOrderNo, vCompanyName);
      end if;

      if Length(NVL(vResult, 'N')) < 10 then
        vResult := '{"code":"0","message":"国际机票改签,手机号空导致未生成短信","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;

      if iNum1 < 1 then
        vResult := '{"code":"0","message":"国际机票改签订单不存在","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

   ------------------------------------------------
     -- REMIND_TO_US:提醒客服值班人事
    -- 输入参数：{"templetid":"REMIND_TO_US","id":"610","remark":"1","telphone":"N"}

    ------------------------------------------------
    if vTempletId in ('REMIND_TO_US') then
      vId := vId;
      vModule := '7';
      select nvl(value, 'N') into vLxSjh from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';

      ------------------------------
      --  获得模板
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from t_base_templet where code='REMIND_TO_US';
      if vRemark in ('1') then
            vTemplet2 := '国内机票出票';
      else
         if vRemark in ('2') then
            vTemplet2 := '国内机票出票';
        else
           if vRemark in ('3') then
            vTemplet2 := '国内机票改签';
          else
               if vRemark in ('4') then
                vTemplet2 := '国际机票改签';
               else
                  if vRemark in ('5') then
                  vTemplet2 := '国内机票退票';
                 else
                     if vRemark in ('6') then
                      vTemplet2 := '国际机票退票';

                    end if;

              end if;

              end if;

          end if;

        end if;
      end if;

      vTemplet1 := Replace(vTemplet1, '#ORDER_TYPE#', vTemplet2);
      vTemplet1 := Replace(vTemplet1, '#ORDER_NO#', vId);

      vResult := insertToQueue(vTempletId,vId,vTemplet1,vLxSjh, vModule, null, null);

    end if;

    ------------------------------------------------
    -- 订单审批
    -- 申请时审核人需要接收短信
    ------------------------------------------------
    if vTempletId in ('ORDER_FOR_APPROVAL') then
      iNum1 := 0;
      vId   := vId;

      for rsOrderAudit in (select *
                             from t_cc_order_audit
                            where AUDIT_ID = vId) loop
        iNum1 := 1;

        --申请人名称，手机号
        for rsUser in (select *
                         from t_base_user
                        where user_id = rsOrderAudit.Apply_User) loop
          vTemplet  := replace(vTemplet, '#APPLY#', rsUser.Name_Cn);
          vTelphone := Trim(rsUser.Mobilephone);
        end loop;

        --申请时间
        vTemplet := replace(vTemplet,
                            '#APPLYTIME#',
                            to_char(rsOrderAudit.Apply_Time,
                                    'yyyy-MM-dd hh24:mi:ss'));

        --订单类型
        for rsDictDetail in (select *
                               from t_base_dict_detail
                              where dict_type_code = 'ORDER_TYPE'
                                and dict_code = rsOrderAudit.Order_Type) loop
          vTemplet := replace(vTemplet,
                              '#ORDERTYPE#',
                              rsDictDetail.Dict_Name);
        end loop;

        if Length(vTelphone) = 11 then
          vTemplet1 := vTemplet;
          vResult   := insertToQueue(vTempletId, vId, vTemplet1, vTelphone, vModule, vOrderNo, vCompanyName);
        end if;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"订单申请,手机号空导致未生成短信","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"订单申请单不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    ------------------------------------------------
    -- 订单审批
    -- 审批通过或驳回时申请人需要接收短信
    ------------------------------------------------
    if vTempletId in ('ORDER_FOR_REPLY') then
      iNum1 := 0;
      vId   := vId;

      for rsOrderAudit in (select *
                             from t_cc_order_audit
                            where AUDIT_ID = vId) loop
        iNum1 := 1;

        --手机号
        for rsUser in (select *
                         from t_base_user
                        where user_id = rsOrderAudit.Apply_User) loop
          vTelphone := Trim(rsUser.Mobilephone);
        end loop;

        --申请时间
        vTemplet := replace(vTemplet,
                            '#APPLYTIME#',
                            to_char(rsOrderAudit.Apply_Time,
                                    'yyyy-MM-dd hh24:mi:ss'));

        --订单类型
        for rsDictDetail in (select *
                               from t_base_dict_detail
                              where dict_type_code = 'ORDER_TYPE'
                                and dict_code = rsOrderAudit.Order_Type) loop
          vTemplet := replace(vTemplet,
                              '#ORDERTYPE#',
                              rsDictDetail.Dict_Name);
        end loop;

        --审批状态
        for rsDictDetail in (select *
                               from t_base_dict_detail
                              where dict_type_code = 'BIZ_TRIP_STATE'
                                and dict_code = rsOrderAudit.State) loop
          vTemplet := replace(vTemplet, '#RESULT#', rsDictDetail.Dict_Name);
        end loop;

        if Length(vTelphone) = 11 then
          vTemplet1 := vTemplet;
          vResult   := insertToQueue(vTempletId, vId, vTemplet1, vTelphone, vModule, vOrderNo, vCompanyName);
        end if;

        if Length(NVL(vResult, 'N')) < 10 then
          vResult := '{"code":"0","message":"订单申请,手机号空导致未生成短信","memo":"N","templetid":"' ||
                     vTempletId || '","id":"' || vId || '"}';
        end if;
      end loop;
      if iNum1 < 1 then
        vResult := '{"code":"0","message":"订单申请单不存在","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","memo":"N","templetid":"' ||
                   vTempletId || '","id":"' || vId || '"}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","memo":"N","templetid":"' || vTempletId || '","id":"' || vId || '"}';
      RETURN vResult;
  END;

  ----------------------------------
  -- 授权码生成及验证工具
  -- 日期：2015-03-11
  -- 1.生成：{"method":"CREATE","telephone":"17712613261","licensetype":"1"}
  -- 2.检验：{"method":"CHECK","telephone":"17712613261","licensetype":"1","licensecode":"666666"}
  ----------------------------------
  FUNCTION licenseTool(viData IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum1 Integer;
    iNum2 Integer;

    vCon varchar2(32000);

    vMethod   varchar2(500);
    vType     varchar2(2);
    vCode     varchar2(6);
    vTelphone varchar2(50);
    vGuid     varchar2(50);

    vTemp varchar2(20000);

    errorResult EXCEPTION;
  BEGIN
    dtNow := sysdate;
    vCon  := viData;

    ----------------------------------------
    -- 解析出条件
    ----------------------------------------
    vMethod   := upper(trim(queryJsonValueFromName('method', vCon)));
    vType     := trim(queryJsonValueFromName('licensetype', vCon));
    vCode     := nvl(trim(queryJsonValueFromName('licensecode', vCon)), 'N');
    vTelphone := trim(queryJsonValueFromName('telephone', vCon));

    ------------------------------------------------------------------------
    -- 国内机票下订单  1 LICENSE_PLANEORDER_CIVIL
    -- 国际机票下订单  2 LICENSE_PLANEORDER_INTER
    -- 国内机票改签  3 LICENSE_PLANECHANGE_CIVIL
    -- 国际机票改签  4 LICENSE_PLANECHANGE_INTER
    -------------------------------------------------------------------------
    if vType not in ('1', '2', '3', '4') then
      vResult := '{"code":"0","message":"业务类型不存在","memo":"N","method":"' ||
                 vMethod || '","telephone":"' || vTelphone ||
                 '","licensetype":"' || vType || '"}';
      Raise errorResult;
    end if;

    ----------------------------------------
    -- 将时间过期的状态转为失效
    ----------------------------------------
    for rs in (select *
                 from T_BASE_LICENSE_CODE
                where mobile_phone = vTelphone
                  and license_type = vType
                  and license_state = '1') loop
      --类型是交易授权码，则取参数：LICENSECODE_VALID_TIME
      if vType in ('1', '2', '3', '4') then
        select to_number(nvl((select value
                               from t_base_config_const
                              where name = 'LICENSECODE_VALID_TIME'
                                and rownum <= 1),
                             '60'))
          into iNum1
          from dual;
      else
        iNum1 := 60;
      end if;
      if (rs.license_time + iNum1 / 24 / 60 / 60) < dtNow then
        update T_BASE_LICENSE_CODE
           set license_state = '0',
               remark        = to_char(dtNow, 'yyyymmddhh24miss')
         where unique_id = rs.unique_id;
        --commit;
      end if;
    end loop;

    if vMethod in ('CREATE') then
      --检查同一手机，同一类型，状态是否有1的
      select count(0)
        into iNum1
        from T_BASE_LICENSE_CODE
       where mobile_phone = vTelphone
         and license_type = vType
         and license_state = '1';
      if iNum1 > 0 then
        vResult := '{"code":"0","message":"该手机号有正在处理的业务，请稍候再试","memo":"N","method":"' ||
                   vMethod || '","telephone":"' || vTelphone ||
                   '","licensetype":"' || vType || '"}';
        Raise errorResult;
      end if;
      --生成授权码
      select lpad(round(dbms_random.value(1, 999999), 0), 6, '0')
        into vCode
        from dual;
      --生成惟一码
      select sys_guid() into vGuid from dual;
      --入库
      insert into T_BASE_LICENSE_CODE
        (unique_id,
         license_code,
         license_time,
         license_type,
         license_state,
         mobile_phone,
         remark)
      values
        (vGuid, vCode, dtNow, vType, '1', vTelphone, '00000000000000');
      --commit ;

      --发送短信，区分业务类型
      if vType in ('1') then
        vTemp := toCreate('{"templetid":"LICENSE_PLANEORDER_CIVIL","id":"' ||
                          vCode || '","remark":"N","telphone":"' ||
                          vTelphone || '"}',
                          '');
      end if;
      if vType in ('2') then
        vTemp := toCreate('{"templetid":"LICENSE_PLANEORDER_INTER","id":"' ||
                          vCode || '","remark":"N","telphone":"' ||
                          vTelphone || '"}',
                          '');
      end if;
      if vType in ('3') then
        vTemp := toCreate('{"templetid":"LICENSE_PLANECHANGE_CIVIL","id":"' ||
                          vCode || '","remark":"N","telphone":"' ||
                          vTelphone || '"}',
                          '');
      end if;
      if vType in ('4') then
        vTemp := toCreate('{"templetid":"LICENSE_PLANECHANGE_INTER","id":"' ||
                          vCode || '","remark":"N","telphone":"' ||
                          vTelphone || '"}',
                          '');
      end if;

      --返回结果
      vResult := '{"code":"1","message":"生成成功","memo":"' || vGuid ||
                 '","method":"' || vMethod || '","telephone":"' ||
                 vTelphone || '","licensetype":"' || vType || '"}';
      Raise errorResult;
    end if;

    if vMethod in ('CHECK') then
      iNum1 := 0;
      for rsCheck in (select *
                        from T_BASE_LICENSE_CODE
                       where mobile_phone = vTelphone
                         and license_type = vType
                         and license_state = '1'
                         and rownum <= 1) loop
        iNum1 := 1;
        if rsCheck.License_Code = vCode then
          update T_BASE_LICENSE_CODE
             set license_state = '2',
                 remark        = to_char(dtNow, 'yyyymmddhh24miss')
           where Unique_Id = rsCheck.Unique_Id;
          --commit ;
          vResult := '{"code":"1","message":"验证通过","memo":"' ||
                     rsCheck.Unique_Id || '","method":"' || vMethod ||
                     '","telephone":"' || vTelphone || '","licensetype":"' ||
                     vType || '"}';
          Raise errorResult;
        else
          vResult := '{"code":"0","message":"验证失败","memo":"' ||
                     rsCheck.Unique_Id || '","method":"' || vMethod ||
                     '","telephone":"' || vTelphone || '","licensetype":"' ||
                     vType || '"}';
          Raise errorResult;
        end if;
      end loop;
      if iNum1 = 0 then
        vResult := '{"code":"0","message":"验证失败,已过期","memo":"N","method":"' ||
                   vMethod || '","telephone":"' || vTelphone ||
                   '","licensetype":"' || vType || '"}';
      end if;
    end if;
    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"空","memo":"N","method":"' ||
                   vMethod || '","telephone":"' || vTelphone ||
                   '","licensetype":"' || vType || '"}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","memo":"N","method":"' || vMethod || '","telephone":"' ||
                 vTelphone || '","licensetype":"' || vType || '"}';
      RETURN vResult;
  END;

PROCEDURE JobCheckTimeOut(viData in VARCHAR2)
  AS
      dtNow date;
      vTemp varchar2(20000);
      vRes  varchar2(2000);
      errorResult EXCEPTION;
      inum1 Integer;
      inum2 Integer;
      ivar2 varchar(2000);
      vTempletId varchar(2000);
      vKhSjh  varchar2(500);
      vTemp1 varchar2(20000);
      vTemp2 varchar2(20000);
      vResult VARCHAR2(32000);
      vCompanyName varchar2(20000);
      vFillFlag number(1,0);

  BEGIN
      dtNow := sysdate;
      vTempletId := upper(viData);


      --国内机票出票延时发送短信
      if vTempletId in ('CHECK_PLANE_TICKET_TIMEOUT') then
         --先设置成15分钟
         --客户支付时间比较，state为已支付/出票中
         for rs in (select * from T_CC_PLANE_ORDER where pur_pay_time<=dtNow-15/24/60 and state in ('2','3') and timeout_state='0') loop
            --是否为补单
            vFillFlag := rs.IS_FILL_ORDER;
            if vFillFlag = 0 or vFillFlag is null then
               --发送短信,要提示联系人/预订人
               for comRs in(select * from t_base_company where company_id = rs.company_id ) loop
                  vRes := toCreate('{"templetid":"PLANE_CIVIL_TIMEOUT_TO","id":"' || rs.PLANE_ORDER_ID || '","remark":"' || comRs.IS_NOTICE_TO_BOOKER ||'","telphone":"N","code":null,"message":null,"memo":null}','');
                  update T_CC_PLANE_ORDER set timeout_time=dtNow,timeout_state='1' where PLANE_ORDER_ID=rs.PLANE_ORDER_ID;

                  --tishixiaomi
                  if to_number(to_char(rs.pur_pay_time, 'FMHH24')) not between 8 and 20 then
                  vRes := toCreate('{"templetid":"REMIND_TO_US","id":"' || rs.PLANE_ORDER_NO || '","remark":"1","telphone":"N","code":null,"message":null,"memo":null}','');
                  end if;

                  commit;
               end loop;
            end if;

         end loop ;
      end if ;

      --国际机票出票延时发送短信
      if vTempletId in ('CHECK_INTER_PLANE_TICKET_TIMEOUT') then
         --先设置成30分钟
         --客户支付时间比较，state为已支付/出票中
         for rs in (select * from T_CC_INTER_PLANE_ORDER where pur_pay_time<=dtNow-30/24/60 and state in ('2','3') and timeout_state='0') loop
            vFillFlag := rs.IS_FILL_ORDER;
            if vFillFlag = 0 or vFillFlag is null then
             --发送短信,要提示联系人/预订人
             for comRs in(select * from t_base_company where company_id = rs.company_id ) loop
                vRes := toCreate('{"templetid":"PLANE_INTER_TIMEOUT_TO","id":"' || rs.PLANE_ORDER_ID || '","remark":"' || comRs.IS_NOTICE_TO_BOOKER ||'","telphone":"N","code":null,"message":null,"memo":null}','');
                update T_CC_INTER_PLANE_ORDER set timeout_time=dtNow,timeout_state='1' where PLANE_ORDER_ID=rs.PLANE_ORDER_ID;

     if to_number(to_char(rs.pur_pay_time, 'FMHH24')) not between 8 and 20 then
            vRes := toCreate('{"templetid":"REMIND_TO_US","id":"' || rs.PLANE_ORDER_NO || '","remark":"2","telphone":"N","code":null,"message":null,"memo":null}','');
            end if;

                commit;
             end loop;
          end if;

         end loop ;
      end if ;

      --国内机票退票延时发送短信
      if vTempletId in ('CHECK_PLANE_REFUND_TIMEOUT') then
         --先设置成15分钟
         --退票申请时间比较，state为已申请
         for rs in (select * from T_CC_PLANE_REFUND where APPLY_TIME<=dtNow-15/24/60 and state='1' and timeout_state='0') loop
           --是否为补单
           vFillFlag := rs.IS_FILL_ORDER;
           if vFillFlag = 0 or vFillFlag is null then
             --发送短信
             vRes := toCreate('{"templetid":"PLANE_CIVIL_REFUND_TIMEOUT_TO","id":"'|| rs.REFUND_ID ||'","remark":"N","telphone":"N","code":null,"message":null,"memo":null}','');
             update T_CC_PLANE_REFUND set timeout_time=dtNow,timeout_state='1' where REFUND_ID=rs.REFUND_ID;

           if to_number(to_char(rs.APPLY_TIME, 'FMHH24')) not between 8 and 20 then
           vRes := toCreate('{"templetid":"REMIND_TO_US","id":"' || rs.refund_NO || '","remark":"3","telphone":"N","code":null,"message":null,"memo":null}','');
           end if;

             commit;
          end if;
         end loop ;
      end if ;

       --国际机票退票延时发送短信
      if vTempletId in ('CHECK_INTER_PLANE_REFUND_TIMEOUT') then
         --先设置成30分钟
         --退票申请时间比较，state为已申请
         for rs in (select * from T_CC_INTER_PLANE_REFUND where APPLY_TIME<=dtNow-30/24/60 and state='1' and timeout_state='0') loop
             --发送短信
             vRes := toCreate('{"templetid":"PLANE_INTER_REFUND_TIMEOUT_TO","id":"'|| rs.REFUND_ID ||'","remark":"N","telphone":"N","code":null,"message":null,"memo":null}','');
             update T_CC_INTER_PLANE_REFUND set timeout_time=dtNow,timeout_state='1' where REFUND_ID=rs.REFUND_ID;

if to_number(to_char(rs.APPLY_TIME, 'FMHH24')) not between 8 and 20 then
                  vRes := toCreate('{"templetid":"REMIND_TO_US","id":"' || rs.refund_NO || '","remark":"4","telphone":"N","code":null,"message":null,"memo":null}','');
                  end if;

             commit;
         end loop ;
      end if ;

      --国内机票改签延时发送短信
      if vTempletId in ('CHECK_PLANE_CHANGE_TIMEOUT') then
        --先设置成15分钟


        --改签申请时间比较，state为已申请
         for rs in (select * from T_CC_PLANE_CHANGE where APPLY_TIME<=dtNow-15/24/60 and state='1' and timeout_state='0') loop
            --是否为补单
            vFillFlag := rs.IS_FILL_ORDER;
            if vFillFlag = 0 or vFillFlag is null then
             --发送短信
             vRes := toCreate('{"templetid":"PLANE_CIVIL_CHANGE_TIMEOUT_TO","id":"'|| rs.CHANGE_ID ||'","remark":"","telphone":"N","code":null,"message":null,"memo":null}','');
             update T_CC_PLANE_CHANGE set timeout_time=dtNow,timeout_state='1' where CHANGE_ID=rs.CHANGE_ID;

                if to_number(to_char(rs.APPLY_TIME, 'FMHH24')) not between 8 and 20 then
                 vRes := toCreate('{"templetid":"REMIND_TO_US","id":"' || rs.change_NO || '","remark":"5","telphone":"N","code":null,"message":null,"memo":null}','');
                 end if;

             commit;
            end if;
         end loop ;

      end if ;

      --国际机票改签延时发送短信
      if vTempletId in ('CHECK_INTER_PLANE_CHANGE_TIMEOUT') then
        --先设置成30分钟
        --改签申请时间比较，state为已申请
         for rs in (select * from T_CC_INTER_PLANE_CHANGE where APPLY_TIME<=dtNow-30/24/60 and state='1' and timeout_state='0') loop
             --发送短信
             --是否为补单
             vFillFlag := rs.IS_FILL_ORDER;
             if vFillFlag = 0 or vFillFlag is null then
               vRes := toCreate('{"templetid":"PLANE_INTER_CHANGE_TIMEOUT_TO","id":"'|| rs.CHANGE_ID ||'","remark":"","telphone":"N","code":null,"message":null,"memo":null}','');
               update T_CC_INTER_PLANE_CHANGE set timeout_time=dtNow,timeout_state='1' where CHANGE_ID=rs.CHANGE_ID;

  if to_number(to_char(rs.APPLY_TIME, 'FMHH24')) not between 8 and 20 then
      vRes := toCreate('{"templetid":"REMIND_TO_US","id":"' || rs.change_NO || '","remark":"6","telphone":"N","code":null,"message":null,"memo":null}','');
           end if;

               commit;
            end if;
         end loop ;
      end if ;


      --国内酒店确认延时发送短信
      if vTempletId in ('CHECK_HOTEL_CONFIRM_TIMEOUT') then
       inum1 := 1;
        for rs in (select * from T_CH_HOTEL_ORDER T where  LOCAL_STATUS='0' and timeout_state='0') loop
        --是否为补单
         vFillFlag := rs.IS_FILL_ORDER;

          if rs.order_type = 1 then--艺龙
            if  trunc(rs.ARRIVAL_DATE ) = trunc(sysdate ) then--当天
              inum1 := 30;
              ivar2 := 'HOTEL_DAY_TIMEOUT_TO';
            else --隔天
               if to_number(to_char(rs.create_time, 'hh24mi')) between 0600 and 2115 then --日班
                inum1 := 75;
                ivar2 := 'HOTEL_DAY_TIMEOUT_TO';
               else --中班
                inum1 := 30;
                ivar2 := 'HOTEL_LIGHT_TIMEOUT_TO';
              end if;
            end if;

          else--房仓
            if  trunc(rs.ARRIVAL_DATE ) = trunc(sysdate ) then--当天
              inum1 := 75;
              ivar2 := 'HOTEL_DAY_TIMEOUT_TO';
            else --隔天
               if to_number(to_char(rs.create_time, 'hh24mi')) between 0600 and 2115 then --日班
                inum1 := 120;
                ivar2 := 'HOTEL_DAY_TIMEOUT_TO';
               else --中班
                inum1 := 30;
                ivar2 := 'HOTEL_LIGHT_TIMEOUT_TO';
              end if;
            end if;

          end if;


          if rs.create_time <= dtNow - inum1/24/60 and vFillFlag = 0 or vFillFlag is null then
          --发送短信,要提示联系人/预订人
           for comRs in(select * from t_base_company where company_id = rs.company_id ) loop
              vRes := toCreate('{"templetid":"'|| ivar2 ||'","id":"' || rs.AFFILIATE_CONFIRMATION_ID || '","remark":"' || comRs.IS_NOTICE_TO_BOOKER ||'","telphone":"N","code":null,"message":null,"memo":null}','');
              update T_CH_HOTEL_ORDER set timeout_time=dtNow,timeout_state='1' where AFFILIATE_CONFIRMATION_ID=rs.AFFILIATE_CONFIRMATION_ID;
              commit;
           end loop;

          end if;



        end loop;


      end if ;


       --国内机票起飞提醒
      if vTempletId in ('CHECK_PLANE_CIVIL_OFF') then
        if to_char(sysdate,'HH24') = 20 then
            --20:00的需要+6到+16
            inum1 :=  6;
            inum2 :=  16;
        else
            --非20:00的需要+6到+7
            inum1 := 6;
            inum2 := 6;
        end if;

        for rs in (
                        select a.* from
            (
           with orig_ticket_od as
 (select t7.plane_ticket_id, t7.idc_name, t7.phone, t8.plane_od_id
    from t_cc_plane_order t6, t_cc_ticket_passenger t7, t_cc_plane_od t8
   where t6.plane_order_id = t7.plane_order_id
     and t8.plane_order_id = t6.plane_order_id
     and t7.state = '3'
     and t7.prev_plane_ticket_id is null
     and t8.depart_time >= sysdate),
change_ticket_od as
 (select t2.plane_ticket_id, t2.idc_name, t2.phone, t4.plane_od_id
    from t_cc_plane_od t4,
         t_cc_ticket_passenger t2,
         (select t3.*
            from t_cc_ticket_od t3,
                 (select *
                    from t_cc_change_ticket t1
                   where exists (select 1
                            from (select plane_order_id,
                                         max(change_id) change_id
                                    from t_cc_plane_change
                                   where state = '3'
                                   group by plane_order_id)
                           where change_id = t1.change_id)) t32
           where t32.plane_ticket_id = t3.plane_ticket_id) t5
   where t4.plane_od_id = t5.plane_od_id
     and t5.plane_ticket_id = t2.plane_ticket_id
     and t2.state = '3'
     and t4.depart_time >= sysdate)
select t12.plane_ticket_id, t12.idc_name, t12.phone, t11.*
  from t_cc_plane_trip t11,
       (select t10.plane_od_id,
               t10.plane_ticket_id,
               t10.idc_name,
               t10.phone,
               min(t9.take_off_time) take_off_time
          from t_cc_plane_trip t9,
               (select *
                  from orig_ticket_od
                union
                select * from change_ticket_od) t10
         where t9.plane_od_id = t10.plane_od_id
           and t9.take_off_time is not null
         group by t10.plane_od_id,
                  t10.plane_ticket_id,
                  t10.idc_name,
                  t10.phone) t12
 where t11.plane_od_id = t12.plane_od_id
   and t11.take_off_time = t12.take_off_time

               )a
              where a.take_off_time >= trunc(SYSDATE + inum1/24, 'HH24') and a.take_off_time < trunc(SYSDATE + (inum2 + 1)/24, 'HH24')

        ) loop


        vKhSjh := rs.phone;
        --是否为补单
        for rsOrder in (select IS_FILL_ORDER
                          from t_cc_plane_order
                            where plane_order_no in
                            (select plane_order_no
                              from t_cc_ticket_passenger
                                where plane_ticket_id=rs.plane_ticket_id)) loop

          vFillFlag := rsOrder.IS_FILL_ORDER;
        end loop;

        if length(NVL(vKhSjh,'N')) = 11 then
        select nvl(Text1, 'N') into vTemp from t_base_templet where code='REMIND_PLANE_CIVIL_OFF';
        vTemp := Replace(vTemp,'#TIME#',to_char(rs.take_off_time, 'FMMM"月"DD"日"'));

        --切割trip
        select nvl((select city_name_cn from T_BASE_CITY where city_code = rs.depart_city_code and rownum <= 1),rs.depart_city_code) into vTemp1 from dual;
        vTemp2 := vTemp2 || vTemp1 || '-';
        select nvl((select city_name_cn from T_BASE_CITY where city_code = rs.arrive_city_code and rownum <= 1),rs.arrive_city_code) into vTemp1 from dual;
        vTemp2 := vTemp2 || vTemp1;
        vTemp := Replace(vTemp,'#TRIP#', vTemp2);

        vTemp := Replace(vTemp,'#HOUR#', to_char(rs.take_off_time, 'FMHH24:FMMI'));

        vTemp2 := '';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp1 from dual;
        vTemp2 :=  vTemp1 || rs.depart_airport_tower ;
        vTemp := Replace(vTemp,'#AIRPORT#', vTemp2);

        vTemp2 := '';
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp1 from dual;
        vTemp2 := vTemp1 || rs.airline_code || rs.flight_no;
        vTemp := Replace(vTemp,'#FLIGHTNO#', vTemp2);

        if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
        for rsCompany in (select * from T_base_company where company_id = rs.company_id and rownum <= 1) loop
           vCompanyName := rsCompany.company_name;
        end loop;

        vResult := insertToQueue('REMIND_PLANE_CIVIL_OFF', rs.plane_ticket_id, vTemp, vKhSjh, '7', rs.plane_order_no, vCompanyName);
        end if;

        end if;
        end loop;


      end if ;

       --国内机票起飞提醒
      if vTempletId in ('CHECK_PLANE_CIVIL_OFF_NEW') then

            inum1 := 3;
            inum2 := 3;

        for rs in (
                        select a.* from
            (
           with orig_ticket_od as
 (select t7.plane_ticket_id, t7.idc_name, t7.phone, t8.plane_od_id
    from t_cc_plane_order t6, t_cc_ticket_passenger t7, t_cc_plane_od t8
   where t6.plane_order_id = t7.plane_order_id
     and t8.plane_order_id = t6.plane_order_id
     and t7.state = '3'
     and t7.prev_plane_ticket_id is null
     and t8.depart_time >= sysdate),
change_ticket_od as
 (select t2.plane_ticket_id, t2.idc_name, t2.phone, t4.plane_od_id
    from t_cc_plane_od t4,
         t_cc_ticket_passenger t2,
         (select t3.*
            from t_cc_ticket_od t3,
                 (select *
                    from t_cc_change_ticket t1
                   where exists (select 1
                            from (select plane_order_id,
                                         max(change_id) change_id
                                    from t_cc_plane_change
                                   where state = '3'
                                   group by plane_order_id)
                           where change_id = t1.change_id)) t32
           where t32.plane_ticket_id = t3.plane_ticket_id) t5
   where t4.plane_od_id = t5.plane_od_id
     and t5.plane_ticket_id = t2.plane_ticket_id
     and t2.state = '3'
     and t4.depart_time >= sysdate)
select t12.plane_ticket_id, t12.idc_name, t12.phone, t11.*
  from t_cc_plane_trip t11,
       (select t10.plane_od_id,
               t10.plane_ticket_id,
               t10.idc_name,
               t10.phone,
               min(t9.take_off_time) take_off_time
          from t_cc_plane_trip t9,
               (select *
                  from orig_ticket_od
                union
                select * from change_ticket_od) t10
         where t9.plane_od_id = t10.plane_od_id
           and t9.take_off_time is not null
         group by t10.plane_od_id,
                  t10.plane_ticket_id,
                  t10.idc_name,
                  t10.phone) t12
 where t11.plane_od_id = t12.plane_od_id
   and t11.take_off_time = t12.take_off_time

               )a
              where a.take_off_time >= trunc(SYSDATE + inum1/24, 'HH24') and a.take_off_time < trunc(SYSDATE + (inum2 + 1)/24, 'HH24')

        ) loop


        vKhSjh := rs.phone;
        --是否为补单
       for rsOrder in (select IS_FILL_ORDER
                         from t_cc_plane_order
                           where plane_order_no in
                           (select plane_order_no
                             from t_cc_ticket_passenger
                               where plane_ticket_id=rs.plane_ticket_id)) loop

         vFillFlag := rsOrder.IS_FILL_ORDER;
       end loop;

        if length(NVL(vKhSjh,'N')) = 11 then
        select nvl(Text1, 'N') into vTemp from t_base_templet where code='REMIND_PLANE_CIVIL_OFF';
        vTemp := Replace(vTemp,'#TIME#',to_char(rs.take_off_time, 'FMMM"月"DD"日"'));

        --切割trip
        vTemp1 := '';
        vTemp2 := '';
        select nvl((select city_name_cn from T_BASE_CITY where city_code = rs.depart_city_code and rownum <= 1),rs.depart_city_code) into vTemp1 from dual;
        vTemp2 := vTemp1 || '-';
        select nvl((select city_name_cn from T_BASE_CITY where city_code = rs.arrive_city_code and rownum <= 1),rs.arrive_city_code) into vTemp1 from dual;
        vTemp2 := vTemp2 || vTemp1;
        vTemp := Replace(vTemp,'#TRIP#', vTemp2);

        vTemp := Replace(vTemp,'#HOUR#', to_char(rs.take_off_time, 'FMHH24:FMMI'));

        vTemp2 := '';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp1 from dual;
        vTemp2 :=  vTemp1 || rs.depart_airport_tower ;
        vTemp := Replace(vTemp,'#AIRPORT#', vTemp2);

        vTemp2 := '';
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp1 from dual;
        vTemp2 := vTemp1 || rs.airline_code || rs.flight_no;
        vTemp := Replace(vTemp,'#FLIGHTNO#', vTemp2);

        if Length(vKhSjh) = 11 and vFillFlag = 0 or vFillFlag is null then
          for rsCompany in (select * from T_base_company where company_id = rs.company_id and rownum <= 1) loop
             vCompanyName := rsCompany.company_name;
          end loop;

          vResult := insertToQueue('REMIND_PLANE_CIVIL_OFF', rs.plane_ticket_id, vTemp, vKhSjh, '7', rs.plane_order_no, vCompanyName);
        end if;

        end if;
        end loop;


      end if ;


      --国内酒店提前一天提醒
      if vTempletId in ('CHECK_HOTEL_CIVIL_IN') then

         for rs in (
                select t.* from t_ch_hotel_order t where local_status = '2'
                  and TRUNC(t.ARRIVAL_DATE,'DD') = TRUNC(sysdate +1,'DD')
                    and TRUNC(t.CREATE_TIME,'DD') != TRUNC(sysdate,'DD')
         ) loop
         --是否为补单
         vFillFlag := rs.IS_FILL_ORDER;
          if vFillFlag = 0 or vFillFlag is null then
             --发送短信
             vRes := toCreate('{"templetid":"REMIND_HOTEL_CIVIL_IN","id":"'|| rs.AFFILIATE_CONFIRMATION_ID ||'","remark":"N","telphone":"N","code":null,"message":null,"memo":null}','');
             --update T_CH_HOTEL_ORDER set remind_state='1' where AFFILIATE_CONFIRMATION_ID=rs.AFFILIATE_CONFIRMATION_ID;
             commit;
          end if;
         end loop ;
      end if ;



  EXCEPTION
    WHEN OTHERS THEN
       dbms_output.put_line(SQLERRM);
  END;


  PROCEDURE JobAnalyseReply(viData in VARCHAR2)
  AS
      dtNow date;
      vTemp varchar2(20000);
      vRes  varchar2(2000);
      errorResult EXCEPTION;
      agreeNo varchar2(2000);
      ivar2 varchar2(2000);
      orderNo varchar2(2000);
      replyContent varchar2(2000);
      telphone varchar2(2000);

  BEGIN
      dtNow := sysdate;


      for replyRs in (select * from T_BASE_MESSAGE_REPLY) loop
        replyContent := replyRs.content;
        if replyContent is not null then
          agreeNo := substr(replyContent, 1 ,1);
          ivar2 := substr(replyContent, 2 ,1);
          if agreeNo in ('0','1') then
            if ivar2 not in ('0','1','2','3','4','5','6','7','8','9') then --不是数字
              orderNo := substr(replyContent, 2);--从第3位开始
            else
              orderNo := substr(replyContent, 1);--从第2位开始
            end if;

            --判断是出差申请单还是订单申请
           if length(orderNo) = 10 then--订单申请

             if substr(orderNo, 1,2) = '11' then--国内机票
                for telphoneRs in(SELECT u.mobilephone FROM t_cc_plane_order T , t_base_user u where t.CREATE_USER = u.user_id and t.plane_order_no = orderNo and rownum<=1) loop
                telphone := telphoneRs.mobilephone;
                end loop;
                --更改状态
              if agreeNo ='0' then --不同意
                update T_CC_PLANE_ORDER t set t.AUDIT_STATE = 3 where t.PLANE_ORDER_NO = orderNo;
              else--同意
                update T_CC_PLANE_ORDER t set t.AUDIT_STATE = 2 where t.PLANE_ORDER_NO = orderNo;
              end if;


             else
               if substr(orderNo, 1,2) = '21' then--国际机票
                --更改状态
                if agreeNo ='0' then --不同意
                  update T_CC_INTER_PLANE_ORDER t set t.AUDIT_STATE = 3 where t.PLANE_ORDER_NO = orderNo;
                else--同意
                  update T_CC_INTER_PLANE_ORDER t set t.AUDIT_STATE = 2 where t.PLANE_ORDER_NO = orderNo;
                end if;

                for telphoneRs in(SELECT u.mobilephone FROM t_cc_inter_plane_order T , t_base_user u where t.CREATE_USER = u.user_id and t.plane_order_no = orderNo and rownum<=1) loop
                telphone := telphoneRs.mobilephone;
                end loop;


               else
                if substr(orderNo, 1,2) = '31' then--酒店

                    NULL;
                else
                  if substr(orderNo, 1,2) = '41' then--火车票
                      --更改状态
                  if agreeNo ='0' then --不同意
                    update T_CC_TRAIN_ORDER t set t.AUDIT_STATE = 3 where t.TRAIN_ORDER_NO = orderNo;
                  else--同意
                    update T_CC_TRAIN_ORDER t set t.AUDIT_STATE = 2 where t.TRAIN_ORDER_NO = orderNo;
                  end if;

                  for telphoneRs in(SELECT u.mobilephone FROM t_cc_train_order T , t_base_user u where t.CREATE_USER_ID = u.user_id and t.train_order_no = orderNo and rownum<=1) loop
                  telphone := telphoneRs.mobilephone;
                  end loop;

                  else
                  NULL;
                  end if;
                end if;
               end if;

                --发送短信
              vRes := toCreate('{"templetid":"ORDER_FOR_REPLY_NEW","id":"' || orderNo || '","remark":"' || agreeNo ||'","telphone":"'|| telphone ||'","code":null,"message":null,"memo":null}','');

             end if;



            else--出差单申请
              --更改状态
              if agreeNo ='0' then --不同意
                update T_CC_BUSINESS_TRIP t set t.state = 4 where t.BIZ_TRIP_ID = orderNo;
              else--同意
                update T_CC_BUSINESS_TRIP t set t.state = 3 where t.BIZ_TRIP_ID = orderNo;
              end if;

              --发送短信
              vRes := toCreate('{"templetid":"BIZ_TRIP_FOR_REPLY","id":"' || orderNo || '","remark":"' || agreeNo ||'","telphone":"N","code":null,"message":null,"memo":null}','');

            end if;



          end if;

        end if;

      end loop;


  EXCEPTION
    WHEN OTHERS THEN
      null;
  END;


  PROCEDURE JobSendEmail(viData in varchar2)
  as
    iNum integer ;
    dtNow date;
    vTmp1 varchar2(5000);
    vTmp2 varchar2(5000);
    vTmp3 varchar2(10000);
    vTmp4 varchar2(10000);
    vRes varchar2(10000);
    vIP varchar2(500);
  begin
    dtNow := sysdate;
     --查询IP
    select VALUE INTO vIP from T_BASE_CONFIG_CONST where NAME='EMAIL_TO_JL_JIKE';
    --search
    for rs in (select * from t_cc_order_accredit where accredit_state='0' and email_state='1' order by id) loop
      if length(rs.guid)=32 then
        select count(0) into iNum from T_BASE_EMAIL_QUEUE where mq_guid=upper(trim(rs.guid));
        if iNum<1 then
        --获得用户EMAIL地址
          select nvl((select email from t_base_user where user_id=rs.accredit_user and rownum<=1),'') into vTmp1 from dual;
          --select '330771718@qq.com' into vTmp1 from dual;
          --获得创建用户姓名地址
          select nvl((select name_cn from t_base_user where user_id=rs.create_user and rownum<=1),'') into vTmp2 from dual;

          --emiliaAdd
          --获得订单信息
          if rs.order_type = '1' then--国内机票
            for planeOrder in (select t.* from t_cc_plane_order t where t.plane_order_id = rs.order_id and rownum <=1) loop
              --获得passenger信息
              for passenger in (select * from t_cc_ticket_passenger where plane_order_id = rs.order_id and rownum <=1) loop
                  vTmp3 := '';
                  vTmp3 := vTmp3||'<p style="font-size:12px">尊敬的用户，您好：<br><br>';
                  vTmp3 := vTmp3||'　　'||vTmp2||'提交了一份新的授权订单，急需您的审阅，请点击以下地址进入<br>';
                  vTmp3 := vTmp3||'<a  href="http://'||vIP||'/travel_web/accredit.jsp?guid='||rs.guid||'">http://'||vIP||'/travel_web/accredit.jsp?guid='||rs.guid||'</a>';
                  vTmp3 := vTmp3||'<br><br>';

                  --订单信息start
                  vTmp3 := vTmp3||'<div>';
                  vTmp3 := vTmp3||'<fieldset>';
                  vTmp3 := vTmp3||'<legend><span style="font-size:18px;color:#2a6496;">订单信息</span></legend>';
                  vTmp3 := vTmp3||'订单号: <span>'|| planeOrder.plane_order_no ||'</span> <br>';
                  vTmp3 := vTmp3||'下单时间: <span>'|| to_char(planeOrder.create_time, 'yyyy-MM-dd HH24:mi:ss') ||'</span> <br/>';
                  vTmp3 := vTmp3||'联系人: <span>'|| planeOrder.CONTACT_NAME ||'</span> <br>';
                  vTmp3 := vTmp3||'邮箱: <span>'|| planeOrder.CONTACT_EMAIL ||'</span> <br>';
                  vTmp3 := vTmp3||'电话: <span>'|| planeOrder.CONTACT_PHONE ||'</span> <br>';
                  vTmp3 := vTmp3||'</fieldset>';
                  vTmp3 := vTmp3||'</div>';
                  --订单信息end

                  --金额信息start
                  vTmp3 := vTmp3||'<fieldset>';
                  vTmp3 := vTmp3||'<legend><span style="font-size:18px;color:#2a6496;">金额信息</span></legend>';
                  vTmp3 := vTmp3||'<div class="fltMoney">';
                  vTmp3 := vTmp3||'<strong>应付金额：</strong> ..........................￥ <span>'|| planeOrder.SALE_PRICE ||'</span>  <br>';
                  vTmp3 := vTmp3||'<strong>成人</strong> ..........................￥ <span>'|| passenger.SALE_PRICE ||'</span> x <span>'|| planeOrder.PASSENGER_NUM ||'</span> 人 <br>';
                  vTmp3 := vTmp3||'&'||'&nbsp;;;;机票价 ..........................￥ <span>'|| to_char(passenger.SALE_PRICE-passenger.AIRPORT_CST_FEE) ||'</span> /人 <br>';
                  vTmp3 := vTmp3||'&'||'&nbsp;;;;机建费 ..........................￥ <span>'|| to_char(passenger.AIRPORT_CST_FEE) ||'</span> /人 <br>';
                  vTmp3 := vTmp3||'<strong>保险费</strong> ..........................￥ <span>'|| to_char(planeOrder.INSURANCE_SALE_PRICE) ||'</span> <br>';
                  vTmp3 := vTmp3||'</div>';
                  vTmp3 := vTmp3||'</fieldset>';
                  --金额信息end

                  --航班信息start
                  vTmp3 := vTmp3||'<div><fieldset><legend><span style="font-size:18px;color:#2a6496;">航班信息</span></legend>';
                  for planeOD in (select t.* from t_cc_plane_od t where t.plane_order_id = rs.order_id  order by t.plane_od_id ) loop
                  vTmp3 := vTmp3 ||'<hr><div><br><table><tr><td>出发时间:<span>'|| to_char(planeOD.DEPART_TIME,'yyyy-MM-dd HH24:mi:ss') ||'</span></td><td>→→→→→→</td><td>到达时间:<span>'|| to_char(planeOD.arrive_TIME,'yyyy-MM-dd HH24:mi:ss') ||'</span></td></tr><t                     for planeTrip in (select t.*, t.rowid from t_cc_plane_trip t  where t.plane_od_id=planeOD.Plane_Od_Id order by t.plane_trip_id) loop
                     vTmp3 := vTmp3 ||'<tr><td><span>'|| planeTrip.Depart_Airport_Name||'</span></td><td>→→→→→→</td><td><span>'|| planeTrip.Arrive_Airport_Name ||'</span></td><td><span>'|| planeTrip.Airline_Code||' '||planeTrip.Flight_No ||'</span></td></t                     end loop;
                     vTmp3 := vTmp3 ||' <tr style="font-size:12px;"><td>退：<span>'|| planeOD.refund_rules ||'</span></td></tr><tr style="font-size:12px;"><td>改：'|| planeOD.CHANGE_rules  ||'</span></td></tr><tr style="font-size:12px;"><td>签：<span>'|| planeOD                  end loop;
                  vTmp3 := vTmp3||'</fieldset></div>';
                  --航班信息end

                  --乘客信息start
                  vTmp3 := vTmp3||'<div><fieldset><legend><span style="font-size:18px;color:#2a6496;">乘客信息</span></legend>';
                  for ticket in (select t.* from t_cc_ticket_passenger t where t.plane_order_id=rs.order_id order by t.plane_ticket_id) loop
                  select nvl((select cost_center_name from t_base_cost_center where cost_center_id=ticket.cost_center_id and rownum<=1),'') into vTmp4 from dual;
                  vTmp3 := vTmp3||' |乘客: <span>'|| ticket.idc_name ||'</span> &nbsp;;;;&nbsp;;;;|证件: <span>'|| ticket.idc_no ||'</span>|票号: <span>'|| ticket.plane_ticket_no ||'</span> &nbsp;;;;&nbsp;;;;|票价: <span>'|| ticket.sale_price ||'</span> &nbsp;;;;&                  end loop;
                  vTmp3 := vTmp3||'</fieldset></div>';
                  --乘客信息end

                  --订票人信息start
                  vTmp3 := vTmp3||'<div><fieldset><legend><span style="font-size:18px;color:#2a6496;">订票人信息</span></legend>';
                  for orderUser in (select * from t_base_user where user_id = rs.create_user and rownum <=1) loop
                      select nvl((select dept_name from t_base_department where dept_id=orderUser.User_Id and rownum<=1),'') into vTmp4 from dual;
                      vTmp3 := vTmp3||'|姓名: <span>'|| orderUser.name_cn ||'</span> &nbsp;;;;&nbsp;;;;|手机号: <span>'|| orderUser.mobilephone ||'</span> &nbsp;;;;&nbsp;;;;|部门: <span>'|| vTmp4 ||'</span> &nbsp;;;;&nbsp;;;;<br>';
                  end loop;
                  vTmp3 := vTmp3||'</fieldset></div>';
                  --订票人信息end

                  vTmp3 := vTmp3||'祝您生活愉快。<br><br>';
                  vTmp3 := vTmp3||'苏州罗盘网络科技有限公司<br>';
                  vTmp3 := vTmp3||'地址: 苏州工业园区金鸡湖大道1355号国际科技园4期1802单元；邮编:215000<br>';
                  vTmp3 := vTmp3||'客服电话: 400-723-9888<br>';
                  vTmp3 := vTmp3||'电话: 0512-6661 1666| 传真: 0512-6661 1666<br>';
                  vTmp3 := vTmp3||'公司网址: www.luopan88.com</p>';
              end loop;

           end loop;

          else


          if rs.order_type = '2'  then--国际机票
              for planeOrder in (select t.* from t_cc_inter_plane_order t where t.plane_order_id = rs.order_id and rownum <=1) loop
              --获得passenger信息
              for passenger in (select * from t_cc_inter_ticket_passenger where plane_order_id = rs.order_id and rownum <=1) loop
                  vTmp3 := '';
                  vTmp3 := vTmp3||'<p style="font-size:12px">尊敬的用户，您好：<br><br>';
                  vTmp3 := vTmp3||'　　'||vTmp2||'提交了一份新的授权订单，急需您的审阅，请点击以下地址进入<br>';
                  vTmp3 := vTmp3||'<a  href="http://'||vIP||'/travel_web/accredit.jsp?guid='||rs.guid||'">http://'||vIP||'/travel_web/accredit.jsp?guid='||rs.guid||'</a>';
                  vTmp3 := vTmp3||'<br><br>';

                  --订单信息start
                  vTmp3 := vTmp3||'<div>';
                  vTmp3 := vTmp3||'<fieldset>';
                  vTmp3 := vTmp3||'<legend><span style="font-size:18px;color:#2a6496;">订单信息</span></legend>';
                  vTmp3 := vTmp3||'订单号: <span>'|| planeOrder.plane_order_no ||'</span> <br>';
                  vTmp3 := vTmp3||'下单时间: <span>'|| to_char(planeOrder.create_time, 'yyyy-MM-dd HH24:mi:ss') ||'</span> <br/>';
                  vTmp3 := vTmp3||'联系人: <span>'|| planeOrder.Contact_Last_Name ||' '||planeOrder.Contact_First_Name ||'</span> <br>';
                  vTmp3 := vTmp3||'邮箱: <span>'|| planeOrder.CONTACT_EMAIL ||'</span> <br>';
                  vTmp3 := vTmp3||'电话: <span>'|| planeOrder.CONTACT_PHONE ||'</span> <br>';
                  vTmp3 := vTmp3||'</fieldset>';
                  vTmp3 := vTmp3||'</div>';
                  --订单信息end

                  --金额信息start
                  vTmp3 := vTmp3||'<fieldset>';
                  vTmp3 := vTmp3||'<legend><span style="font-size:18px;color:#2a6496;">金额信息</span></legend>';
                  vTmp3 := vTmp3||'<div class="fltMoney">';
                  vTmp3 := vTmp3||'<strong>应付金额：</strong> ..........................￥ <span>'|| planeOrder.SALE_PRICE ||'</span>  <br>';
                  vTmp3 := vTmp3||'<strong>成人</strong> ..........................￥ <span>'|| passenger.SALE_PRICE ||'</span> x <span>'|| planeOrder.PASSENGER_NUM ||'</span> 人 <br>';
                  vTmp3 := vTmp3||'&'||'nbsp;机票价 ..........................￥ <span>'|| to_char(passenger.SALE_PRICE-passenger.tax) ||'</span> /人 <br>';
                  vTmp3 := vTmp3||'&'||'nbsp;机建费 ..........................￥ <span>'|| to_char(passenger.tax) ||'</span> /人 <br>';
                  vTmp3 := vTmp3||'<strong>保险费</strong> ..........................￥ <span>'|| to_char(planeOrder.INSURANCE_SALE_PRICE) ||'</span> <br>';
                  vTmp3 := vTmp3||'</div>';
                  vTmp3 := vTmp3||'</fieldset>';
                  --金额信息end

                  --航班信息start
                  vTmp3 := vTmp3||'<div><fieldset><legend><span style="font-size:18px;color:#2a6496;">航班信息</span></legend>';
                  for planeOD in (select t.* from t_cc_inter_plane_od t where t.plane_order_id = rs.order_id  order by t.plane_od_id ) loop
                  vTmp3 := vTmp3 ||'<hr><div><br><table><tr><td>出发时间:<span>'|| to_char(planeOD.DEPART_TIME,'yyyy-MM-dd HH24:mi:ss') ||'</span></td><td>→→→→→→</td><td>到达时间:<span>'|| to_char(planeOD.arrive_TIME,'yyyy-MM-dd HH24:mi:ss') ||'</span></td></tr><t                     for planeTrip in (select t.*, t.rowid from t_cc_inter_plane_trip t  where t.plane_od_id=planeOD.Plane_Od_Id order by t.plane_trip_id) loop
                     vTmp3 := vTmp3 ||'<tr><td><span>'|| planeTrip.Depart_Airport_Name||'</span></td><td>→→→→→→</td><td><span>'|| planeTrip.Arrive_Airport_Name ||'</span></td><td><span>'|| planeTrip.Airline_Code||' '||planeTrip.Flight_No ||'</span></td></t                     end loop;
                     vTmp3 := vTmp3 ||' <tr style="font-size:12px;"><td> 退改签及购票说明:<span>'|| planeOD.Refund_Change_Rules ||'</span></td></tr></table></div><hr>';
                  end loop;
                  vTmp3 := vTmp3||'</fieldset></div>';
                  --航班信息end

                  --乘客信息start
                  vTmp3 := vTmp3||'<div><fieldset><legend><span style="font-size:18px;color:#2a6496;">乘客信息</span></legend>';
                  for ticket in (select t.* from t_cc_inter_ticket_passenger t where t.plane_order_id=rs.order_id order by t.plane_ticket_id) loop
                  select nvl((select cost_center_name from t_base_cost_center where cost_center_id=ticket.cost_center_id and rownum<=1),'') into vTmp4 from dual;
                  vTmp3 := vTmp3||' |乘客: <span>'|| ticket.idc_name ||'</span> &nbsp;;;;&nbsp;;;;|证件: <span>'|| ticket.idc_no ||'</span>|票号: <span>'|| ticket.plane_ticket_no ||'</span> &nbsp;;;;&nbsp;;;;|票价: <span>'|| ticket.sale_price ||'</span> &nbsp;;;;&                  end loop;
                  vTmp3 := vTmp3||'</fieldset></div>';
                  --乘客信息end

                  --订票人信息start
                  vTmp3 := vTmp3||'<div><fieldset><legend><span style="font-size:18px;color:#2a6496;">订票人信息</span></legend>';
                  for orderUser in (select * from t_base_user where user_id = rs.create_user and rownum <=1) loop
                      select nvl((select dept_name from t_base_department where dept_id=orderUser.User_Id and rownum<=1),'') into vTmp4 from dual;
                      vTmp3 := vTmp3||'|姓名: <span>'|| orderUser.name_cn ||'</span> &nbsp;;;;&nbsp;;;;|手机号: <span>'|| orderUser.mobilephone ||'</span> &nbsp;;;;&nbsp;;;;|部门: <span>'|| vTmp4 ||'</span> &nbsp;;;;&nbsp;;;;<br>';
                  end loop;
                  vTmp3 := vTmp3||'</fieldset></div>';
                  --订票人信息end

          vTmp3 := vTmp3||'祝您生活愉快。<br><br>';
          vTmp3 := vTmp3||'苏州罗盘网络科技有限公司<br>';
          vTmp3 := vTmp3||'地址: 苏州工业园区金鸡湖大道1355号国际科技园4期1802单元；邮编:215000<br>';
          vTmp3 := vTmp3||'客服电话: 400-723-9888<br>';
          vTmp3 := vTmp3||'电话: 0512-6661 1666| 传真: 0512-6661 1666<br>';
          vTmp3 := vTmp3||'公司网址: www.luopan88.com</p>';
              end loop;

            end loop;

          else

        vTmp3 := '';
        vTmp3 := vTmp3||'祝您生活愉快。<br><br>';
        vTmp3 := vTmp3||'苏州罗盘网络科技有限公司<br>';
        vTmp3 := vTmp3||'地址: 苏州工业园区金鸡湖大道1355号国际科技园4期1802单元；邮编:215000<br>';
        vTmp3 := vTmp3||'客服电话: 400-723-9888<br>';
        vTmp3 := vTmp3||'电话: 0512-6661 1666| 传真: 0512-6661 1666<br>';
        vTmp3 := vTmp3||'公司网址: www.luopan88.com</p>';

          end if;

          end if;

          insert into T_BASE_EMAIL_QUEUE
            (mq_id,
             mq_type,
             mq_text1,
             mq_text2,
             mq_text3,
             mq_object,
             mq_level,
             mq_state,
             mq_sender,
             mq_sendtime,
             mq_remark,
             create_time,
             create_user,
             create_remark,
             mq_guid)
          values
            (to_char(dtNow, 'YYMMDD') || seq_email_queue_id.nextval,
             '3',
             '您有一笔新的授权订单('||vTmp2||')',
             substr(vTmp3,1,2000),
             substr(vTmp3,2000+1,2000),
             vTmp1,
             '1',
             '0',
             'administrator@luopan88.com',
             dtNow,
             null,
             dtNow,
             'SYSTEM',
             null,
             upper(trim(rs.guid)));
          update t_cc_order_accredit set email_state='2' where ID=rs.ID;
          commit ;
        end if ;
      end if ;
    end loop ;
    --send
    for rsQueue in (select * from T_BASE_EMAIL_QUEUE where MQ_STATE in ('0','1') order by mq_id) loop
      if instr(Trim(rsQueue.Mq_Object),'@')>1 and instr(Trim(rsQueue.Mq_Object),'.')>3 then
        vRes := dbis_sms_tool.sendmail(vitouser => rsQueue.mq_object,
                                    vititle => rsQueue.mq_text1,
                                    vibody => rsQueue.mq_text2||rsQueue.mq_text3);
        update T_BASE_EMAIL_QUEUE set MQ_STATE='2',MQ_REMARK=substrb(vRes,1,200) where mq_id=rsQueue.mq_id;
      else
        update T_BASE_EMAIL_QUEUE set MQ_STATE='3',MQ_REMARK='邮件地址错误' where mq_id=rsQueue.mq_id;
      end if ;
      commit ;
    end loop ;
  end;


END;