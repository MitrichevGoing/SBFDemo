create PACKAGE DBIS_CLIENT_JSON IS
  ----------------------------------
  -- 数据库接口简单版-客户系统--JSON
  --
  -- 日期：2014-12-10
  ----------------------------------
  FUNCTION readData(viData IN VARCHAR2, viText IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION writeData(viData IN VARCHAR2, viText IN VARCHAR2) RETURN VARCHAR2;
END;
