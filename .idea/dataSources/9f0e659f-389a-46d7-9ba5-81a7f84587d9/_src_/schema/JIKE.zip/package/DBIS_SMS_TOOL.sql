create PACKAGE DBIS_SMS_TOOL IS
  ----------------------------------
  -- 编码转换
  -- viCharset：UTF-8,GB2312
  ----------------------------------
  function encodeUrl(viText IN VARCHAR2,viCharset IN VARCHAR2) RETURN VARCHAR2;
  ----------------------------------
  -- 发送短信接口
  -- viType 1=创蓝，2=一信通
  -- viPhone 电话
  -- viText 短信
  -- viExtNo 长号码扩展（0-999999）
  -- viMemo 备注
  ----------------------------------
  function send(viType in varchar2,viPhone in varchar2,viText IN VARCHAR2,viExtNo in varchar2,viMemo in Varchar2) RETURN VARCHAR2;
  ----------------------------------
  -- 发送邮件
  -- viToUser 接收人
  -- viTitle  邮件标题
  -- viBody   邮件内容，支持HTML
  ----------------------------------
  FUNCTION sendMail(viToUser IN VARCHAR2,viTitle IN VARCHAR2,viBody IN VARCHAR2) RETURN VARCHAR2;
END;