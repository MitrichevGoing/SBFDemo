create PACKAGE BODY DBIN_SYSTEM_JSON IS
TYPE ListString IS TABLE OF VARCHAR2(32000);

--------------------------------------------------------------
-- 通用函数：MD5加密
--------------------------------------------------------------
FUNCTION encodeMD5(myText IN VARCHAR2) RETURN VARCHAR2
AS
    RAW_INPUT RAW(128) := UTL_RAW.CAST_TO_RAW(UPPER(myText));
    DECRYPTED_RAW RAW(2048);
    ERROR_IN_INPUT_BUFFER_LENGTH EXCEPTION;
BEGIN
    IF (Length(myText)<=0) OR (myText IS NULL) THEN
        RETURN 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
    ELSE
        SYS.DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT => RAW_INPUT, CHECKSUM => DECRYPTED_RAW);
        RETURN LOWER(RAWTOHEX(DECRYPTED_RAW));
    END IF ;
END;

--------------------------------------------------------------
-- 通用函数：字符串转换成整形
--------------------------------------------------------------
FUNCTION convertStrToInt(viString IN VARCHAR2,iiDefault IN INTEGER) RETURN INTEGER
AS
  voRes varchar2(250);
  noRes number ;
  ioRes integer ;
BEGIN
  ioRes := iiDefault;
  if LengthB(viString)>18 then
    return ioRes;
  end if ;
  voRes := Trim(viString);
  if substr(voRes,1,1) in ('-') then
    voRes  := substr(voRes,2);
  end if ;

  voRes := Replace(voRes,'0');
  voRes := Replace(voRes,'1');
  voRes := Replace(voRes,'2');
  voRes := Replace(voRes,'3');
  voRes := Replace(voRes,'4');
  voRes := Replace(voRes,'5');
  voRes := Replace(voRes,'6');
  voRes := Replace(voRes,'7');
  voRes := Replace(voRes,'8');
  voRes := Replace(voRes,'9');
  if voRes is null then
    noRes := to_number(Trim(viString));
    if noRes between -2147483648 and 2147483647 then
      ioRes := noRes;
    else
      ioRes := iiDefault;
    end if ;
  else
    ioRes := iiDefault;
  end if ;

  return ioRes;
END;

--------------------------------------------------------------
-- 通用函数：解析JSON，获得值
--------------------------------------------------------------
Function queryJsonValueFromName(viName IN varchar2,viData IN varchar2) return varchar2
as
  voRes  varchar2(32000);
  vInput varchar2(32000);
  iPos1 integer ;
  iPos2 integer ;
  iPos3 integer ;
begin
  vInput := upper(viData);
  iPos1 := instr(vInput,'"'||Trim(Upper(viName))||'"');
  iPos2 := instr(vInput,':',iPos1);
  iPos3 := instr(vInput,',',iPos2);
  if iPos3=0 then
     iPos3 := instr(vInput,'}',iPos2);
  end if ;
  voRes := trim(substr(viData,iPos2+1,iPos3-iPos2-1));
  if (substr(voRes,1,1) in ('"')) then
     voRes := substr(voRes,2,Length(voRes)-2);
  end if ;
  return voRes;
end;

--------------------------------------------------------------
-- 接口函数：query_ready_sms-查询出预备发送的短信列表
--------------------------------------------------------------
FUNCTION query_ready_sms(viCon IN Varchar2,listRes OUT ListString) RETURN VARCHAR2
AS
  iAdd INTEGER ;
  iNum INTEGER ;

  dtNow DATE ;
  vsNow varchar2(50);
  voRes VARCHAR2(20000);

  vUser varchar2(250);
  vType varchar2(8);
  vWho  varchar2(250);
  iCount integer ;

  errorResult EXCEPTION;
BEGIN
  ------------------------------------
  -- 解析出条件
  ------------------------------------
  vUser := queryJsonValueFromName('user',viCon);
  vType := queryJsonValueFromName('type',viCon);
  vWho  := queryJsonValueFromName('who' ,viCon);
  iCount:= convertStrToInt(queryJsonValueFromName('count',viCon),1);

  --分配短信
  UPDATE T_BASE_MESSAGE_QUEUE SET MQ_SENDER=vWho,MQ_STATE='1' WHERE MQ_ID IN
    ( SELECT MQ_ID FROM (
         SELECT MQ_ID FROM T_BASE_MESSAGE_QUEUE  WHERE MQ_TYPE=vType AND MQ_STATE='0' ORDER BY MQ_LEVEL
    ) WHERE ROWNUM<=iCount);
  COMMIT ;

  dtNow := SYSDATE ;
  vsNow := TO_CHAR(dtNow,'YYYY-MM-DD HH24:MI:SS');

  listRes := ListString();
  listRes.extend(200);
  listRes(1) := '';
  iAdd := 2;
  listRes(iAdd) := '';

  --------------------------------------------------------------------
  -- 获得短信,1200是方便调试，可以设成32000
  --------------------------------------------------------------------
  iNum := 0;
  for rs in (select * from T_BASE_MESSAGE_QUEUE where MQ_TYPE=vType and MQ_STATE='1' And MQ_SENDER=vWho And rownum<=iCount order by MQ_LEVEL) loop
    IF LENGTHB(nvl(listRes(iAdd),'N'))>=20000 THEN
      iAdd := iAdd+1;
      listRes(iAdd) := '';
    END IF ;
    listRes(iAdd) := listRes(iAdd)||'{"id":"'||rs.mq_id;
    listRes(iAdd) := listRes(iAdd)||'","type":"'||rs.mq_type;
    listRes(iAdd) := listRes(iAdd)||'","text1":"'||rs.mq_text1;
    listRes(iAdd) := listRes(iAdd)||'","text2":"'||rs.mq_text2;
    listRes(iAdd) := listRes(iAdd)||'","text3":"'||rs.mq_text3;
    listRes(iAdd) := listRes(iAdd)||'","object":"'||rs.mq_object;
    listRes(iAdd) := listRes(iAdd)||'"},';
    iNum := iNum+1;
  end loop ;
  if iNum<1 then
    listRes(1) := '{}';
    voRes := 'S:QUERY_READHY_SMS RETURN ROWS=0';
  end if ;
  if iNum=1 then
    listRes(1) := '';
    listRes(iAdd) := substr(listRes(iAdd),1,length(listRes(iAdd))-1);
    voRes := 'S:QUERY_READHY_SMS RETURN ROWS=1';
  end if ;
  if iNum>1 then
    listRes(1) := '[';
    listRes(iAdd) := substr(listRes(iAdd),1,length(listRes(iAdd))-1)||']';
    voRes := 'S:QUERY_READHY_SMS RETURN ROWS='||iNum;
  end if ;
  RAISE errorResult;
EXCEPTION
    WHEN errorResult THEN
      RETURN voRes ||',NOW='|| vsNow;
    WHEN OTHERS THEN
      voRes := 'W:'||SUBSTR(SQLERRM, 1, 220)||',NOW='||vsNow;
      RETURN voRes;
END ;

--------------------------------------------------------------
-- 接口函数：query_table_info-查询出预备发送的短信列表
-- 格式：{"sn":"1234567","fun":"query_table_info","user":"hqchen125","owner":"JIKE"}
--------------------------------------------------------------
FUNCTION query_table_info(viCon IN Varchar2,listRes OUT ListString) RETURN VARCHAR2
AS
  iAdd INTEGER ;
  iNum INTEGER ;

  dtNow DATE ;
  vsNow varchar2(50);
  voRes VARCHAR2(20000);

  vUser varchar2(250);
  vOwner varchar2(250);
  iCount integer ;

  errorResult EXCEPTION;
BEGIN
  ------------------------------------
  -- 解析出条件
  ------------------------------------
  vUser := queryJsonValueFromName('user',viCon);
  vOwner  := upper(trim(queryJsonValueFromName('owner' ,viCon)));

  dtNow := SYSDATE ;
  vsNow := TO_CHAR(dtNow,'YYYY-MM-DD HH24:MI:SS');

  listRes := ListString();
  listRes.extend(200);
  listRes(1) := '';
  iAdd := 2;
  listRes(iAdd) := '';

  --------------------------------------------------------------------
  -- 获得表,1200是方便调试，可以设成32000
  --------------------------------------------------------------------
  iNum := 0;
  for rs in (SELECT A.TABLE_NAME DM,nvl(B.COMMENTS,' ') MC,' ' BZ FROM ALL_TABLES A,ALL_TAB_COMMENTS B WHERE A.OWNER=B.OWNER AND A.OWNER=vOwner AND A.TABLE_NAME=B.TABLE_NAME ORDER BY A.TABLE_NAME) loop
    IF LENGTHB(nvl(listRes(iAdd),'N'))>=1200 THEN
      iAdd := iAdd+1;
      listRes(iAdd) := '';
    END IF ;
    listRes(iAdd) := listRes(iAdd)|| '{"dm":"'||rs.dm;
    listRes(iAdd) := listRes(iAdd)||'","mc":"'||rs.mc;
    listRes(iAdd) := listRes(iAdd)||'","bz":"'||rs.bz;
    listRes(iAdd) := listRes(iAdd)||'"},';
    iNum := iNum+1;
  end loop ;
  if iNum<1 then
    listRes(1) := '{}';
    voRes := 'S:RETURN ROWS=0';
  end if ;
  if iNum=1 then
    listRes(1) := '';
    listRes(iAdd) := substr(listRes(iAdd),1,length(listRes(iAdd))-1);
    voRes := 'S:RETURN ROWS=1';
  end if ;
  if iNum>1 then
    listRes(1) := '[';
    listRes(iAdd) := substr(listRes(iAdd),1,length(listRes(iAdd))-1)||']';
    voRes := 'S:RETURN ROWS='||iNum;
  end if ;
  RAISE errorResult;
EXCEPTION
    WHEN errorResult THEN
      RETURN voRes ||',NOW='|| vsNow;
    WHEN OTHERS THEN
      voRes := 'W:'||SUBSTR(SQLERRM, 1, 220)||',NOW='||vsNow;
      RETURN voRes;
END ;

--------------------------------------------------------------
-- 接口函数：query_table_field_info-查询指定表的字段信息
-- 格式：{"sn":"1234567","fun":"query_table_field_info","user":"hqchen125","owner":"JIKE","tabname":"T_BASE_CITY"}
--------------------------------------------------------------
FUNCTION query_table_field_info(viCon IN Varchar2,listRes OUT ListString) RETURN VARCHAR2
AS
  iAdd INTEGER ;
  iNum INTEGER ;

  dtNow DATE ;
  vsNow varchar2(50);
  voRes VARCHAR2(20000);

  vUser varchar2(250);
  vOwner varchar2(250);
  vTabName varchar2(250);
  iCount integer ;

  errorResult EXCEPTION;
BEGIN
  ------------------------------------
  -- 解析出条件
  ------------------------------------
  vUser := queryJsonValueFromName('user',viCon);
  vOwner  := upper(trim(queryJsonValueFromName('owner' ,viCon)));
  vTabName  := upper(trim(queryJsonValueFromName('tabname' ,viCon)));
  
  dtNow := SYSDATE ;
  vsNow := TO_CHAR(dtNow,'YYYY-MM-DD HH24:MI:SS');

  listRes := ListString();
  listRes.extend(200);
  listRes(1) := '';
  iAdd := 2;
  listRes(iAdd) := '';

  --------------------------------------------------------------------
  -- 获得表,1200是方便调试，可以设成32000
  --------------------------------------------------------------------
  iNum := 0;
  for rs in (
    SELECT A.COLUMN_NAME,
         A.DATA_TYPE,
         A.DATA_LENGTH,
         A.DATA_PRECISION,
         A.DATA_SCALE,
         A.NULLABLE,
         A.DATA_DEFAULT,
         nvl(B.COMMENTS,' ') COMMENTS 
    FROM ALL_TAB_COLUMNS A,ALL_COL_COMMENTS B
   WHERE A.OWNER=vOwner AND A.OWNER=B.OWNER AND A.COLUMN_NAME = B.COLUMN_NAME
     AND A.TABLE_NAME = B.TABLE_NAME
     AND A.TABLE_NAME = vTabName
     ORDER BY A.COLUMN_ID
  ) loop
    IF LENGTHB(nvl(listRes(iAdd),'N'))>=1200 THEN
      iAdd := iAdd+1;
      listRes(iAdd) := '';
    END IF ;
    listRes(iAdd) := listRes(iAdd)|| '{"column_name":"'||rs.column_name;
    listRes(iAdd) := listRes(iAdd)||'","data_type":"'||rs.data_type;
    listRes(iAdd) := listRes(iAdd)||'","data_length":"'||rs.data_length;
    listRes(iAdd) := listRes(iAdd)||'","data_precision":"'||rs.data_precision;
    listRes(iAdd) := listRes(iAdd)||'","data_scale":"'||rs.data_scale;
    listRes(iAdd) := listRes(iAdd)||'","nullable":"'||rs.nullable;
    listRes(iAdd) := listRes(iAdd)||'","data_default":"'||rs.data_default;
    listRes(iAdd) := listRes(iAdd)||'","comments":"'||rs.comments;
    listRes(iAdd) := listRes(iAdd)||'"},';
    iNum := iNum+1;
  end loop ;
  if iNum<1 then
    listRes(1) := '{}';
    voRes := 'S:RETURN ROWS=0';
  end if ;
--  if iNum=1 then
--    listRes(1) := '';
--    listRes(iAdd) := substr(listRes(iAdd),1,length(listRes(iAdd))-1);
--    voRes := 'S:RETURN ROWS=1';
--  end if ;
  if iNum>0 then
    listRes(1) := '[';
    listRes(iAdd) := substr(listRes(iAdd),1,length(listRes(iAdd))-1)||']';
    voRes := 'S:RETURN ROWS='||iNum;
  end if ;
  RAISE errorResult;
EXCEPTION
    WHEN errorResult THEN
      RETURN voRes ||',NOW='|| vsNow;
    WHEN OTHERS THEN
      voRes := 'W:'||SUBSTR(SQLERRM, 1, 220)||',NOW='||vsNow;
      RETURN voRes;
END ;

FUNCTION readData(
    viData IN VARCHAR2,
    viText IN VARCHAR2,
    voData001 OUT VARCHAR2,
    voData002 OUT VARCHAR2,
    voData003 OUT VARCHAR2,
    voData004 OUT VARCHAR2,
    voData005 OUT VARCHAR2,
    voData006 OUT VARCHAR2,
    voData007 OUT VARCHAR2,
    voData008 OUT VARCHAR2,
    voData009 OUT VARCHAR2,
    voData010 OUT VARCHAR2,
    voData011 OUT VARCHAR2,
    voData012 OUT VARCHAR2,
    voData013 OUT VARCHAR2,
    voData014 OUT VARCHAR2,
    voData015 OUT VARCHAR2,
    voData016 OUT VARCHAR2,
    voData017 OUT VARCHAR2,
    voData018 OUT VARCHAR2,
    voData019 OUT VARCHAR2,
    voData020 OUT VARCHAR2,
    voData021 OUT VARCHAR2,
    voData022 OUT VARCHAR2,
    voData023 OUT VARCHAR2,
    voData024 OUT VARCHAR2,
    voData025 OUT VARCHAR2,
    voData026 OUT VARCHAR2,
    voData027 OUT VARCHAR2,
    voData028 OUT VARCHAR2,
    voData029 OUT VARCHAR2,
    voData030 OUT VARCHAR2,
    voData031 OUT VARCHAR2,
    voData032 OUT VARCHAR2,
    voData033 OUT VARCHAR2,
    voData034 OUT VARCHAR2,
    voData035 OUT VARCHAR2,
    voData036 OUT VARCHAR2,
    voData037 OUT VARCHAR2,
    voData038 OUT VARCHAR2,
    voData039 OUT VARCHAR2,
    voData040 OUT VARCHAR2,
    voData041 OUT VARCHAR2,
    voData042 OUT VARCHAR2,
    voData043 OUT VARCHAR2,
    voData044 OUT VARCHAR2,
    voData045 OUT VARCHAR2,
    voData046 OUT VARCHAR2,
    voData047 OUT VARCHAR2,
    voData048 OUT VARCHAR2,
    voData049 OUT VARCHAR2,
    voData050 OUT VARCHAR2,
    voData051 OUT VARCHAR2,
    voData052 OUT VARCHAR2,
    voData053 OUT VARCHAR2,
    voData054 OUT VARCHAR2,
    voData055 OUT VARCHAR2,
    voData056 OUT VARCHAR2,
    voData057 OUT VARCHAR2,
    voData058 OUT VARCHAR2,
    voData059 OUT VARCHAR2,
    voData060 OUT VARCHAR2,
    voData061 OUT VARCHAR2,
    voData062 OUT VARCHAR2,
    voData063 OUT VARCHAR2,
    voData064 OUT VARCHAR2,
    voData065 OUT VARCHAR2,
    voData066 OUT VARCHAR2,
    voData067 OUT VARCHAR2,
    voData068 OUT VARCHAR2,
    voData069 OUT VARCHAR2,
    voData070 OUT VARCHAR2,
    voData071 OUT VARCHAR2,
    voData072 OUT VARCHAR2,
    voData073 OUT VARCHAR2,
    voData074 OUT VARCHAR2,
    voData075 OUT VARCHAR2,
    voData076 OUT VARCHAR2,
    voData077 OUT VARCHAR2,
    voData078 OUT VARCHAR2,
    voData079 OUT VARCHAR2,
    voData080 OUT VARCHAR2,
    voData081 OUT VARCHAR2,
    voData082 OUT VARCHAR2,
    voData083 OUT VARCHAR2,
    voData084 OUT VARCHAR2,
    voData085 OUT VARCHAR2,
    voData086 OUT VARCHAR2,
    voData087 OUT VARCHAR2,
    voData088 OUT VARCHAR2,
    voData089 OUT VARCHAR2,
    voData090 OUT VARCHAR2,
    voData091 OUT VARCHAR2,
    voData092 OUT VARCHAR2,
    voData093 OUT VARCHAR2,
    voData094 OUT VARCHAR2,
    voData095 OUT VARCHAR2,
    voData096 OUT VARCHAR2,
    voData097 OUT VARCHAR2,
    voData098 OUT VARCHAR2,
    voData099 OUT VARCHAR2,
    voData100 OUT VARCHAR2,
    voData101 OUT VARCHAR2,
    voData102 OUT VARCHAR2,
    voData103 OUT VARCHAR2,
    voData104 OUT VARCHAR2,
    voData105 OUT VARCHAR2,
    voData106 OUT VARCHAR2,
    voData107 OUT VARCHAR2,
    voData108 OUT VARCHAR2,
    voData109 OUT VARCHAR2,
    voData110 OUT VARCHAR2,
    voData111 OUT VARCHAR2,
    voData112 OUT VARCHAR2,
    voData113 OUT VARCHAR2,
    voData114 OUT VARCHAR2,
    voData115 OUT VARCHAR2,
    voData116 OUT VARCHAR2,
    voData117 OUT VARCHAR2,
    voData118 OUT VARCHAR2,
    voData119 OUT VARCHAR2,
    voData120 OUT VARCHAR2,
    voData121 OUT VARCHAR2,
    voData122 OUT VARCHAR2,
    voData123 OUT VARCHAR2,
    voData124 OUT VARCHAR2,
    voData125 OUT VARCHAR2,
    voData126 OUT VARCHAR2,
    voData127 OUT VARCHAR2,
    voData128 OUT VARCHAR2,
    voData129 OUT VARCHAR2,
    voData130 OUT VARCHAR2,
    voData131 OUT VARCHAR2,
    voData132 OUT VARCHAR2,
    voData133 OUT VARCHAR2,
    voData134 OUT VARCHAR2,
    voData135 OUT VARCHAR2,
    voData136 OUT VARCHAR2,
    voData137 OUT VARCHAR2,
    voData138 OUT VARCHAR2,
    voData139 OUT VARCHAR2,
    voData140 OUT VARCHAR2,
    voData141 OUT VARCHAR2,
    voData142 OUT VARCHAR2,
    voData143 OUT VARCHAR2,
    voData144 OUT VARCHAR2,
    voData145 OUT VARCHAR2,
    voData146 OUT VARCHAR2,
    voData147 OUT VARCHAR2,
    voData148 OUT VARCHAR2,
    voData149 OUT VARCHAR2,
    voData150 OUT VARCHAR2,
    voData151 OUT VARCHAR2,
    voData152 OUT VARCHAR2,
    voData153 OUT VARCHAR2,
    voData154 OUT VARCHAR2,
    voData155 OUT VARCHAR2,
    voData156 OUT VARCHAR2,
    voData157 OUT VARCHAR2,
    voData158 OUT VARCHAR2,
    voData159 OUT VARCHAR2,
    voData160 OUT VARCHAR2,
    voData161 OUT VARCHAR2,
    voData162 OUT VARCHAR2,
    voData163 OUT VARCHAR2,
    voData164 OUT VARCHAR2,
    voData165 OUT VARCHAR2,
    voData166 OUT VARCHAR2,
    voData167 OUT VARCHAR2,
    voData168 OUT VARCHAR2,
    voData169 OUT VARCHAR2,
    voData170 OUT VARCHAR2,
    voData171 OUT VARCHAR2,
    voData172 OUT VARCHAR2,
    voData173 OUT VARCHAR2,
    voData174 OUT VARCHAR2,
    voData175 OUT VARCHAR2,
    voData176 OUT VARCHAR2,
    voData177 OUT VARCHAR2,
    voData178 OUT VARCHAR2,
    voData179 OUT VARCHAR2,
    voData180 OUT VARCHAR2,
    voData181 OUT VARCHAR2,
    voData182 OUT VARCHAR2,
    voData183 OUT VARCHAR2,
    voData184 OUT VARCHAR2,
    voData185 OUT VARCHAR2,
    voData186 OUT VARCHAR2,
    voData187 OUT VARCHAR2,
    voData188 OUT VARCHAR2,
    voData189 OUT VARCHAR2,
    voData190 OUT VARCHAR2,
    voData191 OUT VARCHAR2,
    voData192 OUT VARCHAR2,
    voData193 OUT VARCHAR2,
    voData194 OUT VARCHAR2,
    voData195 OUT VARCHAR2,
    voData196 OUT VARCHAR2,
    voData197 OUT VARCHAR2,
    voData198 OUT VARCHAR2,
    voData199 OUT VARCHAR2,
    voData200 OUT VARCHAR2) RETURN VARCHAR2
AS
  listRes ListString;
  vReturn varchar2(4000);
  ------------------------------------
  -- 1.用户登录后生成的用户登录授权号
  -- 2.方法名称
  -- 3.用户名称
  ------------------------------------
  vSn   varchar2(32);
  vFun  varchar2(500);
  vUser varchar2(500);

  iNum1 integer ;
  iNum2 integer ;

  errorResult EXCEPTION;
BEGIN
  ---------------------------------------------------
  -- 初始化,解析授权码、函数和用户名称
  -- 获得SN、FUN和USER
  ---------------------------------------------------
  vSn   := queryJsonValueFromName('sn',viData);
  vFun  := queryJsonValueFromName('fun',viData);
  vUser := queryJsonValueFromName('user',viData);

  ----------------------------------
  -- 验证接口参数
  ----------------------------------
  if (vSn is null or vFun is null or vUser is null) then
    vReturn := 'W:输入参数解析失败';
    raise errorResult;
  end if ;

  ----------------------------------
  -- 验证函数名称，只验证大写或小写
  ----------------------------------
  select count(0) into iNum1 from t_base_dbi where dbi_name in (upper(vFun),lower(vFun));
  if iNum1<1 then
    vReturn := 'W:接口函数['||vFun||']缺失';
    raise errorResult;
  end if ;

  ----------------------------------
  -- 授权验证,暂无
  ----------------------------------

  ----------------------------------
  -- 用户验证，暂无
  ----------------------------------

  listRes := ListString();
  listRes.extend(200);

  -------------------------------------------
  -- query_ready_sms:查询出预备发送的短信列表
  -------------------------------------------
  if lower(vFun) in ('query_ready_sms') then
     vReturn := query_ready_sms(viData,listRes);
  end if ;
  
  -------------------------------------------
  -- query_table_info:查询表结构的信息
  -------------------------------------------
  if lower(vFun) in ('query_table_info') then
     vReturn := query_table_info(viData,listRes);
  end if ;
  
  -------------------------------------------
  -- query_table_field_info:查询指定表的字段信息
  -------------------------------------------
  if lower(vFun) in ('query_table_field_info') then
     vReturn := query_table_field_info(viData,listRes);
  end if ;

  IF listRes IS NOT NULL AND listRes.Count=200 THEN
    voData001 := listRes(1);
    voData002 := listRes(2);
    voData003 := listRes(3);
    voData004 := listRes(4);
    voData005 := listRes(5);
    voData006 := listRes(6);
    voData007 := listRes(7);
    voData008 := listRes(8);
    voData009 := listRes(9);
    voData010 := listRes(10);
    voData011 := listRes(11);
    voData012 := listRes(12);
    voData013 := listRes(13);
    voData014 := listRes(14);
    voData015 := listRes(15);
    voData016 := listRes(16);
    voData017 := listRes(17);
    voData018 := listRes(18);
    voData019 := listRes(19);
    voData020 := listRes(20);
    voData021 := listRes(21);
    voData022 := listRes(22);
    voData023 := listRes(23);
    voData024 := listRes(24);
    voData025 := listRes(25);
    voData026 := listRes(26);
    voData027 := listRes(27);
    voData028 := listRes(28);
    voData029 := listRes(29);
    voData030 := listRes(30);
    voData031 := listRes(31);
    voData032 := listRes(32);
    voData033 := listRes(33);
    voData034 := listRes(34);
    voData035 := listRes(35);
    voData036 := listRes(36);
    voData037 := listRes(37);
    voData038 := listRes(38);
    voData039 := listRes(39);
    voData040 := listRes(40);
    voData041 := listRes(41);
    voData042 := listRes(42);
    voData043 := listRes(43);
    voData044 := listRes(44);
    voData045 := listRes(45);
    voData046 := listRes(46);
    voData047 := listRes(47);
    voData048 := listRes(48);
    voData049 := listRes(49);
    voData050 := listRes(50);
    voData051 := listRes(51);
    voData052 := listRes(52);
    voData053 := listRes(53);
    voData054 := listRes(54);
    voData055 := listRes(55);
    voData056 := listRes(56);
    voData057 := listRes(57);
    voData058 := listRes(58);
    voData059 := listRes(59);
    voData060 := listRes(60);
    voData061 := listRes(61);
    voData062 := listRes(62);
    voData063 := listRes(63);
    voData064 := listRes(64);
    voData065 := listRes(65);
    voData066 := listRes(66);
    voData067 := listRes(67);
    voData068 := listRes(68);
    voData069 := listRes(69);
    voData070 := listRes(70);
    voData071 := listRes(71);
    voData072 := listRes(72);
    voData073 := listRes(73);
    voData074 := listRes(74);
    voData075 := listRes(75);
    voData076 := listRes(76);
    voData077 := listRes(77);
    voData078 := listRes(78);
    voData079 := listRes(79);
    voData080 := listRes(80);
    voData081 := listRes(81);
    voData082 := listRes(82);
    voData083 := listRes(83);
    voData084 := listRes(84);
    voData085 := listRes(85);
    voData086 := listRes(86);
    voData087 := listRes(87);
    voData088 := listRes(88);
    voData089 := listRes(89);
    voData090 := listRes(90);
    voData091 := listRes(91);
    voData092 := listRes(92);
    voData093 := listRes(93);
    voData094 := listRes(94);
    voData095 := listRes(95);
    voData096 := listRes(96);
    voData097 := listRes(97);
    voData098 := listRes(98);
    voData099 := listRes(99);
    voData100 := listRes(100);
    voData101 := listRes(101);
    voData102 := listRes(102);
    voData103 := listRes(103);
    voData104 := listRes(104);
    voData105 := listRes(105);
    voData106 := listRes(106);
    voData107 := listRes(107);
    voData108 := listRes(108);
    voData109 := listRes(109);
    voData110 := listRes(110);
    voData111 := listRes(111);
    voData112 := listRes(112);
    voData113 := listRes(113);
    voData114 := listRes(114);
    voData115 := listRes(115);
    voData116 := listRes(116);
    voData117 := listRes(117);
    voData118 := listRes(118);
    voData119 := listRes(119);
    voData120 := listRes(120);
    voData121 := listRes(121);
    voData122 := listRes(122);
    voData123 := listRes(123);
    voData124 := listRes(124);
    voData125 := listRes(125);
    voData126 := listRes(126);
    voData127 := listRes(127);
    voData128 := listRes(128);
    voData129 := listRes(129);
    voData130 := listRes(130);
    voData131 := listRes(131);
    voData132 := listRes(132);
    voData133 := listRes(133);
    voData134 := listRes(134);
    voData135 := listRes(135);
    voData136 := listRes(136);
    voData137 := listRes(137);
    voData138 := listRes(138);
    voData139 := listRes(139);
    voData140 := listRes(140);
    voData141 := listRes(141);
    voData142 := listRes(142);
    voData143 := listRes(143);
    voData144 := listRes(144);
    voData145 := listRes(145);
    voData146 := listRes(146);
    voData147 := listRes(147);
    voData148 := listRes(148);
    voData149 := listRes(149);
    voData150 := listRes(150);
    voData151 := listRes(151);
    voData152 := listRes(152);
    voData153 := listRes(153);
    voData154 := listRes(154);
    voData155 := listRes(155);
    voData156 := listRes(156);
    voData157 := listRes(157);
    voData158 := listRes(158);
    voData159 := listRes(159);
    voData160 := listRes(160);
    voData161 := listRes(161);
    voData162 := listRes(162);
    voData163 := listRes(163);
    voData164 := listRes(164);
    voData165 := listRes(165);
    voData166 := listRes(166);
    voData167 := listRes(167);
    voData168 := listRes(168);
    voData169 := listRes(169);
    voData170 := listRes(170);
    voData171 := listRes(171);
    voData172 := listRes(172);
    voData173 := listRes(173);
    voData174 := listRes(174);
    voData175 := listRes(175);
    voData176 := listRes(176);
    voData177 := listRes(177);
    voData178 := listRes(178);
    voData179 := listRes(179);
    voData180 := listRes(180);
    voData181 := listRes(181);
    voData182 := listRes(182);
    voData183 := listRes(183);
    voData184 := listRes(184);
    voData185 := listRes(185);
    voData186 := listRes(186);
    voData187 := listRes(187);
    voData188 := listRes(188);
    voData189 := listRes(189);
    voData190 := listRes(190);
    voData191 := listRes(191);
    voData192 := listRes(192);
    voData193 := listRes(193);
    voData194 := listRes(194);
    voData195 := listRes(195);
    voData196 := listRes(196);
    voData197 := listRes(197);
    voData198 := listRes(198);
    voData199 := listRes(199);
    voData200 := listRes(200);
  ELSE
    vReturn := 'S:RESULT IS NULL';
  END IF ;
  Raise errorResult;
EXCEPTION
    WHEN errorResult THEN
         IF SUBSTR(vReturn,1,1) NOT IN ('S','W','E') THEN
           vReturn := 'W:NULL';
         END IF ;
         RETURN vReturn;
    WHEN OTHERS THEN
         vReturn := 'W:'||SUBSTR(SQLERRM, 1, 256);
         RETURN vReturn;
END ;

-----------------------------------------------------------------------------------
-- 写接口部分
-- 1.update_sms_state
-----------------------------------------------------------------------------------
FUNCTION update_sms_state(viCon IN VARCHAR2,viText IN VARCHAR2) RETURN VARCHAR2
AS
  vResult VARCHAR2(32000);

  vUser varchar2(250);
  vID   varchar2(200);
  vState varchar2(50);
  vText varchar2(5000);

  errorResult EXCEPTION;
BEGIN
  ------------------------------------
  -- 解析出条件
  -- {"sn":"授权码","fun":"update_sms_state","user":"phoneSms","id":"141208012345678","state":"2","text":"OK"}
  ------------------------------------
  vUser := queryJsonValueFromName('user',viCon);
  vID := queryJsonValueFromName('id',viCon);
  vState := queryJsonValueFromName('state' ,viCon);
  vText  := queryJsonValueFromName('text' ,viCon);
  --针对已经分配的进行更新
  update T_BASE_MESSAGE_QUEUE set MQ_STATE=SubstrB(Trim(vState),1,1),mq_sendtime=sysdate,mq_remark=SubstrB(Trim(vText),1,200) where mq_id=Trim(vID) and mq_state='1';
  COMMIT;
  --错误结果
  --vResult := '{"errorid":"90003","msg":"接口结果-RESULT IS NULL","text":"W"}';
  --成功结果
  vResult := '{"id":"'||vID||'","msg":"update ok","text":"S"}';
  Raise errorResult;
EXCEPTION
  WHEN errorResult THEN
    if vResult is null then 
      vResult := '{"errorid":"90000","msg":"警告-NULL","text":"W"}';
    end if ;
    RETURN vResult;
  WHEN OTHERS THEN
    vResult := '{"errorid":"90000","msg":"异常-'||SUBSTR(SQLERRM, 1, 256)||'","text":"E"}';
    RETURN vResult;
END;

FUNCTION writeData(viData IN VARCHAR2,viText IN VARCHAR2) RETURN VARCHAR2
AS
  vReturn varchar2(4000);
  ------------------------------------
  -- 1.用户登录后生成的用户登录授权号
  -- 2.方法名称
  -- 3.用户名称
  ------------------------------------
  vSn   varchar2(32);
  vFun  varchar2(500);
  vUser varchar2(500);

  iNum1 integer ;
  iNum2 integer ;

  errorResult EXCEPTION;
BEGIN
  ---------------------------------------------------
  -- 初始化,解析授权码、函数和用户名称
  -- 获得SN、FUN和USER
  ---------------------------------------------------
  vSn   := queryJsonValueFromName('sn',viData);
  vFun  := queryJsonValueFromName('fun',viData);
  vUser := queryJsonValueFromName('user',viData);

  ----------------------------------
  -- 验证接口参数
  ----------------------------------
  if (vSn is null or vFun is null or vUser is null) then
    vReturn := 'W:输入参数解析失败';
    raise errorResult;
  end if ;

  ----------------------------------
  -- 验证函数名称，只验证大写或小写
  ----------------------------------
  select count(0) into iNum1 from t_base_dbi where dbi_name in (upper(vFun),lower(vFun));
  if iNum1<1 then
    vReturn := 'W:接口函数['||vFun||']缺失';
    raise errorResult;
  end if ;

  ----------------------------------
  -- 授权验证,暂无
  ----------------------------------

  ----------------------------------
  -- 用户验证，暂无
  ----------------------------------

  ---------------------------------------------------------------------------------------------------------------------------------
  -- update_sms_state:更新短信状态
  -- {"sn":"授权码","fun":"update_sms_state","user":"phoneSms","id":"141208012345678","state":"2","text":"OK"}
  ---------------------------------------------------------------------------------------------------------------------------------
  if lower(vFun) in ('update_sms_state') then
     vReturn := update_sms_state(viData,viText);
  end if ;
  raise errorResult;
EXCEPTION
    WHEN errorResult THEN
      if vReturn is null then 
        vReturn := '{"errorid":"90000","msg":"警告-写接口无返回","text":"W"}';
      end if ;
      RETURN vReturn;
    WHEN OTHERS THEN
      vReturn := '{"errorid":"90000","msg":"异常,写接口-'||SUBSTR(SQLERRM, 1, 256)||'","text":"E"}';
      RETURN vReturn;
END ;

END ;
