create PACKAGE BODY      DBIS_SMS_TOOL IS
  --TYPE ListString IS TABLE OF VARCHAR2(32000);
  
  --------------------------------------------------------------
  -- 通用函数：MD5加密
  --------------------------------------------------------------
  FUNCTION encodeMD5(myText IN VARCHAR2) RETURN VARCHAR2 AS
    RAW_INPUT     RAW(10240) := UTL_RAW.CAST_TO_RAW(UPPER(myText));
    DECRYPTED_RAW RAW(2048);
    ERROR_IN_INPUT_BUFFER_LENGTH EXCEPTION;
  BEGIN
    IF (Length(myText) <= 0) OR (myText IS NULL) THEN
      RETURN 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
    ELSE
      SYS.DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT    => RAW_INPUT,
                                       CHECKSUM => DECRYPTED_RAW);
      RETURN LOWER(RAWTOHEX(DECRYPTED_RAW));
    END IF;
  END;

  function encodeUrl(viText IN VARCHAR2,viCharset IN VARCHAR2) RETURN VARCHAR2
  AS
    voRes varchar2(30000);
  begin
    voRes := utl_url.escape(viText, true, viCharset);
    return voRes;
  exception
    when others then
      voRes := '';
      return voRes;
  end;

  function isNumString(viText in varchar2) return  integer
  as
    vsText varchar2(1000);
  begin
    vsText := NVL(viText,'N');

    if substrb(vsText,1,1) in ('N') then return 0; end if ;

    vsText := replace(vsText,'0');
    vsText := replace(vsText,'1');
    vsText := replace(vsText,'2');
    vsText := replace(vsText,'3');
    vsText := replace(vsText,'4');
    vsText := replace(vsText,'5');
    vsText := replace(vsText,'6');
    vsText := replace(vsText,'7');
    vsText := replace(vsText,'8');
    vsText := replace(vsText,'9');

    if NVL(vsText,'0') in ('0') then
      return 1;
    else
      return 0;
    end if ;
  end ;

  function isMobilePhone(viText in varchar2) return  integer
  as
    vsText varchar2(1000);
  begin
    vsText := NVL(viText,'N');

    if substrb(vsText,1,1) not in ('1') then return 0; end if ;
    if lengthb(vsText)!=11 then return 0; end if ;

    vsText := replace(vsText,'0');
    vsText := replace(vsText,'1');
    vsText := replace(vsText,'2');
    vsText := replace(vsText,'3');
    vsText := replace(vsText,'4');
    vsText := replace(vsText,'5');
    vsText := replace(vsText,'6');
    vsText := replace(vsText,'7');
    vsText := replace(vsText,'8');
    vsText := replace(vsText,'9');

    if NVL(vsText,'0') in ('0') then
      return 1;
    else
      return 0;
    end if ;
  end ;

  ----------------------------------
  -- 发送短信接口
  -- viType 1=创蓝，2=一信通
  -- viPhone 手机
  -- viText 短信
  -- viExtNo 长号码扩展（0-999999）
  -- viMemo 备注
  ----------------------------------
  FUNCTION send(viType in varchar2,viPhone in varchar2,viText IN VARCHAR2,viExtNo in varchar2,viMemo in Varchar2) RETURN VARCHAR2
  AS
    voRes varchar2(2000);
    vsMemo varchar2(2000);

    --变量
    vsHttp varchar2(32000);
    vsWsdl varchar2(32000);
    vsText varchar2(30000);
    vsExtNo varchar2(18);
    reqHttp utl_http.req;
    reqWsdl utl_http.req;
    respGet  utl_http.resp;
    respPost utl_http.resp;
    vsResCl varchar2(30000);
    vsResLt varchar2(30000);
    vsContent varchar2(32767);
    viPos1 integer;
    viPos2 integer;

    errorResult EXCEPTION;
    errorResCl EXCEPTION;
    errorResLt EXCEPTION;
  BEGIN
    vsMemo := viMemo;
    -------------------------------------
    --验证信息
    -------------------------------------
    if nvl(viType,'3') not in ('1','2') then
      voRes := '0=短信供应商错误';
      raise errorResult;
    end if ;

    if isMobilePhone(viPhone)=0 then
      voRes := '0=手机['||viPhone||']验证失败';
      raise errorResult;
    end if ;

    if nvl(viText,'N') in ('N') then
      voRes := '0=短信内容为空';
      raise errorResult;
    end if ;

    vsExtNo := nvl(substrb(viExtNo,1,18),'8');
    if isNumString(vsExtNo)=0 then
      voRes := '0=扩展长号码错误';
      raise errorResult;
    end if ;

    -------------------------------------
    --创蓝供应商
    -------------------------------------
    if viType in ('1') then
    begin
      vsText := encodeUrl(viText,'UTF-8');
      if vsText is null  then
        voRes := '0=短信内容转码错误';
        raise errorResCl;
      end if ;

      vsHttp := 'http://222.73.117.156/msg/HttpBatchSendSM?account=luopan123'||'&'||'pswd=Tch123456'||'&'||'mobile='||viPhone||'&'||'msg='||vsText||'&'||'needstatus=true'||'&'||'extno='||vsExtNo;
      --使用代理
      utl_http.set_proxy('192.168.1.50:8818','');
      --调用HTTP
      reqHttp  := utl_http.begin_request(vsHttp);
      utl_http.set_header(reqHttp, 'user-agent', 'mozilla/4.0');
      --获得返回结果集
      respGet := utl_http.get_response(reqHttp);
      --获得结果
      utl_http.read_text(respGet, vsResCl, 256);
      --关闭
      utl_http.end_response(respGet);
      -------------------------------------------------------------
      --验证结果
      --vsResCl=20151010145151,0回车符1001010145151649000
      -------------------------------------------------------------
      --代码  说明
      --0 提交成功
      --101 无此用户
      --102 密码错
      --103 提交过快（提交速度超过流速限制）
      --104 系统忙（因平台侧原因，暂时无法处理提交的短信）
      --105 敏感短信（短信内容包含敏感词）
      --106 消息长度错（>536或<=0）
      --107 包含错误的手机号码
      --108 手机号码个数错（群发>50000或<=0;单发>200或<=0）
      --109 无发送额度（该用户可用短信数已使用完）
      --110 不在发送时间内
      --111 超出该账户当月发送额度限制
      --112 无此产品，用户没有订购该产品
      --113 extno格式错（非数字或者长度不对）
      --115 自动审核驳回
      --116 签名不合法，未带签名（用户必须带签名的前提下）
      --117 IP地址认证错,请求调用的IP地址不是系统登记的IP地址
      --118 用户没有相应的发送权限
      --119 用户已过期
      -------------------------------------------------------------
      case 
        when instr(vsResCl,',0'  )>1 then return '1=提交成功';
        when instr(vsResCl,',101')>1 then return '0=提交异常:无此用户';                                         
        when instr(vsResCl,',102')>1 then return '0=提交异常:密码错';                                           
        when instr(vsResCl,',103')>1 then return '0=提交异常:提交过快（提交速度超过流速限制）';                 
        when instr(vsResCl,',104')>1 then return '0=提交异常:系统忙（因平台侧原因，暂时无法处理提交的短信）';   
        when instr(vsResCl,',105')>1 then return '0=提交异常:敏感短信（短信内容包含敏感词）';                   
        when instr(vsResCl,',106')>1 then return '0=提交异常:消息长度错（>536或<=0）';                          
        when instr(vsResCl,',107')>1 then return '0=提交异常:包含错误的手机号码';                               
        when instr(vsResCl,',108')>1 then return '0=提交异常:手机号码个数错（群发>50000或<=0;单发>200或<=0）';  
        when instr(vsResCl,',109')>1 then return '0=提交异常:无发送额度（该用户可用短信数已使用完）';           
        when instr(vsResCl,',110')>1 then return '0=提交异常:不在发送时间内';                                   
        when instr(vsResCl,',111')>1 then return '0=提交异常:超出该账户当月发送额度限制';                       
        when instr(vsResCl,',112')>1 then return '0=提交异常:无此产品，用户没有订购该产品';                     
        when instr(vsResCl,',113')>1 then return '0=提交异常:extno格式错（非数字或者长度不对）';                
        when instr(vsResCl,',115')>1 then return '0=提交异常:自动审核驳回';                                     
        when instr(vsResCl,',116')>1 then return '0=提交异常:签名不合法，未带签名（用户必须带签名的前提下）';   
        when instr(vsResCl,',117')>1 then return '0=提交异常:IP地址认证错,请求调用的IP地址不是系统登记的IP地址';
        when instr(vsResCl,',118')>1 then return '0=提交异常:用户没有相应的发送权限';                           
        when instr(vsResCl,',119')>1 then return '0=提交异常:用户已过期';                                       
      else
        return '0=无效的验证结果';
      end case;
    exception
      WHEN errorResCl THEN
        return voRes;
      WHEN utl_http.end_of_body THEN
        utl_http.end_response(respGet);
        voRes := '0=调用HTTP异常';
        return voRes;
      WHEN others THEN
        voRes := '0=异常'||SUBSTR(SQLERRM, 1, 256);
        return voRes;
    end;
    end if ;

    -------------------------------------
    --一信通供应商
    -------------------------------------
    if viType in ('2') then
    begin
      vsText := viText;
      --内容      
      vsContent := '';
      vsContent := vsContent||'<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.flaginfo.com.cn">';
      vsContent := vsContent||'<soapenv:Header/>';
      vsContent := vsContent||'<soapenv:Body>';
      vsContent := vsContent||'<ws:Sms>';
      vsContent := vsContent||'<ws:in0>219248</ws:in0>';
      vsContent := vsContent||'<ws:in1>sz_lpwl</ws:in1>';
      vsContent := vsContent||'<ws:in2>luopan66611666</ws:in2>';
      vsContent := vsContent||'<ws:in3><![CDATA['||vsText||']]></ws:in3>';
      vsContent := vsContent||'<ws:in4>'||viPhone||'</ws:in4>';
      vsContent := vsContent||'<ws:in5>'||TO_CHAR(SYSDATE,'YYYYMMDDHH24')||SEQ_SMS_FLOWID.NEXTVAL||'</ws:in5>';
      vsContent := vsContent||'<ws:in6></ws:in6>';
      vsContent := vsContent||'<ws:in7>1</ws:in7>';
      vsContent := vsContent||'<ws:in8></ws:in8>';
      vsContent := vsContent||'<ws:in9></ws:in9>';
      vsContent := vsContent||'<ws:in10>'||vsExtNo||'</ws:in10>';
      vsContent := vsContent||'</ws:Sms>';
      vsContent := vsContent||'</soapenv:Body>';
      vsContent := vsContent||'</soapenv:Envelope>';  
      
      vsWsdl := 'http://api.ums86.com:8899/sms_hb/services/Sms?wsdl';
      --使用代理
      utl_http.set_proxy('192.168.1.50:8818','');
      --调用HTTP
      reqWsdl  := utl_http.begin_request(vsWsdl,'POST','HTTP/1.1');
      utl_http.set_header(reqWsdl, 'user-agent', 'mozilla/4.0');
      utl_http.set_header(reqWsdl, 'Content-Type', 'text/xml; charset=utf-8');
      utl_http.set_header(reqWsdl, 'Content-Length', lengthb(vsContent));      
      --写输入参数
      utl_http.write_text(reqWsdl, vsContent);
      --获得返回结果集
      respPost := utl_http.get_response(reqWsdl);
      --获得结果
      utl_http.read_text(respPost, vsResLt, 2000);
      --关闭
      utl_http.end_response(respPost);
      -------------------------------------------------------------
      --验证结果
      --vsResLt=...<ns1:out>result=0&amp;description=发送短信成功&amp;taskid=206169599546&amp;faillist=&amp;task_id=206169599546</ns1:out>
      -------------------------------------------------------------
      vsResLt := upper(vsResLt);
      viPos1  := instr(vsResLt,'RESULT=');
      viPos2  := instr(vsResLt,'</',viPos1);
      vsResLt := substr(vsResLt,viPos1,viPos2-viPos1);
      vsResLt := replace(vsResLt,'&'||'AMP;',',');
      if instr(vsResLt,'RESULT=0')=1 then
         return '1='||replace(substr(vsResLt,22),'=','-');  
      else
        if instr(vsResLt,'RESULT=')=1 then
           return '0='||replace(substr(vsResLt,22),'=','-');  
        else
           return '0=无效的结果'; 
        end if ;
      end if ;
    exception
      WHEN errorResLt THEN
        return voRes;
      WHEN utl_http.end_of_body THEN
        utl_http.end_response(respPost);
        voRes := '0=调用WEBSERVEICE异常';
        return voRes;
      WHEN others THEN
        voRes := '0=异常'||SUBSTR(SQLERRM, 1, 256);
        return voRes;
    end;
    end if ;
EXCEPTION
  when errorResult then
    return voRes;
  WHEN others THEN
    voRes := '0=异常'||SUBSTR(SQLERRM, 1, 256);
    return voRes;
END;

FUNCTION sendMail(viToUser IN VARCHAR2,viTitle IN VARCHAR2,viBody IN VARCHAR2) RETURN VARCHAR2
AS
    vsNow VARCHAR2(50);
    --SMTP的域名或IP,若是端口映射，则填写代理机器IP
    v_mailhost VARCHAR2(30) := '192.168.1.50';
    --SMTP的端口
    v_mailport INTEGER := 9025;
    --登录SMTP服务器的用户名；只是用户名，不包括@163.com部分
    v_user VARCHAR2(100) := 'administrator';
    --登录SMTP服务器的密码
    v_pass VARCHAR2(20) := 'jike110911091109';
    --发送人的邮箱，一般与 user 对应
    vsFromUser VARCHAR2(50) := 'administrator@luopan88.com';
    --发送人的姓名
    vsFromUserName VARCHAR2(50) := '罗盘智慧差旅';
    --到邮件服务器的连接
    v_conn UTL_SMTP.connection;
    --邮件内容
    vsMsg VARCHAR2(32000);
    --返回结果
    voRes VARCHAR2(2000);
    --异常
    raiseExp exception;
BEGIN
    vsMsg := viBody;
    vsNow := to_char(sysdate,'yyyy-mm-dd hh24:mi:ss');
      
    ----------------------------
    --获得连接
    ----------------------------
    v_conn := UTL_SMTP.open_connection(v_mailhost, v_mailport);

    --------------------------------------------------------------------------
    -- 问候服务器：进行HELLO测试
    -- esmtp 就用ehlo，smtp 用 helo。
    -- esmtp是带验证功能的（需要密码的）
    -- 是用 ehlo()还是 helo() 自己测试
    -- 否则会报：ORA-29279: SMTP 永久性错误: 503 5.5.2 Send hello first.
    --------------------------------------------------------------------------
    UTL_SMTP.ehlo(v_conn, v_mailhost);

    --------------------------------------------------------------------------
    -- 如果smtp服务器带验证，则现面三行代码开启，否则注释掉
    --------------------------------------------------------------------------
    UTL_SMTP.command(v_conn, 'AUTH LOGIN');
    UTL_SMTP.command(v_conn,UTL_RAW.cast_to_varchar2(UTL_ENCODE.base64_encode(UTL_RAW.cast_to_raw(v_user))));
    UTL_SMTP.command(v_conn,UTL_RAW.cast_to_varchar2(UTL_ENCODE.base64_encode(UTL_RAW.cast_to_raw(v_pass))));

    --------------------------------------------------------------------------
    -- 设置发件人
    -- 设置收件人
    --------------------------------------------------------------------------
    UTL_SMTP.mail(v_conn, '<' || vsFromUser || '>');
    UTL_SMTP.rcpt(v_conn, '<' || viToUser   || '>');

    ------------------------------------------------------------------------------------------
    -- 发送邮件
    -- 方法一：允许先拼接成MSG，再发送，如下：
    -- v_msg := 'Date:' || TO_CHAR(SYSDATE, 'dd mon yy hh24:mi:ss') ||
    --       UTL_TCP.CRLF || 'From: ' || v_sender      || '<' || v_sender || '>' ||
    --       UTL_TCP.CRLF || 'To: '   || V1_RECIPIENT  || '<' || V1_RECIPIENT || '>' ||
    --       UTL_TCP.CRLF || 'Subject: ' || V2_SUBJECT || UTL_TCP.CRLF ||
    --       UTL_TCP.CRLF -- 这前面是报头信息
    --       || V3_message; -- 这个是邮件正文
    -- UTL_SMTP.write_raw_data(v_conn, UTL_RAW.cast_to_raw(v_msg)); --标题和内容都能用中文
    --
    -- 方法二：直接用UTL_SMTP.WRITE_DATA写,本例中采用此方法
    --
    -- 注意：创建要发送的邮件内容 注意报头信息和邮件正文之间要空一行
    -- Date:后面加上+????表示时区,+0200表示是东2区；同理+0800就指东八区,就是北京时间
    ------------------------------------------------------------------------------------------
    --打开流
    UTL_SMTP.open_data(v_conn);
    UTL_SMTP.WRITE_DATA(v_conn, 'Date: ' || TO_CHAR(SYSDATE, 'yyyy-mm-dd hh24:mi:ss')||' +0800'|| UTL_TCP.CRLF);
    --UTL_SMTP.WRITE_DATA(v_conn, 'From: ' || vsFromUser || '<' || vsFromUser || '>'|| UTL_TCP.CRLF);
    --发送人显示中文
    UTL_SMTP.WRITE_RAW_DATA(v_conn,UTL_RAW.CAST_TO_RAW('From: '|| vsFromUserName ||'<'|| vsFromUser ||'>'||UTL_TCP.CRLF));
    UTL_SMTP.WRITE_DATA(v_conn, 'To: '   || viToUser   || '<' || viToUser   || '>' ||UTL_TCP.CRLF);
    --下面两行当需要显示HTML格式时需要加上，编码我用的是GBK
    UTL_SMTP.WRITE_DATA(v_conn, 'MIME-Version: 1.0'|| UTL_TCP.CRLF);
    UTL_SMTP.WRITE_DATA(v_conn, 'Content-Type: text/html;charset=GBK'||UTL_TCP.CRLF);
    --标题
    UTL_SMTP.write_raw_data(v_conn,utl_raw.cast_to_raw('Subject:' ||viTitle||UTL_TCP.CRLF ));
    UTL_SMTP.WRITE_DATA(v_conn, UTL_TCP.CRLF);
    --内容,支持HTML
    UTL_SMTP.write_raw_data(v_conn, utl_raw.cast_to_raw(vsMsg));
    --关闭流
    UTL_SMTP.close_data(v_conn);
    --关闭连接
    UTL_SMTP.quit(v_conn);
    voRes := '1=SUCCESS,NOW='|| vsNow;
    RETURN voRes;
EXCEPTION
    WHEN OTHERS THEN
        voRes := '0=异常:'||SUBSTR(SQLERRM, 1, 220)||',NOW='|| vsNow;
        RETURN voRes;
END;

END;