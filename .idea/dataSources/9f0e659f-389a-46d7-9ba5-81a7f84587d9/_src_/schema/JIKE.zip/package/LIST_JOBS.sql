create PACKAGE LIST_JOBS IS
  ----------------------------------
  -- 国内酒店订单-取消，每分钟轮循
  -- 条件：
  -- 1.表名：T_CH_HOTEL_ORDER
  -- 2.条件：ORDER_ID IS NULL
  --         SYSDATE-CREATE_TIME>=28分钟
  --         LOCAL_STATUS NOT IN ('4')
  -- 3.结果：LOCAL_STATUS='4'
  -- 日期：2015-02-11
  ----------------------------------
  PROCEDURE CANCEL_HOTEL_ORDER(iiMinute IN INTEGER);

  ----------------------------------
  -- 机票订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_PLANE_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-03-12
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_PLANE_ORDER(currentDay IN DATE);

  ----------------------------------
  -- 机票报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_PLANE_TICKET
  -- 2.条件：查询前一天的机票数据
  -- 3.结果：
  -- 日期：2015-03-24
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_PLANE_TICKET(currentDay IN DATE);

  ----------------------------------
  -- 酒店订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_HOTEL_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-03-25
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_HOTEL_ORDER(currentDay IN DATE);

  ----------------------------------
  -- 酒店人员报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_HOTEL_CUSTOMER
  -- 2.条件：查询前一天的人员数据
  -- 3.结果：
  -- 日期：2015-08-10
  ----------------------------------
  PROCEDURE CAL_REPORT_HOTEL_CUSTOMER(currentDay IN DATE);

  ----------------------------------
  -- 保险订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_HOTEL_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-03-26
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_INS_ORDER(currentDay IN DATE);

  ----------------------------------
  -- 行程报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_PLANE_TRIP
  -- 2.条件：查询前一天的行程数据
  -- 3.结果：
  -- 日期：2015-04-22
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_PLANE_TRIP(currentDay IN DATE);

  ----------------------------------
  -- 火车票订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_TRAIN_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-07-11
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_TRAIN_ORDER(currentDay IN DATE);

  ----------------------------------
  -- 火车票报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_TRAIN_TICKET
  -- 2.条件：查询前一天的火车票数据
  -- 3.结果：
  -- 日期：2015-07-13
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_TRAIN_TICKET(currentDay IN DATE);
END;
