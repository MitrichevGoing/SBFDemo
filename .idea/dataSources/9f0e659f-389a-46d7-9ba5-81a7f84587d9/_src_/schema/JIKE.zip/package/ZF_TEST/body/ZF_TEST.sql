create package body ZF_TEST is
  PROCEDURE ZF_TEST1 AS
    iNum INTEGER;
  
    dtNow DATE;
    vsNow varchar2(50);
    errorResult EXCEPTION;
  BEGIN
  
    insert into t_zf_test1 (birthday) values (sysdate);
    commit;
  
    RAISE errorResult;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  PROCEDURE ZF_TEST2 AS
    iNum INTEGER;
  
    dtNow DATE;
    vsNow varchar2(50);
    errorResult EXCEPTION;
  BEGIN
  
    insert into t_zf_test1 (birthday) values (sysdate - 1);
    commit;
  
    RAISE errorResult;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
end ZF_TEST;
