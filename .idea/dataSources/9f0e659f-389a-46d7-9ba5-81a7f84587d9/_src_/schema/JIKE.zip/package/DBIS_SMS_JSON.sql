create PACKAGE DBIS_SMS_JSON IS
  ----------------------------------
  -- 数据库接口简单版-短信系统--JSON
  ----------------------------------

  ----------------------------------
  -- 生成短信
  -- 日期：2015-03-07
  ----------------------------------
  FUNCTION toCreate(viData IN VARCHAR2,viText IN VARCHAR2) RETURN VARCHAR2;

  ----------------------------------
  -- 授权码生成及验证工具
  -- 日期：2015-03-11
  -- 1.生成：{"method":"CREATE","telephone":"17712613261","licensetype":"1"}
  -- 2.检验：{"method":"CHECK","telephone":"17712613261","licensetype":"1","licensecode":"666666"}
  ----------------------------------
  FUNCTION licenseTool(viData IN VARCHAR2,viText IN VARCHAR2) RETURN VARCHAR2;

  --JOB检查
  PROCEDURE JobCheckTimeOut(viData in VARCHAR2);

  --JOB检查EMAIL
  PROCEDURE JobSendEmail(viData in varchar2);
END;
