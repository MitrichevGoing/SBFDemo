create PACKAGE SMS_SEND_PACKAGE IS
  --********************************************************
  --通用函数 BEGIN
  --********************************************************
  --1.MD5加密---
  FUNCTION encodeMD5(encodeText IN VARCHAR2) RETURN VARCHAR2;

  --2.字符串转换成整型--
  FUNCTION convertStrToInt(viString IN VARCHAR2, iiDefault IN INTEGER) RETURN INTEGER;

  --3.解析json,获得值--
  Function queryJsonValueFromName(viName IN VARCHAR2, viData IN VARCHAR2) RETURN VARCHAR2;

  -- 3.计算短信发送时间（如果是延时短信及限制短信）
  function workOnMsgSendTime(viCode varchar2,viDelay integer) return date;

  -- 4. 计算短信限制时间（如果短信限制开关开了 LIMIT）
  function workOnMsgLimitTime(viCode varchar2) return integer;

  -- 5 分析短信开关
  function workOnMsgSwitch(viCode varchar2,viSwitch integer) return integer;
  
  --6短信解析过程、发送过程 通用函数
  function smsGeneralInterface(vCode varchar2,vDelay integer,vSwitch integer,vMaType integer,vPriority integer,vMsgType integer,
        vOrderId integer,vCompanyId varchar2,vTemplet varchar2,vUserPhone varchar2,vRemark varchar2,vId varchar2,
        vCompanyName varchar2,vErrorMsg varchar2,vOrderNo varchar2,vObjectRole integer)
  return varchar2;
  
  --7.短信接收角色分析
  function judgeSendObject(
    vOrderPhone varchar2,  --预订人
    vContactPhone varchar2
  ) return integer;
  
  --8.乘机人角色分析
  function judgeSendUser(
    vUserPhone varchar2,   --乘机人
    vOrderPhone varchar2,  --预订人
    vContactPhone varchar2
  ) return integer;
  --********************************************************
  --通用函数 end
  --********************************************************



  --********************************************************
  --插入短信待发送列表 BEGIN--
  --********************************************************
  --4.插入解析器列表--
  --4.插入解析器列表--
  function insertToAnalysisQueue(
    viMaType    varchar2,  --短信业务类型 1-用户基础业务 2-订单业务  3-拓展业务
    viPriority   number,       --短信优先级
    viMsgType    varchar2,  --短信类型
    viMaSwitch   number,       --短信开关
    viMaDelay    number,       --短信延迟时间
    viOrderId    varchar2,  --订单ID
    viCompanyId  number,  --公司ID
    viText       varchar2,  --短信文本
    viPhone      varchar2,   --短信接收人电话
    viREMARK       varchar2,   --备用字段
    viFLAG         number,        --解析标识 0-失败 1-成功
    viUserId      varchar2,    --用户id
    viCode        varchar2,    --对应短信模板
    vId           varchar2    --id 基础业务为用户id,订单业务订单id,拓展业务为业务编码
  ) return varchar2;

  --5.插入业务短信待发送列表--
  function insertToAwaitQueue
  (
    viMType varchar2,           -- 短信类型
    viText    varchar2,         -- 短信文本
    viObject  varchar2,         -- 短信接收者
    viMaId    NUMBER,           -- 对应短信解析流水号
    viSendTime Date,            -- 发送时间
    viCode  varchar2,             -- 短信模板
    viCompanyName varchar2,     -- 企业名称
    viOrderId varchar2,         -- 订单流水id
    viObjectRole integer,           -- 短信接收者角色  1-联系人 2-预订人  3-用户、乘客
    viState   varchar2,          -- 短信状态
    viHanded  integer,             --是否手动编辑
    viUserId  varchar2,          -- 用户id
    viCreater varchar2,           -- 短信创建者 自动发送为SYSTEM/ 手动为客服id
    viRemark varchar2,            -- 备用字段
    viPriority number,           --发送优先级
    viOrderNo varchar2,          --订单编号
    viDelay   number            -- 延时数
  ) return varchar2 ;

  -- 6.插入错误消息队列表--
  function insertToErrorQueue
    (
      viMaId    NUMBER,
      viOrderId  varchar2,
      viObject  varchar2,
      viMId    NUMBER,
      viErrType varchar2,
      viErrMsg varchar2,
      viErrText varchar2
    ) return varchar2;
    
  --********************************************************
  --插入短信待发送列表 END--
  --********************************************************
  
  --********************************************************
  --生成短信文本、以及处理逻辑  begin--
  --********************************************************
  function toCreateMessage(vCode IN VARCHAR2, vId IN VARCHAR2,vRemark IN VARCHAR2,vPhone IN VARCHAR2,
            vMaType IN VARCHAR2,vPriority IN INT,vDelay in INT,vSwitch in INT,vMsgType in VARCHAR2) RETURN VARCHAR2;


END;