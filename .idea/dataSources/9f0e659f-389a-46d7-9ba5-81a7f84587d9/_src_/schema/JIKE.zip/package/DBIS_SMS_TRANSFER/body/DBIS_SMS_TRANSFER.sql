create PACKAGE BODY      DBIS_SMS_TRANSFER AS

  function smsSendingTransfer return varchar2 AS
    voRes varchar2(30000);      --返回的结果参数
    iNum integer ;              --计数器
    iNum2 integer;              --计数器2
    dtNow date;                 --当前系统时间
    vsNow varchar2(80);         --24小时制 时间符串
    vMeId varchar2(500);        --返回的错误消息流水号
    vErrMsg varchar2(3000);     --出错信息文本
  BEGIN
    dtNow := Sysdate;
    vsNow := to_char(dtNow,'yyyy-mm-dd hh24:mi:ss');

    --SMS队列  and to_char(SEND_TIME,'yyyy-mm-dd hh24:mi:ss') = vsNow
    for rs in (select * from T_BASE_MSG_AWAIT_QUEUE where M_STATE='1'AND SEND_TIME <= sysdate order by MID DESC, PRIORITY) loop

        --目前同一手机一天最多100条
        select count(0) into iNum from T_BASE_MSG_AWAIT_QUEUE
            where OBJECT_RECEIVE=rs.OBJECT_RECEIVE and M_STATE ='2' and SEND_TIME between trunc(dtNow) and trunc(dtNow+1);
        --超过100条，不发送
        if iNum>100 then
          --取消短信发送，同时此条短信进入错误信息队列表
          update T_BASE_MSG_AWAIT_QUEUE set M_STATE='3' where MID=rs.MID and M_STATE = '1';
          vErrMsg := vErrMsg || '【该用户当天发送次数已超过100次】';
          vMeId := SMS_SEND_PACKAGE.insertToErrorQueue(rs.MA_ID,rs.ORDER_ID,rs.OBJECT_RECEIVE,rs.MID,1,vErrMsg,rs.TEXT1);
          commit;
        else
          ---------------------------------
          -- 调用创蓝接口
          -- 1=成功
          -- 0=失败
          ---------------------------------
          voRes := dbis_sms_tool.send('1',rs.OBJECT_RECEIVE,rs.TEXT1,'6','');
          case
            when substr(voRes,1,2) in ('1=') then
              update T_BASE_MSG_AWAIT_QUEUE set M_STATE='2',REMARK='创蓝,'||substrb(voRes,3,200),SEND_TIME=sysdate where MID=rs.MID;
              /*
              insert into T_BASE_MSG_HISTORY VALUES(SEQ_MSG_HISTORY_ID.nextval,rs.MID,rs.ORDER_ID,rs.COMPANY_NAME,rs.TEXT1,
          rs.TEXT2,rs.SENDER,rs.OBJECT_RECEIVE,rs.OBJECT_ROLE,'2',rs.RE_SEND_TIMES,rs.RE_SEND_TIME,rs.MA_ID,rs.CREATE_TIME,rs.SEND_TIME,
          rs.M_TYPE,rs.HANDED,rs.REMARK,rs.USER_ID,rs.CREATER,rs.TEMP_CODE,rs.QU_ID,rs.PRIORITY,rs.ORDER_NO,rs.DELAY_TIME,sysdate);
          
              delete from T_BASE_MSG_AWAIT_QUEUE WHERE MID = rs.MID;
              */
              commit;
            when substr(voRes,1,2) in ('0=') then
              update T_BASE_MSG_AWAIT_QUEUE set M_STATE='3',REMARK='错误:'||vsNow||',创蓝,'||substrb(voRes,3,150) where MID=rs.MID;
              --插入错误消息列表
              vErrMsg := vErrMsg || '【创蓝，短信发送失败！'|| vsNow || substrb(voRes,3,150) ||'】';
              --判断该条短信是否已经存在错误消息队列，若已存在，则更新，反之，则新增
              select count(0) into iNum2 from T_BASE_MSG_ERROR_QUEUE WHERE MID = rs.MID;
              if iNum2 > 0 then
                update T_BASE_MSG_ERROR_QUEUE set ERR_TYPE =1,ME_STATE = 0 ,ERR_MSG = vErrMsg,ERR_TIME = dtNow,SLOVE_TIME = dtNow where MID = rs.MID;
              else
                vMeId := SMS_SEND_PACKAGE.insertToErrorQueue(rs.MA_ID,rs.ORDER_ID,rs.OBJECT_RECEIVE,rs.MID,1,vErrMsg,rs.TEXT1);
              end if;

              commit;
          else
            update T_BASE_MSG_AWAIT_QUEUE set M_STATE='3',REMARK='异常:'||vsNow||',创蓝,'||substrb(voRes,3,150) where MID=rs.MID;
            --插入错误消息列表
            vErrMsg := vErrMsg || '【错误！创蓝接口异常！'|| vsNow || substrb(voRes,3,150) ||'】';
            --判断该条短信是否已经存在错误消息队列，若已存在，则更新，反之，则新增
              select count(0) into iNum2 from T_BASE_MSG_ERROR_QUEUE WHERE MID = rs.MID;
              if iNum2 > 0 then
                update T_BASE_MSG_ERROR_QUEUE set ERR_TYPE =1,ME_STATE = 0 ,ERR_MSG = vErrMsg,ERR_TIME = dtNow,SLOVE_TIME = dtNow where MID = rs.MID;
              else
                vMeId := SMS_SEND_PACKAGE.insertToErrorQueue(rs.MA_ID,rs.ORDER_ID,rs.OBJECT_RECEIVE,rs.MID,1,vErrMsg,rs.TEXT1);
              end if;
            --vMeId := SMS_SEND_PACKAGE.insertToErrorQueue(rs.MA_ID,rs.ORDER_ID,rs.OBJECT_RECEIVE,rs.MID,1,vErrMsg,rs.TEXT1);
            commit;
          end case ;
          commit;
        end if ;

        --删除记录
        --delete from T_BASE_MSG_SEND WHERE MID = rs.MID;
        commit;
    end loop ;
    return '1=完成';
  exception
    when others then
      voRes := '0=异常:'||SUBSTR(SQLERRM, 1, 256);
      return voRes;
  END;



  --**********************************
  --短信错误消息重新发送 中转调度--
  --**********************************
  function errsmsResendTransfer return varchar2 as
    dtNow      date;     --当前日期
    vNum       integer;  --计数器
    vResult    varchar2(3000); --返回结果
    vTimes     integer;  --重发次数
    vDelay     integer;  --默认重发延迟时间
    iNum2      integer;
  BEGIN
    dtNow := sysdate;
    vDelay := 30;--默认重发延迟时间为30s

    for cursor_err in (select * from T_BASE_MSG_ERROR_QUEUE where ERR_TYPE = 1 and ME_STATE = 0 order by ME_ID DESC) loop
      select RE_SEND_TIMES into vTimes from T_BASE_MSG_AWAIT_QUEUE WHERE MID = cursor_err.MID;
      --计算重发次数
      if vTimes is null then
        vTimes := 1;
      else
        vTimes := vTimes + 1;
      end if;

      --若重发次数达到2次，则下次不再自动重发，需手工编辑重发
      if vTimes <= 2 then
        --重新发送一次，并且将该短信对应的重发次数+1，发送时间延迟30s,优先级变为1，重新加入待发送队列
        update T_BASE_MSG_ERROR_QUEUE
                set SLOVE_TIME = dtNow , ME_STATE = 1 where ME_ID = cursor_err.ME_ID;
        --更新短信队列状态
        update T_BASE_MSG_AWAIT_QUEUE
                set RE_SEND_TIMES = vTimes ,RE_SEND_TIME = sysdate + (1/(24*60*60))*vDelay , PRIORITY = 1
                where MID = cursor_err.MID;

        vResult := 'yes!错误流水号：' || cursor_err.ME_ID || '--重发成功！';

        commit;

      else
        vResult := 'no!错误流水号：' || cursor_err.ME_ID || '--超过重发次数限制！';
      end if;

    end loop;

    --重发因网络延迟二十分钟以内的短信

    for cursor_await in (select * from T_BASE_MSG_AWAIT_QUEUE where M_STATE = '1' and SEND_TIME < sysdate-10/(24*60*60) and RE_SEND_TIMES <= 3) loop
      if ROUND(TO_NUMBER(sysdate - cursor_await.SEND_TIME) * 24 * 60 * 60) < 1200 then
        update T_BASE_MSG_AWAIT_QUEUE set SEND_TIME = sysdate + 30/(24*60*60),RE_SEND_TIME = sysdate,
          RE_SEND_TIMES = cursor_await.RE_SEND_TIMES + 1 where MID = cursor_await.MID;
      end if;
    end loop;

    --取数据
    /*
    for cursor_get in (select * from T_BASE_MSG_AWAIT_QUEUE where M_STATE = '1' and SEND_TIME <= sysdate and RE_SEND_TIMES < 4) loop
        select count(0) into iNum2 from T_BASE_MSG_SEND WHERE MID = cursor_get.MID;
        if iNum2 > 0 then
          return vResult;
        else
        insert into t_base_msg_send VALUES(cursor_get.MID,cursor_get.ORDER_ID,cursor_get.COMPANY_NAME,cursor_get.TEXT1,cursor_get.TEXT2,cursor_get.SENDER,cursor_get.OBJECT_RECEIVE,cursor_get.OBJECT_ROLE,cursor_get.M_STATE,cursor_get.RE_SEND_TIMES,cursor_ge                                             cursor_get.M_TYPE,cursor_get.HANDED,cursor_get.REMARK,cursor_get.USER_ID,cursor_get.CREATER,cursor_get.TEMP_CODE,cursor_get.QU_ID,cursor_get.PRIORITY,cursor_get.ORDER_NO,cursor_get.DELAY_TIME,sysdate);
        end if;

    end loop;
    */
    return vResult;

  END;

  ---下行短信 （审批）
  function toCheckSmsReply return varchar2
  as
    iNum integer;
    vsCode varchar2(4000);
    vsRes  varchar2(4000);
    dtNow date;
    --vResult varchar2(3000);
  BEGIN
    dtNow := sysdate;
    for rs in (select * from T_BASE_MESSAGE_RECEIVE where state='0') loop
      vsCode := trim(rs.msg);
      --自动验证通过(现由JOB实现，准备放到此处)

      --是否匹配到：０-未匹配，１-找到匹配
      iNum := 0;
      --1.0订单验证未通过
      for rsOrder0 in (select a.order_endtime,a.audit_id, a.order_id,a.order_type,nvl((select mobilephone from t_base_user where user_id=a.audit_user and state='1' and rownum<=1),'0') phone from T_CC_ORDER_AUDIT a where decline_code=vsCode and state='1') l        for rsOrderUser in (select Audit_Id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_order_audit_user where Audit_Id=rsOrder0.Audit_Id) loop
          --手机号相同,匹配到
          if rsOrderUser.Phone in (rs.mobile) then
            iNum := 1;
            if dtNow>rsOrder0.Order_Endtime then
              update T_CC_ORDER_AUDIT set state='4',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='订单审批码过期' where Audit_Id=rsOrderUser.Audit_Id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批码过期',dotime=dtNow where id=rs.id;
            else
              update T_CC_ORDER_AUDIT set state='4',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核未通过' where Audit_Id=rsOrderUser.Audit_Id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批未通过',dotime=dtNow where id=rs.id;
            end if ;
          end if ;
          --根据订单类型进行判断 国内机票、国际机票、火车票
          if rsOrder0.Order_Type='1' then
             update t_cc_plane_order set audit_state='3' where plane_order_id=rsOrder0.Order_Id and audit_state in ('1');
             --发短信
             vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_PLANE_CIVIL',to_char(rsOrder0.Order_Id),'0','','2',1,20,0,2);
        end if ;
          if rsOrder0.Order_Type='2' then
             update T_CC_INTER_PLANE_ORDER set audit_state='3' where plane_order_id=rsOrder0.Order_Id and audit_state in ('1');
             --发短信
             vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_PLANE_INTER',to_char(rsOrder0.Order_Id),'0','','2',1,20,0,2);
          end if ;
          if rsOrder0.Order_Type= '17' then
             update T_CC_TRAIN_ORDER set audit_state= '3' where train_order_id=rsOrder0.Order_Id and audit_state in ('1');
             --发短信
             vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_TRAIN',to_char(rsOrder0.Order_Id),'0','','2',1,20,0,2);
          end if;
        end loop ;
      end loop ;

      --1.1订单验证通过
      for rsOrder1 in (select a.order_endtime, a.audit_id, a.order_id,a.order_type,nvl((select mobilephone from t_base_user where user_id=a.audit_user and state='1' and rownum<=1),'0') phone from T_CC_ORDER_AUDIT a where PASS_CODE=vsCode and state='1') loo        for rsOrderUser in (select Audit_Id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_order_audit_user where Audit_Id=rsOrder1.Audit_Id) loop
          --手机号相同,匹配到
          if rsOrderUser.Phone in (rs.mobile) then
            iNum := 1;
            if dtNow>rsOrder1.Order_Endtime then
              update T_CC_ORDER_AUDIT set state='4',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核码过期' where Audit_Id=rsOrderUser.Audit_Id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批码过期',dotime=dtNow where id=rs.id;
              if rsOrder1.Order_Type='1' then
                 update t_cc_plane_order set audit_state='3' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
                 --发短信
                 vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_PLANE_CIVIL',to_char(rsOrder1.Order_Id),'0','','2',1,20,0,2);
              end if ;
              if rsOrder1.Order_Type='2' then
                 update T_CC_INTER_PLANE_ORDER set audit_state='3' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
                 --发短信
                 vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_PLANE_INTER',to_char(rsOrder1.Order_Id),'0','','2',1,20,0,2);
              end if ;
              if rsOrder1.Order_Type= '17' then
                 update T_CC_TRAIN_ORDER set audit_state= '3' where train_order_id=rsOrder1.Order_Id and audit_state in ('1');
                 --发短信
                 vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_TRAIN',to_char(rsOrder1.Order_Id),'0','','2',1,20,0,2);
              end if;
            else
              update T_CC_ORDER_AUDIT set state='3',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核已通过' where Audit_Id=rsOrderUser.Audit_Id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批已通过',dotime=dtNow where id=rs.id;
              if rsOrder1.Order_Type='1' then
                 update t_cc_plane_order set audit_state='2' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
                 --发短信
                 vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_PLANE_CIVIL',to_char(rsOrder1.Order_Id),'1','','2',1,20,0,2);
              end if ;
              if rsOrder1.Order_Type='2' then
                 update T_CC_INTER_PLANE_ORDER set audit_state='2' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
                 --发短信
                 vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_PLANE_INTER',to_char(rsOrder1.Order_Id),'1','','2',1,20,0,2);
              end if ;
              if rsOrder1.Order_Type= '17' then
                 update T_CC_TRAIN_ORDER set audit_state= '2' where train_order_id=rsOrder1.Order_Id and audit_state in ('1');
                 --发短信
                 vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_ORDER_FOR_REPLY_TRAIN',to_char(rsOrder1.Order_Id),'1','','2',1,20,0,2);
              end if;
            end if ;
          end if ;
        end loop ;
      end loop ;

      --2.0行程单的验证未通过　状态=4
      for rsXcd0 in (select a.trip_endtime, a.biz_trip_id from T_CC_BUSINESS_TRIP a where decline_code=vsCode and state='1') loop
        --通过子表去查询手机号
        for rsBizTripUser in (select biz_trip_id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_biztrip_audit_user where biz_trip_id=rsXcd0.Biz_Trip_Id) loop
          --手机号相同,匹配到
          if rsBizTripUser.Phone in (rs.mobile) then
            iNum := 1;
            if dtNow>rsXcd0.trip_endtime then
              update T_CC_BUSINESS_TRIP set state='4',audit_state='3',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批码过期' where biz_trip_id=rsBizTripUser.biz_trip_id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批码过期',dotime=dtNow where id=rs.id;
              --发短信
              vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_TRAIN_BIZ_APPROVAL_TO_ORDER',to_char(rsBizTripUser.Biz_Trip_Id),'0','','2',1,20,0,2);
            else
              update T_CC_BUSINESS_TRIP set state='4',audit_state='3',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批未通过' where biz_trip_id=rsBizTripUser.biz_trip_id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批未通过',dotime=dtNow where id=rs.id;
              --发短信
              vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_TRAIN_BIZ_APPROVAL_TO_ORDER',to_char(rsBizTripUser.Biz_Trip_Id),'0','','2',1,20,0,2);
            end if ;
          end if ;
        end loop ;
      end loop ;

      --2.1行程单的验证已通过　状态=3
      for rsXcd1 in (select a.trip_endtime,a.biz_trip_id,nvl((select mobilephone from t_base_user where user_id=a.audit_user and state='1' and rownum<=1),'0') phone from T_CC_BUSINESS_TRIP a where pass_code=vsCode and state='1') loop
        --通过子表去查询手机号
        for rsBizTripUser in (select biz_trip_id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_biztrip_audit_user where biz_trip_id=rsXcd1.Biz_Trip_Id) loop
          --手机号相同,匹配到
          if rsBizTripUser.Phone in (rs.mobile) then
            iNum := 1;
            if dtNow>rsXcd1.trip_endtime then
              update T_CC_BUSINESS_TRIP set state='4',audit_state='3',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批码过期' where biz_trip_id=rsBizTripUser.biz_trip_id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批码过期',dotime=dtNow where id=rs.id;
              --发短信
              vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_TRAIN_BIZ_APPROVAL_TO_ORDER',to_char(rsBizTripUser.Biz_Trip_Id),'0','','2',1,20,0,2);
            else
              update T_CC_BUSINESS_TRIP set state='3',audit_state='2',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批已通过' where biz_trip_id=rsBizTripUser.biz_trip_id;
              update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批已通过',dotime=dtNow where id=rs.id;
              --发短信
              vsRes := SMS_SEND_PACKAGE.toCreateMessage('MSG_TRAIN_BIZ_APPROVAL_TO_ORDER',to_char(rsBizTripUser.Biz_Trip_Id),'1','','2',1,20,0,2);
            end if ;
          end if ;
        end loop ;
      end loop ;


      --未找到匹配的数据
      if iNum=0 then
        update T_BASE_MESSAGE_RECEIVE set state='2',res='无需处理',dotime=dtNow where id=rs.id;
      end if ;

      commit;


    end loop ;
    return  vsRes;
  END;


  ----------------------------------------------------------------------------------------------
  --每月末将发送队列短信移到历史发送区  每月最后一天的12点执行一次
  ----------------------------------------------------------------------------------------------
  
  function solveSmsRecord return varchar2 as
    iNum integer;
    result varchar2(300);
  begin
    for cursor_record in (select * from T_BASE_MSG_AWAIT_QUEUE where m_state <> '1' and SEND_TIME < trunc(sysdate-1) order by send_time ,PRIORITY) loop
        insert into T_BASE_MSG_HISTORY VALUES(SEQ_MSG_HISTORY_ID.nextval,cursor_record.MID,cursor_record.ORDER_ID,cursor_record.COMPANY_NAME,cursor_record.TEXT1,
          cursor_record.TEXT2,cursor_record.SENDER,cursor_record.OBJECT_RECEIVE,cursor_record.OBJECT_ROLE,cursor_record.M_STATE,cursor_record.RE_SEND_TIMES,cursor_record.RE_SEND_TIME,cursor_record.MA_ID,cursor_record.CREATE_TIME,cursor_record.SEND_TIME,
          cursor_record.M_TYPE,cursor_record.HANDED,cursor_record.REMARK,cursor_record.USER_ID,cursor_record.CREATER,cursor_record.TEMP_CODE,cursor_record.QU_ID,cursor_record.PRIORITY,cursor_record.ORDER_NO,cursor_record.DELAY_TIME,sysdate);

        delete from T_BASE_MSG_AWAIT_QUEUE WHERE MID = cursor_record.MID;
    end loop;
    result := '短信记录移库完成';
    return result;
  end;
  

END DBIS_SMS_TRANSFER;