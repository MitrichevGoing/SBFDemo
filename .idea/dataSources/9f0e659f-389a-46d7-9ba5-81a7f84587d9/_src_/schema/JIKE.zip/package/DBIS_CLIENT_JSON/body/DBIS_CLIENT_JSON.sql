create PACKAGE BODY DBIS_CLIENT_JSON IS
  TYPE ListString IS TABLE OF VARCHAR2(32000);

  --------------------------------------------------------------
  -- 通用函数：MD5加密
  --------------------------------------------------------------
  FUNCTION encodeMD5(myText IN VARCHAR2) RETURN VARCHAR2 AS
    RAW_INPUT     RAW(128) := UTL_RAW.CAST_TO_RAW(UPPER(myText));
    DECRYPTED_RAW RAW(2048);
    ERROR_IN_INPUT_BUFFER_LENGTH EXCEPTION;
  BEGIN
    IF (Length(myText) <= 0) OR (myText IS NULL) THEN
      RETURN 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
    ELSE
      SYS.DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT    => RAW_INPUT,
                                       CHECKSUM => DECRYPTED_RAW);
      RETURN LOWER(RAWTOHEX(DECRYPTED_RAW));
    END IF;
  END;

  --------------------------------------------------------------
  -- 通用函数：字符串转换成整形
  --------------------------------------------------------------
  FUNCTION convertStrToInt(viString IN VARCHAR2, iiDefault IN INTEGER)
    RETURN INTEGER AS
    voRes varchar2(250);
    noRes number;
    ioRes integer;
  BEGIN
    ioRes := iiDefault;
    if LengthB(viString) > 18 then
      return ioRes;
    end if;
    voRes := Trim(viString);
    if substr(voRes, 1, 1) in ('-') then
      voRes := substr(voRes, 2);
    end if;

    voRes := Replace(voRes, '0');
    voRes := Replace(voRes, '1');
    voRes := Replace(voRes, '2');
    voRes := Replace(voRes, '3');
    voRes := Replace(voRes, '4');
    voRes := Replace(voRes, '5');
    voRes := Replace(voRes, '6');
    voRes := Replace(voRes, '7');
    voRes := Replace(voRes, '8');
    voRes := Replace(voRes, '9');
    if voRes is null then
      noRes := to_number(Trim(viString));
      if noRes between - 2147483648 and 2147483647 then
        ioRes := noRes;
      else
        ioRes := iiDefault;
      end if;
    else
      ioRes := iiDefault;
    end if;

    return ioRes;
  END;

  --------------------------------------------------------------
  -- 通用函数：解析JSON，获得值
  --------------------------------------------------------------
  Function queryJsonValueFromName(viName IN varchar2, viData IN varchar2)
    return varchar2 as
    voRes  varchar2(32000);
    vInput varchar2(32000);
    iPos1  integer;
    iPos2  integer;
    iPos3  integer;
  begin
    vInput := upper(viData);
    iPos1  := instr(vInput, '"' || Trim(Upper(viName)) || '"');
    iPos2  := instr(vInput, ':', iPos1);
    iPos3  := instr(vInput, ',', iPos2);
    if iPos3 = 0 then
      iPos3 := instr(vInput, '}', iPos2);
    end if;
    voRes := trim(substr(viData, iPos2 + 1, iPos3 - iPos2 - 1));
    if (substr(voRes, 1, 1) in ('"')) then
      voRes := substr(voRes, 2, Length(voRes) - 2);
    end if;
    return voRes;
  end;

  --------------------------------------------------------------
  -- 接口函数：query_ready_sms-查询出预备发送的短信列表
  --------------------------------------------------------------
  FUNCTION query_ready_sms(viCon IN Varchar2, listRes OUT ListString)
    RETURN VARCHAR2 AS
    iAdd INTEGER;
    iNum INTEGER;

    dtNow DATE;
    vsNow varchar2(50);
    voRes VARCHAR2(20000);

    vUser  varchar2(250);
    vType  varchar2(8);
    vWho   varchar2(250);
    iCount integer;

    errorResult EXCEPTION;
  BEGIN
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser  := queryJsonValueFromName('user', viCon);
    vType  := queryJsonValueFromName('type', viCon);
    vWho   := queryJsonValueFromName('who', viCon);
    iCount := convertStrToInt(queryJsonValueFromName('count', viCon), 1);

    --分配短信
    UPDATE T_BASE_MESSAGE_QUEUE
       SET MQ_SENDER = vWho, MQ_STATE = '1'
     WHERE MQ_ID IN (SELECT MQ_ID
                       FROM (SELECT MQ_ID
                               FROM T_BASE_MESSAGE_QUEUE
                              WHERE MQ_TYPE = vType
                                AND MQ_STATE = '0'
                              ORDER BY MQ_LEVEL)
                      WHERE ROWNUM <= iCount);
    COMMIT;

    dtNow := SYSDATE;
    vsNow := TO_CHAR(dtNow, 'YYYY-MM-DD HH24:MI:SS');

    listRes := ListString();
    listRes.extend(200);
    listRes(1) := '';
    iAdd := 2;
    listRes(iAdd) := '';

    --------------------------------------------------------------------
    -- 获得短信,1200是方便调试，可以设成32000
    --------------------------------------------------------------------
    iNum := 0;
    for rs in (select *
                 from T_BASE_MESSAGE_QUEUE
                where MQ_TYPE = vType
                  and MQ_STATE = '1'
                  And MQ_SENDER = vWho
                  And rownum <= iCount) loop
      IF LENGTHB(nvl(listRes(iAdd), 'N')) >= 1200 THEN
        iAdd := iAdd + 1;
        listRes(iAdd) := '';
      END IF;
      listRes(iAdd) := listRes(iAdd) || '{"id":"' || rs.mq_id;
      listRes(iAdd) := listRes(iAdd) || '","type":"' || rs.mq_type;
      listRes(iAdd) := listRes(iAdd) || '","text1":"' || rs.mq_text1;
      listRes(iAdd) := listRes(iAdd) || '","text2":"' || rs.mq_text2;
      listRes(iAdd) := listRes(iAdd) || '","text3":"' || rs.mq_text3;
      listRes(iAdd) := listRes(iAdd) || '","object":"' || rs.mq_object;
      listRes(iAdd) := listRes(iAdd) || '"},';
      iNum := iNum + 1;
    end loop;
    if iNum < 1 then
      listRes(1) := '{}';
      voRes := 'S:QUERY_READHY_SMS RETURN ROWS=1';
    end if;
    if iNum = 1 then
      listRes(1) := '';
      listRes(iAdd) := substr(listRes(iAdd), 1, length(listRes(iAdd)) - 1);
      voRes := 'S:QUERY_READHY_SMS RETURN ROWS=1';
    end if;
    if iNum > 1 then
      listRes(1) := '[';
      listRes(iAdd) := substr(listRes(iAdd), 1, length(listRes(iAdd)) - 1) || ']';
      voRes := 'S:QUERY_READHY_SMS RETURN ROWS=' || iNum;
    end if;
    RAISE errorResult;
  EXCEPTION
    WHEN errorResult THEN
      RETURN voRes || ',NOW=' || vsNow;
    WHEN OTHERS THEN
      voRes := 'W:' || SUBSTR(SQLERRM, 1, 220) || ',NOW=' || vsNow;
      RETURN voRes;
  END;

  --------------------------------------------------------------
  -- 获取结算日，结算日若大于本月最后一天，则结算日改为本月最后一天
  --------------------------------------------------------------
  Function getSettlementDay(dtNow IN date, settlementDay IN integer)
    return integer as
    v_settlementDay integer;
  begin
    if dtNow is null or settlementDay is null then
      return v_settlementDay;
    end if;
    select to_number(to_char(last_day(dtNow), 'dd'))
      into v_settlementDay
      from dual;
    if settlementDay < v_settlementDay then
      v_settlementDay := settlementDay;
    end if;
    return v_settlementDay;
  end;

  -----------------------------------------------------------------------------------------
  -- 1.支付 {"sn":"1234567","fun":"pay_defray","user":"hqchen125",companyId":320500000001,"orderId":88}
  -----------------------------------------------------------------------------------------
  FUNCTION pay_defray(viCon IN VARCHAR2, viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser           varchar2(250);
    vCompanyId      varchar2(200);
    vPlane_order_id varchar2(500);
    nPurchaser_id   number;
    nDetail_id      number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    --{"purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}
    --vResult := '{"code":"1","message":"支付完成","purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}';
    --raise errorResult;
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser           := queryJsonValueFromName('user', viCon);
    vCompanyId      := queryJsonValueFromName('companyId', viCon);
    vPlane_order_id := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填写机票结算
    -- 2.修改机票订单状态
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_cc_plane_order a
                where a.plane_order_id = to_number(vPlane_order_id)
                  and a.company_id = to_number(vCompanyId)
                  and a.state in ('1')
                  and rownum <= 1) loop
      iNum := 1;
      /*select seq_detailpur_detailid.nextval into nDetail_id from dual;
      insert into T_FIN_DETAIL_PUR
        (detail_id,
         Purchaser_Id,
         Company_Id,
         Oper_User,
         oper_time,
         Oper_Money,
         Operation,
         OPER_ID,
         state)
      values
        (nDetail_id,
         nPurchaser_id,
         to_number(vCompanyId),
         '',
         sysdate,
         rs.sale_price,
         '1',
         rs.plane_order_id,
         '0');
      insert into t_Fin_Detail_Pur_Plane_Order
        (detail_id, Biz_Trip_Id, Prepayment, Overdraft, Total_Templimit)
      values
        (nDetail_id, rs.biz_trip_id, 0, 0, 0);*/
      update t_cc_plane_order
         set state           = '2',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             pur_settle_type = '2'
       where plane_order_id = to_number(vPlane_order_id)
         and company_id = to_number(vCompanyId)
         and state in ('1');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 2.国际支付 {"sn":"1234567","fun":"inter_pay_defray","user":"hqchen125",companyId":320500000001,"orderId":88}
  -----------------------------------------------------------------------------------------
  FUNCTION inter_pay_defray(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser           varchar2(250);
    vCompanyId      varchar2(200);
    vPlane_order_id varchar2(500);
    nPurchaser_id   number;
    nDetail_id      number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    --{"purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}
    --vResult := '{"code":"1","message":"支付完成","purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}';
    --raise errorResult;
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser           := queryJsonValueFromName('user', viCon);
    vCompanyId      := queryJsonValueFromName('companyId', viCon);
    vPlane_order_id := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填写机票结算
    -- 2.修改机票订单状态
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_cc_inter_plane_order a
                where a.plane_order_id = to_number(vPlane_order_id)
                  and a.company_id = to_number(vCompanyId)
                  and a.state in ('1')
                  and rownum <= 1) loop
      iNum := 1;
      /*select SEQ_INT_DETAILPUR_DETAILID.nextval into nDetail_id from dual;
      insert into T_FIN_INTER_DETAIL_PUR
        (detail_id,
         Purchaser_Id,
         Company_Id,
         Oper_User,
         oper_time,
         Oper_Money,
         Operation,
         OPER_ID,
         state)
      values
        (nDetail_id,
         nPurchaser_id,
         to_number(vCompanyId),
         '',
         sysdate,
         rs.sale_price,
         '1',
         rs.plane_order_id,
         '0');
      insert into t_fin_inter_detail_pur_p_o
        (detail_id, Biz_Trip_Id, Prepayment, Overdraft, Total_Templimit)
      values
        (nDetail_id, rs.biz_trip_id, 0, 0, 0);*/
      update t_cc_inter_plane_order
         set state           = '2',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             pur_settle_type = '2'
       where plane_order_id = to_number(vPlane_order_id)
         and company_id = to_number(vCompanyId)
         and state in ('1');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -------------------------------------------------------------------------------------------------------------------------------------------------
  -- 3.验证余额：pay_validate_balance {"sn":"1234567","fun":"pay_validate_balance","user":"hqchen125","companyId":320500000001,"orderId":88}
  -------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION pay_validate_balance(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser           varchar2(250);
    vCompanyId      varchar2(200);
    vPlane_order_id varchar2(500);
    vPurchaser_id   number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser           := queryJsonValueFromName('user', viCon);
    vCompanyId      := queryJsonValueFromName('companyId', viCon);
    vPlane_order_id := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 余额验证规则：
    -- 1.最后每月的结算日到现在这段时间内，来计算余额
    -- 2.计算的金额包括：出票价+已退票价，不包括退票中的
    -- A.判断订单表、保险表、退票表等，计算出本次支付的总费用和本结算周期已经支付的总费用
    -- B.判断采购商总额度表、临时额度表，计算出总额度
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    -- ???：以后尽量用详情表内的，因为有可能存在子状态是退票的
    for rs in (select *
                 from t_cc_plane_order
                where plane_order_id = to_number(vPlane_order_id)
                  and state = '1') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vPlane_order_id ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  -------------------------------------------------------------------------------------------------------------------------------------------------
  -- 4.国际验证余额：inter_pay_validate_balance {"sn":"1234567","fun":"inter_pay_validate_balance","user":"hqchen125","companyId":320500000001,"orderId":88}
  -------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION inter_pay_validate_balance(viCon  IN VARCHAR2,
                                      viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser           varchar2(250);
    vCompanyId      varchar2(200);
    vPlane_order_id varchar2(500);
    vPurchaser_id   number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser           := queryJsonValueFromName('user', viCon);
    vCompanyId      := queryJsonValueFromName('companyId', viCon);
    vPlane_order_id := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 余额验证规则：
    -- 1.最后每月的结算日到现在这段时间内，来计算余额
    -- 2.计算的金额包括：出票价+已退票价，不包括退票中的
    -- A.判断订单表、保险表、退票表等，计算出本次支付的总费用和本结算周期已经支付的总费用
    -- B.判断采购商总额度表、临时额度表，计算出总额度
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    -- ???：以后尽量用详情表内的，因为有可能存在子状态是退票的
    for rs in (select *
                 from t_cc_inter_plane_order
                where plane_order_id = to_number(vPlane_order_id)
                  and state = '1') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vPlane_order_id ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  ---------------------------------------------------------------------------------------------------------------------------------
  -- 5.验证账期：{"sn":"1234567","fun":"pay_validate_accountperiod","user":"hqchen125","companyId":320500000001}
  ---------------------------------------------------------------------------------------------------------------------------------
  FUNCTION pay_validate_accountperiod(viCon  IN VARCHAR2,
                                      viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow  Date;
    iNum   Integer;
    iCount Integer;

    vUser      varchar2(250);
    vCompanyId varchar2(200);
    vText      varchar2(5000);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;
    dtTmp date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vText      := queryJsonValueFromName('text', viCon);

    ----------------------------------------------------------------------------------------------------------------
    -- 判断账期
    -- 规则：通过每月结算日，与当前日期生成出最早结算日期
    -- 最早结算日期与NOW时间范围内，无已经结算的记录，则判断上上结算周期，有已经结算的记录，则判断上结算周期
    ----------------------------------------------------------------------------------------------------------------
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum := 1;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上上结算周期
          dtOne := ADD_MONTHS(dtTwo, -2);
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
          dtOne := ADD_MONTHS(dtOne, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
            dtOne := dtOne;
          else
            dtTmp := dtTwo;
            dtTwo := dtOne;
            dtOne := ADD_MONTHS(dtTmp, -1);
          end if;
        end if;
      end if;
      --判断结算周期内的订单，是否存在未结算记录
      --1.国内机票订单，是否存在未结算，状态：2-已预订已支付，3-出票成功；
      --2.国内机票退废票订单
      --3.其他订单
      --无已经结算的记录，则判断上一周期,有已经结算记录,是判断上周期
      select count(0)
        into iCount
        from T_CC_PLANE_ORDER
       where company_id = rsZq.company_id
         and state in ('5')
         and sup_settle_time between dtOne + 1 / 24 / 60 / 60 and dtTwo;
      if iCount < 1 then
        select count(0)
          into iCount
          from T_CC_PLANE_ORDER
         where company_id = rsZq.company_id
           and state in ('2', '3')
           and create_time <= dtOne;
      else
        select count(0)
          into iCount
          from T_CC_PLANE_ORDER
         where company_id = rsZq.company_id
           and state in ('2', '3')
           and create_time <= dtTwo;
      end if;
      if iCount > 0 then
        vResult := '{"isInAccountPeriod":0}';
        vResult := '{"code":"0","message":"验证账期失败","isInAccountPeriod":0}';
      else
        vResult := '{"code":"1","message":"验证账期成功","isInAccountPeriod":1}';
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"isInAccountPeriod":0}';
    end if;
    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInAccountPeriod":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInAccountPeriod":0}';
      RETURN vResult;
  END;

  ---------------------------------------------------------------------------------------------------------------------------------
  -- 6.国际验证账期：{"sn":"1234567","fun":"inter_pay_validate_accountperiod","user":"hqchen125","companyId":320500000001}
  ---------------------------------------------------------------------------------------------------------------------------------
  FUNCTION inter_pay_val_accountperiod(viCon  IN VARCHAR2,
                                       viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow  Date;
    iNum   Integer;
    iCount Integer;

    vUser      varchar2(250);
    vCompanyId varchar2(200);
    vText      varchar2(5000);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;
    dtTmp date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vText      := queryJsonValueFromName('text', viCon);

    ----------------------------------------------------------------------------------------------------------------
    -- 判断账期
    -- 规则：通过每月结算日，与当前日期生成出最早结算日期
    -- 最早结算日期与NOW时间范围内，无已经结算的记录，则判断上上结算周期，有已经结算的记录，则判断上结算周期
    ----------------------------------------------------------------------------------------------------------------
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum := 1;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上上结算周期
          dtOne := ADD_MONTHS(dtTwo, -2);
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
          dtOne := ADD_MONTHS(dtOne, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
            dtOne := dtOne;
          else
            dtTmp := dtTwo;
            dtTwo := dtOne;
            dtOne := ADD_MONTHS(dtTmp, -1);
          end if;
        end if;
      end if;
      --判断结算周期内的订单，是否存在未结算记录
      --1.国内机票订单，是否存在未结算，状态：2-已预订已支付，3-出票成功；
      --2.国内机票退废票订单
      --3.其他订单
      --无已经结算的记录，则判断上一周期,有已经结算记录,是判断上周期
      select count(0)
        into iCount
        from T_CC_INTER_PLANE_ORDER
       where company_id = rsZq.company_id
         and state in ('5')
         and sup_settle_time between dtOne + 1 / 24 / 60 / 60 and dtTwo;
      if iCount < 1 then
        select count(0)
          into iCount
          from T_CC_INTER_PLANE_ORDER
         where company_id = rsZq.company_id
           and state in ('2', '3')
           and create_time <= dtOne;
      else
        select count(0)
          into iCount
          from T_CC_INTER_PLANE_ORDER
         where company_id = rsZq.company_id
           and state in ('2', '3')
           and create_time <= dtTwo;
      end if;
      if iCount > 0 then
        vResult := '{"isInAccountPeriod":0}';
        vResult := '{"code":"0","message":"验证账期失败","isInAccountPeriod":0}';
      else
        vResult := '{"code":"1","message":"验证账期成功","isInAccountPeriod":1}';
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"isInAccountPeriod":0}';
    end if;
    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInAccountPeriod":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInAccountPeriod":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 7.支付 {"sn":"1234567","fun":"train_pay_defray","user":"hqchen125",companyId":320500000001,"orderId":88}
  -----------------------------------------------------------------------------------------
  FUNCTION train_pay_defray(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser           varchar2(250);
    vCompanyId      varchar2(200);
    vTrain_order_id varchar2(500);
    nPurchaser_id   number;
    nDetail_id      number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    --{"purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}
    --vResult := '{"code":"1","message":"支付完成","purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}';
    --raise errorResult;
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser           := queryJsonValueFromName('user', viCon);
    vCompanyId      := queryJsonValueFromName('companyId', viCon);
    vTrain_order_id := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填火车票票结算
    -- 2.修改火车票订单状态
    ----------------------------------------------------------------------------
    -- -1 TRAIN_ORDER_STATE   已失效
    --  1 TRAIN_ORDER_STATE   已预订未支付
    --  2 TRAIN_ORDER_STATE   已支付
    --  3 TRAIN_ORDER_STATE   出票中
    --  4 TRAIN_ORDER_STATE   已出票
    --  5 TRAIN_ORDER_STATE   出票失败

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_cc_train_order a
                where a.train_order_id = to_number(vTrain_order_id)
                  and a.company_id = to_number(vCompanyId)
                  and a.state in ('1')
                  and rownum <= 1) loop
      iNum := 1;

      update t_cc_train_order
         set state           = '2',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             pur_settle_type = '2'
       where train_order_id = to_number(vTrain_order_id)
         and company_id = to_number(vCompanyId)
         and state in ('1');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 8.国内火车票验证余额 {"sn":"1234567","fun":"train_pay_validate_balance","user":"hqchen125","companyId":320500000001,"orderId":88}
  -----------------------------------------------------------------------------------------
  FUNCTION train_pay_validate_balance(viCon  IN VARCHAR2,
                                      viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser           varchar2(250);
    vCompanyId      varchar2(200);
    vTrain_order_id varchar2(500);
    vPurchaser_id   number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser           := queryJsonValueFromName('user', viCon);
    vCompanyId      := queryJsonValueFromName('companyId', viCon);
    vTrain_order_id := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 余额验证规则：
    -- 1.最后每月的结算日到现在这段时间内，来计算余额
    -- 2.计算的金额包括：出票价+已退票价，不包括退票中的
    -- A.判断订单表、保险表、退票表等，计算出本次支付的总费用和本结算周期已经支付的总费用
    -- B.判断采购商总额度表、临时额度表，计算出总额度
    ----------------------------------------------------------------------------
    -- -1 TRAIN_ORDER_STATE   已失效
    --  1 TRAIN_ORDER_STATE   已预订未支付
    --  2 TRAIN_ORDER_STATE   已支付
    --  3 TRAIN_ORDER_STATE   出票中
    --  4 TRAIN_ORDER_STATE   已出票
    --  5 TRAIN_ORDER_STATE   出票失败

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    -- ???：以后尽量用详情表内的，因为有可能存在子状态是退票的
    for rs in (select *
                 from t_cc_train_order
                where train_order_id = to_number(vTrain_order_id)
                  and state = '1') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vTrain_order_id ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 9.支付 {"sn":"1234567","fun":"hotel_pay_defray","user":"hqchen125",companyId":320500000001,"orderId":"88"}
  -- 已废弃
  -----------------------------------------------------------------------------------------
  FUNCTION hotel_pay_defray(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser                    varchar2(250);
    vCompanyId               varchar2(200);
    vAffiliateConfirmationId varchar2(500);
    nPurchaser_id            number;
    nDetail_id               number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    --{"purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}
    --vResult := '{"code":"1","message":"支付完成","purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}';
    --raise errorResult;
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser                    := queryJsonValueFromName('user', viCon);
    vCompanyId               := queryJsonValueFromName('companyId', viCon);
    vAffiliateConfirmationId := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填酒店结算
    -- 2.修改酒店订单状态
    ----------------------------------------------------------------------------
    --  0 HOTEL_ORDER_STATE   确认中
    --  6 HOTEL_ORDER_STATE   待支付

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_ch_hotel_order a
                where a.affiliate_confirmation_id = vAffiliateConfirmationId
                  and a.company_id = to_number(vCompanyId)
                  and a.local_status in ('6')
                  and a.pur_pay_state in ('0')
                  and rownum <= 1) loop
      iNum := 1;

      update t_ch_hotel_order
         set pur_pay_state   = '1',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             local_status    = '0',
             pur_settle_type = '2'
       where affiliate_confirmation_id = vAffiliateConfirmationId
         and company_id = to_number(vCompanyId)
         and local_status in ('6')
         and pur_pay_state in ('0');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_total_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 10.国内酒店验证余额 {"sn":"1234567","fun":"hotel_pay_validate_balance","user":"hqchen125","companyId":320500000001,"orderId":"88"}
  -- 已废弃
  -----------------------------------------------------------------------------------------
  FUNCTION hotel_pay_validate_balance(viCon  IN VARCHAR2,
                                      viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser                    varchar2(250);
    vCompanyId               varchar2(200);
    vAffiliateConfirmationId varchar2(500);
    vPurchaser_id            number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser                    := queryJsonValueFromName('user', viCon);
    vCompanyId               := queryJsonValueFromName('companyId', viCon);
    vAffiliateConfirmationId := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 余额验证规则：
    -- 1.最后每月的结算日到现在这段时间内，来计算余额
    -- 2.计算的金额包括：出票价+已退票价，不包括退票中的
    -- A.判断订单表、保险表、退票表等，计算出本次支付的总费用和本结算周期已经支付的总费用
    -- B.判断采购商总额度表、临时额度表，计算出总额度
    ----------------------------------------------------------------------------
    --  0 HOTEL_ORDER_LOCAL_STATE   确认中
    --  3 HOTEL_ORDER_LOCAL_STATE   已成交
    --  6 HOTEL_ORDER_LOCAL_STATE   待支付

    --  1 HOTEL_PAY_STATUS = 1  未支付
    --  2 HOTEL_PAY_STATUS = 2  已支付

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    -- ???：以后尽量用详情表内的，因为有可能存在子状态是退票的
    for rs in (select *
                 from t_ch_hotel_order
                where affiliate_confirmation_id = vAffiliateConfirmationId
                  and local_status = '6'
                  and pur_pay_state = '0') loop
      iNum  := 1;
      nJeBc := rs.sale_total_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' ||
                 vAffiliateConfirmationId || '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    --采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  -------------------------------------------------------------------------------------------------------------------------------------------------
  -- 11.国内改签_验证余额：pay_val_change_balance {"sn":"1234567","fun":"pay_val_change_balance","user":"hqchen125","companyId":320500000001,"orderId":88}
  -------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION pay_val_change_balance(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vChange_id    varchar2(500);
    vPurchaser_id number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vChange_id := queryJsonValueFromName('orderId', viCon);

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    for rs in (select *
                 from t_cc_plane_change
                where change_id = to_number(vChange_id)
                  and state = '5') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vChange_id ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 12.国内改签_支付 {"sn":"1234567","fun":"pay_change_defray","user":"hqchen125",companyId":320500000001,"orderId":88,"operUser":210}
  -----------------------------------------------------------------------------------------
  FUNCTION pay_change_defray(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vChange_id    varchar2(500);
    nPurchaser_id number;
    nDetail_id    number;
    vOperUser     number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);

    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vChange_id := queryJsonValueFromName('orderId', viCon);
    vOperUser  := queryJsonValueFromName('operUser', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填写机票结算
    -- 2.修改机票订单状态
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_cc_plane_change a
                where a.change_id = to_number(vChange_id)
                  and a.company_id = to_number(vCompanyId)
                  and a.state in ('5')
                  and rownum <= 1) loop
      iNum := 1;
      /*select seq_detailpur_detailid.nextval into nDetail_id from dual;
      insert into T_FIN_DETAIL_PUR
        (detail_id,
         Purchaser_Id,
         Company_Id,
         Oper_User,
         oper_time,
         Oper_Money,
         Operation,
         OPER_ID,
         state)
      values
        (nDetail_id,
         nPurchaser_id,
         to_number(vCompanyId),
         '',
         sysdate,
         rs.sale_price,
         '1',
         rs.plane_order_id,
         '0');
      insert into t_Fin_Detail_Pur_Plane_Order
        (detail_id, Biz_Trip_Id, Prepayment, Overdraft, Total_Templimit)
      values
        (nDetail_id, rs.biz_trip_id, 0, 0, 0);*/
      update t_cc_plane_change
         set state           = '6',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             pur_pay_user    = to_number(vOperUser),
             pur_settle_type = '2'
       where change_id = to_number(vChange_id)
         and company_id = to_number(vCompanyId)
         and state in ('5');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -------------------------------------------------------------------------------------------------------------------------------------------------
  -- 13.国际改签_验证余额：inter_pay_val_change_balance {"sn":"1234567","fun":"inter_pay_val_change_balance","user":"hqchen125","companyId":320500000001,"orderId":88}
  -------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION inter_pay_val_change_balance(viCon  IN VARCHAR2,
                                        viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vChange_id    varchar2(500);
    vPurchaser_id number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vChange_id := queryJsonValueFromName('orderId', viCon);

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    for rs in (select *
                 from t_cc_inter_plane_change
                where change_id = to_number(vChange_id)
                  and state = '5') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vChange_id ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 14.国际改签_支付 {"sn":"1234567","fun":"inter_pay_change_defray","user":"hqchen125",companyId":320500000001,"orderId":88}
  -----------------------------------------------------------------------------------------
  FUNCTION inter_pay_change_defray(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vChange_id    varchar2(500);
    nPurchaser_id number;
    nDetail_id    number;
    vOperUser     number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);

    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vChange_id := queryJsonValueFromName('orderId', viCon);
    vOperUser  := queryJsonValueFromName('operUser', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填写机票结算
    -- 2.修改机票订单状态
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_cc_inter_plane_change a
                where a.change_id = to_number(vChange_id)
                  and a.company_id = to_number(vCompanyId)
                  and a.state in ('5')
                  and rownum <= 1) loop
      iNum := 1;
      /*select seq_detailpur_detailid.nextval into nDetail_id from dual;
      insert into T_FIN_DETAIL_PUR
        (detail_id,
         Purchaser_Id,
         Company_Id,
         Oper_User,
         oper_time,
         Oper_Money,
         Operation,
         OPER_ID,
         state)
      values
        (nDetail_id,
         nPurchaser_id,
         to_number(vCompanyId),
         '',
         sysdate,
         rs.sale_price,
         '1',
         rs.plane_order_id,
         '0');
      insert into t_Fin_Detail_Pur_Plane_Order
        (detail_id, Biz_Trip_Id, Prepayment, Overdraft, Total_Templimit)
      values
        (nDetail_id, rs.biz_trip_id, 0, 0, 0);*/
      update t_cc_inter_plane_change
         set state           = '6',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             pur_pay_user    = to_number(vOperUser),
             pur_settle_type = '2'
       where change_id = to_number(vChange_id)
         and company_id = to_number(vCompanyId)
         and state in ('5');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 15.支付 {"sn":"1234567","fun":"hotel_pay_defray_v2","user":"hqchen125",companyId":320500000001,"orderId":"88"}
  -----------------------------------------------------------------------------------------
  FUNCTION hotel_pay_defray_v2(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vHotelOrderId varchar2(500);
    nPurchaser_id number;
    nDetail_id    number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    --{"purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}
    --vResult := '{"code":"1","message":"支付完成","purchaserId":320500001,"prepayment":0,"overdraft":9000,"totalTempLimit":0,"operMoney":1000,"isDefray":1}';
    --raise errorResult;
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser         := queryJsonValueFromName('user', viCon);
    vCompanyId    := queryJsonValueFromName('companyId', viCon);
    vHotelOrderId := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填酒店结算
    -- 2.修改酒店订单状态
    ----------------------------------------------------------------------------
    --  0 HOTEL_ORDER_STATE   确认中
    --  6 HOTEL_ORDER_STATE   待支付

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_ch_hotel_order_v2 a
                where a.hotel_order_id = vHotelOrderId
                  and a.company_id = to_number(vCompanyId)
                  and a.state = '0'
                  and rownum <= 1) loop
      iNum := 1;

      update t_ch_hotel_order_v2
         set PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             state           = '9',
             pur_settle_type = '2',
             local_state     = '0'
       where hotel_order_id = vHotelOrderId
         and company_id = to_number(vCompanyId)
         and state = '0';
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 16.国内酒店验证余额 {"sn":"1234567","fun":"hotel_pay_validate_balance_v2","user":"hqchen125","companyId":320500000001,"orderId":"88"}
  -----------------------------------------------------------------------------------------
  FUNCTION hotel_pay_validate_balance_v2(viCon  IN VARCHAR2,
                                         viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vHotelOrderId varchar2(500);
    vPurchaser_id number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser         := queryJsonValueFromName('user', viCon);
    vCompanyId    := queryJsonValueFromName('companyId', viCon);
    vHotelOrderId := queryJsonValueFromName('orderId', viCon);

    ----------------------------------------------------------------------------
    -- 余额验证规则：
    -- 1.最后每月的结算日到现在这段时间内，来计算余额
    -- 2.计算的金额包括：出票价+已退票价，不包括退票中的
    -- A.判断订单表、保险表、退票表等，计算出本次支付的总费用和本结算周期已经支付的总费用
    -- B.判断采购商总额度表、临时额度表，计算出总额度
    ----------------------------------------------------------------------------
    --  0 HOTEL_ORDER_LOCAL_STATE   确认中
    --  3 HOTEL_ORDER_LOCAL_STATE   已成交
    --  6 HOTEL_ORDER_LOCAL_STATE   待支付

    --  1 HOTEL_PAY_STATUS = 1  未支付
    --  2 HOTEL_PAY_STATUS = 2  已支付

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    -- ???：以后尽量用详情表内的，因为有可能存在子状态是退票的
    for rs in (select *
                 from t_ch_hotel_order_v2
                where hotel_order_id = vHotelOrderId
                  and state = '0') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vHotelOrderId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------------
  -- 17.火车票改签_支付 {"sn":"1234567","fun":"train_pay_change_defray","user":"hqchen125",companyId":320500000001,"orderId":88,"operUser":210}
  -----------------------------------------------------------------------------------------
  FUNCTION train_pay_change_defray(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vChange_id    varchar2(500);
    nPurchaser_id number;
    nDetail_id    number;
    vOperUser     number;
    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);

    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vChange_id := queryJsonValueFromName('orderId', viCon);
    vOperUser  := queryJsonValueFromName('operUser', viCon);

    ----------------------------------------------------------------------------
    -- 支付规则：
    -- 1.先生成结算，并填写机票结算
    -- 2.修改机票订单状态
    ----------------------------------------------------------------------------
    -- -1 PLANE_ORDER_STATE   已失效
    --  1 PLANE_ORDER_STATE   已预订未支付
    --  2 PLANE_ORDER_STATE   已支付
    --  3 PLANE_ORDER_STATE   已出票
    --  4 PLANE_ORDER_STATE   出票失败

    --获得采购商的ID
    select nvl((select purchaser_id
                 from T_BASE_PURCHASER
                where company_id = to_number(vCompanyId)
                  and rownum <= 1),
               0)
      into nPurchaser_id
      from dual;
    iNum := 0;
    for rs in (select *
                 from t_cc_train_change a
                where a.train_change_id = to_number(vChange_id)
                  and a.company_id = to_number(vCompanyId)
                  and a.state in ('1')
                  and rownum <= 1) loop
      iNum := 1;
      /*select seq_detailpur_detailid.nextval into nDetail_id from dual;
      insert into T_FIN_DETAIL_PUR
        (detail_id,
         Purchaser_Id,
         Company_Id,
         Oper_User,
         oper_time,
         Oper_Money,
         Operation,
         OPER_ID,
         state)
      values
        (nDetail_id,
         nPurchaser_id,
         to_number(vCompanyId),
         '',
         sysdate,
         rs.sale_price,
         '1',
         rs.plane_order_id,
         '0');
      insert into t_Fin_Detail_Pur_Plane_Order
        (detail_id, Biz_Trip_Id, Prepayment, Overdraft, Total_Templimit)
      values
        (nDetail_id, rs.biz_trip_id, 0, 0, 0);*/
      update t_cc_train_change
         set state           = '6',
             PUR_PAY_TIME    = sysdate,
             pur_pay_type    = '4',
             pur_pay_user    = to_number(vOperUser),
             pur_settle_type = '2'
       where train_change_id = to_number(vChange_id)
         and company_id = to_number(vCompanyId)
         and state in ('1');
      vResult := '{"code":"1","message":"支付完成","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":' ||
                 rs.sale_price || ',"isDefray":1}';
    end loop;

    if iNum = 0 then
      vResult := '{"code":"0","message":"支付未找到订单","purchaserId":' ||
                 nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","purchaserId":' ||
                   nPurchaser_id ||
                   ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","purchaserId":' || nPurchaser_id ||
                 ',"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":0,"isDefray":0}';
      RETURN vResult;
  END;

  -------------------------------------------------------------------------------------------------------------------------------------------------
  -- 18.火车票改签_验证余额：train_pay_val_change_balance {"sn":"1234567","fun":"train_pay_val_change_balance","user":"hqchen125","companyId":320500000001,"orderId":88}
  -------------------------------------------------------------------------------------------------------------------------------------------------
  FUNCTION train_pay_val_change_balance(viCon  IN VARCHAR2,
                                        viText IN VARCHAR2) RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    dtNow Date;
    iNum  Integer;

    vUser         varchar2(250);
    vCompanyId    varchar2(200);
    vChange_id    varchar2(500);
    vPurchaser_id number(20);

    ------------------------------------
    --本次金额（当前订单）
    --结算周期内已付金额（所有已经支付订单）
    --企业的总透支金额
    ------------------------------------
    nJeBc  number(12, 2);
    nJeYf  number(12, 2);
    nJeZed number(12, 2);
    nJeTz1 number(12, 2);
    nJeTz2 number(12, 2);

    iDay1 Integer;
    iDay2 Integer;
    dtOne date;
    dtTwo date;

    errorResult EXCEPTION;
  BEGIN
    dtNow := trunc(sysdate);
    ------------------------------------
    -- 解析出条件
    ------------------------------------
    vUser      := queryJsonValueFromName('user', viCon);
    vCompanyId := queryJsonValueFromName('companyId', viCon);
    vChange_id := queryJsonValueFromName('orderId', viCon);

    --获得本次支付的总费用
    iNum  := 0;
    nJeBc := 0;
    for rs in (select *
                 from t_cc_train_change
                where train_change_id = to_number(vChange_id)
                  and state = '1') loop
      iNum  := 1;
      nJeBc := rs.sale_price;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此未支付订单：ID=' || vChange_id ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;

    --获得结算周期最后一天
    iNum := 0;
    for rsZq in (select *
                   from T_BASE_PURCHASER t
                  where t.company_id = to_number(vCompanyId)
                    and state = 1) loop
      iNum          := 1;
      vPurchaser_id := rsZq.Purchaser_Id;
      --算出结算周期
      if instr(rsZq.settlement_days, ',') < 1 then
        iDay1 := getSettlementDay(dtNow, to_number(rsZq.settlement_days));
        iDay2 := 0;
        dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                         LPAD(iDay1, 2, '0') || ' 23:59:59',
                         'YYYY-MM-DD HH24:MI:SS');
        if Trunc(dtTwo) > dtNow then
          --上一结算周期
          dtTwo := ADD_MONTHS(dtTwo, -1);
        end if;
      else
        iDay1 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   1,
                                                   instr(rsZq.settlement_days,
                                                         ',') - 1)));
        iDay2 := getSettlementDay(dtNow,
                                  to_number(substr(rsZq.settlement_days,
                                                   instr(rsZq.settlement_days,
                                                         ',') + 1)));
        if iDay2 > iDay1 then
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        else
          dtOne := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay2, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
          dtTwo := To_date(TO_CHAR(dtNow, 'YYYY-MM') || '-' ||
                           LPAD(iDay1, 2, '0') || ' 23:59:59',
                           'YYYY-MM-DD HH24:MI:SS');
        end if;
        if dtNow < trunc(dtOne) then
          dtTwo := ADD_MONTHS(dtTwo, -1);
        else
          if dtNow >= trunc(dtTwo) then
            dtTwo := dtTwo;
          else
            dtTwo := dtOne;
          end if;
        end if;
      end if;
    end loop;
    if iNum = 0 then
      vResult := '{"code":"0","message":"无此采购商：CompanyId=' || vCompanyId ||
                 '","isInBalance":0}';
      raise errorResult;
    end if;
    --获得所有已支付的费用总和 nJeYf
    select sum(sale_price)
      INTO nJeYf
      from (select tt.sale_price
              from t_cc_train_order torder, t_cc_train_ticket tt
             where torder.train_order_id = tt.train_order_id
               and torder.pur_id = vPurchaser_id
               and torder.state in ('2', '3', '4', '7', '8')
               and (tt.pur_settle_state is null or
                   tt.pur_settle_state <> '1')
               and (tt.pur_settle_type is null or tt.pur_settle_type <> '1')
               and tt.prev_train_ticket_id is null
            /*and (torder.create_time is null or
            torder.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select pt.sale_price
              from t_cc_plane_order po, t_cc_ticket_passenger pt
             where po.plane_order_id = pt.plane_order_id
               and po.pur_id = vPurchaser_id
               and po.state in ('2', '3', '4')
               and (pt.pur_settle_state is null or
                   pt.pur_settle_state <> '1')
               and (pt.pur_settle_type is null or pt.pur_settle_type <> '1')
               and pt.prev_plane_ticket_id is null
            /*and (po.create_time is null or
            po.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select ipt.sale_price
              from t_cc_inter_plane_order      ipo,
                   t_cc_inter_ticket_passenger ipt
             where ipo.plane_order_id = ipt.plane_order_id
               and ipo.pur_id = vPurchaser_id
               and ipo.state in ('2', '3', '4')
               and (ipt.pur_settle_state is null or
                   ipt.pur_settle_state <> '1')
               and (ipt.pur_settle_type is null or
                   ipt.pur_settle_type <> '1')
               and ipt.prev_plane_ticket_id is null
            /*and (ipo.create_time is null or
            ipo.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select nr.sale_price
              from t_ch_hotel_order_v2 ho, t_ch_room_nightly_rate_v2 nr
             where ho.hotel_order_id = nr.hotel_order_id
               and ho.pur_id = vPurchaser_id
               and ho.payment_type = 'PrePay'
               and ho.state in ('1', '3', '5')
               and (nr.pur_settle_state is null or
                   nr.pur_settle_state <> '1')
               and (nr.pur_settle_type is null or nr.pur_settle_type <> '1')
            /*and (ho.create_time is null or
            ho.create_time between dtTwo + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            union all
            select sale_price
              from t_cc_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_inter_plane_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select sale_price
              from t_cc_train_change
             where pur_id = vPurchaser_id
               and state in ('3', '6')
               and (pur_check_state is null or pur_check_state <> '1')
               and (pur_settle_type is null or pur_settle_type <> '1')
            /*and (apply_time is null or
            apply_time between dtTwo + 1 / 24 / 60 / 60 and SYSDATE)*/
            union all
            select t1.sale_price
              from t_cc_insurance_order_detail t1, t_cc_insurance_order t2
             where t1.insurance_order_id = t2.insurance_order_id
               and t1.pur_id = vPurchaser_id
               and (t1.pur_settle_state is null or
                   t1.pur_settle_state <> '1')
               and (t1.pur_settle_type is null or t1.pur_settle_type <> '1')
            /*and (t2.create_time is null or
            t2.create_time between dtTwo - 30 + 1 / 24 / 60 / 60 and
            SYSDATE)*/
            );
    --采购商额度
    select nvl((select overdraft
                 from t_base_purchaser
                where company_id = vCompanyId
                  and rownum <= 1),
               0)
      into nJeTz1
      from dual;
    /*--采购商临时额度
    select sum(temp_delay_credit)
      into nJeTz2
      from t_cc_purchaser_temp_limit
     where purchaser_id = vPurchaser_id
       and valid_start_time between dtTwo + 1 / 24 / 60 / 60 and sysdate;*/
    nJeYf  := NVL(nJeYf, 0);
    nJeTz1 := NVL(nJeTz1, 0);
    nJeTz2 := NVL(nJeTz2, 0);
    nJeZed := nJeTz1 + nJeTz2;
    if (nJeBc + nJeYf) > nJeZed then
      vResult := '{"code":"0","message":"余额不足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":0}';
    else
      vResult := '{"code":"1","message":"余额充足：待付=' || nJeBc || '，已付=' ||
                 nJeYf || '，总额度=' || nJeZed || '","isInBalance":1}';
    end if;

    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"code":"0","message":"结果为空","isInBalance":0}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","isInBalance":0}';
      RETURN vResult;
  END;

  FUNCTION readData(viData IN VARCHAR2, viText IN VARCHAR2) RETURN VARCHAR2 AS
    listRes ListString;
    vReturn varchar2(4000);
    vResult varchar2(32767);
    ------------------------------------
    -- 1.用户登录后生成的用户登录授权号
    -- 2.方法名称
    -- 3.用户名称
    ------------------------------------
    vSn   varchar2(32);
    vFun  varchar2(500);
    vUser varchar2(500);

    iNum1 integer;
    iNum2 integer;
    i     integer;

    errorResult EXCEPTION;
  BEGIN
    ---------------------------------------------------
    -- 初始化,解析授权码、函数和用户名称
    -- 获得SN、FUN和USER
    ---------------------------------------------------
    vSn   := queryJsonValueFromName('sn', viData);
    vFun  := queryJsonValueFromName('fun', viData);
    vUser := queryJsonValueFromName('user', viData);

    ----------------------------------
    -- 验证接口参数
    ----------------------------------
    if (vSn is null or vFun is null or vUser is null) then
      --vReturn := 'W:输入参数解析失败';
      vResult := '{"code":"0","message":"接口验证-输入参数解析失败"}';
      raise errorResult;
    end if;

    ----------------------------------
    -- 验证函数名称，只验证大写或小写
    ----------------------------------
    select count(0)
      into iNum1
      from t_base_dbi
     where dbi_name in (upper(vFun), lower(vFun));
    if iNum1 < 1 then
      vResult := '{"code":"0","message":"接口验证-接口函数［' || vFun || '］缺失"}';
      raise errorResult;
    end if;

    ----------------------------------
    -- 授权验证,暂无
    ----------------------------------

    ----------------------------------
    -- 用户验证，暂无
    ----------------------------------

    listRes := ListString();
    listRes.extend(200);

    -------------------------------------------
    -- query_ready_sms:查询出预备发送的短信列表
    -------------------------------------------
    if lower(vFun) in ('query_ready_sms') then
      vResult := query_ready_sms(viData, listRes);
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- pay_validate_accountperiod验证账期：{"sn":"1234567","fun":"pay_validate_accountperiod","user":"hqchen125","companyId":320500000001}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('pay_validate_accountperiod') then
      vResult := pay_validate_accountperiod(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- pay_validate_balance 验证余额：{"sn":"1234567","fun":"pay_validate_balance","user":"hqchen125","companyId":320500000001,"bizTripId":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('pay_validate_balance') then
      vResult := pay_validate_balance(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- pay_defray支付：{"sn":"1234567","fun":"pay_defray","user":"hqchen125",companyId":320500000001,"planeOrderId":88}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('pay_defray') then
      vResult := pay_defray(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- inter_pay_defray支付：{"sn":"1234567","fun":"inter_pay_defray","user":"hqchen125","companyId":320500000001,"planeOrderId":88,"operUser":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('inter_pay_defray') then
      vResult := inter_pay_defray(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- inter_pay_val_accountperiod验证账期：{"sn":"1234567","fun":"inter_pay_validate_accountperiod","user":"hqchen125","companyId":320500000001}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('inter_pay_validate_accountperiod') then
      vResult := inter_pay_val_accountperiod(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- inter_pay_validate_balance 验证余额：{"sn":"1234567","fun":"inter_pay_validate_balance","user":"hqchen125","companyId":320500000001,"bizTripId":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('inter_pay_validate_balance') then
      vResult := inter_pay_validate_balance(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- train_pay_defray支付：{"sn":"1234567","fun":"pay_defray","user":"hqchen125","companyId":320500000001,"trainOrderId":88,"operUser":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('train_pay_defray') then
      vResult := train_pay_defray(viData, viText);
      raise errorResult;
    end if;

    ---------------------------------------------------------------------------------------------------------------------------------
    -- train_pay_validate_balance 验证余额：{"sn":"1234567","fun":"train_pay_validate_balance","user":"hqchen125","companyId":320500000001,"trainOrderId":88}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('train_pay_validate_balance') then
      vResult := train_pay_validate_balance(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- hotel_pay_validate_balance 验证余额：{"sn":"1234567","fun":"hotel_pay_validate_balance","user":"hqchen125","companyId":320500000001,"trainOrderId":88}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('hotel_pay_validate_balance') then
      vResult := hotel_pay_validate_balance(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- hotel_pay_defray支付：{"sn":"1234567","fun":"hotel_pay_defray","user":"hqchen125","companyId":320500000001,"trainOrderId":88,"operUser":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('hotel_pay_defray') then
      vResult := hotel_pay_defray(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- pay_val_change_balance 验证余额：{"sn":"1234567","fun":"pay_val_change_balance","user":"hqchen125","companyId":320500000001,"changeId":88}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('pay_val_change_balance') then
      vResult := pay_val_change_balance(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- pay_change_defray支付：{"sn":"1234567","fun":"pay_change_defray","user":"hqchen125","companyId":320500000001,"changeId":88,"operUser":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('pay_change_defray') then
      vResult := pay_change_defray(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- inter_pay_val_change_balance 验证余额：{"sn":"1234567","fun":"inter_pay_val_change_balance","user":"hqchen125","companyId":320500000001,"changeId":88}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('inter_pay_val_change_balance') then
      vResult := inter_pay_val_change_balance(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- inter_pay_change_defray支付：{"sn":"1234567","fun":"inter_pay_change_defray","user":"hqchen125","companyId":320500000001,"changeId":88,"operUser":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('inter_pay_change_defray') then
      vResult := inter_pay_change_defray(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- 支付 {"sn":"1234567","fun":"hotel_pay_defray_v2","user":"hqchen125",companyId":320500000001,"hotelOrderId":"88"}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('hotel_pay_defray_v2') then
      vResult := hotel_pay_defray_v2(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- {"sn":"1234567","fun":"hotel_pay_validate_balance_v2","user":"hqchen125","companyId":320500000001,"hotelOrderId":"88"}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('hotel_pay_validate_balance_v2') then
      vResult := hotel_pay_validate_balance_v2(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- {"sn":"1234567","fun":"train_pay_change_defray","user":"hqchen125","companyId":320500000001,"orderId":88,"operUser":1}', '{"code":"1","message":"支付完成","purchaserId":320500001,"prepayment":0,"overdraft":0,"totalTempLimit":0,"operMoney":1150,"isDefray    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('train_pay_change_defray') then
      vResult := train_pay_change_defray(viData, viText);
      raise errorResult;
    end if;
    ---------------------------------------------------------------------------------------------------------------------------------
    -- {"sn":"1234567","fun":"train_pay_val_change_balance","user":"hqchen125","companyId":320500000001,"orderId":88}', '{"code":"1","message":"余额充足：待付=1150，已付=0，总额度=10000","isInBalance":1}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('train_pay_val_change_balance') then
      vResult := train_pay_val_change_balance(viData, viText);
      raise errorResult;
    end if;

    ---------------------
    -- 生成返回结果
    ---------------------
    vResult := '';
    IF listRes IS NOT NULL AND listRes.Count = 200 THEN
      For i in 1 .. 200 LOOP
        vResult := vResult || listRes(i);
      END LOOP;
    ELSE
      vResult := '{"code":"0","message":"接口结果-RESULT IS NULL"}';
    END IF;
    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      IF vResult is null OR instr(vResult, '{') = 0 OR
         instr(vResult, '}') = 0 THEN
        vResult := '{"code":"0","message":"结果为空"}';
      END IF;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"code":"0","message":"异常-' || SUBSTR(SQLERRM, 1, 256) || '"}';
      RETURN vResult;
  END;

  -----------------------------------------------------------------------------------
  -- 写接口部分
  -- 1.update_sms_state 更新短信状态
  -----------------------------------------------------------------------------------
  FUNCTION update_sms_state(viCon IN VARCHAR2, viText IN VARCHAR2)
    RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);

    vUser  varchar2(250);
    vID    varchar2(200);
    vState varchar2(50);
    vText  varchar2(5000);

    errorResult EXCEPTION;
  BEGIN
    ------------------------------------
    -- 解析出条件
    -- {"sn":"授权码","fun":"update_sms_state","user":"phoneSms","id":"141208012345678","state":"2","text":"OK"}
    ------------------------------------
    vUser  := queryJsonValueFromName('user', viCon);
    vID    := queryJsonValueFromName('id', viCon);
    vState := queryJsonValueFromName('state', viCon);
    vText  := queryJsonValueFromName('text', viCon);
    --针对已经分配的进行更新
    update T_BASE_MESSAGE_QUEUE
       set MQ_STATE    = SubstrB(Trim(vState), 1, 1),
           mq_sendtime = sysdate,
           mq_remark   = SubstrB(Trim(vText), 1, 200)
     where mq_id = Trim(vID)
       and mq_state = '1';
    COMMIT;
    --错误结果
    --vResult := '{"errorid":"90003","msg":"接口结果-RESULT IS NULL","text":"W"}';
    --成功结果
    vResult := '{"id":"' || vID || '","msg":"update ok","text":"S"}';
    Raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vResult is null then
        vResult := '{"errorid":"90000","msg":"警告-NULL","text":"W"}';
      end if;
      RETURN vResult;
    WHEN OTHERS THEN
      vResult := '{"errorid":"90000","msg":"异常-' || SUBSTR(SQLERRM, 1, 256) ||
                 '","text":"E"}';
      RETURN vResult;
  END;

  FUNCTION writeData(viData IN VARCHAR2, viText IN VARCHAR2) RETURN VARCHAR2 AS
    vReturn varchar2(4000);
    ------------------------------------
    -- 1.用户登录后生成的用户登录授权号
    -- 2.方法名称
    -- 3.用户名称
    ------------------------------------
    vSn   varchar2(32);
    vFun  varchar2(500);
    vUser varchar2(500);

    iNum1 integer;
    iNum2 integer;

    errorResult EXCEPTION;
  BEGIN
    ---------------------------------------------------
    -- 初始化,解析授权码、函数和用户名称
    -- 获得SN、FUN和USER
    ---------------------------------------------------
    vSn   := queryJsonValueFromName('sn', viData);
    vFun  := queryJsonValueFromName('fun', viData);
    vUser := queryJsonValueFromName('user', viData);

    ----------------------------------
    -- 验证接口参数
    ----------------------------------
    if (vSn is null or vFun is null or vUser is null) then
      vReturn := 'W:输入参数解析失败';
      raise errorResult;
    end if;

    ----------------------------------
    -- 验证函数名称，只验证大写或小写
    ----------------------------------
    select count(0)
      into iNum1
      from t_base_dbi
     where dbi_name in (upper(vFun), lower(vFun));
    if iNum1 < 1 then
      vReturn := 'W:接口函数[' || vFun || ']缺失';
      raise errorResult;
    end if;

    ----------------------------------
    -- 授权验证,暂无
    ----------------------------------

    ----------------------------------
    -- 用户验证，暂无
    ----------------------------------

    ---------------------------------------------------------------------------------------------------------------------------------
    -- update_sms_state:更新短信状态
    -- {"sn":"授权码","fun":"update_sms_state","user":"phoneSms","id":"141208012345678","state":"2","text":"OK"}
    ---------------------------------------------------------------------------------------------------------------------------------
    if lower(vFun) in ('update_sms_state') then
      vReturn := update_sms_state(viData, viText);
    end if;
    raise errorResult;
  EXCEPTION
    WHEN errorResult THEN
      if vReturn is null then
        vReturn := '{"errorid":"90000","msg":"警告-写接口无返回","text":"W"}';
      end if;
      RETURN vReturn;
    WHEN OTHERS THEN
      vReturn := '{"errorid":"90000","msg":"异常,写接口-' ||
                 SUBSTR(SQLERRM, 1, 256) || '","text":"E"}';
      RETURN vReturn;
  END;

END;
