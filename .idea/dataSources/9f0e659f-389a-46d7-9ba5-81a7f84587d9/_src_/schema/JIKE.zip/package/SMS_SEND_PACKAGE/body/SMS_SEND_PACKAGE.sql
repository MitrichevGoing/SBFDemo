create PACKAGE BODY      SMS_SEND_PACKAGE AS

 --********************************************************
  --通用函数 BEGIN
  --********************************************************
  --1.MD5加密---
  FUNCTION encodeMD5(encodeText IN VARCHAR2)
  RETURN VARCHAR2 AS
    RAW_INPUT     RAW(10240) := UTL_RAW.CAST_TO_RAW(UPPER(encodeText));
    DECRYPTED_RAW RAW(2048);
    ERROR_IN_INPUT_BUFFER_LENGTH EXCEPTION;
  BEGIN
    IF (Length(encodeText) <= 0) OR (encodeText IS NULL) THEN
      RETURN 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
    ELSE
    SYS.DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT    => RAW_INPUT,
                                     CHECKSUM => DECRYPTED_RAW);
    RETURN LOWER(RAWTOHEX(DECRYPTED_RAW));
    END IF;
  END;

  --2.字符串转换成整型--
  FUNCTION convertStrToInt(viString IN VARCHAR2, iiDefault IN INTEGER)
  RETURN INTEGER AS
    voRes varchar2(250);
    noRes number;
    ioRes integer;
  BEGIN
    ioRes := iiDefault;
    if LengthB(viString) > 18 then
      return ioRes;
    end if;
    voRes := Trim(viString);
    if substr(voRes, 1, 1) in ('-') then
      voRes := substr(voRes, 2);
    end if;

    voRes := Replace(voRes, '0');
    voRes := Replace(voRes, '1');
    voRes := Replace(voRes, '2');
    voRes := Replace(voRes, '3');
    voRes := Replace(voRes, '4');
    voRes := Replace(voRes, '5');
    voRes := Replace(voRes, '6');
    voRes := Replace(voRes, '7');
    voRes := Replace(voRes, '8');
    voRes := Replace(voRes, '9');
    if voRes is null then
      noRes := to_number(Trim(viString));
    if noRes between - 2147483648 and 2147483647 then
      ioRes := noRes;
    else
      ioRes := iiDefault;
    end if;
    else
      ioRes := iiDefault;
    end if;
    return ioRes;
  END;

  --3.解析json,获得值--
  Function queryJsonValueFromName(viName IN VARCHAR2, viData IN VARCHAR2)
  RETURN VARCHAR2 AS
    voRes  varchar2(32000);
    vInput varchar2(32000);
    iPos1  integer;
    iPos2  integer;
    iPos3  integer;
  begin
    vInput := upper(viData);
    iPos1  := instr(vInput, '"' || Trim(Upper(viName)) || '"');
    iPos2  := instr(vInput, ':', iPos1);
    iPos3  := instr(vInput, ',', iPos2);
    if iPos3 = 0 then
      iPos3 := instr(vInput, '}', iPos2);
    end if;
    voRes := trim(substr(viData, iPos2 + 1, iPos3 - iPos2 - 1));
    if (substr(voRes, 1, 1) in ('"')) then
      voRes := substr(voRes, 2, Length(voRes) - 2);
    end if;
    return voRes;
  end;

  -- 3.计算短信发送时间（如果是延时短信及限制短信）
  function workOnMsgSendTime(viCode varchar2,viDelay integer)
  return date as
  dtNow   date;   --系统当前时间
  vSendTime date;  -- 发送时间
  BEGIN
    dtNow := sysdate;
    if length(viCode) = 0 and (viDelay = 0 or viDelay is null) then
      return dtNow;
    else
      for cursor_temp in (select * from T_BASE_MSG_TEMPLATE WHERE MT_CODE = viCode) loop
        if cursor_temp.MT_DELAY = 1 then
          vSendTime := sysdate + (1/(24*60*60))*(cursor_temp.DELAY_TIME) ;
        elsif viDelay > 0 then
          vSendTime := sysdate + (1/(24*60*60))*(viDelay) ;
        else
          return dtNow;
        end if;
      end loop;
    end if;
    return vSendTime;
  END;


  -- 4. 计算短信限制时间（如果短信限制开关开了 LIMIT）
  function workOnMsgLimitTime(viCode varchar2)
  return integer as
  dtNow       date;
  vIsSend     integer;    -- 0-不限制  1-对于当前时间限制
  vLimitBegin date;       -- 限制时间开始
  vLimitEnd   date;       -- 限制时间结束
  vDay        varchar2(500);   -- 星期几
  BEGIN
    dtNow := sysdate; --系统时间
    if length(viCode) = 0 then
      return 0;
    else
      for cursor_temp in (select * from T_BASE_MSG_TEMPLATE WHERE MT_CODE = viCode) loop
          --先判断是否有星期限制 取remark字段，格式：星期一，星期三  则星期一，星期三不发
          if cursor_temp.MT_LIMIT = 1 then
              vLimitBegin := cursor_temp.LIMIT_BEGIN;
              vLimitEnd   := cursor_temp.LIMIT_END;
              --判断是否只传（限制）了日期
              if to_char(vLimitBegin,'hh24:mi:ss') = '00:00:00' then  --只限制日期
                if to_char(dtNow,'yyyy-MM-dd') < to_char(vLimitBegin,'yyyy-MM-dd')
                    or to_char(dtNow,'yyyy-MM-dd') > to_char(vLimitEnd,'yyyy-MM-dd') then
                    return 0;
                elsif length(cursor_temp.REMARK) > 0 then
                    --在限制时间段内，判断星期，如果星期满足，则也发送
                    vDay := to_char(sysdate,'day');
                    if instr(cursor_temp.REMARK,vDay) > 0 then
                      return 0;
                    else
                      return 1;
                    end if;
                else
                    return 1;
                end if;
            else
              --日期和时间都限制，先判断日期，再判断时间
              if to_char(dtNow,'yyyy-MM-dd') < to_char(vLimitBegin,'yyyy-MM-dd')
                  or to_char(dtNow,'yyyy-MM-dd') > to_char(vLimitEnd,'yyyy-MM-dd') then
                  --先判断星期
                  if length(cursor_temp.REMARK) > 0 then
                    --在限制时间段内，判断星期，如果星期满足，则也发送
                    vDay := to_char(sysdate,'day');
                    if instr(cursor_temp.REMARK,vDay) > 0 then
                      return 0;
                    elsif to_char(dtNow,'hh24:mi:ss') >= to_char(vLimitBegin,'hh24:mi:ss')
                      and to_char(dtNow,'hh24:mi:ss') <= to_char(vLimitEnd,'hh24:mi:Ss') then
                      return 1;
                    else
                      return 0;
                    end if;
                  end if;
              else
                  return 1;
              end if;

            end if;
          else
            return 0;
          end if;
      end loop;
    end if;
  END;


  -- 5 分析短信开关
  function workOnMsgSwitch(viCode varchar2,viSwitch integer)
  return integer as
  vIsSend integer;

  BEGIN
    select MT_SWITCH into vIsSend from T_BASE_MSG_TEMPLATE where MT_CODE = viCode ;
    if vIsSend = 0 THEN
      return 1;
    elsif viSwitch = 1 then
      return 1;
    else
      return 0;
    end if;
  END;


  --6短信解析过程、发送过程 通用函数
  function smsGeneralInterface(vCode varchar2,vDelay integer,vSwitch integer,vMaType integer,vPriority integer,vMsgType integer,
        vOrderId integer,vCompanyId varchar2,vTemplet varchar2,vUserPhone varchar2,vRemark varchar2,vId varchar2,
        vCompanyName varchar2,vErrorMsg varchar2,vOrderNo varchar2,vObjectRole integer)
  return varchar2 as
    vUserId varchar2(500);
    vState varchar2(50);
    vResult varchar2(3000);
    vSendTime date;
    vFlag integer;
    vIsSend integer;
    vMaId varchar2(500);
    vMId varchar2(500);
    vMeId varchar2(500);
  BEGIN
      --判断解析是否出错，如果出错，则不发送，直接进入错误消息队列，待处理,如果该短信为取消发送，那么出错也不处理
      vSendTime := workOnMsgSendTime(vCode,vDelay); --发送时间
      vFlag := workOnMsgLimitTime(vCode); --限制发送标识
      vIsSend := workOnMsgSwitch(vCode,vSwitch); -- 是否要取消发送

      --判断userId
      if vOrderId is null then
        vUserId := vId;
      end if;

      if length(vErrorMsg) = 0 or vErrorMsg is null then
        --生成解析信息，返回解析ID
        vMaId := insertToAnalysisQueue(vMaType,vPriority,vMsgType,
            vIsSend,vDelay,vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,1,vUserId,vCode,vId);

        --根据延时时间计算短信发送时间,以客服配置短信模板延时时间为准，即：
        --若接口设置短信为延时短信，同时客服配置模板延时时间，那么以模板延时时间为准，不叠加

        --如果vFlag = 1 或者 vIsSend = 1 则生成短信，但是取消发送
        if vFlag = 1 or vIsSend = 1 then
          vState := '4';
        else
          vState := '1';
        end if;

        --生成短信
        vMID := insertToAwaitQueue(vMaType,vTemplet,vUserPhone,vMaId,vSendTime,vCode,
            vCompanyName,vOrderId,vObjectRole,vState,0,vUserId,'SYSTEM',vRemark,vPriority,vOrderNo,vDelay);

        vResult := '{"code":"0","message":"解析成功，短信待发送","memo":"N",
                    "telephone":"' || vUserPhone ||
                   '","temp":"' || vCode || '"}';
      else
        --生成解析信息，返回解析ID
        vMaId := insertToAnalysisQueue(vMaType,vPriority,vMsgType,
            vIsSend,vDelay,vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,0,vUserId,vCode,vId);

        if vIsSend = 0 then   --如果短信取消发送，那么解析出错不处理
          vMeId := insertToErrorQueue(vMaId,vOrderId,vUserPhone,vMId,0,vErrorMsg,vTemplet);
        end if;

        vResult := '{"code":"0","message":"解析出错，短信待处理","memo":"N",
                    "telephone":"' || vUserPhone ||
                   '","temp":"' || vCode || '"}';
      end if;

      return vResult;

  END;

  ------------------------------------------------------
  --7.判断乘机人、联系人或者预订人的发送状态
  ------------------------------------------------------
  function judgeSendObject(
    vOrderPhone varchar2,  --预订人
    vContactPhone varchar2
  ) return integer as
  iNum1 integer;
  BEGIN
    --先判断预订人，后判断联系人，若联系人==预订人，则只发预订人角色
    if vOrderPhone is null or vOrderPhone = '' then
        iNum1 := 0;
        if vContactPhone is not null or vContactPhone <>'' then
          iNum1 := 2;
        end if;
    elsif vOrderPhone is null or vContactPhone = '' then
        iNum1 := 1;
    elsif vOrderPhone = vContactPhone then
        iNum1 := 1;
    else
        iNum1 := 3;
    end if;
    return iNum1;
  END;

  function judgeSendUser(
    vUserPhone varchar2,   --乘机人
    vOrderPhone varchar2,  --预订人
    vContactPhone varchar2
  ) return integer as
  iNum1 integer;
  BEGIN
    --先拿乘客跟预订人比，若相同，则不发乘客短信；若不相同，再和联系人比，若相同，则不发乘客短信
    /*
    if vUserPhone is null or length(vUserPhone) <> 11 then
      iNum1 := 0;  --不发乘客短信
    else
      if vOrderPhone is not null then
        if vUserPhone = vOrderPhone then
            iNum1 := 0;
        elsif vContactPhone is null then
            iNum1 := 1;
        elsif vContactPhone = vOrderPhone then
            iNum1 := 0;
        else
            iNum1 := 1;
        end if;
      end if;
    end if;
    */
    /*
    if vUserPhone is null then
      return 0;
    else
      if vOrderPhone is null and vContactPhone is null then
        return 1;
      elsif vContactPhone is not null and vUserPhone = vContactPhone then
        return 0;
      elsif vOrderPhone is not null and vOrderPhone = vUserPhone then
        return 0;
      else
        return 1;
      end if;
    end if;*/
    return 1;
  END;


  ------------------------------------------------------------------------------
  ---8.判断火车票座位等级
  ------------------------------------------------------------------------------
  function getTrainSeatLevel(viSeat integer) return varchar2 as
    vSeatLevel varchar2(3000);
  BEGIN
    if viSeat = 0 then
      vSeatLevel := '商务座';
    elsif viSeat = 1 then
      vSeatLevel := '特等座';
    elsif viSeat = 2 then
      vSeatLevel := '一等座';
    elsif viSeat = 3 then
      vSeatLevel := '二等座';
    elsif viSeat = 4 then
      vSeatLevel := '高级软卧';
    elsif viSeat = 5 then
      vSeatLevel := '软卧';
    elsif viSeat = 6 then
      vSeatLevel := '硬卧';
    elsif viSeat = 7 then
      vSeatLevel := '软座';
    elsif viSeat = 8 then
      vSeatLevel := '硬座';
    elsif viSeat = 9 then
      vSeatLevel := '无座';
    else
      vSeatLevel := '其他';
    end if;
    return vSeatLevel;
  END;


  --********************************************************
  --通用函数 end
  --********************************************************



  --********************************************************
  --插入短信待发送列表 BEGIN--
  --********************************************************
  --4.插入解析器列表--
  function insertToAnalysisQueue(
    viMaType    varchar2,  --短信业务类型 1-用户基础业务 2-订单业务  3-拓展业务
    viPriority   number,       --短信优先级
    viMsgType    varchar2,  --短信类型
    viMaSwitch   number,       --短信开关
    viMaDelay    number,       --短信延迟时间
    viOrderId    varchar2,   --订单ID
    viCompanyId  number,      --公司ID
    viText       varchar2,    --短信文本
    viPhone      varchar2,    --短信接收人电话
    viREMARK       varchar2,   --备用字段
    viFLAG         number,    --解析标识 0-失败 1-成功
    viUserId      varchar2,    --用户id
    viCode        varchar2,    --对应短信模板
    vId           varchar2    --id 基础业务为用户id,订单业务订单id,拓展业务为业务编码
    ) return varchar2 as

    dtNow      date;              --系统现在时间
    vResult    varchar2(14000);   --返回的结果信息
    vQuId      varchar2(500);          --短信解析唯一标识
    vText      varchar2(14000);          --短信解析的文本
    vPhone     varchar2(500);          --接收短信的号码
    vCount     number(2,0);               --解析短信的次数，用于判断是否重复解析
    vMaId      varchar2(500);         --解析流水号
  BEGIN
    dtNow := sysdate;
    vText := viText;
    vPhone := viPhone;

    if length(nvl(vText, 'N')) > 5 then
      --短信解析唯一标识，防止重复  手机号+短信内容+生成日期
      vQuId := upper(encodeMD5(vPhone || vText || TO_CHAR(dtNow, 'YYYYMMDD')));
      --以QuId查询该解析短信是否已经存在
      select count(*) into vCount from T_BASE_MSG_ANALYSIS_QUEUE where UQ_ID = vQuId;
      --如果该短信已经解析过，则不重复解析
      if vCount < 1 then
        --解析流水号
        vMaId := to_char(dtNow,'YYYYMMDD') || SEQ_MSG_ANALYSIS_ID.nextval;
        insert into T_BASE_MSG_ANALYSIS_QUEUE
          (
            MA_ID,
            ORDER_ID,
            MA_TYPE,
            PRIORITY,
            FLAG,
            GRADE,
            APP_TIME,
            MSG_TYPE,
            MA_SWITCH,
            MA_DELAY,
            HANDED,
            COMPANY_ID,
            REMARK,
            UQ_ID,
            HAND_TIME,
            USER_ID,
            CODE
          )
          values
          (
            vMaId,
            viOrderId,
            viMaType,
            viPriority,
            viFLAG,
            'A',
            sysdate,
            viMsgType,
            viMaSwitch,
            viMaDelay,
            0,
            viCompanyId,
            viREMARK,
            vQuId,
            null,
            viUserId,
            viCode
          );
          --返回解析结果
          if viFLAG = 1 then
            vResult := '{message":"OK",code":"' ||
                     viCode || '","id":"' || vId || '"}';
          else
            vResult := '{message":"解析失败",code":"' ||
                   viCode || '","id":"' || vId || '"}';
          end if;
        else
          vResult := '{message":"重复解析",code":"' ||
               viCode || '","id":"' || vId || '"}';
        end if;
    else
      vResult := '{message":"短信内容过短",code":"' ||
         viCode || '","id":"' || vId || '"}';
    end if;
    return vMaId;
  END;


    --5.插入业务短信待发送列表--
    function insertToAwaitQueue
    (
      viMType varchar2,           -- 短信类型
      viText    varchar2,         -- 短信文本
      viObject  varchar2,         -- 短信接收者
      viMaId    NUMBER,           -- 对应短信解析流水号
      viSendTime Date,            -- 发送时间
      viCode  varchar2,             -- 短信模板
      viCompanyName varchar2,     -- 企业名称
      viOrderId varchar2,         -- 订单流水id
      viObjectRole integer,           -- 短信接收者角色   0-联系人 1-预订人  2-乘客  3-申请人
      viState   varchar2,          -- 短信状态
      viHanded  integer,             --是否手动编辑
      viUserId  varchar2,          -- 用户id
      viCreater varchar2,           -- 短信创建者 自动发送为SYSTEM/ 手动为客服id
      viRemark varchar2,            -- 备用字段
      viPriority  number,            -- 发送优先级
      viOrderNo varchar2,            --订单号
      viDelay  number                --延时数
    ) return varchar2 as
      dtNow      date;
      vResult    varchar2(14000);
      vQuId      varchar2(500);
      vText      varchar2(14000);
      vPhone     varchar2(500);
      vCount     integer;
      vMId       varchar2(500);
    BEGIN
      dtNow := sysdate;
      vText := viText;
      vPhone := viObject;

      if length(nvl(vText, 'N')) > 5 then
        --短信解析唯一标识，防止重复  手机号+短信内容+生成日期
        vQuId := upper(encodeMD5(vPhone || vText || TO_CHAR(dtNow, 'YYYYMMDD')));
        --以QuId查询该解析短信是否已经存在
        select count(0) into vCount from T_BASE_MSG_AWAIT_QUEUE where QU_ID = vQuId;
        --如果该短信已经编辑完成，则不重复编辑
        if vCount < 1 then
          --短信待发送队列流水号
          vMId := to_char(dtNow,'YYYYMMDD') || SEQ_MSG_AWAIT_ID.nextval;
          insert into T_BASE_MSG_AWAIT_QUEUE
            (
              MID,
              ORDER_ID,
              COMPANY_NAME,
              TEXT1,
              TEXT2,
              SENDER,
              OBJECT_RECEIVE,
              OBJECT_ROLE,
              M_STATE,
              RE_SEND_TIMES,
              MA_ID,
              CREATE_TIME,
              SEND_TIME,
              RE_SEND_TIME,
              M_TYPE,
              HANDED,
              USER_ID,
              QU_ID,
              CREATER,
              TEMP_CODE,
              REMARK,
              PRIORITY,
              ORDER_NO,
              DELAY_TIME
            )
          values
            (
              vMId,
              viOrderId,
              viCompanyName,
              vText,
              null,
              'SYSTEM',
              vPhone,
              viObjectRole,
              viState,
              0,
              viMaId,
              dtNow,
              viSendTime,
              null,
              viMType,
              viHanded,
              viUserId,
              vQuId,
              viCreater,
              viCode,
              viRemark,
              viPriority,
              viOrderNo,
              viDelay
            );
      end if;
    end if;
    return vMId;
    END;

    -- 6.插入错误消息队列表--
    function insertToErrorQueue
      (
        viMaId    NUMBER,
        viOrderId  varchar2,
        viObject  varchar2,
        viMId    NUMBER,
        viErrType varchar2,
        viErrMsg varchar2,
        viErrText varchar2
      ) return varchar2 as
      dtNow      date;
      vResult    varchar2(14000);
      vCount     int;
      vMeId      varchar2(500);
    BEGIN
      dtNow := sysdate;
      vMeId := to_char(dtNow,'YYYYMMDD') || SEQ_MSG_ERROR_ID.nextval;
      select count(*) into vCount from T_BASE_MSG_ERROR_QUEUE where MA_ID = viMaId ;
      if vCount < 1 then
        insert into T_BASE_MSG_ERROR_QUEUE
          (
            ME_ID,
            ORDER_ID,
            MA_ID,
            MID,
            ERR_TYPE,
            ERR_MSG,
            ERR_TEXT,
            RIGT_TEXT,
            ME_STATE,
            REMARK,
            ERR_TIME,
            SLOVE_TIME
          )
        values
          (
            vMeId,
            viOrderId,
            viMaId,
            viMId,
            viErrType,
            viErrMsg,
            viErrText,
            null,
            '0',
            null,
            dtNow,
            null
          );

        vResult := '{message":"OK","id":"' || viMaId || '"}';
      else
        vResult := '{message":"该错误短信已经存在","id":"' || viMaId || '"}';
      end if;
    return vMeId;
    END;

  --********************************************************
  --插入短信待发送列表 END--
  --********************************************************

  --********************************************************
  --生成短信业务逻辑 BEGIN--
  --********************************************************

  --短信解析器
  function toCreateMessage(vCode IN VARCHAR2, vId IN VARCHAR2,vRemark IN VARCHAR2,vPhone IN VARCHAR2,
            vMaType IN VARCHAR2,vPriority IN INT,vDelay in INT,vSwitch in INT,vMsgType in VARCHAR2)
  RETURN VARCHAR2 AS
    vResult VARCHAR2(32000);
    dtNow Date;                     --系统当前时间
    vDayOfWeek varchar2(20);        --一周内星期几
    iNum1 Integer;                  -- 计数变量
    iNum2 Integer;                  -- 计数变量
    iNum3 Integer;                  -- 计数变量
    iNum4 Integer;                  -- 计数变量
    iNum5 Integer;                  -- 计数变量
    iNum6 Integer;                  -- 计数变量
    iNum7 Integer;                  -- 计数变量
    iNum9 Integer;                  -- 计数变量
    iNum11 number(8,2);             --金额
    iNum12 number(8,2);             --金额
    iNum13 number(8,2);             --金额

    --vJsonToParm varchar2(32000);    -- java接口传过来的短信参数
    --vCode varchar2(500);            -- 短信模板code
    --vId        varchar2(20000);     -- 用户基础业务为userId 订单业务为订单id  拓展业务为业务编码
    vIdConvert number(20,0);        -- long 型的id
    --vRemark    varchar2(20000);     -- 备注信息
    --vPhone  varchar2(50);           -- 指定短信接收者
    vPhone1  varchar2(50);          -- 指定短信接受者

    vTemplet  varchar2(32000);      -- 短信模板
    vTemplet1 varchar2(32000);      --短信模板
    vTemplet2 varchar2(32000);      --短信模板
    vTemplet3 varchar2(32000);      --短信模板

    type str_arraylist is table of varchar2(1000);
    str_list str_arraylist;
                                    -- 字符数组
    type str_arraylist2 is table of varchar2(1000);
    str_list2 str_arraylist2;
                                    -- 字符数组
    vTempId   number(16,0);         --短信模板id

    vTemp varchar2(30000);          -- 短信文本
    vTemp1 varchar2(30000);         -- 短信文本
    vTemp2 varchar2(30000);         -- 短信文本
    vTemp3 varchar2(30000);         -- 短信文本
    vTemp4 varchar2(30000);         -- 短信文本
    vTemp5 varchar2(30000);         -- 短信文本
    vTemp6 varchar2(500);
    vTemp7 varchar2(3000);          --短信文本
    vTemp8 varchar2(3000);          --短信文本
    vTemp9 varchar2(3000);          --短信文本
    vTemp10 varchar2(3000);         --短信文本

    --vMaType varchar2(100);          -- 短信业务类型 1-用户基础业务  2-订单业务  3-拓展业务
    --vPriority integer;                  -- 短信优先级 0-做高级 依次递减
    --vDelay  integer;                    -- 延迟发送时间  /s
    --vSwitch integer;                    -- 短信开关
    --vMsgType varchar2(100);         -- 短信类型 1-及时短信 2-群发短信  3-延时短信  4-延时群发短信
    vState  varchar2(100);          --短信发送状态
    vIsSend integer;                -- 是否取消发送
    vMaId   varchar2(500);          -- 解析id
    vMID    varchar2(500);          -- 短信ID
    vMeId   varchar2(500);          -- 错误消息id

    --客户手机号，联系手机号，预订手机号
    vUserPhone  varchar2(500);      -- 客户电话（乘客）
    vContactPhone  varchar2(500);   -- 联系人电话
    vOrderPhone  varchar2(500);     -- 预订人电话
    vKeFuPhone   varchar2(500);     -- 客服电话
    vAdviserId  number(16,0);       -- 顾问经理
    vUserPhoneId number(16,0);      -- 客户id
    vContactPhoneId number(16,0);   -- 联系人Id
    vOrderPhoneId number(16,0);       -- 预订人id
    vObjectRole  number(1,0);       --短信接收者角色  0-联系人 1-预订人 2-乘客  3-申请人

    --id号
    vUserId varchar2(500);          -- 用户id
    vOrderId varchar2(500);         -- 订单id
    --发送时间
    vSendTime date;
    vSendTime2 date;
    vSendTime3 date;

    vQuId varchar2(500);            -- 短信唯一标识

    vModule  varchar2(500);         -- 短信模板
    vOrderNo  varchar2(500);        -- 订单编号
    vCompanyName  varchar2(500);    -- 公司名称
    vCompanyId number(20);          -- 公司id
    --审批提示码
    vPassCode varchar2(6000);       -- 审批通过提示编码
    vDeclineCode varchar2(6000);    -- 审批拒绝提示编码
    vEndTime varchar2(500);         -- 审批截止时间
    --客户顾问、手机
    vCsrMan varchar2(500);          -- 客户顾问
    vCsrManCell varchar2(500);      -- 顾问手机
    --判断标识
    vFlag  integer;                 -- 短信控制标识
    vFlag1 integer;                 -- 短信控制标识
    vFlag2 integer;                 -- 短信控制标识
    vFlag3 integer;                 -- 短信控制标识
    --解析短信出错消息
    vErrorMsg varchar2(5000);       -- 出错信息文本
    vErrorMsg1 varchar2(5000);      -- 出错信息文本2
    vErrorMsg2  varchar2(5000);     -- 出错信息文本3
    --乘客姓名、乘客票号
    vUserName varchar2(500);        -- 乘客姓名
    vPassNo varchar2(500);          -- 乘客票号
    --异常
    errorResult EXCEPTION;
  BEGIN
    dtNow := sysdate;

    dbms_output.put_line(vCode || vId || vRemark || vPhone ||
            vMaType || vPriority || vDelay || vSwitch || vMsgType);

    --vJsonToParm := viData;
    --vId  := 'ERROR';

    ----------------------------------------
    -- 解析出条件
    ----------------------------------------
    --vCode := upper(trim(queryJsonValueFromName('code', vJsonToParm)));
    --vId   := trim(queryJsonValueFromName('id', vJsonToParm));
    --vRemark := trim(queryJsonValueFromName('remark', vJsonToParm));
    --vPhone  := trim(queryJsonValueFromName('mobilephone', vJsonToParm));
    --vMaType := trim(queryJsonValueFromName('maType',vJsonToParm));
    --vPriority := convertStrToInt(trim(queryJsonValueFromName('priority',vJsonToParm)),-1);
    --vDelay := convertStrToInt(trim(queryJsonValueFromName('maDelay',vJsonToParm)),-1);
    --vSwitch := convertStrToInt(trim(queryJsonValueFromName('maSwitch',vJsonToParm)),-1);
    --vMsgType := trim(queryJsonValueFromName('msgType',vJsonToParm));

    ---------------------------------------
    -- 获得模板,如果为空或长度不符合则退出
    ---------------------------------------
    select nvl((select nvl(Text1, 'N') from T_BASE_MSG_TEMPLATE where MT_CODE like '%' || vCode ||'%' and rownum <= 1),'N') into vTemplet from dual;
    if Length(vTemplet) < 5 then
      raise errorResult;
    end if;


    ----------------------------------------
    --短信文本编辑
    ----------------------------------------
    --******************************
    --1.基础业务类
    --******************************

    --****************************************************
    --1.MSG_BASE_PASSWORD_INIT：新建用户初始化账户密码
    --2.尊敬的客户，欢迎注册罗盘智慧差旅！您的登录账号为您的手机号码，登录密码为#PASSWORD#，
    --请尽快访问www.luopan88.com修改密码并开启您的智慧差旅。
    --如有疑问请联系您的专属客户经理：#CUSTOMERMANAGER#(联系电话：#CSRMANPHONE#)，谢谢！
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_PASSWORD_INIT') then
      --一旦短信模板OK,则开始解析短信

      --如果缺失密码，则直接进入错误短信列表
      if vRemark is null or vRemark = '' then
        vErrorMsg := vErrorMsg || '(缺失密码)';
      else
        vTemp  := UPPER(TRIM(vRemark));
        vTemplet := replace(vTemplet, '#PASSWORD#', vTemp);
      end if;

      --解析用户信息
      --先判断该用户是否存在
      --vIdConvert := convertStrToInt(vId,-1);
      --如果缺失用户ID，则直接进入错误短信列表
      if vId is null or vId = '' then
        vErrorMsg := '(缺少USER_ID)';
      else
        vIdConvert := to_number(vId);

        select count(*) into iNum1 from T_BASE_USER WHERE USER_ID = vIdConvert and state = '1';
        if iNum1 = 0 then
          vErrorMsg := vErrorMsg || '(用户不存在)';
        else
          for cursor_user in (select * from T_BASE_USER
                                where USER_ID = vIdConvert
                                and rownum <= 1) loop
          --企业信息
          vCompanyId := cursor_user.company_id;
          select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = vCompanyId;
          -- 解析用户手机号
          if cursor_user.mobilephone is null then
            vErrorMsg := vErrorMsg || '(用户手机号为空，USER_ID=' || vId ||')';
         else
            vUserPhone := cursor_user.mobilephone;
          end if;

          --解析客户专属经理信息
          if cursor_user.company_id is not null then
            --查询该企业顾问（客户经理）
            select CUSTOMER_MANAGER into vAdviserId from T_BASE_COMPANY where company_id = cursor_user.company_id;
            --如果该企业的客户经理为空，则不更新信息
            if vAdviserId is not null then
             select NAME_CN,MOBILEPHONE into vCsrMan,vCsrManCell
              from T_CS_EMPLOYEE
                where EMPLOYEE_ID = vAdviserId;

                if length(vCsrMan) <> 0 or vCsrMan is not null then
                  vTemplet := replace(vTemplet, '#CUSTOMERMANAGER#',vCsrMan);
                  if length(vCsrManCell) <> 0 or vCsrManCell is not null then
                    vTemplet := replace(vTemplet, '#CSRMANPHONE#',vCsrManCell);
                  else
                    vTemplet := replace(vTemplet, '(联系电话：#CSRMANPHONE#)','');
                  end if;
                ELSE
                  vTemplet := replace(vTemplet, '您的专属客户经理：#CUSTOMERMANAGER#(联系电话：#CSRMANPHONE#)。','');
                end if;
            else
                vTemplet := replace(vTemplet, '您的专属客户经理：#CUSTOMERMANAGER#(联系电话：#CSRMANPHONE#)。','');
            end if;
         else
            --vErrorMsg := vErrorMsg || '(用户companyId 缺少)';
            vTemplet := replace(vTemplet, '您的专属客户经理：#CUSTOMERMANAGER#(联系电话：#CSRMANPHONE#)。','');
         end if;

         end loop;
        end if;
      end if;

      --短信逻辑处理
      vObjectRole := 3;
      vOrderNo :='';

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;



    --********************临时交易密码********************************
    --1.MSG_BASE_TEMP_PAYPASSWORD：忘记交易密码，发送临时交易密码
    --2.尊敬的客户：您的临时交易密码为#PAYPASSWORD#，#MINUTE#分钟内使用即有效。
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_TEMP_PAYPASSWORD') then
      --用户id
      vIdConvert := convertStrToInt(vId,-1);
      --短信接收对象
      vUserPhone := vPhone;

      select count(0) into iNum1 from T_BASE_USER WHERE USER_ID = vIdConvert;
      --用户不存在，直接进入错误短信
      if iNum1 = 0 then
        vErrorMsg := vErrorMsg || '(用户不存在)';
      end if;
      --临时交易密码未传，则直接进入错误短信
      if vRemark is null then
        vErrorMsg := vErrorMsg || '(未获取到临时交易密码)';
      else
        vTemplet := replace(vTemplet,'#PAYPASSWORD#',vRemark);
      end if;
      --获取短信接收对象
      if vUserPhone is null then
        vErrorMsg := vErrorMsg || '(未获取到短信接收对象)';
      else
        for cursor_user in (select * from T_BASE_USER
                              WHERE mobilephone = vUserPhone and state = '1'
                                  and rownum <= 1) loop

            --企业名称
            select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE company_id = cursor_user.company_id;
            --获取临时交易密码过期时间
            select nvl((select value
                          from t_base_config_const
                          where name = 'LOGIN_FALSE_LATER_TIME'
                          and rownum <= 1),
                          '30') into vTemp from dual;
            if vTemp is null then
              vErrorMsg := vErrorMsg || '(未获取到临时交易密码过期时间)';
            else
              vTemplet := replace(vTemplet,'#MINUTE#',vTemp);
            end if;
        end loop;
      end if;


      --短信逻辑处理
      vOrderNo :='';
      vObjectRole :=3;

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;



    --********************忘记登录密码，发送临时登录密码********************************
    --1.MSG_BASE_TEMP_PASSWORD：忘记登录密码，发送临时登录密码
    --2.尊敬的客户：您的登录密码为#PASSWORD#，请在#MINUTE#分钟内登录，过期无效
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_TEMP_PASSWORD') then
      --用户id
      vIdConvert := convertStrToInt(vId,-1);
      --短信接收对象
      vUserPhone := vPhone;

      select count(0) into iNum1 from T_BASE_USER WHERE USER_ID = vIdConvert;
      --用户不存在，直接进入错误短信
      if iNum1 = 0 then
        vErrorMsg := vErrorMsg || '(用户不存在)';
      end if;
      --临时交易密码未传，则直接进入错误短信
      if vRemark is null then
        vErrorMsg := vErrorMsg || '(未获取到临时登录密码)';
      else
        vTemplet := replace(vTemplet,'#PASSWORD#',vRemark);
      end if;
      --获取短信接收对象
      if vUserPhone is null then
        vErrorMsg := vErrorMsg || '(未获取到短信接收对象)';
      else
        for cursor_user in (select * from T_BASE_USER
                              WHERE mobilephone = vUserPhone and state = '1'
                                  and rownum <= 1) loop

            --企业名称
            select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE company_id = cursor_user.company_id;
            --获取临时交易密码过期时间
            select nvl((select value
                          from t_base_config_const
                          where name = 'LOGIN_FALSE_LATER_TIME'
                          and rownum <= 1),
                          '30') into vTemp from dual;
            if vTemp is null then
              vErrorMsg := vErrorMsg || '(未获取到临时登录密码过期时间)';
            else
              vTemplet := replace(vTemplet,'#MINUTE#',vTemp);
            end if;
        end loop;
      end if;


      --短信逻辑处理
      vOrderNo :='';
      vObjectRole := 3;

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;


    --********************管理员重置用户登录密码********************************
    --1.MSG_BASE_RESET_PASSWORD：管理员重置用户登录密码
    --2.尊敬的客户：您所在企业(#COMPANYNAME#)的管理员重置了您的登录密码为#PASSWORD#，请尽快登录罗盘智慧差旅系统进行修改
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_RESET_PASSWORD') then
      --用户id
      vIdConvert := convertStrToInt(vId,-1);
      select count(0) into iNum1 from T_BASE_USER WHERE USER_ID = vIdConvert and state = '1';
      --用户不存在，直接进入错误短信
      if iNum1 = 0 then
        vErrorMsg := vErrorMsg || '(用户不存在)';
      end if;
      --临时交易密码未传，则直接进入错误短信
      if vRemark is null then
        vErrorMsg := vErrorMsg || '(未获取到登录密码)';
      else
        vTemplet := replace(vTemplet,'#PASSWORD#',vRemark);
      end if;

      for cursor_user in (select * from T_BASE_USER
                            WHERE USER_ID = vIdConvert and state = '1'
                                and rownum <= 1) loop
          --用户手机号（短信接收号码）
          vUserPhone := cursor_user.mobilephone;
          if vUserPhone is null then
            vErrorMsg := vErrorMsg || '(未获取到用户手机号)';
          end if;

          --企业名称
          select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE company_id = cursor_user.company_id;

          if vCompanyName is null then
            vErrorMsg := vErrorMsg || '(用户所在企业名未获取)';
          else
            vTemplet := replace(vTemplet,'#COMPANYNAME#',vCompanyName);
          end if;

      end loop;
      --短信逻辑处理
      vOrderNo :='';
      vObjectRole := 3;

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;


    --********************管理员重置用户交易密码********************************
    --1.MSG_BASE_RESET_PAYPASSWORD：管理员重置用户交易密码
    --2.尊敬的客户：您所在企业#COMPANYNAME#的管理员重置了您的交易密码为#PAYPASSWORD#，请尽快登录罗盘智慧差旅系统进行修改
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_RESET_PAYPASSWORD') then
      --用户id
      vIdConvert := convertStrToInt(vId,-1);
      select count(0) into iNum1 from T_BASE_USER WHERE USER_ID = vIdConvert and state = '1';
      --用户不存在，直接进入错误短信
      if iNum1 = 0 then
        vErrorMsg := vErrorMsg || '(用户不存在)';
      end if;
      --临时交易密码未传，则直接进入错误短信
      if vRemark is null then
        vErrorMsg := vErrorMsg || '(未获取到交易密码)';
      else
        vTemplet := replace(vTemplet,'#PAYPASSWORD#',vRemark);
      end if;

      for cursor_user in (select * from T_BASE_USER
                            WHERE user_id = vIdConvert and state = '1'
                                and rownum <= 1) loop
          --用户手机号（短信接收号码）
          vUserPhone := cursor_user.mobilephone;
          if vUserPhone is null then
            vErrorMsg := vErrorMsg || '(未获取到用户手机号)';
          end if;

          --企业名称
          select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE company_id = cursor_user.company_id;

          if vCompanyName is null then
            vErrorMsg := vErrorMsg || '(用户所在企业名未获取)';
          else
            vTemplet := replace(vTemplet,'#COMPANYNAME#',vCompanyName);
          end if;

      end loop;
      --短信逻辑处理
      vOrderNo := '';
      vObjectRole := 3;

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;


    --********************发送动态验证码********************************
    --1.MSG_BASE_IDENTIFY_CODE：发送动态验证码
    --2.您好，手机动态验证码为(#IDENTIFY_CODE#)，您可以使用其登录，欢迎体验罗盘智慧差旅
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_IDENTIFY_CODE') then
      --短信接收对象
      vUserPhone := vPhone;
      --根据短信接收对象，获取企业名称
      for cursor_user in (select * from T_BASE_USER
                            WHERE mobilephone = vUserPhone
                              and state = '1' and rownum <=1) loop
          --企业名称
          select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE company_id = cursor_user.company_id;
      end loop;

      if vUserPhone is null then
        vErrorMsg := vErrorMsg || '(无法获取短信接收对象)';
      elsif vRemark is null then
        vErrorMsg := vErrorMsg || '(无法获取验证码)';
      else
        vTemplet := replace(vTemplet,'#IDENTIFY_CODE#',vRemark);
      end if;

      --短信逻辑处理
      vOrderNo :='';
      vObjectRole := 3;

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;


    --********************发送邀请码********************************
    --1.MSG_BASE_INV_CODE：发送邀请码
    --2.您好，我公司向您发来邀请码(#VIN_CODE#)，您可以使用邀请码进行登录，欢迎体验罗盘智慧差旅
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_BASE_INV_CODE') then
      --短信接收对象
      vUserPhone := vPhone;
      --根据短信接收对象，获取企业名称
      for cursor_user in (select * from T_BASE_USER
                            WHERE mobilephone = vUserPhone
                              and state = '1' and rownum <=1) loop
          --企业名称
          select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE company_id = cursor_user.company_id;
      end loop;

      if vUserPhone is null then
        vErrorMsg := vErrorMsg || '(无法获取短信接收对象)';
      elsif vRemark is null then
        vErrorMsg := vErrorMsg || '(无法获取邀请码)';
      else
        vTemplet := replace(vTemplet,'#VIN_CODE#',vRemark);
      end if;

      --短信逻辑处理
      vOrderNo :='';
      vObjectRole := 3;

      if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
      end if;

    end if;


    --********************国内机票出票成功 发送给乘客、联系人或预订人********************************
    --1.CODE:MSG_PLANE_CIVIL_OUT_TO_PASS
    --2.模板：#TIME##FLIGHTNO##AIRPORT#，已经出票成功，#NAME#票号#ORDERNO#，请至实际承运航司#AIRINFO#办理值机，感谢您的预订！祝您旅途愉快！网上退改更方便，服务电话：4007239888
    --3.传递参数：
    --  CODE:MSG_PLANE_CIVIL_OUT_TO_LINK
    --4.模板：您预订的#TIME##FLIGHTNO##AIRPORT#，出票成功并已短信通知乘客(若乘客已预留手机号)，#NAME##ORDERNO#，订单金额#PRICE#，
    --感谢您的预订！网上退改更方便，服务电话：4007239888"
    --  CODE:MSG_PLANE_CIVIL_OUT_TO_ALL
    --5 模板：您预订的#TIME##FLIGHTNO##AIRPORT#，已经出票成功，#NAME#票号#ORDERNO#，请至实际承运航司#AIRINFO#办理值机，订单金额#PRICE#，
    --感谢您的预订！网上退改更方便，服务电话：4007239888"

    --********************国内机票 提前三小时起飞短信*******************************
    --1.MSG_REMIND_PLANE_CIVIL_OFF
    -- 您预订的#TIME##TRIP#的行程 #HOUR#从#AIRPORT#航站楼出发，航班号#FLIGHTNO#，建议您带好证件及时办理登机手续，祝您旅途愉快，服务电话：4007239888
    --3.传递参数：
    --*****************************************************
    --****************************************************************************************
    if vCode in ('MSG_PLANE_CIVIL_OUT_TO') then
      --order_id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;

      ---获取预订人、联系人、乘客短信模板----------------------------------------------------------------------
        select TEXT1 INTO vTemplet1 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_CIVIL_OUT_TO_LINK';

      --********开始解析短信参数***************
      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
        --订单编号
        if rsPlaneOrder.PLANE_ORDER_NO is not null then
            vOrderNo := rsPlaneOrder.PLANE_ORDER_NO;
        end if;

        --企业名称
        for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                              WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
            vCompanyName := rsCompany.COMPANY_NAME;
            --判断是否要给预订人发短信
            if rsCompany.IS_NOTICE_TO_BOOKER  is not null and rsCompany.IS_NOTICE_TO_BOOKER = '1' then
              vFlag1 := 1;
            else
              vFlag1 := 0;
            end if;
        end loop;

        select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1;
        -----------------------
        --解析短信发送对象
        -----------------------
        --联系人电话
        vContactPhone := rsPlaneOrder.Contact_Phone;
        --预订人电话
        vOrderPhone := '';
        if vFlag1 = 1 then
          select nvl((select mobilephone from t_base_user where user_id = rsPlaneOrder.Create_User and rownum<=1),'') into vOrderPhone from dual;
        end if;


      --国内机票行程按起飞时间排序
      vTemp3 :='';
      for cursor_trip in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
        --提前三小时起飞提醒
        select TEXT1 INTO vTemplet3 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_REMIND_PLANE_CIVIL_OFF';
          -- 起飞提醒短信时间
          vTemplet3 := Replace(vTemplet3,'#TIME#',to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"'));
          --先解析航程信息，存入vTemp3
          if NVL(vTemp3, 'N') != 'N' then
            vTemp3 := vTemp3 || '；';
          end if;
          if cursor_trip.take_off_time is not null then
            vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"');
          end if;
          /**
          if cursor_trip.arrive_time is not null then
             vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
          end if;
          */
          --如果起飞时间为空，则直接错误短信
          if vTemp3 = '' or vTemp3 = 'N' then
            vErrorMsg := vErrorMsg || '(起飞时间未获取)';
          end if;
          --航司编码为空，直接进入错误信息列表
          if cursor_trip.airline_code is null then
            vErrorMsg := vErrorMsg || '(航司编码未获取)';
          else
          if  cursor_trip.airline_code is not null then
            select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';
            vTemp4 := vTemp || '(' || cursor_trip.airline_code || ')';
          end if;
            vTemp3 := vTemp3 || cursor_trip.depart_airport_name || replace(cursor_trip.depart_airport_tower, '-', '') ||'(' ||to_char(cursor_trip.take_off_time, 'HH24:FMMI') || ')' ||' - ';
            vTemp3 := vTemp3 || cursor_trip.arrive_airport_name || replace(cursor_trip.arrive_airport_tower, '-', '') || '(' || to_char(cursor_trip.arrive_time, 'HH24:FMMI') || ')';
            --出发航站楼
            if cursor_trip.DEPART_AIRPORT_TOWER is not null then
              vTemplet3 := Replace(vTemplet3,'#DEPTERMIAL#',cursor_trip.DEPART_AIRPORT_TOWER);
            end if;
            --起飞时间
            if cursor_trip.take_off_time is not null then
              vTemplet3 := Replace(vTemplet3,'#HOUR#',to_char(cursor_trip.take_off_time, 'FMHH24:FMMI'));
            end if;

            vTemp8 := cursor_trip.depart_airport_name || '--'|| cursor_trip.arrive_airport_name;
            --航班号
            vTemplet3 := Replace(vTemplet3,'#FLIGHTNO#',cursor_trip.airline_code || cursor_trip.FLIGHT_NO);
            --计算发送时间
            -- 当天航班不发送登机提醒，其他则提前一天 晚6点发送
            if cursor_trip.take_off_time is not null then
              vSendTime := cursor_trip.take_off_time -1;
              vSendTime2 := to_date(to_char(vSendTime,'yyyy-MM-dd')|| '18:00:00','yyyy-MM-dd hh24:mi:ss');
              if vSendTime2 > sysdate then
                  iNum9 := ROUND(TO_NUMBER(vSendTime2 - sysdate) * 24 * 60 * 60);
              else
                  iNum9 := 0;
              end if;
            end if;

          end if;

          vTemplet3 := Replace(vTemplet3,'#TRIP#',vTemp8);

          for rsTicket in (select Phone from T_CC_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '3') loop
            --乘机人电话
            vUserPhone := NVL(Trim(rsTicket.Phone),'');

            if vUserPhone is not null and length(vUserPhone) = 11 and iNum9 <> 0 then
              ---发送给乘机人提前起飞短信
                vResult := smsGeneralInterface('MSG_REMIND_PLANE_CIVIL_OFF',iNum9,vSwitch,vMaType,4,vMsgType,
                  vOrderId,vCompanyId,vTemplet3,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg2,vOrderNo,2);
            end if;
          end loop;
      end loop;

      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------

      ---------------------------------------------------------------------------------------------------
        --乘客信息
        iNum3 := 0;
        for rsTicket in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '3') loop
        --短信模板
        select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_CIVIL_OUT_TO_PASS';

          --记录一共有几个乘客
          iNum3 := iNum3 + 1;
          --乘机人电话
          vUserPhone := NVL(Trim(rsTicket.Phone),'');

          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;

          vTemp2 := vTemp2||rsTicket.Idc_Name;

          --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
          --vTemp6 := vTemp6 || '-' || iNum1;
          iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

          if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
            vObjectRole := 2; --乘客角色
              vTemp5 := 'MSG_PLANE_CIVIL_OUT_TO_PASS';
              --vTemplet := Replace(vTemplet, '#NAME#', rsTicket.IDC_NAME);
              --vTemplet := Replace(vTemplet, '#ORDERNO#', rsTicket.Plane_Ticket_No);
              vTemplet := Replace(vTemplet, '#DATE##FLIGHTNO##AIRPORT#', vTemp3);
              vTemplet := Replace(vTemplet, '#AIRINFO#', vTemp4);
              vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);

          end if;

        end loop;

        --有多个乘客
        iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

        -------给预订人、联系人发送短信------------------------------------------------------
        vTemp5 :='MSG_PLANE_CIVIL_OUT_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        /*
        vTemplet1 := Replace(vTemplet1, '#PRICE#',rsPlaneOrder.sale_price);

        --若乘客手机为空，则不发送--已短信通知乘客这句提醒
        if vUserPhone is null then
          vTemplet1 := Replace(vTemplet1,'并已短信通知乘客(若乘客已预留手机号)','');
        end if;
        --订单金额无法获取，直接报错误短信
        if rsPlaneOrder.sale_price is null or rsPlaneOrder.sale_price = '' then
          vErrorMsg1 := vErrorMsg1 || '(订单金额无法获取)';
        end if;*/

          if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet1,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
          end if;

          if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
          end if;

      end loop;
      --*******短信参数解析完毕******************
    end if;

    --********************国内机票出票失败 发给乘机人、联系人或预订人********************************
    --1.MSG_PLANE_CIVIL_FAIL_TO_PASS
    --2.#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您火速预订其他航班啦，订单已经取消，谢谢您的支持！网上预订更方便，服务电话：4007239888
    --3.传递参数：

    --1.MSG_PLANE_CIVIL_FAIL_TO_LINK
    --2.您预订的#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您为您的旅客火速预订其他航班，订单已经取消，订单金额#TOTAL#元，
    --将在3-15个工作日退还到您的付款账户，谢谢您的支持！网上预订更方便，服务电话：4007239888
    --3.传递参数：

    --********************国际机票 提前三小时起飞短信*******************************
    --1.MSG_REMIND_PLANE_CIVIL_OFF
    -- 您预订的#TIME##TRIP#的行程 #HOUR#从#AIRPORT#航站楼出发，航班号#FLIGHTNO#，建议您带好证件及时办理登机手续，祝您旅途愉快，服务电话：4007239888
    --3.传递参数：
    --*****************************************************
    --*****************************************************
    if vCode in ('MSG_PLANE_CIVIL_FAIL_TO') then
      --order_id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;


      --********开始解析短信参数***************
      --国内机票行程按起飞时间排序
      vTemp3 :='';
      for cursor_trip in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
        --先解析航程信息，存入vTemp3
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
        --航司编码为空，直接进入错误信息列表
        if cursor_trip.airline_code is null then
          vErrorMsg := vErrorMsg || '(航司编码未获取)';
        else
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
          vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';
          vTemp3 := vTemp3 || cursor_trip.depart_airport_name || replace(cursor_trip.depart_airport_tower, '-', '') || '-';
          vTemp3 := vTemp3 || cursor_trip.arrive_airport_name || replace(cursor_trip.arrive_airport_tower, '-', '');
        end if;
      end loop;

      if vTemp3 is null or vTemp3 = '' or vTemp3 = 'N' then
        vErrorMsg := vErrorMsg || '(航程信息获取失败)';
      end if;

      -------------------------------------------------------------------------------------------------
      -- -1 TICKET_STATE 机票票号状态-无效
      -- 1  TICKET_STATE 机票票号状态-未出票
      -- 2  TICKET_STATE 机票票号状态-出票中
      -- 3  TICKET_STATE 机票票号状态-出票成功
      -- 4  TICKET_STATE 机票票号状态-出票失败
      -------------------------------------------------------------------------------------------------

      ---获取预订人、联系人、乘客短信模板----------------------------------------------------------------------


        select TEXT1 INTO vTemplet1 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_CIVIL_FAIL_TO_LINK';

      ---------------------------------------------------------------------------------------------------

      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
        --订单编号
        vOrderNo := rsPlaneOrder.PLANE_ORDER_NO;
        --是否为补单标志，补单短信取消发送
        --vFlag := rsPlaneOrder.IS_FILL_ORDER;
        --企业名称
        for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                              WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
            vCompanyName := rsCompany.COMPANY_NAME;
            --判断是否要给预订人发短信
            if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
              vFlag1 := 1;
            else
              vFlag1 := 0;
            end if;
        end loop;

        --select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1;
        -----------------------
        --解析短信发送对象
        -----------------------
        --联系人电话
        vContactPhone := rsPlaneOrder.Contact_Phone;
        --预订人电话
        vOrderPhone := '';
        if vFlag1 = 1 then
          select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'') into vOrderPhone from dual;
        end if;

        --乘客信息
        for rsTicket in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '4') loop
          select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_CIVIL_FAIL_TO_PASS';
          --乘机人电话
          vUserPhone := NVL(Trim(rsTicket.Phone),'');

          --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
          --vTemp6 := vTemp6 || '-' || iNum1;

          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsTicket.Idc_Name||'票号：'||rsTicket.Plane_Ticket_No;

          iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

          if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
            vTemp5 := 'MSG_PLANE_CIVIL_FAIL_TO_PASS';
            vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
          end if;
        end loop;

        --先判断该企业是否要给预订人发短信，若开启了配置则发送，若未配置，则只发送给乘客和联系人
        --若预订人不需要发短信，则只要判断联系人和乘客是否为同一人
        iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

        -------给预订人、联系人发送短信------------------------------------------------------
        vTemp5 :='MSG_PLANE_CIVIL_FAIL_TO_LINK';
        vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vTemplet1 := Replace(vTemplet1, '#TOTAL#',rsPlaneOrder.sale_price);

          if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone)= 11 then  --给联系人发短信
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet1,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
          end if;

          if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
          end if;

      end loop;
    end if;


    --********************国内机票改签成功 发送给乘机人、预订人或联系人********************************
    --1.MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS
    --2.您好，您的改签已完成，原#FLIGHTNOOLD##AIRPORT#，改为:#FLIGHTNONEW#,#TIME#，#NAME#票号#ORDERNO#，祝您旅途愉快！网上退改更方便，服务电话：4007239888
    --3.传递参数：

    --1.MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK
    --2.您好，您申请的改签已完成，原#FLIGHTNOOLD##AIRPORT#，改为:#FLIGHTNONEW#,#TIME#，已短信通知乘机人，#NAME##ORDERNO#，改签费用#PRICE#，祝生活愉快！网上退改更方便，服务电话：4007239888
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO') then
      --订单id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;

      ---------------------------------------
      --获得旧行程vTemp1，再获得新行程vTemp2
      ---------------------------------------
      vTemp1 := '';
      vTemp2 := '';
      for rsCo in (select * from t_cc_change_od t where  change_id = vIdConvert order by orig_od_id) loop
        --查询订单起飞模板，生成新模板
        select TEXT1 into vTemplet3 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_REMIND_PLANE_CIVIL_OFF';
        --多行程时用"；"分开
        if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
        --旧行程
         /*
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by take_off_time) loop
          vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');

          vTemp1 := vTemp1 || rsPt.airline_name || rsPt.airline_code || rsPt.flight_no || ' ';

          vTemp1 := vTemp1 || rsPt.depart_airport_name || replace(rsPt.depart_airport_tower, '-', '') || '-';

          vTemp1 := vTemp1 || rsPt.arrive_airport_name || replace(rsPt.arrive_airport_tower, '-', '');
        end loop ;
        */


        --多行程时用"；"分开
        if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
        --新行程
        for rsPt in (select * from t_cc_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by take_off_time) loop
          --新的起飞提醒 起飞时间
          vTemplet3 := Replace(vTemplet3,'#TIME#',to_char(rsPt.take_off_time, 'FMMM"月"DD"日"'));

          vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');

          vTemp2 := vTemp2 || rsPt.airline_name || rsPt.flight_no || ' ';

          vTemp2 := vTemp2 || rsPt.depart_airport_name || replace(rsPt.depart_airport_tower, '-', '') || '-';

          vTemp2 := vTemp2 || rsPt.arrive_airport_name || replace(rsPt.arrive_airport_tower, '-', '');

          --出发航站楼
          vTemplet3 := Replace(vTemplet3,'#DEPTERMIAL#',rsPt.DEPART_AIRPORT_TOWER);
          --起飞时间
          vTemplet3 := Replace(vTemplet3,'#HOUR#',to_char(rsPt.take_off_time, 'FMHH24:FMMI'));
          --航班号
          vTemplet3 := Replace(vTemplet3,'#FLIGHTNO#',rsPt.FLIGHT_NO);

          vTemp8 := rsPt.depart_airport_name ||'--'|| rsPt.arrive_airport_name;
          vTemplet3 := Replace(vTemplet3,'#TRIP#',vTemp8);
          --计算发送时间
          --vSendTime2 := rsPt.take_off_time - (1/24)*3;
          vSendTime := rsPt.take_off_time -1;
          vSendTime2 := to_date(to_char(vSendTime,'yyyy-MM-dd')|| '18:00:00','yyyy-MM-dd hh24:mi:ss');

          for rsCjr in (select * from T_CC_TICKET_PASSENGER a1
                            where exists (select 0 from t_cc_change_ticket a2
                                where a2.change_id = vIdConvert and a2.plane_ticket_no=a1.plane_ticket_no)
                                and state = '3') loop
              --更新原来的起飞提醒短信
              --先根据订单编号,查询到原订单的起飞提醒，然后更新
                for cursor_order in (select * from T_BASE_MSG_AWAIT_QUEUE
                      WHERE ORDER_NO = rsCjr.PLANE_ORDER_NO and PRIORITY = 4 and OBJECT_RECEIVE = Trim(rsCjr.Phone) and TEXT1 like '%'||vTemp8||'%') loop
                    --更新
                  update T_BASE_MSG_AWAIT_QUEUE SET TEXT1 = vTemplet3,SEND_TIME = vSendTime2 where MID = cursor_order.MID and ORDER_NO = rsCjr.PLANE_ORDER_NO;
                end loop;

          end loop;
        end loop ;
      end loop ;

      -------------------------------------------
      -- 获得联系人（申请人）手机和改签费用vTemp3
      -------------------------------------------
      for rsPc in (select * from t_cc_plane_change where change_id = vIdConvert and state='3') loop

          --企业信息
          for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                                WHERE COMPANY_ID = rsPc.COMPANY_ID and rownum <= 1) loop
              vCompanyName := rsCompany.COMPANY_NAME;
              --判断是否要给预订人发短信
              if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
                vFlag1 := 1;
                select mobilephone into vOrderPhone from t_base_user where user_id=rsPc.Apply_User;
              else
                vFlag1 := 0;
              end if;
          end loop;

          --改签费用
          vTemp3 := rsPc.sale_price;

          --联系人电话
          select Contact_Phone into vContactPhone from t_cc_plane_order where plane_order_no = rsPc.plane_order_no;

      end loop;

      --------------------------------------
      -- 新行程，获得乘机人信息
      --------------------------------------
      vTemp4 := '';
      iNum2  := 0;
      iNum3  := 0;
      for rsCjr in (select * from T_CC_TICKET_PASSENGER a1
                        where exists (select 0 from t_cc_change_ticket a2
                            where a2.change_id = vIdConvert and a2.plane_ticket_no=a1.plane_ticket_no)
                            and state = '3') loop
        --乘机人手机
        vUserPhone := Trim(rsCjr.Phone);
        --订单编号
        vOrderNo := rsCjr.PLANE_ORDER_NO;

        ----------------------------------------------------------------
        -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
        ----------------------------------------------------------------
        if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
        vTemp4 := vTemp4||rsCjr.Idc_Name;

        --给乘机人发短信
        select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS';

        if vTemplet1 = 'N' then
          vErrorMsg := vErrorMsg || '(改签乘机人模板缺失)';
        end if;
        /*
        vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.Idc_Name);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);*/
        vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);

        iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

        if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送（短信开关）
          vTemp5 := 'MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO_PASS';
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet1,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
        end if;



        --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
        --vTemp6 := vTemp6 || '-' || iNum1;

      end loop;

      iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

      --给联系人或预订人发短信
      select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK';

      if vTemplet2 = 'N' then
        vErrorMsg := vErrorMsg || '(改签乘机人模板缺失)';
      end if;
      vTemp5 :='MSG_PLANE_CIVIL_CHANGE_SUCCESS_TO_LINK';

      vTemplet2 := Replace(vTemplet2, '#FLIGHTNONEW#,#TIME#', vTemp2);
      vTemplet2 := Replace(vTemplet2, '#NAME#',vTemp4);
      --订单销价为空，则直接错误短信

        if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
        end if;

        if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
        end if;

    end if;



  --********************国内机票退票成功 发送给乘机人、联系人或预订人********************************
  --1.MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_PASS
  --2.您好，您的退票已完成，#TIME##FLIGHTNO##AIRPORT#，#NAME#票号#ORDERNO#，祝您生活愉快！网上退改更方便，服务电话：4007239888
  --3.传递参数：

  --1.MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_LINK
  --2.您好，您申请的退票已完成，#TIME##FLIGHTNO##AIRPORT#，#NAME##ORDERNO#，退还金额：#REFUNDFEE#，将在3-15个工作日退还到您的付款账户，谢谢您的支持！祝您生活愉快！网上退改更方便，服务电话：4007239888
  --3.传递参数：
  --*****************************************************
  if vCode in ('MSG_PLANE_CIVIL_REFUND_SUCCESS_TO') then
    --订单id
    vIdConvert := convertStrToInt(vId, -1);
    vOrderId := vId;
    iNum1 := 0;
    iNum2 := 0;

    for rsRefundTicket in (
                select DISTINCT a.plane_ticket_id,a.idc_name,a.phone,a.plane_ticket_no,a.apply_user,a.refund_no,a.company_id, a.plane_order_no ,a.IS_FILL_ORDER from (
        select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.apply_user,t1.refund_no,
        t1.plane_order_no,t1.company_id,t1.IS_FILL_ORDER,
        t6.plane_trip_id,t6.plane_od_id,t6.plane_order_id,t6.depart_city,t6.depart_city_code,
        t6.arrive_city,t6.arrive_city_code,t6.depart_airport,t6.depart_airport_code,t6.arrive_airport,t6.arrive_airport_code,
        t6.depart_airport_tower,t6.arrive_airport_tower,t6.take_off_time,t6.arrive_time,t6.flight_no

          from t_cc_plane_refund     t1,
               t_cc_refund_ticket    t2,
               t_cc_ticket_passenger t3,
               t_cc_ticket_od        t4,
               t_cc_plane_od         t5,
               t_cc_plane_trip       t6
         where t1.refund_id = t2.refund_id
           and t2.plane_ticket_id = t3.plane_ticket_id
           and t3.plane_ticket_id = t4.plane_ticket_id
           and t4.plane_od_id = t5.plane_od_id
           and t5.plane_od_id = t6.plane_od_id
           and t1.refund_id = vIdConvert
         order by t3.plane_ticket_id, t6.take_off_time asc
         )a
    ) loop

    vOrderPhoneId := rsRefundTicket.apply_user;
    iNum1 := iNum1 + 1 ;

    --预订人电话
    for rsUser in(select * from t_base_user where user_id = vOrderPhoneId and rownum <= 1) loop
         vOrderPhone := rsUser.mobilephone;
    end loop;

    ----------------------------------------------------------------
    -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
    ----------------------------------------------------------------
    if NVL(vTemp2, 'N') != 'N' then
      vTemp2 := vTemp2 || ',';
    end if;
    vTemp2 := vTemp2 || rsRefundTicket.idc_name ;

     if iNum2 < 1 then
        --查询一张票的多个行程
        for rsRefundTrip in(
                    select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.APPLY_USER,t6.*
            from t_cc_plane_refund     t1,
                 t_cc_refund_ticket    t2,
                 t_cc_ticket_passenger t3,
                 t_cc_ticket_od        t4,
                 t_cc_plane_od         t5,
                 t_cc_plane_trip       t6
           where t1.refund_id = t2.refund_id
             and t2.plane_ticket_id = t3.plane_ticket_id
             and t3.plane_ticket_id = t4.plane_ticket_id
             and t4.plane_od_id = t5.plane_od_id
             and t5.plane_od_id = t6.plane_od_id
             and t1.refund_id = vIdConvert
             and t3.plane_ticket_id = rsRefundTicket.plane_ticket_id
           order by t3.plane_ticket_id, t6.take_off_time asc
        ) loop

          if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
          end if;
          vTemp3 := vTemp3 || to_char(rsRefundTrip.take_off_time, 'FMMM"月"DD"日"') ;

          vTemp3 := vTemp3 || rsRefundTrip.depart_airport_name || '-';

          vTemp3 := vTemp3 || rsRefundTrip.arrive_airport_name  ;

          vTemp7 := rsRefundTrip.depart_airport_name || '--' || rsRefundTrip.arrive_airport_name;

          --更新原来的起飞提醒短信
          --先根据订单编号,查询到原订单的起飞提醒，然后更新
          for cursor_order in (select * from T_BASE_MSG_AWAIT_QUEUE
            WHERE ORDER_NO = rsRefundTicket.plane_order_no and PRIORITY = 4 and OBJECT_RECEIVE = rsRefundTicket.phone and TEXT1 like '%'||vTemp7||'%') loop
              --更新
              update T_BASE_MSG_AWAIT_QUEUE SET M_STATE = '4' where MID = cursor_order.MID;
          end loop;


        end loop;

        iNum2 := iNum2 + 1;
        end if;

        if vTemp3 = '' or vTemp3 = 'N' then
          vErrorMsg := vErrorMsg || '(订单行程信息未获取)';
        end if;

      ------------------------------
      --  获得乘机人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_PASS';
      --vFlag := workOnMsgSwitch('MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_PASS',vSwitch);
      --vTemplet1 := Replace(vTemplet1, '#NAME#', rsRefundTicket.Idc_Name);
      --vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsRefundTicket.plane_ticket_no);
      vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

      vUserPhone := NVL(rsRefundTicket.phone,'N');
      vOrderNo := rsRefundTicket.plane_order_no;

      --企业信息
      for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER,CONTACT_MOBILEPHONE from T_BASE_COMPANY
                            WHERE COMPANY_ID = rsRefundTicket.COMPANY_ID and rownum <= 1) loop
          vCompanyName := rsCompany.COMPANY_NAME;
          --判断是否要给预订人发短信
          if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
            vFlag1 := 1;
          else
            vFlag1 := 0;
            vOrderPhone := '';
          end if;
      end loop;

      --乘机人模板为空，则直接报错误短信
      if vTemplet1 is null or vTemplet1 = '' then
        vErrorMsg := vErrorMsg || '(乘机人模板为空)';
      end if;

      iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

      --给pass发送短信，补单不发送
      if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then
        vTemp5 := 'MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_PASS';
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet1,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
      end if;


      --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
      --vTemp6 := vTemp6 || '-' || iNum1;



    end loop;

    --联系人模板
    select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_LINK';

    vTemp5 := 'MSG_PLANE_CIVIL_REFUND_SUCCESS_TO_LINK';
    --模板内容为空，则为错误短信
    if vTemplet2 is null or vTemplet2 = '' then
      vErrorMsg := vErrorMsg || '(联系人模板为空)';
    end if;

    vTemplet2 := Replace(vTemplet2, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
    vTemplet2 := Replace(vTemplet2, '#NAME#', vTemp2);

    iNum5 := 0;
    iNum12 := 0;
    /*
    for rsRefundTicket in (select sale_price,plane_ticket_id from t_cc_refund_ticket where refund_id = vIdConvert) loop
        iNum5 := iNum5 + 1;
       for rsTicket in (select sale_price from t_cc_ticket_passenger where PLANE_TICKET_ID = rsRefundTicket.plane_ticket_id ) loop
          iNum12 := rsTicket.sale_price - rsRefundTicket.sale_price;
       end loop;
    end loop;
    vTemplet2 := Replace(vTemplet2, '#REFUNDFEE#',iNum12*iNum5);
    */

    if vTemp3 is null or vTemp3 = 'N' then
      vErrorMsg1 := vErrorMsg1 || '(行程信息未获取)';
    end if;

    --判断乘机人、预订人和联系人之间的联系
    iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

    --补单不发
      if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
      end if;

      if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
      end if;
  end if;


    --********************国内机票 支付完成提醒预订人********************************
  --1.MSG_PLANE_CIVIL_PAY_REMIND
  --2.您好，您的订单已生成，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
  --3.传递参数：

  --1.MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU
  --2.有一笔#ORDERTYPE#订单已生成，订单号#ORDERNO#，预订公司：#COMPANY# ，预订人号码：#YDSJH#.
  --3.传递参数：
  --*****************************************************
  if vCode in ('MSG_PLANE_CIVIL_PAY_REMIND') then
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;
      iNum1 := 0;
      if vIdConvert is null then
        vErrorMsg := vErrorMsg || '(订单id解析出错)';
      end if;
      --客服短信模板
      select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';

      --获得行程信息，存入临时变量　vTemp3
      vTemp3 := '';
      for rs in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop

        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');
        select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = rs.airline_code and rownum <= 1),rs.airline_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || rs.airline_code || rs.flight_no || ' ';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.depart_airport_code and rownum <= 1),rs.depart_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.depart_airport_tower, '-', '') || '-';
        select nvl((select name_cn from T_BASE_AIRPORT where airport_code = rs.arrive_airport_code and rownum <= 1),rs.arrive_airport_code) into vTemp from dual;
        vTemp3 := vTemp3 || vTemp || replace(rs.arrive_airport_tower, '-', '');
      end loop;
      -------------------------------------------------------------------------------------------------

      for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
        iNum1 := 1;
        vTemp2 := '';

        vOrderNo := rsPlaneOrder.plane_order_no;
        --预订人手机号
        select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vOrderPhone from dual;
        vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);

        --如果订单编号为空，则直接错误短信
        if vOrderNo is null or vOrderNo = '' then
          vErrorMsg := vErrorMsg || '(订单编号为空)';
        end if;
        --------------------------------------
        -- 获得企业信息 企业名称+是否给预订人发送短信
        --------------------------------------
        for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER,CONTACT_MOBILEPHONE from T_BASE_COMPANY
                              WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
            vCompanyName := rsCompany.COMPANY_NAME;
            --判断是否发给预订人
            if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
              vFlag1 := 1;
            else
              vFlag1 := 0;
              vOrderPhone := '';
            end if;
        end loop;

        --------------------------------------
        -- 乘机人表获得乘机人信息
        --------------------------------------
        for rsCjr in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vIdConvert) loop
          ----------------------------------------------------------------
          -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
          ----------------------------------------------------------------
          if NVL(vTemp2, 'N') != 'N' then
            vTemp2 := vTemp2 || ',';
          end if;
          vTemp2 := vTemp2||rsCjr.Idc_Name;

        end loop;

        ------------------------------
        --  获得预订人模板并替换信息
        ------------------------------
        select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_PAY_REMIND';
        if vTemplet1 is null or vTemplet1 = '' then
          vErrorMsg := vErrorMsg || '(预订人短信模板为空)';
        end if;
        -- vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
       -- vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
        vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

        --------------------------------
        vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND';

        if vOrderPhone is not null and length(vOrderPhone) = 11 then
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
        end if;

        vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国内机票');
        vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
        vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);

        vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
        --给客服短信
        select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PLANE';

        if vTemp = 'N' then
          vErrorMsg := vErrorMsg ||'(客服电话未获取)';
        end if;


          --开始循环分割字段
          while(length(vTemp)>0) loop
          --如果有逗号，以逗号进行分割
            if INSTR(vTemp,',' ) > 0 then
                    vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
                --取到第n个逗号(也就是第n次循环)后面的剩余字符串
                    vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
                    vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                      vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
                --没有逗号，说明不需要分割
                else
                vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                  vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
                  exit;
           end if;
          end loop;

    end loop;
  end if;


  --********************国内机票 改签申请提醒 申请人*******************************
  --1.MSG_PLANE_CIVIL_CHANGE_REMIND
  --2.您好，您的改签申请已经收到，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
  --3.传递参数：
  --*****************************************************
  if vCode in ('MSG_PLANE_CIVIL_CHANGE_REMIND') then
    --订单ID
    vIdConvert := convertStrToInt(vId, -1);
    vOrderId := vId;

    iNum1 := 1;

    for rsPlaneChange in (
      /*select a.change_id,a.plane_order_id,b.plane_order_no,a.apply_user,a.company_id
          from T_CC_PLANE_CHANGE a,t_cc_plane_order b
            where a.plane_order_id = b.plane_order_id and a.change_id = vIdConvert) loop*/
      select t.change_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_PLANE_CHANGE t
        left join t_cc_plane_order m on t.plane_order_id = m.plane_order_id
          where change_id = vIdConvert and rownum <= 1) loop
      iNum1 := 1;
      vTemp2 := '';

      --------------------------------------
      -- 获得所属模块+订单号+企业名称
      --------------------------------------
      vOrderNo := rsPlaneChange.plane_order_no;
      for rsCompany in (select * from T_base_company where company_id = rsPlaneChange.company_id and rownum <= 1) loop
         vCompanyName := rsCompany.company_name;
      end loop;
      --------------------------------------
      -- 获得申请人的手机号码
      --------------------------------------

      select nvl((select mobilephone from t_base_user where user_id=rsPlaneChange.apply_User and rownum<=1),'N') into vOrderPhone from dual;

      ------------------------------
      --  获得预订人模板并替换信息
      ------------------------------
      select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE ='MSG_PLANE_CIVIL_CHANGE_REMIND';

      vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

      if vOrderNo is null or vOrderNo = '' then
        vErrorMsg := vErrorMsg ||'(订单编号未获取)';
      end if;

      if vTemplet1 is null or vTemplet1 = 'N' then
        vErrorMsg := vErrorMsg || '(申请人模板未获取)';
      end if;

      --------------------------------
      vTemp5 := 'MSG_PLANE_CIVIL_CHANGE_REMIND';

       if vOrderPhone is not null and  length(vOrderPhone) = 11 then
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
         vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
       end if;

       ------------------------------
      --  给客服发送短信通知
      ------------------------------
      select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';

      vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
      vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国内机票改签');
      vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
      vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
      vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);
      --给客服小米短信
      select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';

      if vTemp = 'N' then
        vErrorMsg1 := '(客服手机未获取)';
      end if;

      --开始循环分割字段
      while(length(vTemp)>0) loop
      --如果有逗号，以逗号进行分割
        if INSTR(vTemp,',' ) > 0 then
                vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
            --取到第n个逗号(也就是第n次循环)后面的剩余字符串
                vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
                vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                  vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
            --没有逗号，说明不需要分割
            else
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
              exit;
       end if;
      end loop;

    end loop;
end if;


--********************国内机票 退票申请提醒 申请人*******************************
--1.MSG_PLANE_CIVIL_REFUND_REMIND
--2.您好，您的退票申请已经收到，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_CIVIL_REFUND_REMIND') then
  --订单ID
  vIdConvert := convertStrToInt(vId, -1);
  vOrderId := vId;

  --iNum1 := 1;

  for rsPlaneRefund in (
  select t.refund_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_PLANE_REFUND t
      left join t_cc_plane_order m on t.plane_order_id = m.plane_order_id where refund_id = vIdConvert and rownum <= 1
  ) loop
    iNum1 := 1;
    vTemp2 := '';
    --------------------------------------
    -- 获得所属模块+订单号+企业名称
    --------------------------------------
    vOrderNo := rsPlaneRefund.plane_order_no;
    for rsCompany in (select * from T_base_company where company_id = rsPlaneRefund.company_id and rownum <= 1) loop
       vCompanyName := rsCompany.company_name;
    end loop;
    --------------------------------------
    -- 获得申请人的手机号码
    --------------------------------------

    select nvl((select mobilephone from t_base_user where user_id=rsPlaneRefund.apply_User and rownum<=1),'N') into vOrderPhone from dual;

    ------------------------------
    --  获得预订人模板并替换信息
    ------------------------------
    select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_REFUND_REMIND';

    vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

    if vOrderNo is null or vOrderNo = '' then
      vErrorMsg := vErrorMsg || '(订单号为空)';
    end if;

    --------------------------------
     if vOrderPhone is not null and length(vOrderPhone) = 11  then
     vTemp5 :='MSG_PLANE_CIVIL_REFUND_REMIND';
     vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
       vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
    end if;

     ------------------------------
    --  给客服发送短信通知
    ------------------------------
    select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
    vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
    vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国内机票退票');
    vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
    vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
    vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);


    --给客服小米短信
    select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
    if vTemp = 'N' then
      vErrorMsg1 := '(客服手机未获取)';
    end if;

    --开始循环分割字段
    while(length(vTemp)>0) loop
    --如果有逗号，以逗号进行分割
      if INSTR(vTemp,',' ) > 0 then
              vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
          --取到第n个逗号(也就是第n次循环)后面的剩余字符串
              vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
              vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
          --没有逗号，说明不需要分割
          else
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
            exit;
     end if;
    end loop;

  end loop;
end if;



--********************国际机票出票成功 发送给乘客、联系人或预订人********************************
--1.CODE:MSG_PLANE_INTER_OUT_TO_PASS
--2.模板：#TIME##FLIGHTNO##AIRPORT#，已经出票成功，#NAME#票号#ORDERNO#，请至实际承运航司#AIRINFO#办理值机，感谢您的预订！祝您旅途愉快！网上退改更方便，服务电话：4007239888
--3.传递参数：
--  CODE:MSG_PLANE_INTER_OUT_TO_LINK
--4.模板：您预订的#TIME##FLIGHTNO##AIRPORT#，出票成功并已短信通知乘客(若乘客已预留手机号)，#NAME##ORDERNO#，订单金额#PRICE#，
--感谢您的预订！网上退改更方便，服务电话：4007239888"
--  CODE:MSG_PLANE_INTER_OUT_TO_ALL
--5 模板：您预订的#TIME##FLIGHTNO##AIRPORT#，已经出票成功，#NAME#票号#ORDERNO#，请至实际承运航司#AIRINFO#办理值机，订单金额#PRICE#，
--感谢您的预订！网上退改更方便，服务电话：4007239888"

--********************国际机票 提前三小时起飞短信*******************************
--1.MSG_REMIND_PLANE_INTER_OFF
-- 您预订的#TIME##TRIP#的行程 #HOUR#从#AIRPORT#航站楼出发，航班号#FLIGHTNO#，建议您带好证件及时办理登机手续，祝您旅途愉快，服务电话：4007239888
--3.传递参数：
--*****************************************************
--****************************************************************************************
if vCode in ('MSG_PLANE_INTER_OUT_TO') then
  --order_id
  vIdConvert := convertStrToInt(vId, -1);
  vOrderId := vId;
  --********开始解析短信参数***************
  for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
    --订单编号
    vOrderNo := rsPlaneOrder.PLANE_ORDER_NO;
    --订单销价
    vTemp9 := rsPlaneOrder.sale_price;
    --企业名称
    for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                          WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
        vCompanyName := rsCompany.COMPANY_NAME;
        --判断是否要给预订人发短信
        if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
        else
          vFlag1 := 0;
        end if;
    end loop;

    select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1;
    -----------------------
    --解析短信发送对象
    -----------------------
    --联系人电话
    vContactPhone := rsPlaneOrder.Contact_Phone;
    --预订人电话
    vOrderPhone := '';
    if vFlag1 = 1 then
      select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'') into vOrderPhone from dual;
    end if;

  end loop;

  --国内机票行程按起飞时间排序
  vTemp3 :='';
  for cursor_trip in (select * from t_cc_inter_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
    --提前三小时起飞提醒
    select TEXT1 INTO vTemplet3 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_REMIND_PLANE_INTER_OFF';
    -- 起飞提醒短信时间
    vTemplet3 := Replace(vTemplet3,'#TIME#',to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"'));

    --先解析航程信息，存入vTemp3
    if NVL(vTemp3, 'N') != 'N' then
      vTemp3 := vTemp3 || '；';
    end if;
    vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI');
    --vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
    --航司编码为空，直接进入错误信息列表
    if cursor_trip.airline_code is null then
      vErrorMsg := vErrorMsg || '(航司编码未获取)';
    else
      select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
      vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';
      vTemp4 := vTemp || '(' || cursor_trip.airline_code || ')';

      vTemp3 := vTemp3 || cursor_trip.depart_airport_name || replace(cursor_trip.depart_airport_tower, '-', '') || '(' || to_char(cursor_trip.take_off_time, 'HH24:FMMI') || ')'|| '-';

      vTemp3 := vTemp3 || cursor_trip.arrive_airport_name || replace(cursor_trip.arrive_airport_tower, '-', '')|| '(' || to_char(cursor_trip.arrive_time, 'HH24:FMMI') || ')';

      --出发航站楼
      vTemplet3 := Replace(vTemplet3,'#AIRPORT#',cursor_trip.DEPART_AIRPORT_TOWER);
      --起飞时间
      vTemplet3 := Replace(vTemplet3,'#HOUR#',to_char(cursor_trip.take_off_time, 'FMHH24:FMMI'));

      vTemp8 := cursor_trip.DEPART_CITY_NAME || '--' || cursor_trip.ARRIVE_CITY_NAME;
      --航班号
      vTemplet3 := Replace(vTemplet3,'#FLIGHTNO#',cursor_trip.FLIGHT_NO);
      --计算发送时间
      vSendTime2 := cursor_trip.take_off_time - (1/24)*3;
      iNum9 := ROUND(TO_NUMBER(vSendTime2 - sysdate) * 24 * 60 * 60);

      /*for rsTicket in (select phone from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '3') loop
        --乘客电话
        vUserPhone := NVL(Trim(rsTicket.Phone),'');

          if length(vUserPhone) = 11 then
            ---发送给乘机人提前起飞短信
            vTemplet3 := Replace(vTemplet3,'#TRIP#',vTemp8);
            if length(vUserPhone) = 11 then
              vResult := smsGeneralInterface('MSG_REMIND_PLANE_INTER_OFF',iNum9,vSwitch,vMaType,4,vMsgType,
                vOrderId,vCompanyId,vTemplet3,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg2,vOrderNo,2);
            end if;
          end if;
     end loop;*/
    end if;

  end loop;

  -------------------------------------------------------------------------------------------------
  -- -1 TICKET_STATE 机票票号状态-无效
  -- 1  TICKET_STATE 机票票号状态-未出票
  -- 2  TICKET_STATE 机票票号状态-出票中
  -- 3  TICKET_STATE 机票票号状态-出票成功
  -- 4  TICKET_STATE 机票票号状态-出票失败
  -------------------------------------------------------------------------------------------------

  ---获取预订人、联系人、乘客短信模板----------------------------------------------------------------------

    select TEXT1 INTO vTemplet1 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_INTER_OUT_TO_LINK';

  ---------------------------------------------------------------------------------------------------

    --乘客信息
    iNum3 := 0;
    for rsTicket in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '3') loop
      --记录一共有几个乘客
      iNum3 := iNum3 + 1;
      --乘机人电话
      vUserPhone := NVL(Trim(rsTicket.Phone),'');
      --短信模板
      select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_INTER_OUT_TO_PASS';

      --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
      --vTemp6 := vTemp6 || '-' || iNum1;

      ----------------------------------------------------------------
      -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2||rsTicket.LAST_NAME || '/' || rsTicket.FIRST_NAME;

      if rsTicket.Plane_Ticket_No is null then
        vErrorMsg := vErrorMsg || '(票号为空)';
      end if;

      iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

      if  vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
        vObjectRole := 2; --乘客角色
        --if iNum1 in (1,3,5,7,9) then  --乘机人模板
          vTemp5 := 'MSG_PLANE_INTER_OUT_TO_PASS';
          --vTemplet := Replace(vTemplet, '#NAME#', rsTicket.LAST_NAME || '/' || rsTicket.FIRST_NAME);
          --vTemplet := Replace(vTemplet, '#ORDERNO#',rsTicket.Plane_Ticket_No);
          vTemplet := Replace(vTemplet, '#DATE##FLIGHTNO# #AIRPORT#', vTemp3);
          vTemplet := Replace(vTemplet, '#AIRINFO#', vTemp4);
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);

      end if;
    end loop;

    --有多个乘客
    iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

    -------给预订人、联系人发送短信------------------------------------------------------
    vTemp5 :='MSG_PLANE_INTER_OUT_TO_LINK';
    vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
    vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
    /*
    vTemplet1 := Replace(vTemplet1, '#PRICE#',vTemp9);
    --若乘客手机为空，则不发送--已短信通知乘客这句提醒
    if vUserPhone is null then
      vTemplet1 := Replace(vTemplet1,'并已短信通知乘客(若乘客已预留手机号)','');
    end if;

    if vTemp9 is null or vTemp9 = '' then
      vErrorMsg1 := vErrorMsg1 || '(订单销价未获取)';
    end if;
    */
    --if vFlag2 is null or vFlag2 = 0 then  --补单不发送
      if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet1,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
      end if;

      if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
      end if;
    --end if;

  --*******短信参数解析完毕******************
end if;

--********************国际机票出票失败 发给乘机人、联系人或预订人********************************
--1.MSG_PLANE_INTER_FAIL_TO_PASS
--2.#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您火速预订其他航班啦，订单已经取消，谢谢您的支持！网上预订更方便，服务电话：4007239888
--3.传递参数：

--1.MSG_PLANE_INTER_FAIL_TO_LINK
--2.您预订的#TIME##FLIGHTNO##AIRPORT#，因机票已被抢空了，请您为您的旅客火速预订其他航班，订单已经取消，订单金额#TOTAL#元，
--将在3-15个工作日退还到您的付款账户，谢谢您的支持！网上预订更方便，服务电话：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_INTER_FAIL_TO') then
  --order_id
  vIdConvert := convertStrToInt(vId, -1);
  vOrderId := vId;
  --********开始解析短信参数***************
  --国内机票行程按起飞时间排序
  vTemp3 :='';
  for cursor_trip in (select * from t_cc_inter_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
    --先解析航程信息，存入vTemp3
    if NVL(vTemp3, 'N') != 'N' then
      vTemp3 := vTemp3 || '；';
    end if;
    vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
    vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
    --航司编码为空，直接进入错误信息列表
    if cursor_trip.airline_code is null then
      vErrorMsg := vErrorMsg || '(航司编码未获取)';
    else
      select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
      vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';

      vTemp3 := vTemp3 || cursor_trip.depart_airport_name || replace(cursor_trip.depart_airport_tower, '-', '') || '-';

      vTemp3 := vTemp3 || cursor_trip.arrive_airport_name || replace(cursor_trip.arrive_airport_tower, '-', '');
    end if;
  end loop;

  -------------------------------------------------------------------------------------------------
  -- -1 TICKET_STATE 机票票号状态-无效
  -- 1  TICKET_STATE 机票票号状态-未出票
  -- 2  TICKET_STATE 机票票号状态-出票中
  -- 3  TICKET_STATE 机票票号状态-出票成功
  -- 4  TICKET_STATE 机票票号状态-出票失败
  -------------------------------------------------------------------------------------------------

  ---获取预订人、联系人、乘客短信模板----------------------------------------------------------------------

    select TEXT1 INTO vTemplet1 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_INTER_FAIL_TO_LINK';
  ---------------------------------------------------------------------------------------------------

  for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
    --订单编号
    vOrderNo := rsPlaneOrder.PLANE_ORDER_NO;
    --企业名称
    for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                          WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
        vCompanyName := rsCompany.COMPANY_NAME;
        --判断是否要给预订人发短信
        if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
        else
          vFlag1 := 0;
        end if;
    end loop;

    --select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1;
    -----------------------
    --解析短信发送对象
    -----------------------
    --联系人电话
    vContactPhone := rsPlaneOrder.Contact_Phone;
    --预订人电话
    vOrderPhone := '';
    if vFlag1 = 1 then
      select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'') into vOrderPhone from dual;
    end if;

    --乘客信息
    for rsTicket in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '4') loop
      select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_PLANE_INTER_FAIL_TO_PASS';
      --乘机人电话
      vUserPhone := NVL(Trim(rsTicket.Phone),'');
      --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
      --vTemp6 := vTemp6 || '-' || iNum1;

      ----------------------------------------------------------------
      -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2||rsTicket.last_Name || '/' || rsTicket.first_Name ||'票号'||rsTicket.Plane_Ticket_No;

      iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

      if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
        vTemp5 := 'MSG_PLANE_INTER_FAIL_TO_PASS';
        vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
      end if;
    end loop;
    --先判断该企业是否要给预订人发短信，若开启了配置则发送，若未配置，则只发送给乘客和联系人
    --若预订人不需要发短信，则只要判断联系人和乘客是否为同一人


    -------给预订人、联系人发送短信------------------------------------------------------
    vTemp5 :='MSG_PLANE_INTER_FAIL_TO_LINK';
    vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
    vTemplet1 := Replace(vTemplet1, '#TOTAL#',rsPlaneOrder.sale_price);

    iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

      if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet1,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
      end if;

      if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
      end if;
  end loop;
end if;


--********************国际机票改签成功 发送给乘机人、预订人或联系人********************************
--1.MSG_PLANE_INTER_CHANGE_SUCCESS_TO_PASS
--2.您好，您的改签已完成，原#FLIGHTNOOLD##AIRPORT#，改为:#FLIGHTNONEW#,#TIME#，#NAME#票号#ORDERNO#，祝您旅途愉快！网上退改更方便，服务电话：4007239888
--3.传递参数：

--1.MSG_PLANE_INTER_CHANGE_SUCCESS_TO_LINK
--2.您好，您申请的改签已完成，原#FLIGHTNOOLD##AIRPORT#，改为:#FLIGHTNONEW#,#TIME#，已短信通知乘机人，#NAME##ORDERNO#，改签费用#PRICE#，祝生活愉快！网上退改更方便，服务电话：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_INTER_CHANGE_SUCCESS_TO') then
  --订单id
  vIdConvert := convertStrToInt(vId, -1);
  vOrderId := vId;

  --初始化字符数组
  str_list := str_arraylist();
  str_list2 := str_arraylist2();
  str_list.extend(30);
  str_list2.extend(30);

  ---------------------------------------
  --获得旧行程vTemp1，再获得新行程vTemp2
  ---------------------------------------
  vTemp1 := '';
  vTemp2 := '';
  iNum6 := 0;
  iNum7 := 0;
  for rsCo in (select * from t_cc_inter_change_od t where  change_id=vIdConvert order by orig_od_id) loop

    --多行程时用"；"分开
    if NVL(vTemp1, 'N') != 'N' then vTemp1 := vTemp1 || '；'; end if;
    --旧行程
    /*
    for rsPt in (select * from t_cc_inter_plane_trip where plane_od_id=rsCo.Orig_Od_Id and rownum<=1 order by take_off_time) loop
      vTemp1 := vTemp1 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
      vTemp1 := vTemp1 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');

      vTemp1 := vTemp1 || rsPt.airline_name || rsPt.airline_code || rsPt.flight_no || ' ';

      vTemp1 := vTemp1 || rsPt.depart_airport_name || replace(rsPt.depart_airport_tower, '-', '') || '-';

      vTemp1 := vTemp1 || rsPt.arrive_airport_name || replace(rsPt.arrive_airport_tower, '-', '');

      vTemp7 := rsPt.depart_City_Name || '--' || rsPt.Arrive_City_Name || ';';

       iNum6 := iNum6 + 1;

       str_list(iNum6) := vTemp7;
    end loop ;
    */

    --多行程时用"；"分开
    if NVL(vTemp2, 'N') != 'N' then vTemp2 := vTemp2 || '；'; end if;
    --新行程
    for rsPt in (select * from t_cc_inter_plane_trip where plane_od_id=rsCo.Od_Id and rownum<=1 order by take_off_time) loop
      --查询订单起飞模板，生成新模板
      select TEXT1 into vTemplet3 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_REMIND_PLANE_CIVIL_OFF';
      --新的起飞提醒 起飞时间
      vTemplet3 := Replace(vTemplet3,'#TIME#',to_char(rsPt.take_off_time, 'FMMM"月"DD"日"'));

      vTemp2 := vTemp2 || to_char(rsPt.take_off_time, 'FMMM"月"DD"日"');
      -- vTemp2 := vTemp2 || to_char(rsPt.arrive_time, 'FMHH24:FMMI');

      vTemp2 := vTemp2 || rsPt.airline_name || rsPt.flight_no || ' ';

      vTemp2 := vTemp2 || rsPt.depart_airport_name  || replace(rsPt.depart_airport_tower, '-', '') || '(' || to_char(rsPt.take_off_time, 'HH24:FMMI') || ')'|| '-';

      vTemp2 := vTemp2 || rsPt.arrive_airport_name || replace(rsPt.arrive_airport_tower, '-', '') || '(' || to_char(rsPt.take_off_time, 'HH24:FMMI') || ')';

      --出发航站楼
      vTemplet3 := Replace(vTemplet3,'#AIRPORT#',rsPt.DEPART_AIRPORT_TOWER);
      --起飞时间
      vTemplet3 := Replace(vTemplet3,'#HOUR#',to_char(rsPt.take_off_time, 'FMHH24:FMMI'));
      --航班号
      vTemplet3 := Replace(vTemplet3,'#FLIGHTNO#',rsPt.FLIGHT_NO);
      --trip
      --select nvl((select city_name_cn from T_BASE_CITY where city_code = rsPt.depart_city_code and rownum <= 1),rsPt.depart_city_code) into vTemp7 from dual;
      --vTemp8 := vTemp7 || '-';
      --select nvl((select city_name_cn from T_BASE_CITY where city_code = rsPt.arrive_city_code and rownum <= 1),rsPt.arrive_city_code) into vTemp8 from dual;
      vTemp8 := rsPt.depart_City_Name || '--'||rsPt.Arrive_City_Name;
      vTemplet3 := Replace(vTemplet3,'#TRIP#',vTemp8);
      --计算发送时间
      vSendTime2 := rsPt.take_off_time - (1/24)*3;

      iNum7 := iNum7 + 1;
      str_list2(iNum7) := vTemp8;

      ---------------------------------------------------------------------
      ----分割旧行程，主要是针对多程改签
      ---------------------------------------------------------------------

      end loop;

  end loop ;



  /*for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER a1
                    where exists (select 0 from t_cc_inter_change_ticket a2
                        where a2.change_id = vIdConvert and a2.plane_ticket_no=a1.plane_ticket_no)
                        and state = '3') loop
      --更新原来的起飞提醒短信
      --先根据订单编号,查询到原订单的起飞提醒，然后更新
      for i in 1..str_list.count loop
        for cursor_order in (select * from T_BASE_MSG_AWAIT_QUEUE
              WHERE ORDER_NO = rsCjr.PLANE_ORDER_NO and PRIORITY = 4 and OBJECT_RECEIVE = Trim(rsCjr.Phone) and TEXT1 like '%'||str_list(i)||'%') loop
            --更新
          update T_BASE_MSG_AWAIT_QUEUE SET TEXT1 = str_list2(i),SEND_TIME = vSendTime2 where MID = cursor_order.MID;
        end loop;
      end loop;

  end loop;

  /*while(INSTR(vTemp7,';')>0) loop
    if instr(vTemp7,';')>0 then
        vTemp5 := SUBSTR(vTemp7,1,INSTR(vTemp7,';')-1);
        vTemp7 := SUBSTR(vTemp7, INSTR(vTemp7,';')+1 , LENGTH(vTemp7) - INSTR(vTemp7,';'));
    end if;


    end loop ;*/

  -------------------------------------------
  -- 获得联系人（申请人）手机和改签费用vTemp3
  -------------------------------------------
  for rsPc in (select * from t_cc_inter_plane_change where change_id = vIdConvert and state='3') loop

      --企业信息
      for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                            WHERE COMPANY_ID = rsPc.COMPANY_ID and rownum <= 1) loop
          vCompanyName := rsCompany.COMPANY_NAME;
          --判断是否要给预订人发短信
          if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
            vFlag1 := 1;
            select mobilephone into vOrderPhone from t_base_user where user_id=rsPc.Apply_User;
          else
            vFlag1 := 0;
          end if;
      end loop;

      --改签费用
      vTemp3 := rsPc.sale_price;
      --联系人电话
      select Contact_Phone into vContactPhone from t_cc_inter_plane_order where plane_order_no = rsPc.plane_order_no;

  end loop;

  --------------------------------------
  -- 新行程，获得乘机人信息
  --------------------------------------
  vTemp4 := '';
  iNum2  := 0;
  iNum3  := 0;
  for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER a1
                    where exists (select 0 from t_cc_inter_change_ticket a2
                        where a2.change_id = vIdConvert and a2.plane_ticket_no=a1.plane_ticket_no)
                        and state = '3') loop
    --乘机人手机
    vUserPhone := Trim(rsCjr.Phone);
    --改签订单号
    vOrderNo := rsCjr.plane_order_no;

    ----------------------------------------------------------------
    -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
    ----------------------------------------------------------------
    if NVL(vTemp4, 'N') != 'N' then vTemp4 := vTemp4 || '，'; end if;
    vTemp4 := vTemp4||rsCjr.LAST_NAME || '/' || rsCjr.FIRST_NAME;

    --给乘机人发短信
    select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_CHANGE_SUCCESS_TO_PASS';

    if vTemplet1 = 'N' then
      vErrorMsg := vErrorMsg || '(改签乘机人模板缺失)';
    end if;
    --vTemplet1 := Replace(vTemplet1, '#NAME#', rsCjr.LAST_NAME || '/' || rsCjr.FIRST_NAME);
    --vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsCjr.Plane_Ticket_No);
    --vTemplet1 := Replace(vTemplet1, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
    vTemplet1 := Replace(vTemplet1, '#FLIGHTNONEW#,#TIME#', vTemp2);

    iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

    if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
      vTemp5 := 'MSG_PLANE_INTER_FAIL_TO_PASS';
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet1,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
    end if;

    --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
    --vTemp6 := vTemp6 || '-' || iNum1;

  end loop;

  iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

  --给联系人或预订人发短信
  select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_CHANGE_SUCCESS_TO_LINK';

  if vTemplet2 = 'N' then
    vErrorMsg1 := vErrorMsg1 || '(改签乘机人模板缺失)';
  end if;
  vTemp5 :='MSG_PLANE_INTER_CHANGE_SUCCESS_TO_LINK';
  --vTemplet2 := Replace(vTemplet2, '#FLIGHTNOOLD##AIRPORT#', vTemp1);
  vTemplet2 := Replace(vTemplet2, '#FLIGHTNONEW#,#TIME#', vTemp2);
  vTemplet2 := Replace(vTemplet2, '#NAME#',vTemp4);
  /*
  vTemplet2 := Replace(vTemplet2, '#PRICE#',vTemp3);
  if vTemp3 is null or vTemp3 = '' then
    vErrorMsg1 := vErrorMsg1 || '(订单销价未获取)';
  end if;
*/
    if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
    end if;

    if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
    end if;

end if;



--********************国际机票退票成功 发送给乘机人、联系人或预订人********************************
--1.MSG_PLANE_INTER_REFUND_SUCCESS_TO_PASS
--2.您好，您的退票已完成，#TIME##FLIGHTNO##AIRPORT#，#NAME#票号#ORDERNO#，祝您生活愉快！网上退改更方便，服务电话：4007239888
--3.传递参数：

--1.MSG_PLANE_INTER_REFUND_SUCCESS_TO_LINK
--2.您好，您申请的退票已完成，#TIME##FLIGHTNO##AIRPORT#，#NAME##ORDERNO#，退还金额：#REFUNDFEE#，将在3-15个工作日退还到您的付款账户，谢谢您的支持！祝您生活愉快！网上退改更方便，服务电话：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_INTER_REFUND_SUCCESS_TO') then
--订单id
vIdConvert := convertStrToInt(vId, -1);
vOrderId := vId;
iNum1 := 0;
iNum2 := 0;

for rsRefundTicket in (
            select DISTINCT a.plane_ticket_id,a.idc_name,a.first_name,a.last_name,a.phone,a.plane_ticket_no,a.apply_user,a.refund_no,a.company_id, a.plane_order_no ,a.IS_FILL_ORDER from (
    select t3.plane_ticket_id, t3.idc_name, t3.first_name, t3.last_name, t3.phone,t3.plane_ticket_no, t1.apply_user,t1.refund_no,
    t1.plane_order_no,t1.company_id,t1.IS_FILL_ORDER,
    t6.plane_trip_id,t6.plane_od_id,t6.plane_order_id,t6.depart_city,t6.depart_city_code,
    t6.arrive_city,t6.arrive_city_code,t6.depart_airport,t6.depart_airport_code,t6.arrive_airport,t6.arrive_airport_code,
    t6.depart_airport_tower,t6.arrive_airport_tower,t6.take_off_time,t6.arrive_time,t6.flight_no

      from t_cc_inter_plane_refund     t1,
           t_cc_inter_refund_ticket    t2,
           t_cc_inter_ticket_passenger t3,
           t_cc_inter_ticket_od        t4,
           t_cc_inter_plane_od         t5,
           t_cc_inter_plane_trip       t6
     where t1.refund_id = t2.refund_id
       and t2.plane_ticket_id = t3.plane_ticket_id
       and t3.plane_ticket_id = t4.plane_ticket_id
       and t4.plane_od_id = t5.plane_od_id
       and t5.plane_od_id = t6.plane_od_id
       and t1.refund_id = vIdConvert
     order by t3.plane_ticket_id, t6.take_off_time asc
     )a
) loop

vOrderPhoneId := rsRefundTicket.apply_user;
iNum1 := iNum1 + 1 ;
--是否为补单
--vFlag := rsRefundTicket.IS_FILL_ORDER;

--预订人电话
for rsUser in(select * from t_base_user where user_id = vOrderPhoneId and rownum <= 1) loop
     vOrderPhone := rsUser.mobilephone;
end loop;

----------------------------------------------------------------
-- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
----------------------------------------------------------------
if NVL(vTemp2, 'N') != 'N' then
  vTemp2 := vTemp2 || ',';
end if;
vTemp2 := vTemp2 || rsRefundTicket.idc_name;

 if iNum2 < 1 then
    --查询一张票的多个行程
    for rsRefundTrip in(
                select t3.plane_ticket_id, t3.idc_name, t3.phone,t3.plane_ticket_no, t1.APPLY_USER,t6.*
        from t_cc_inter_plane_refund     t1,
             t_cc_inter_refund_ticket    t2,
             t_cc_inter_ticket_passenger t3,
             t_cc_inter_ticket_od        t4,
             t_cc_inter_plane_od         t5,
             t_cc_inter_plane_trip       t6
       where t1.refund_id = t2.refund_id
         and t2.plane_ticket_id = t3.plane_ticket_id
         and t3.plane_ticket_id = t4.plane_ticket_id
         and t4.plane_od_id = t5.plane_od_id
         and t5.plane_od_id = t6.plane_od_id
         and t1.refund_id = vIdConvert
         and t3.plane_ticket_id = rsRefundTicket.plane_ticket_id
       order by t3.plane_ticket_id, t6.take_off_time asc
    ) loop

      if NVL(vTemp3, 'N') != 'N' then
      vTemp3 := vTemp3 || '；';
      end if;
      vTemp3 := vTemp3 || to_char(rsRefundTrip.take_off_time, 'FMMM"月"DD"日"') ;

      vTemp3 := vTemp3 || rsRefundTrip.depart_airport_name || '-';

      vTemp3 := vTemp3 || rsRefundTrip.arrive_airport_name ;

      vTemp7 := rsRefundTrip.Depart_City_Name || '--' || rsRefundTrip.Arrive_City_Name ;

      --更新原来的起飞提醒短信
      --先根据订单编号,查询到原订单的起飞提醒，然后更新
      for cursor_order in (select * from T_BASE_MSG_AWAIT_QUEUE
        WHERE ORDER_NO = rsRefundTicket.plane_order_no and PRIORITY = 4 and OBJECT_RECEIVE = rsRefundTicket.phone and TEXT1 like '%'||vTemp7||'%') loop
          --更新
          update T_BASE_MSG_AWAIT_QUEUE SET M_STATE = '4' where MID = cursor_order.MID;
      end loop;

    end loop;

    iNum2 := iNum2 + 1;
    end if;

    if vTemp3 is null or vTemp3 = '' then
      vErrorMsg := vErrorMsg || '(订单行程信息未获取)';
    end if;

  ------------------------------
  --  获得乘机人模板并替换信息
  ------------------------------
  select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_REFUND_SUCCESS_TO_PASS';
  vTemplet1 := Replace(vTemplet1, '#NAME#', rsRefundTicket.last_name || '/' || rsRefundTicket.first_name);
  --vTemplet1 := Replace(vTemplet1, '#ORDERNO#',rsRefundTicket.plane_ticket_no);
  vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

  vUserPhone := NVL(rsRefundTicket.phone,'N');
  vOrderNo := rsRefundTicket.plane_order_no;

  --企业信息
  for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER,CONTACT_MOBILEPHONE from T_BASE_COMPANY
                        WHERE COMPANY_ID = rsRefundTicket.COMPANY_ID and rownum <= 1) loop
      vCompanyName := rsCompany.COMPANY_NAME;
      --判断是否要给预订人发短信
      if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
        vFlag1 := 1;
      else
        vFlag1 := 0;
        vOrderPhone := '';
      end if;
  end loop;

  --乘机人模板为空，则直接报错误短信
  if vTemplet1 is null or vTemplet1 = '' then
    vErrorMsg := vErrorMsg || '(乘机人模板为空)';
  end if;

  iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

  --给pass发送短信，补单不发送
  if vUserPhone is not null and Length(vUserPhone) = 11 and iNum1 = 1 then
    vTemp5 := 'MSG_PLANE_INTER_REFUND_SUCCESS_TO_PASS';
    vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet1,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
  end if;

  --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
  vTemp6 := vTemp6 || '-' || iNum1;

end loop;

--判断乘机人、预订人和联系人之间的联系
iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

--联系人模板
select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_REFUND_SUCCESS_TO_LINK';
vTemp5 := 'MSG_PLANE_INTER_REFUND_SUCCESS_TO_LINK';
--模板内容为空，则为错误短信
if vTemplet2 is null or vTemplet2 = '' then
  vErrorMsg1 := vErrorMsg1 || '(联系人模板为空)';
end if;

vTemplet2 := Replace(vTemplet2, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
vTemplet2 := Replace(vTemplet2, '#NAME#', vTemp2);
/*
iNum5 := 0;
iNum12 := 0;
for rsRefundTicket in (select sale_price,plane_ticket_id from t_cc_inter_refund_ticket where refund_id = vIdConvert) loop
    iNum5 := iNum5 + 1;
   for rsTicket in (select sale_price from t_cc_inter_ticket_passenger where PLANE_TICKET_ID = rsRefundTicket.plane_ticket_id ) loop
      iNum12 := rsTicket.sale_price - rsRefundTicket.sale_price;
   end loop;
end loop;
vTemplet2 := Replace(vTemplet2, '#REFUNDFEE#',iNum12*iNum5);

if vTemp3 is null or vTemp3 = '' then
  vErrorMsg1 := vErrorMsg1 || '(订单行程信息未获取)';
end if;
*/
--补单不发
  if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
    vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
  end if;

  if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
    vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
  end if;

end if;


--********************国际机票 支付完成提醒预订人********************************
--1.MSG_PLANE_INTER_PAY_REMIND
--2.您好，您的订单已生成，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
--3.传递参数：

--1.MSG_PLANE_INTER_PAY_REMIND_TO_KEFU
--2.有一笔#ORDERTYPE#订单已生成，订单号#ORDERNO#，预订公司：#COMPANY# ，预订人号码：#YDSJH#.
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_INTER_PAY_REMIND') then
  vIdConvert := convertStrToInt(vId, -1);
  vOrderId := vId;
  iNum1 := 0;
  if vIdConvert is null then
    vErrorMsg := vErrorMsg || '(订单id解析出错)';
  end if;
  --发给客服的短信模板
  select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';

  --获得行程信息，存入临时变量　vTemp3
  vTemp3 := '';
  for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop

    if NVL(vTemp3, 'N') != 'N' then
      vTemp3 := vTemp3 || '；';
    end if;
    vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
    vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');

    vTemp3 := vTemp3 || rs.airline_name || rs.airline_code || rs.flight_no || ' ';

    vTemp3 := vTemp3 || rs.depart_airport_name || replace(rs.depart_airport_tower, '-', '') || '-';

    vTemp3 := vTemp3 || rs.arrive_airport_name || replace(rs.arrive_airport_tower, '-', '');
  end loop;
  -------------------------------------------------------------------------------------------------

  for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
    iNum1 := 1;
    vTemp2 := '';
    --是否为补单
    --vFlag := rsPlaneOrder.IS_FILL_ORDER;
    vOrderNo := rsPlaneOrder.plane_order_no;
    --获得预订人号码
    select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'N') into vOrderPhone from dual;
    vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);

    --如果订单编号为空，则直接错误短信
    if vOrderNo is null or vOrderNo = '' then
      vErrorMsg := vErrorMsg || '(订单编号为空)';
    end if;
    --------------------------------------
    -- 获得企业信息 企业名称+是否给预订人发送短信
    --------------------------------------
    for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER,CONTACT_MOBILEPHONE from T_BASE_COMPANY
                          WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
        vCompanyName := rsCompany.COMPANY_NAME;

        --判断是否发给预订人
        if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
        else
          vFlag1 := 0;
          vOrderPhone := '';
        end if;
    end loop;


    --------------------------------------
    -- 乘机人表获得乘机人信息
    --------------------------------------
    for rsCjr in (select * from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vIdConvert) loop
      ----------------------------------------------------------------
      -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
      ----------------------------------------------------------------
      if NVL(vTemp2, 'N') != 'N' then
        vTemp2 := vTemp2 || ',';
      end if;
      vTemp2 := vTemp2||rsCjr.Idc_Name;

    end loop;

    ------------------------------
    --  获得预订人模板并替换信息
    ------------------------------
    select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_PAY_REMIND';
    if vTemplet1 is null or vTemplet1 = '' then
      vErrorMsg := vErrorMsg || '(预订人短信模板为空)';
    end if;
    -- vTemplet1 := Replace(vTemplet1, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
   -- vTemplet1 := Replace(vTemplet1, '#NAME#',vTemp2);
    vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

    --------------------------------
    vTemp5 := 'MSG_PLANE_INTER_PAY_REMIND';
    if vOrderPhone is not null and length(vOrderPhone) = 11 then
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
    end if;


    vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国际机票');
    vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
    vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);

    vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
    --给客服短信
    select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_PLANE';

    if vTemp = 'N' then
      vErrorMsg := vErrorMsg ||'(客服电话未获取)';
    end if;

      --开始循环分割字段
      while(length(vTemp)>0) loop
      --如果有逗号，以逗号进行分割
        if INSTR(vTemp,',' ) > 0 then
                vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
            --取到第n个逗号(也就是第n次循环)后面的剩余字符串
                vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
                vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                  vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
            --没有逗号，说明不需要分割
            else
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
              exit;
       end if;
      end loop;


end loop;
end if;


--********************国际机票 改签申请提醒 申请人*******************************
--1.MSG_PLANE_INTER_CHANGE_REMIND
--2.您好，您的改签申请已经收到，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_INTER_CHANGE_REMIND') then
--订单ID
vIdConvert := convertStrToInt(vId, -1);
vOrderId := vId;

iNum1 := 1;

for rsPlaneChange in (
  select t.change_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_INTER_PLANE_CHANGE t
    left join t_cc_inter_plane_order m on t.plane_order_id = m.plane_order_id
      where change_id = vIdConvert and rownum <= 1) loop
  iNum1 := 1;
  vTemp2 := '';

  --------------------------------------
  -- 获得所属模块+订单号+企业名称
  --------------------------------------
  vOrderNo := rsPlaneChange.plane_order_no;
  for rsCompany in (select * from T_base_company where company_id = rsPlaneChange.company_id and rownum <= 1) loop
     vCompanyName := rsCompany.company_name;
  end loop;
  --------------------------------------
  -- 获得申请人的手机号码
  --------------------------------------

  select nvl((select mobilephone from t_base_user where user_id=rsPlaneChange.apply_User and rownum<=1),'N') into vOrderPhone from dual;

  ------------------------------
  --  获得预订人模板并替换信息
  ------------------------------
  select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE ='MSG_PLANE_INTER_CHANGE_REMIND';

  vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);

  if vOrderNo is null or vOrderNo = '' then
    vErrorMsg := vErrorMsg ||'(订单编号未获取)';
  end if;

  if vTemplet1 is null or vTemplet1 = 'N' then
    vErrorMsg := vErrorMsg || '(申请人模板未获取)';
  end if;

  --------------------------------
  vTemp5 := 'MSG_PLANE_INTER_CHANGE_REMIND';
   if vOrderPhone is not null and length(vOrderPhone) = 11 then
    vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
     vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
   end if;

   ------------------------------
  --  给客服发送短信通知
  ------------------------------
  select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';
  vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
  vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国际机票改签');
  vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
  vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
  vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);
  --给客服小米短信
  select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
  if vTemp = 'N' then
    vErrorMsg1 := '(客服手机未获取)';
  end if;

  --开始循环分割字段
  while(length(vTemp)>0) loop
  --如果有逗号，以逗号进行分割
    if INSTR(vTemp,',' ) > 0 then
            vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
        --取到第n个逗号(也就是第n次循环)后面的剩余字符串
            vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
        --没有逗号，说明不需要分割
        else
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
          exit;
   end if;
  end loop;

end loop;
end if;


--********************国际机票 退票申请提醒 申请人*******************************
--1.MSG_PLANE_INTER_REFUND_REMIND
--2.您好，您的退票申请已经收到，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_PLANE_INTER_REFUND_REMIND') then
--订单ID
vIdConvert := convertStrToInt(vId, -1);
vOrderId := vId;

--iNum1 := 1;

for rsPlaneRefund in (
select t.refund_id,t.plane_order_id,m.plane_order_no,t.apply_user,t.company_id,t.is_fill_order from T_CC_INTER_PLANE_REFUND t
  left join t_cc_inter_plane_order m on t.plane_order_id = m.plane_order_id where refund_id = vIdConvert and rownum <= 1
) loop
iNum1 := 1;
vTemp2 := '';
--------------------------------------
-- 获得所属模块+订单号+企业名称
--------------------------------------
vOrderNo := rsPlaneRefund.plane_order_no;
for rsCompany in (select * from T_base_company where company_id = rsPlaneRefund.company_id and rownum <= 1) loop
   vCompanyName := rsCompany.company_name;
end loop;
--------------------------------------
-- 获得申请人的手机号码
--------------------------------------

select nvl((select mobilephone from t_base_user where user_id=rsPlaneRefund.apply_User and rownum<=1),'N') into vOrderPhone from dual;

------------------------------
--  获得预订人模板并替换信息
------------------------------
select nvl(Text1, 'N') into vTemplet1 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_REFUND_REMIND';

vTemplet1 := Replace(vTemplet1, '#ORDERNO#',vOrderNo);


--------------------------------
 if vOrderPhone is not null and length(vOrderPhone) = 11  then
 vTemp5 :='MSG_PLANE_INTER_REFUND_REMIND';
 vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
   vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
end if;

 ------------------------------
--  给客服发送短信通知
------------------------------
select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';
vTemp5 := 'MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';
vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','国际机票退票');
vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);
--给客服小米短信
select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';
if vTemp = 'N' then
  vErrorMsg1 := '(客服手机未获取)';
end if;

--开始循环分割字段
while(length(vTemp)>0) loop
--如果有逗号，以逗号进行分割
  if INSTR(vTemp,',' ) > 0 then
          vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
      --取到第n个逗号(也就是第n次循环)后面的剩余字符串
          vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
          vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
      --没有逗号，说明不需要分割
      else
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
        exit;
 end if;
end loop;

end loop;
end if;



--********************酒店支付完成 给预订人*******************************
--1.MSG_HOTEL_CIVIL_PAY_REMIND
--（客人姓名）， 5/25号入住成都紫菲hotel ，订单已经提交，正在为您处理中啦！谢谢!
--2.#NAME#，#INTIME#号入住#HOTELNAME#，订单已经提交，正在为您处理中！谢谢！
--3.传递参数：
--*****************************************************
if vCode in ('MSG_HOTEL_CIVIL_PAY_REMIND') then
  --订单id
  vOrderId := vId;
  vIdConvert := convertStrToInt(vId, -1);
  --模板未获取，直接报错
  if vTemplet is null or vTemplet = '' then
    vErrorMsg := vErrorMsg || '(模板未获取)';
  end if;

  for cursor_order in (select * from T_CH_HOTEL_ORDER_V2
                      where HOTEL_ORDER_ID = vIdConvert) loop
    --酒店订单编号
    vOrderNo := cursor_order.HOTEL_ORDER_NO;
    if vOrderNo is null or vOrderNo = '' then
      vErrorMsg := vErrorMsg || '订单号为空';
    end if;

    --获取预订人手机号
    select nvl((select mobilephone from t_base_user where user_id=cursor_order.Create_User and rownum<=1),'N') into vOrderPhone from dual;
    vTemp6 := vOrderPhone;

    if vOrderPhone is null or vOrderPhone = '' then
      vErrorMsg := vErrorMsg || '预订人手机号为空';
    end if;

    --获取企业信息
    for cursor_company in (select * from t_base_company where company_id = cursor_order.company_id and rownum <= 1) loop
        vCompanyName := cursor_company.company_name;

        --判断是否发给预订人
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
        else
          vFlag1 := 0;
          vOrderPhone := '';
        end if;
    end loop;

    --格式化入住时间
    vTemp4 := to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd');

    --若入住人姓名为空，则直接报错误短信
    if vTemp4 is null or vTemp4 = '' then
      vErrorMsg := vErrorMsg||'(酒店入住日期为空)';
    end if;
    ---------------------------------------------------------------------
    --生成预订人的短信内容
    ---------------------------------------------------------------------
    vTemplet := Replace(vTemplet,'#NAME#',cursor_order.CUSTOMER_NAMES);
    vTemplet := Replace(vTemplet,'#INTIME#',vTemp4);
    vTemplet := Replace(vTemplet,'#HOTELNAME#',cursor_order.HOTEL_NAME);

    if vOrderPhone is not null and length(vOrderPhone) = 11 then
      vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
    end if;

     ---------------------------------------------------------------------
  -- 发送给客服
  ---------------------------------------------------------------------
  select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';
  select nvl(value, 'N') into vTemp from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_HT';
  vTemp5 := 'MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';
  vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','酒店');
  vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
  vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
  vTemplet2 := Replace(vTemplet2, '#YDSJH#',vTemp6);

  --开始循环分割字段
  while(length(vTemp)>0) loop
  --如果有逗号，以逗号进行分割
    if INSTR(vTemp,',' ) > 0 then
            vContactPhone := SUBSTR(vTemp ,1,INSTR(vTemp,',') - 1 );
        --取到第n个逗号(也就是第n次循环)后面的剩余字符串
            vTemp := SUBSTR(vTemp,INSTR(vTemp,',') + 1 , LENGTH(vTemp) - INSTR(vTemp,','));
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
        --没有逗号，说明不需要分割
        else
        vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet2,vTemp,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
          exit;
   end if;
  end loop;

  end loop;


end if;


--********************酒店预订成功 给住宿人*******************************
--1.MSG_HOTEL_SUCCESS_TO_CUS
--  ** 5/25号入住成都紫菲hotel 单人间，1间1晚，总价298，不含早， 房间保留到18:00，预订已经成功，
-- 祝您旅途愉快！酒店地址 电话 ***，订单号：**，此单通过我司合作商艺龙预订，请直接报艺龙预订和姓名办理入住，
--    谢谢，网上预定更方便的，有问题请致电：4007239888
--2 #NAME# #INDATE#号入住#HTOELNAME# #ROOMTYPE#，#ROOMNUM#间#DAYNUM#晚，总价#PRICE#，不含早， 房间保留到#SAVETIME#，预订已经成功，
-- 祝您旅途愉快！酒店地址：#ADDRESS# 电话：#PHONE#，订单号：#ORDERNO#，此单通过我司合作商艺龙预订，请直接报艺龙预订和姓名办理入住，
--    谢谢，网上预定更方便的，有问题请致电：4007239888
--3.传递参数：

--********************酒店预订成功 给联系人*******************************
--1.MSG_HOTEL_SUCCESS_TO_LINK
--  您好，您为**客人预订  5/25号入住1晚1间  成都紫菲hotel 单人间 已经预订成功，感谢您的预订！
--  订单号：**此单通过我司合作商艺龙预订，请直接报艺龙预订和姓名办理入住，谢谢，已经短信通知旅客，网上预定更方便的，有问题请致电：4007239888
--2 您好，您为(#NAME#)预订  #INDATE#号入住#DAYNUM#晚#ROOMNUM#间 （#HOTELNAME#）#ROOMTYPE# 已经预订成功，感谢您的预订！
-- 订单号：#ORDERNO# ，此单通过我司合作商艺龙预订，请直接报艺龙预订和姓名办理入住，谢谢，已经短信通知旅客（若旅客预留手机号），网上预定更方便的，有问题请致电：4007239888
--3.传递参数：
--*****************************************************
--*****************************************************
if vCode in ('MSG_HOTEL_SUCCESS_TO_CUS') then
    if vTemplet is null then
      vErrorMsg := vErrorMsg || '(住宿人模板未获取)';
    end if;
    --订单ID
    vIdConvert := convertStrToInt(vId,-1);

    --解析酒店订单
    iNUm1 := 0;
    for cursor_order in (select * from T_CH_HOTEL_ORDER_V2 where HOTEL_ORDER_ID = vIdConvert and STATE = '3') loop

      --订单号
      vOrderNo := cursor_order.HOTEL_ORDER_NO;
      if vOrderNo is null or vOrderNo = '' then
        vErrorMsg := vErrorMsg || '订单号为空';
      end if;

      --企业Id
      vCompanyId := cursor_order.COMPANY_ID;
      --预定人手机号
      select mobilephone into vOrderPhone from t_base_user where user_id = cursor_order.CREATE_USER ;
      --联系人手机号
      vContactPhone := cursor_order.CONTACT_MOBILE ;

      --企业信息
      for cursor_company in (select * from T_BASE_COMPANY where COMPANY_ID = cursor_order.COMPANY_ID) loop

        vCompanyName := cursor_company.COMPANY_NAME;

        --判断是否发给预订人
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
        else
          vFlag1 := 0;
          vOrderPhone := '';
        end if;

      end loop;

      --根据HOTEL_ORDER_ID 查询房间数量
      select count(*) into iNum1 from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID;

       --判断当前时间是否已经过了入住时间
       if sysdate <= cursor_order.LATEST_ARRIVAL_TIME then
          for cursor_room in (select * from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID) loop
            iNum1 := iNum1 + 1;
            --查询对应入住人模板
            select nvl(Text1, 'N') into vTemplet from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_SUCCESS_TO_CUS';
            --根据roomid 查询房间
            for cursor_cust in (select * from T_CH_HOTEL_ORDER_CUSTOMER_V2 where ORDER_ROOM_ID = cursor_room.ORDER_ROOM_ID) loop
                if cursor_cust.IS_USER = 1 then
                    for cusor_user in (select mobilephone,name_cn,PINYIN_FULL from t_base_user where user_id = cursor_cust.CUSTOMER_ID) loop
                        vUserPhone := cusor_user.mobilephone;
                        if cusor_user.name_cn is not null then
                            vTemp2 := cusor_user.name_cn;
                        else
                            vTemp2 := cusor_user.PINYIN_FULL;
                        end if;
                    end loop;
                else
                    for cusor_user in (select mobilephone,NAME,FULL_NAME from T_BASE_GENERAL_CONTACT where CONTACT_ID = cursor_cust.CUSTOMER_ID) loop
                        vUserPhone := cusor_user.mobilephone;
                        if cusor_user.NAME is not null then
                            vTemp2 := cusor_user.NAME;
                        else
                            vTemp2 := cusor_user.FULL_NAME;
                        end if;
                    end loop;
                end if;

                iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

                --
                vTemplet := Replace(vTemplet,'#NAME#',vTemp2);      --入住人姓名
                vTemplet := Replace(vTemplet,'#INDATE#',to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd'));      --入住时间
                vTemplet := Replace(vTemplet,'#DAYNUM#',cursor_order.CHECKIN_DAYS);      --入住天数
                vTemplet := Replace(vTemplet,'#ROOMNUM#',iNum1);  --房间数
                vTemplet := Replace(vTemplet,'#HOTELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
                vTemplet := Replace(vTemplet,'#ADDRESS#',cursor_order.HOTEL_ADDRESS);    --酒店地址
                vTemplet := Replace(vTemplet,'#SAVETIME#',cursor_order.LATEST_ARRIVAL_TIME);   --最晚入住时间
                vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);   --订单号
                vTemplet := Replace(vTemplet,'#TEL#',cursor_order.HOTEL_PHONE);               --酒店联系方式

                iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

                -- 发送给入住人
                if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then
                  vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                    vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
                end if;
            end loop;
          end loop;
       end if;

       --发送给预订人联系人
       --查询对应模板
       select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_SUCCESS_TO_LINK';

       vTemplet2 := Replace(vTemplet2,'#NAME#',cursor_order.CUSTOMER_NAMES);      --入住人姓名
       vTemplet2 := Replace(vTemplet2,'#INDATE#',to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd'));      --入住时间
       vTemplet2 := Replace(vTemplet2,'#DAYNUM#',cursor_order.CHECKIN_DAYS);      --入住天数
       vTemplet2 := Replace(vTemplet2,'#ROOMNUM#',iNum1);  --房间数
       vTemplet2 := Replace(vTemplet2,'#HOTELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
       vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);   --订单号

       iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

       --发送给联系人
       if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then
         vResult := smsGeneralInterface('MSG_HOTEL_SUCCESS_TO_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
           vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,0);
       end if;

       if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then
         vResult := smsGeneralInterface('MSG_HOTEL_SUCCESS_TO_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
           vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
       end if;
    end loop;
end if;


--********************担保酒店预订成功 给住宿人*******************************
--1.MSG_HOTEL_ENSURE_SUCCESS_TO_CUS
--  担保订单：确认 ** 5/27号 入住莫泰168（杭州地铁站店）单人间，1间，总价189元，房间保留至次日中午12点不能取消修改，
--  未入住将扣除首日房费。（酒店地址 电话）订单号：** 此单通过我司合作商预订，请直接报姓名办理入住， 网上预定更方便，有问题请致电：4007239888
--2 担保订单：确认 #NAME# #INDATE#号 入住#HOTELNAME# #ROOMTYPE#，1间，总价#PRICE#元，房间保留至次日中午12点不能取消修改，
--    未入住将扣除首日房费。（酒店地址:#ADDRESS# 电话:#TEL#）订单号：#ORDERNO# 此单通过我司合作商预订，请直接报姓名办理入住，
--     网上预定更方便，有问题请致电：4007239888
--3.传递参数：
--*****************************************************

--********************担保酒店预订成功 给联系人*******************************
--1.MSG_HOTEL_ENSURE_SUCCESS_TO_LINK
--  您好，您为 ** 预订，5/27号 入住莫泰168（杭州地铁站店）单人间，1间，房间保留至次日中午12点不能取消修改，未入住将扣除首日房费。订单号：** 网上预定更方便的，有问题请致电：4007239888
--2 您好，您为 #NAME# 预订，#INDATE#号 入住#HOTELNAME# #ROOMTYPE#，1间，房间保留至次日中午12点不能取消修改，未入住将扣除首日房费。订单号：#ORDERNO# 网上预定更方便的，有问题请致电：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_HOTEL_ENSURE_SUCCESS_TO_CUS') then
  if vTemplet is null then
    vErrorMsg := vErrorMsg || '(住宿人模板未获取)';
  end if;
  --订单ID
  vIdConvert := convertStrToInt(vId,-1);

  --解析酒店订单
  iNUm1 := 0;
  for cursor_order in (select * from T_CH_HOTEL_ORDER_V2 where HOTEL_ORDER_ID = vIdConvert and STATE = '3') loop

    --订单号
    vOrderNo := cursor_order.HOTEL_ORDER_NO;
    --企业Id
    vCompanyId := cursor_order.COMPANY_ID;
    --预定人手机号
    select mobilephone into vOrderPhone from t_base_user where user_id = cursor_order.CREATE_USER ;
    --联系人手机号
    vContactPhone := cursor_order.CONTACT_MOBILE ;

    --企业信息
    for cursor_company in (select * from T_BASE_COMPANY where COMPANY_ID = cursor_order.COMPANY_ID) loop

      vCompanyName := cursor_company.COMPANY_NAME;

      --判断是否发给预订人
      if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
        vFlag1 := 1;
      else
        vFlag1 := 0;
        vOrderPhone := '';
      end if;

    end loop;

    --根据HOTEL_ORDER_ID 查询房间数量
    select count(*) into iNum1 from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID;

     --判断当前时间是否已经过了入住时间
     if sysdate <= cursor_order.LATEST_ARRIVAL_TIME then
        for cursor_room in (select * from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID) loop
          iNum1 := iNum1 + 1;
          --房型
          if vTemp3 is not null then
            vTemp3 := vTemp3 ||',';
          end if;
          vTemp3 := vTemp3 || cursor_room.ROOM_NAME;
          --查询对应入住人模板
          select nvl(Text1, 'N') into vTemplet from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_ENSURE_SUCCESS_TO_CUS';
          --根据roomid 查询房间
          for cursor_cust in (select * from T_CH_HOTEL_ORDER_CUSTOMER_V2 where ORDER_ROOM_ID = cursor_room.ORDER_ROOM_ID) loop
              if cursor_cust.IS_USER = 1 then
                  for cusor_user in (select mobilephone,name_cn,PINYIN_FULL from t_base_user where user_id = cursor_cust.CUSTOMER_ID) loop
                      vUserPhone := cusor_user.mobilephone;
                      if cusor_user.name_cn is not null then
                          vTemp2 := cusor_user.name_cn;
                      else
                          vTemp2 := cusor_user.PINYIN_FULL;
                      end if;
                  end loop;
              else
                  for cusor_user in (select mobilephone,NAME,FULL_NAME from T_BASE_GENERAL_CONTACT where CONTACT_ID = cursor_cust.CUSTOMER_ID) loop
                      vUserPhone := cusor_user.mobilephone;
                      if cusor_user.NAME is not null then
                          vTemp2 := cusor_user.NAME;
                      else
                          vTemp2 := cusor_user.FULL_NAME;
                      end if;
                  end loop;
              end if;

              iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

              --
              vTemplet := Replace(vTemplet,'#NAME#',vTemp2);      --入住人姓名
              vTemplet := Replace(vTemplet,'#INDATE#',to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd'));      --入住时间
              vTemplet := Replace(vTemplet,'#DAYNUM#',cursor_order.CHECKIN_DAYS);      --入住天数
              vTemplet := Replace(vTemplet,'#ROOMNUM#',iNum1);  --房间数
              vTemplet := Replace(vTemplet,'#HOTELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
              vTemplet := Replace(vTemplet,'#ADDRESS#',cursor_order.HOTEL_ADDRESS);    --酒店地址
              vTemplet := Replace(vTemplet,'#SAVETIME#',cursor_order.LATEST_ARRIVAL_TIME);   --最晚入住时间
              vTemplet := Replace(vTemplet,'#ORDERNO#',cursor_order.HOTEL_ORDER_NO);   --订单号
              vTemplet := Replace(vTemplet,'#TEL#',cursor_order.HOTEL_PHONE);               --酒店联系方式
              vTemplet := Replace(vTemplet,'#ROOMTYPE#',cursor_room.ROOM_NAME);                 --房型名称

              -- 发送给入住人
              if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then
                vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                  vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
              end if;
          end loop;
        end loop;
     end if;

     --发送给预订人联系人
     --查询对应模板
     select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_ENSURE_SUCCESS_TO_LINK';

     vTemplet2 := Replace(vTemplet2,'#NAME#',cursor_order.CUSTOMER_NAMES);      --入住人姓名
     vTemplet2 := Replace(vTemplet2,'#INDATE#',to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd'));      --入住时间
     vTemplet2 := Replace(vTemplet2,'#DAYNUM#',cursor_order.CHECKIN_DAYS);      --入住天数
     vTemplet2 := Replace(vTemplet2,'#ROOMNUM#',iNum1);  --房间数
     vTemplet2 := Replace(vTemplet2,'#HOTELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
     vTemplet2 := Replace(vTemplet2,'#ORDERNO#',cursor_order.HOTEL_ORDER_NO);   --订单号
     vTemplet2 := Replace(vTemplet2,'#ROOMTYPE#',vTemp3);                         --房型

     iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

     --发送给联系人
     if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11  then
       vResult := smsGeneralInterface('MSG_HOTEL_SUCCESS_TO_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
         vOrderId,vCompanyId,vTemplet2,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
     end if;

     if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then
       vResult := smsGeneralInterface('MSG_HOTEL_SUCCESS_TO_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
         vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,0);
     end if;
  end loop;
end if;


--********************预付酒店预订成功 给住宿人*******************************
--1.MSG_HOTEL_ADVANCE_SUCCESS_TO_CUS
--  预付订单：确认 ** 5/27号 入住莫泰168（杭州地铁站店）单人间，1间，总价189元，房间保留至次日中午12点不能取消修改，未入住将扣除房费。（酒店地址 电话）订单号：** 此单通过我司合作商预订，请直接报姓名办理入住， 网上预定更方便，有问题请致电：4007239888
--2 预付订单：#NAME# #INDATE#号 入住#HTOELNAME# #ROOMTYPE#，1间，房间保留至次日中午12点不能取消修改，未入住将扣除房费.
-- 酒店地址:#ADDRESS# 电话:#TEL#。订单号：#ORDERNO# 此单通过我司合作商预订，请直接报姓名办理入住， 服务热线：4007239888
--3.传递参数：
--*****************************************************

--********************预付酒店预订成功 给联系人*******************************
--1.MSG_HOTEL_ADVANCE_SUCCESS_TO_LINK
--  您好，您为 ** 预订，5/27号 入住莫泰168（杭州地铁站店）单人间，1间，房间保留至次日中午12点不能取消修改，未入住将扣除首日房费，提前离店需要扣除提前离店当晚的费用。订单号：**   网上预定更方便的，有问题请致电：4007239888
--2 您为 #NAME# 预订，#INDATE#号 入住#HOTELNAME# #ROOMTYPE#，#ROOMNUM#间，总价#PRICE#元，房间保留至次日中午12点不能取消修改，未入住将扣除房费。酒店地址:#ADDRESS# 电话:#TEL#。订单号：#ORDERNO#，服务热线：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_HOTEL_ADVANCE_SUCCESS_TO_CUS') then
  if vTemplet is null then
    vErrorMsg := vErrorMsg || '(住宿人模板未获取)';
  end if;
  --订单ID
  vIdConvert := convertStrToInt(vId,-1);

  --解析酒店订单
  iNUm1 := 0;
  for cursor_order in (select * from T_CH_HOTEL_ORDER_V2 where HOTEL_ORDER_ID = vIdConvert and STATE = '3') loop

    --订单号
    vOrderNo := cursor_order.HOTEL_ORDER_NO;
    --企业Id
    vCompanyId := cursor_order.COMPANY_ID;
    --预定人手机号
    if cursor_order.CREATE_USER is not null then
      select mobilephone into vOrderPhone from t_base_user where user_id = cursor_order.CREATE_USER ;
    end if;
    --联系人手机号
    vContactPhone := cursor_order.CONTACT_MOBILE ;
    --企业信息
    for cursor_company in (select * from T_BASE_COMPANY where COMPANY_ID = cursor_order.COMPANY_ID) loop

      vCompanyName := cursor_company.COMPANY_NAME;

      --判断是否发给预订人
      if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
        vFlag1 := 1;
      else
        vFlag1 := 0;
        vOrderPhone := '';
      end if;

    end loop;

    --根据HOTEL_ORDER_ID 查询房间数量
    select count(*) into iNum1 from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID;

     --判断当前时间是否已经过了入住时间
     if sysdate <= cursor_order.LATEST_ARRIVAL_TIME then
        --预订房间数
        select count(*) into iNum1 from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID;

        for cursor_room in (select * from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID) loop

          --房型
          vTemp3 :=  cursor_room.ROOM_NAME;
          --根据roomid 查询房间
          iNum4 := 0;
          for cursor_cust in (select * from T_CH_HOTEL_ORDER_CUSTOMER_V2 where ORDER_ROOM_ID = cursor_room.ORDER_ROOM_ID) loop

          --查询对应入住人模板
          select nvl(Text1, 'N') into vTemplet from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_ADVANCE_SUCCESS_TO_CUS';
              if cursor_cust.IS_USER = 1 then
                  for cusor_user in (select mobilephone,name_cn,PINYIN_FULL from t_base_user where user_id = cursor_cust.CUSTOMER_ID) loop
                      vUserPhone := cusor_user.mobilephone;
                      if cusor_user.name_cn is not null then
                          vTemp2 := cusor_user.name_cn;
                      else
                          vTemp2 := cusor_user.PINYIN_FULL;
                      end if;
                  end loop;
              else
                  for cusor_user in (select mobilephone,NAME,FULL_NAME from T_BASE_GENERAL_CONTACT where CONTACT_ID = cursor_cust.CUSTOMER_ID) loop
                      vUserPhone := cusor_user.mobilephone;
                      if cusor_user.NAME is not null then
                          vTemp2 := cusor_user.NAME;
                      else
                          vTemp2 := cusor_user.FULL_NAME;
                      end if;
                  end loop;
              end if;

              iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

              --
              vTemplet := Replace(vTemplet,'#NAME#',vTemp2);      --入住人姓名
              vTemplet := Replace(vTemplet,'#INDATE#',to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd'));      --入住时间
              vTemplet := Replace(vTemplet,'#DAYNUM#',cursor_order.CHECKIN_DAYS);      --入住天数
              vTemplet := Replace(vTemplet,'#ROOMNUM#',iNum1);  --房间数
              vTemplet := Replace(vTemplet,'#HTOELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
              vTemplet := Replace(vTemplet,'#ADDRESS#',cursor_order.HOTEL_ADDRESS);    --酒店地址
              vTemplet := Replace(vTemplet,'#SAVETIME#',cursor_order.LATEST_ARRIVAL_TIME);   --最晚入住时间
              vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);   --订单号
              vTemplet := Replace(vTemplet,'#TEL#',cursor_order.HOTEL_PHONE);               --酒店联系方式
              vTemplet := Replace(vTemplet,'#ROOMTYPE#',cursor_room.ROOM_NAME);                 --房型名称

              -- 发送给入住人
              if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then
                vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                  vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
              end if;
          end loop;
        end loop;
     end if;

     --发送给预订人联系人
     --查询对应模板
     select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_ADVANCE_SUCCESS_TO_LINK';

     vTemplet2 := Replace(vTemplet2,'#NAME#',cursor_order.CUSTOMER_NAMES);      --入住人姓名
     vTemplet2 := Replace(vTemplet2,'#INDATE#',to_char(cursor_order.ARRIVAL_DATE,'mm') || '/' || to_char(cursor_order.ARRIVAL_DATE,'dd'));      --入住时间
     vTemplet2 := Replace(vTemplet2,'#DAYNUM#',cursor_order.CHECKIN_DAYS);      --入住天数
     vTemplet2 := Replace(vTemplet2,'#ROOMNUM#',iNum1);  --房间数
     vTemplet2 := Replace(vTemplet2,'#HOTELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
     vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);   --订单号
     vTemplet2 := Replace(vTemplet2,'#ROOMTYPE#',vTemp3);                         --房型
     vTemplet2 := Replace(vTemplet2,'#PRICE#',cursor_order.SALE_PRICE);          -- 订单价格
     vTemplet2 := Replace(vTemplet2,'#HTOELNAME#',cursor_order.HOTEL_NAME);     --酒店名称
     vTemplet2 := Replace(vTemplet2,'#ADDRESS#',cursor_order.HOTEL_ADDRESS);    --酒店地址
     vTemplet2 := Replace(vTemplet2,'#TEL#',cursor_order.HOTEL_PHONE);               --酒店联系方式

     iNum1 := judgeSendObject(vOrderPhone,vContactPhone);
     --发送给联系人
     if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then
       vResult := smsGeneralInterface('MSG_HOTEL_SUCCESS_TO_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
         vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
     end if;

     if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then
       vResult := smsGeneralInterface('MSG_HOTEL_SUCCESS_TO_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
         vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,0);
     end if;
  end loop;
end if;


--*******************日班暂缓 发送给入住人********************************
--1.MSG_HOTEL_DAY_DELAY_TO_CUS
-- 示例： 您预订的**酒店，罗盘正在帮您火速联系酒店中啦，请您稍等了，感谢您的预定。订单号：**
-- 模板： 您预订的#HOTELNAME#，罗盘正在帮您火速联系酒店中，请您稍候，感谢您的预定。订单号：#ORDERNO#。
--3.传递参数：
--*****************************************************
if vCode in ('MSG_HOTEL_DAY_DELAY_TO_CUS') then
    if vTemplet is null then
      vErrorMsg := vErrorMsg || '(住宿人模板未获取)';
    end if;
    --订单ID
    vIdConvert := convertStrToInt(vId,-1);
    --酒店订单详情
    for cursor_order in (select * from T_CH_HOTEL_ORDER_V2 where HOTEL_ORDER_ID = vIdConvert) loop
      --酒店订单号
      vOrderNo := cursor_order.HOTEL_ORDER_NO;

      for cursor_room in (select * from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID) loop
        --查询对应入住人模板
        select nvl(Text1, 'N') into vTemplet from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_ADVANCE_SUCCESS_TO_CUS';
        --根据roomid 查询房间
        for cursor_cust in (select * from T_CH_HOTEL_ORDER_CUSTOMER_V2 where ORDER_ROOM_ID = cursor_room.ORDER_ROOM_ID) loop
            if cursor_cust.IS_USER = 1 then
                for cusor_user in (select mobilephone,name_cn,PINYIN_FULL from t_base_user where user_id = cursor_cust.CUSTOMER_ID) loop
                    vUserPhone := cusor_user.mobilephone;
                end loop;
            else
                for cusor_user in (select mobilephone,NAME,FULL_NAME from T_BASE_GENERAL_CONTACT where CONTACT_ID = cursor_cust.CUSTOMER_ID) loop
                    vUserPhone := cusor_user.mobilephone;
                end loop;
            end if;

            vTemplet := Replace(vTemplet,'#HOTELNAME#',cursor_order.HOTEL_NAME);
            vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);

            -- 发送给入住人
            if vUserPhone is not null and length(vUserPhone) = 11 then
              vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
                vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
            end if;
          end loop;
      end loop;
    end loop;
end if;
--*******************日班暂缓 发送给预订人********************************
--1.MSG_HOTEL_DAY_DELAY_TO_LINK
-- 示例： 您为**客人预订的**酒店，罗盘正在帮您火速联系酒店中啦，请您的旅客稍等了，感谢您的理解与支持。订单号：**
-- 模板： 您为#CUSNAME#客人预订的#HOTELNAME#，罗盘正在帮您火速联系酒店中啦，请您的旅客稍等了，感谢您的理解与支持。订单号：#ORDERNO#
--3.传递参数：
--*****************************************************

--*******************中班暂缓 发送给预订人********************************
--1.MSG_HOTEL_MID_DELAY_TO_LINK
-- 示例： 您为**客人预订的**酒店，罗盘正在帮您火速联系酒店中，请您的旅客稍候，感谢您的理解与支持。订单号：**
-- 模板： 您为#CUSNAME#客人预订的#HOTELNAME#，罗盘正在帮您火速联系酒店中啦，请您的旅客稍等了，感谢您的理解与支持。订单号：#ORDERNO#
--3.传递参数：
--*****************************************************

--*******************满房取消 发送给入住人********************************
--1.MSG_HOTEL_NOROOM_CANCEL_TO_CUS
-- 示例： 您预订的*月*号入住**酒店已经没房,未联系到您，订单已经取消，请您在网上重新预订，罗盘深表歉意，感谢您的预订与支持。订单号：** 有问题请致电：4007239888
-- 模板： 您预订的#INDATE#入住#HOTELNAME#已经没房,未联系到您，订单已经取消，请您在网上重新预订，罗盘深表歉意，感谢您的预订与支持。订单号：#ORDERNO# 有问题请致电：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_HOTEL_NOROOM_CANCEL_TO_CUS') then
  if vTemplet is null then
    vErrorMsg := vErrorMsg || '(住宿人模板未获取)';
  end if;
  --订单ID
  vIdConvert := convertStrToInt(vId,-1);

  --酒店订单详情
  for cursor_order in (select * from T_CH_HOTEL_ORDER_V2 where HOTEL_ORDER_ID = vIdConvert) loop
    --酒店订单号
    vOrderNo := cursor_order.HOTEL_ORDER_NO;
    --预订人
    select mobilephone into vOrderPhone from t_base_user where user_id = cursor_order.CREATE_USER;
    --联系人
    vContactPhone := cursor_order.CONTACT_MOBILE;
    --企业信息
    for cursor_company in (select * from T_BASE_COMPANY where COMPANY_ID = cursor_order.COMPANY_ID) loop
        vCompanyName := cursor_company.COMPANY_NAME;

        --判断是否发给预订人
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
        else
          vFlag1 := 0;
          vOrderPhone := '';
        end if;
    end loop;

    for cursor_room in (select * from T_CH_HOTEL_ORDER_ROOM_V2 where HOTEL_ORDER_ID = cursor_order.HOTEL_ORDER_ID) loop
      --查询对应入住人模板 根据不同的取消原因选择推送模板
      if vRemark = 'O' or vRemark = 'U' then --满房取消
          select nvl(Text1, 'N') into vTemplet from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_NOROOM_CANCEL_TO_CUS';
      elsif vRemark = 'G' then
          select nvl(Text1, 'N') into vTemplet from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_CHANGE_CANCEL_TO_CUS';
      end if;

      --根据roomid 查询房间
      for cursor_cust in (select * from T_CH_HOTEL_ORDER_CUSTOMER_V2 where ORDER_ROOM_ID = cursor_room.ORDER_ROOM_ID) loop
          if cursor_cust.IS_USER = 1 then
              for cusor_user in (select mobilephone,name_cn,PINYIN_FULL from t_base_user where user_id = cursor_cust.CUSTOMER_ID) loop
                  vUserPhone := cusor_user.mobilephone;
              end loop;
          else
              for cusor_user in (select mobilephone,NAME,FULL_NAME from T_BASE_GENERAL_CONTACT where CONTACT_ID = cursor_cust.CUSTOMER_ID) loop
                  vUserPhone := cusor_user.mobilephone;
              end loop;
          end if;

          if vRemark = 'O' or vRemark = 'U' then --满房取消
            vTemplet := Replace(vTemplet,'#HOTELNAME#',cursor_order.HOTEL_NAME);
            vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
            vTemp5 := 'MSG_HOTEL_NOROOM_CANCEL_TO_CUS';
          elsif vRemark = 'G' then
            vTemplet := Replace(vTemplet,'#INDATE#',cursor_order.ARRIVAL_DATE);
            vTemplet := Replace(vTemplet,'#HOTELNAME#',cursor_order.HOTEL_NAME);
            vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
            vTemp5 := 'MSG_HOTEL_CHANGE_CANCEL_TO_CUS';
          end if;

            iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

          -- 发送给入住人
          if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then
            vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
              vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
          end if;

        end loop;
    end loop;

    --生成联系人、预订人短信
    if vRemark = 'O' or vRemark = 'U' then --满房取消
      select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_NOROOM_CANCEL_TO_LINK';
      vTemplet2 := Replace(vTemplet2,'#CUSNAME#',cursor_order.CUSTOMER_NAMES);
      vTemplet2 := Replace(vTemplet2,'#HOTELNAME#',cursor_order.HOTEL_NAME);
      vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);
      vTemp5 := 'MSG_HOTEL_NOROOM_CANCEL_TO_CUS';
    else if vRemark = 'G' then
      select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_HOTEL_CHANGE_CANCEL_TO_LINK';
      vTemplet2 := Replace(vTemplet2,'#CUSNAME#',cursor_order.CUSTOMER_NAMES);
      vTemplet2 := Replace(vTemplet2,'#INDATE#',cursor_order.ARRIVAL_DATE);
      vTemplet2 := Replace(vTemplet2,'#HOTELNAME#',cursor_order.HOTEL_NAME);
      vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);
      vTemp5 := 'MSG_HOTEL_CHANGE_CANCEL_TO_CUS';
    end if;

    iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

    --发送给联系人
    if vContactPhone is not null and length(vContactPhone) = 11 and iNum1 in (2,3) then
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,0);
    end if;

    --发送给预订人
    if vOrderPhone is not null and length(vOrderPhone) = 11 and iNum1 in (1,3) then
      vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
    end if;
  end if;
  end loop;
end if;

--*******************满房取消 发送给入住人********************************
--1.MSG_HOTEL_NOROOM_CANCEL_TO_LINK
-- 示例： 您为**客人预订的**酒店已经没房了，订单已经取消，已经短信通知入住人，请您帮您的旅客在网上重新预订啦，罗盘深表歉意中，感谢您的预订与支持。订单号：**有问题请致电：4007239888
-- 模板： 您为#CUSNAME#客人预订的#HOTELNAME#已经没房了，订单已经取消，已经短信通知入住人，请您帮您的旅客在网上重新预订啦，罗盘深表歉意，感谢您的预订与支持。订单号：#ORDERNO#，有问题请致电：4007239888
--3.传递参数：
--*****************************************************

--*******************变价取消 发送给入住人********************************
--1.MSG_HOTEL_CHANGE_CANCEL_TO_CUS
-- 示例： 您预订的*月*号入住**酒店，预订时间太早了，酒店还未更新价格，无法为您预订，因未联系到您，订单已经取消，罗盘正在努力敦促酒店更改价格中，如有需要请在网上预订重新预订，感谢您的预订与支持。订单号：**  有问题请致电：4007239888
-- 模板： 您预订的#INDATE#入住#HOTELNAME#，预订时间太早了，酒店还未更新价格，无法为您预订，因未联系到您，订单已经取消，罗盘正在努力敦促酒店更改价格中，如有需要请在网上预订重新预订，感谢您的预订与支持。订单号：#ORDERNO#  有问题请致电：4007239888
--3.传递参数：
--*****************************************************

--*******************变价取消 发送给联系人********************************
--1.MSG_HOTEL_CHANGE_CANCEL_TO_LINK
-- 示例： 您为**客人预订的*月*号入住**酒店，酒店价格不正确，因未联系到您，订单已经取消，罗盘深感歉意，罗盘正在努力敦促酒店更改价格中，如有需要请在网上为您的客人重新预订，感谢您的预订与支持。订单号：**  有问题请致电：4007239888
-- 模板： 您为#CUSNAME#客人预订的#INDATE#入住#HOTELNAME#，酒店价格不正确，因未联系到您，订单已经取消，罗盘深感歉意，罗盘正在努力敦促酒店更改价格中，如有需要请在网上为您的客人重新预订，感谢您的预订与支持。订单号：**  有问题请致电：4007239888
--3.传递参数：
--*****************************************************



--********************火车票订单支付成功 提醒预订人*******************************
--1.MSG_TRAIN_PAY_REMIND
--  *月*号 **乘客，16:04苏州-17:05到上海 二等座1张 ，订单已经提交，已经为您处理中啦！谢谢您
--2 (#DATE#，#NAME#乘客，#TRIP#，#level# #TICKETS#张)，订单已经提交，正在为您处理中！谢谢！
--3.传递参数：
--***************************************************************************
if vCode in ('MSG_TRAIN_PAY_REMIND') then
  if vTemplet is null or vTemplet = '' then
    vErrorMsg := vErrorMsg || '(模板未获取)';
  end if;
  --订单id
  vIdConvert := convertStrToInt(vId,-1);

  --解析火车票行程
  for cursor_trip in (select * from t_cc_train_trip where train_order_id = vIdConvert) loop
    --出发时间 月 日
    vTemp := to_char(cursor_trip.DEPART_DATE,'mm')||'月'||to_char(cursor_trip.DEPART_DATE,'dd')||'日';
    --生成行程信息
    vTemp1 := vTemp1 || cursor_trip.DEPART_TIME || cursor_trip.DEPART_STATION || '-';
    vTemp1 := vTemp1 || cursor_trip.ARRIVE_TIME || cursor_trip.ARRIVE_STATION ;
    --订单号
    vOrderNo := cursor_trip.TRAIN_ORDER_NO;
    --座位等级
    if cursor_trip.SEAT_TYPE_CODE is not null then
        vTemp2 := getTrainSeatLevel(cursor_trip.SEAT_TYPE_CODE);
    end if;

    --预订人信息
    for cursor_order in (select Create_User_Id from T_CC_TRAIN_ORDER WHERE TRAIN_ORDER_ID = vIdConvert) loop
        select nvl((select mobilephone from t_base_user where user_id=cursor_order.Create_User_Id and rownum<=1),'N') into vOrderPhone from dual;
    end loop;
    vTemp8 := vOrderPhone;

    --获取企业信息
    for cursor_company in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER FROM T_BASE_COMPANY
                                WHERE COMPANY_ID = cursor_trip.COMPANY_ID) loop
        --企业名称
        vCompanyName := cursor_company.COMPANY_NAME;
        --判断是否要给预订人发送短信
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
            vFlag1 := 1;
        else
            vFlag1 := 0;
            vOrderPhone := '';
        end if;
    end loop;

  end loop;

  --若行程信息为空，则直接报错误短信
  if vTemp is null or vTemp = '' then
    vErrorMsg := vErrorMsg || '(出发时间未获取)';
  end if;
  if vTemp1 is null or vTemp1 = '' then
    vErrorMsg := vErrorMsg || '(行程信息不完整)';
  end if;
  if vTemp2 is null or vTemp2 = '' then
    vErrorMsg := vErrorMsg || '(座位等级获取失败)';
  end if;

  --获取乘车人信息
  --计算票数
  iNum4 := 0;
  for cursor_pass in (select * from T_CC_TRAIN_TICKET where TRAIN_ORDER_ID = vIdConvert) loop
    --获取乘车人姓名
    vTemp3 := vTemp3 || cursor_pass.IDC_NAME || ',';
    iNum4 := iNum4 + 1;
  end loop;

  if vTemp3 is null or vTemp3 = '' then
    vErrorMsg := vErrorMsg || '(乘客姓名未获取)';
  end if;

  ---------生成短信内容--------------
  vTemplet := Replace(vTemplet,'#DATE#',vTemp);
  vTemplet := Replace(vTemplet,'#NAME#',vTemp3);
  vTemplet := Replace(vTemplet,'#TRIP#',vTemp1);
  vTemplet := Replace(vTemplet,'#level#',vTemp2);
  vTemplet := Replace(vTemplet,'#TICKETS#',iNum4);

  if vOrderPhone is not null and length(vOrderPhone) = 11 then
    vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
  end if;

  --------发送给客服提醒--------------
  select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';
  vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','火车票');
  vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
  vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
  vTemplet2 := Replace(vTemplet2, '#YDSJH#',vTemp8);
  select nvl(value, 'N') into vKeFuPhone from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE_HT';
  vTemp5 := 'MSG_PLANE_INTER_PAY_REMIND_TO_KEFU';

  if vKeFuPhone is not null and length(vKeFuPhone) = 11 then
    vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vKeFuPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
  end if;

end if;


--********************火车票出票成功  乘客、联系人|预订人*******************************
--1.MSG_TRAIN_OUT_SUCCESS_PASS
--  *月*号 **乘客，16:04苏州-17:05到上海 二等座1张，购票成功，*车*座， 谢谢您的预订，祝您旅途愉快，订单号：** 有问题请致电：4007239888
--2 (#DATE#，#NAME#乘客，#TRIP#，#level# 1张)，购票成功，#CARRIAGE#车#SEAT#座， 谢谢您的预订，祝您旅途愉快，订单号：#ORDERNO# 有问题请致电：4007239888
--3.传递参数：

--********************火车票出票成功  联系人或预订人模板*******************************
--1.MSG_TRAIN_OUT_SUCCESS_LINK
--  您好，您为**客人预订的*月*号16:04苏州-17:05到上海二等座1张已经购票成功，已经短信通知乘车人（若乘客已预留手机号），感谢您的预订。订单号：** 有问题请致电：4007239888
--2 您好，您为#NAME#预订的(#DATE#，#TRIP#，#level# #TICKETS#张)已经购票成功，座位号：#SEATINFO#，已经短信通知乘车人（若乘客已预留手机号），感谢您的预订。订单号：#ORDERNO#，有问题请致电：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_TRAIN_OUT_SUCCESS_PASS') then
  vOrderId := vId;
  vIdConvert := convertStrToInt(vId,-1);

  --解析火车票行程
  for cursor_trip in (select * from t_cc_train_trip where train_order_id = vIdConvert) loop
    --出发时间 月 日
    vTemp := to_char(cursor_trip.DEPART_DATE,'mm')||'/'||to_char(cursor_trip.DEPART_DATE,'dd');
    --生成行程信息
    vTemp1 := vTemp1 || cursor_trip.train_code || '次 ' ||  cursor_trip.DEPART_STATION ||'(' ||cursor_trip.DEPART_TIME || ')'||' - ';
    vTemp1 := vTemp1  || cursor_trip.ARRIVE_STATION || '('|| cursor_trip.ARRIVE_TIME ||')';
    --订单号
    vOrderNo := cursor_trip.TRAIN_ORDER_NO;
    --座位等级
    vTemp2 := getTrainSeatLevel(cursor_trip.SEAT_TYPE_CODE);
  end loop;
  if vTemp is null or vTemp1 is null or vTemp2 is null then
      vErrorMsg := vErrorMsg || '(行程信息未获取)';
  end if;

  --解析火车票订单参数
  for cursor_order in (select Create_User_Id,COMPANY_ID,CONTACT_PHONE,SUP_BILL_NO from T_CC_TRAIN_ORDER WHERE TRAIN_ORDER_ID = vIdConvert ) loop
    --获得企业信息
    for cursor_company in (select company_name,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY WHERE COMPANY_ID = cursor_order.COMPANY_ID) loop
      vCompanyName := cursor_company.company_name;
      --判断该企业是否开启给预订人发送短信
      if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
        vFlag1 := 1;
        select mobilephone into vOrderPhone from t_base_user where user_id=cursor_order.CREATE_USER_ID;
      else
        vFlag1 := 0;
      end if;
    end loop;
    --获得联系人信息
    if cursor_order.Contact_Phone is not null then
      vContactPhone := cursor_order.Contact_Phone;
    end if;
    --12306订单号
    vTemp9 := cursor_order.SUP_BILL_NO;

    if vTemp9 is null or vTemp9 = '' then
      vErrorMsg := vErrorMsg || '(12306订单号未获取)';
      vErrorMsg1 := vErrorMsg1 || '(12306订单号未获取)';
    end if;
  end loop;

  --解析火车票参数
  iNum4 :=0;
  vTemp8 := '';
  for cursor_ticket in (select TRAIN_BOX,SEAT_NO,IDC_NAME,PHONE from T_CC_TRAIN_TICKET where TRAIN_ORDER_ID = vIdConvert) loop
    iNum4 := iNum4 + 1;
    --车厢座次
    vTemp3 := cursor_ticket.TRAIN_BOX;
    vTemp4 := cursor_ticket.SEAT_NO;
    --乘客信息
    vTemp5 := vTemp5 || cursor_ticket.IDC_NAME || ',';
    --乘客手机号
    vUserPhone := cursor_ticket.PHONE;

    vTemp8 := vTemp8 || '('||cursor_ticket.IDC_NAME ||':'||cursor_ticket.TRAIN_BOX||'车'||cursor_ticket.SEAT_NO||'号)';

    -----------联系人模板
    select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_OUT_SUCCESS_PASS';

    iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

    if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
      vObjectRole := 2; --乘客角色
        vTemplet := Replace(vTemplet, '#DATE#', vTemp);
        vTemplet := Replace(vTemplet, '#NAME#',cursor_ticket.IDC_NAME);
        vTemplet := Replace(vTemplet, '#TRIP#', vTemp1);
        vTemplet := Replace(vTemplet, '#LEVEL#', vTemp2);
        vTemplet := Replace(vTemplet, '#CARRIAGE#', vTemp3);
        vTemplet := Replace(vTemplet, '#SEAT#', vTemp4);
        vTemplet := Replace(vTemplet,'#ORDERNO#',vTemp9);
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
    end if;
  end loop;

  select TEXT1 INTO vTemplet2 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_OUT_SUCCESS_LINK';

  --先判断该企业是否要给预订人发短信，若开启了配置则发送，若未配置，则只发送给乘客和联系人
  --若预订人不需要发短信，则只要判断联系人和乘客是否为同一人
  iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

  -----------------发送给预订人或联系人
  vTemplet2 := Replace(vTemplet2, '#DATE#', vTemp);
  vTemplet2 := Replace(vTemplet2, '#NAME#',vTemp5);
  vTemplet2 := Replace(vTemplet2, '#TRIP#', vTemp1);
  vTemplet2 := Replace(vTemplet2, '#LEVEL#', vTemp2);
  vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vTemp9);
  vTemplet2 := Replace(vTemplet2,'#TICKETS#',iNum4);
  vTemplet2 := Replace(vTemplet2,'#SEATINFO#',vTemp8);

  if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
    vResult := smsGeneralInterface('MSG_TRAIN_OUT_SUCCESS_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
  end if;

  if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
    vResult := smsGeneralInterface('MSG_TRAIN_OUT_SUCCESS_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
  end if;

end if;


--********************火车票出票失败  乘客*******************************
--1.MSG_TRAIN_OUT_FAIL_PASS
--  *月*号 **乘客 苏州-上海1张，车票已经卖完了，罗盘建议您火速去网上预订其他车次，感谢您的预订与支持！订单号：** 有问题请致电：4007239888
--2 (#DATE#，#NAME#乘客，#TRIP#，#level#)，#REASON#，罗盘建议您火速去网上预订其他车次，感谢您的预订与支持！订单号：#ORDERNO# 有问题请致电：4007239888
--3.传递参数：

--********************火车票出票失败  联系人或预订人*******************************
--1.MSG_TRAIN_OUT_FAIL_LINK
--  您好，您为**客人预订的16:04苏州-上海1张车票已经卖完了，已经短信通知乘车人，罗盘建议您为您的旅客火速去网上订其他车次，感谢您的预订。订单号：**有问题请致电：4007239888
--2 您好，您为#NAME#预订的(#DATE#，#TRIP#，#level# #TICKETS#张)，#REASON#，已经短信通知乘客（若乘客已预留手机号），罗盘建议您火速去网上预订其他车次，感谢您的预订与支持！订单号：#ORDERNO# 有问题请致电：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_TRAIN_OUT_FAIL_PASS') then
    vOrderId := vId;
    vIdConvert := convertStrToInt(vId,-1);

    --解析火车票行程
    for cursor_trip in (select * from t_cc_train_trip where train_order_id = vIdConvert) loop
      --出发时间 月 日
      vTemp := to_char(cursor_trip.DEPART_DATE,'mm')||'月'||to_char(cursor_trip.DEPART_DATE,'dd')||'日';
      --生成行程信息
      vTemp1 := vTemp1 || cursor_trip.train_code || '次 '||  cursor_trip.DEPART_STATION || '('|| cursor_trip.DEPART_TIME ||')' || '-';
      vTemp1 := vTemp1 ||  cursor_trip.ARRIVE_STATION || '('||cursor_trip.ARRIVE_TIME ||')';
      --订单号
      vOrderNo := cursor_trip.TRAIN_ORDER_NO;
      --座位等级
      vTemp2 := getTrainSeatLevel(cursor_trip.SEAT_TYPE_CODE);
    end loop;
    if vTemp is null or vTemp1 is null or vTemp2 is null then
        vErrorMsg := vErrorMsg || '(行程信息未获取)';
    end if;

    --解析火车票订单参数
    vTemp6 := '出票失败';
    for cursor_order in (select Create_User_Id,COMPANY_ID,CONTACT_PHONE,ticketing_remark from T_CC_TRAIN_ORDER WHERE TRAIN_ORDER_ID = vIdConvert ) loop
      --获得企业信息
      for cursor_company in (select company_name,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY WHERE COMPANY_ID = cursor_order.COMPANY_ID) loop
        vCompanyName := cursor_company.company_name;
        --判断该企业是否开启给预订人发送短信
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
          select mobilephone into vOrderPhone from t_base_user where user_id=cursor_order.CREATE_USER_ID;
        else
          vFlag1 := 0;
        end if;
      end loop;
      --获得联系人信息
      if cursor_order.Contact_Phone is not null then
        vContactPhone := cursor_order.Contact_Phone;
      end if;
      --获得预订人信息
      if cursor_order.CREATE_USER_ID is not null then
          select mobilephone into vOrderPhone from t_base_user where user_id = cursor_order.CREATE_USER_ID;
      end if;

      --失败信息
      if cursor_order.ticketing_remark is not null then
        if instr(cursor_order.ticketing_remark,'合作商户余额不足') > 0 then
            vTemp6 := '出票失败';
        else
            vTemp6 := cursor_order.ticketing_remark;
        end if;
      else
        vTemp6 := '出票失败';
      end if;
    end loop;

    --解析火车票参数
    iNum4 := 0;
    vTemp5 := '';
    for cursor_ticket in (select TRAIN_BOX,SEAT_NO,IDC_NAME,PHONE from T_CC_TRAIN_TICKET where TRAIN_ORDER_ID = vIdConvert) loop
      iNum4 := iNum4 + 1;
      --乘客信息
      if vTemp5 <> '' then
        vTemp5 := vTemp5 || ',';
      end if ;
      vTemp5 := vTemp5 || cursor_ticket.IDC_NAME;
      --乘客手机号
      vUserPhone := cursor_ticket.PHONE;

      ----------乘客模板-------出票失败不发送给乘客

      select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_OUT_FAIL_PASS';

      iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

      if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
        vObjectRole := 2; --乘客角色
          vTemplet := Replace(vTemplet, '#DATE#', vTemp);
          vTemplet := Replace(vTemplet, '#NAME#',cursor_ticket.IDC_NAME);
          vTemplet := Replace(vTemplet, '#TRIP#', vTemp1);
          vTemplet := Replace(vTemplet, '#LEVEL#', vTemp2);
        --  vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
          if vTemp6 = '出票失败' then
              vTemplet := Replace(vTemplet,'因#REASON#，','');
          else
              vTemplet := Replace(vTemplet,'#REASON#',vTemp6);
          end if;


          vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,2);
      end if;

    end loop;

    --先判断该企业是否要给预订人发短信，若开启了配置则发送，若未配置，则只发送给乘客和联系人
    --若预订人不需要发短信，则只要判断联系人和乘客是否为同一人
    iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

    -----------联系人模板
    select TEXT1 INTO vTemplet2 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_OUT_FAIL_LINK';

    -----------------发送给预订人或联系人
    vTemplet2 := Replace(vTemplet2, '#DATE#', vTemp);
    vTemplet2 := Replace(vTemplet2, '#NAME#',vTemp5);
    vTemplet2 := Replace(vTemplet2, '#TRIP#', vTemp1);
    vTemplet2 := Replace(vTemplet2, '#LEVEL#', vTemp2);
  --  vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);
    vTemplet2 := Replace(vTemplet2,'#TICKETS#',iNum4);
    if vTemp6 = '出票失败' then
        vTemplet2 := Replace(vTemplet2,'因#REASON#，','');
    else
        vTemplet2 := Replace(vTemplet2,'#REASON#',vTemp6);
    end if;

    if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
      vResult := smsGeneralInterface('MSG_TRAIN_OUT_FAIL_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
    end if;

    if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
      vResult := smsGeneralInterface('MSG_TRAIN_OUT_FAIL_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
        vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
    end if;

end if;


--********************火车票订单 退票申请提醒 申请人*******************************
--1.MSG_TRAIN_REFUND_REMIND
--2.您好，您的火车票退票申请已经收到，我们正在为您火速处理中，请耐心等待，订单号#ORDERNO#，祝您生活愉快，服务热线4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_TRAIN_REFUND_REMIND') then
  vOrderId := vId;
  vIdConvert := convertStrToInt(vId,-1);

  --解析火车票行程
  for cursor_refund in (select TRAIN_ORDER_NO,COMPANY_ID,APPLY_USER_ID from T_CC_TRAIN_REFUND WHERE TRAIN_REFUND_ID = vIdConvert) loop
      --火车票订单号
      vTemplet := Replace(vTemplet,'#ORDERNO#',cursor_refund.TRAIN_ORDER_NO);
      vOrderNo := cursor_refund.TRAIN_ORDER_NO;
      --获取企业名称
      for rsCompany in (select * from T_base_company where company_id = cursor_refund.company_id and rownum <= 1) loop
         vCompanyName := rsCompany.company_name;
      end loop;
      --------------------------------------
      -- 获得申请人的手机号码
      --------------------------------------
      select nvl((select mobilephone from t_base_user where user_id=cursor_refund.APPLY_USER_ID and rownum<=1),'N') into vOrderPhone from dual;

      if vOrderNo is null or vOrderNo = '' then
        vErrorMsg := vErrorMsg ||'(订单编号未获取)';
      end if;

      if vTemplet is null or vTemplet = 'N' then
        vErrorMsg := vErrorMsg || '(申请人模板未获取)';
      end if;

      -----------------------------

       if vOrderPhone is not null and length(vOrderPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
         vOrderId,vCompanyId,vTemplet,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
       end if;

  end loop;

  ------------------------------
 --  给客服发送短信通知
 ------------------------------
 select nvl(Text1, 'N') into vTemplet2 from T_BASE_MSG_TEMPLATE where MT_CODE='MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';

 vTemp5 := 'MSG_PLANE_CIVIL_PAY_REMIND_TO_KEFU';
 vTemplet2 := Replace(vTemplet2, '#ORDERTYPE#','火车票退票');
 vTemplet2 := Replace(vTemplet2, '#ORDERNO#',vOrderNo);
 vTemplet2 := Replace(vTemplet2, '#COMPANY#',vCompanyName);
 vTemplet2 := Replace(vTemplet2, '#YDSJH#',vOrderPhone);
 --给客服小米短信
 select nvl(value, 'N') into vContactPhone from T_BASE_CONFIG_CONST where NAME = 'KEFU_MOBILEPHONE';

 if vContactPhone is not null and length(vContactPhone) =11 then
   vResult := smsGeneralInterface(vTemp5,vDelay,vSwitch,vMaType,vPriority,vMsgType,
     vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,4);
 end if;

end if;




--********************火车票退票成功  乘客*******************************
--1.MSG_TRAIN_REFUND_SUCCESS_PASS
-- **乘客 *月*号 苏州-上海1张，已经退票成功，退票费：**祝您生活愉快。订单号：** 有问题请致电：4007239888
--2 (#NAME#乘客，DATE#，#TRIP#1张)，已经退票成功，退还金额：#PRICE#。祝您生活愉快。订单号：#ORDER_NO#，有问题请致电：4007239888
--3.传递参数：

--********************火车票退票成功  联系人或预订人*******************************
--1.MSG_TRAIN_REFUND_SUCCESS_LINK
-- 您好，您为**客人 *月*号苏州-上海 1张车票申请退票，已经成功，退票费：** 已经短信通知乘车人，祝您生活愉快！订单号：** 有问题请致电：4007239888
--2.您好，您为#NAME#(#DATE#，#TRIP# #TICKETS#张车票申请的退票)，已经退票成功，退还金额：#PRICE#。祝您生活愉快。订单号：#ORDERNO#，有问题请致电：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_TRAIN_REFUND_SUCCESS_PASS') then
  vOrderId := vId;
  vIdConvert := convertStrToInt(vId,-1);

  --解析火车票行程
  for cursor_refund in (select * from T_CC_TRAIN_REFUND WHERE TRAIN_REFUND_ID = vIdConvert) loop
    --根据退票id查询原订单信息
    for cursor_trip in (select * from t_cc_train_trip WHERE train_order_id = cursor_refund.TRAIN_ORDER_ID) loop
      --出发时间 月 日
      vTemp := to_char(cursor_trip.DEPART_DATE,'mm')||'月'||to_char(cursor_trip.DEPART_DATE,'dd')||'日';
      --生成行程信息
      vTemp1 := vTemp1|| cursor_trip.train_code || '次 ' ||  cursor_trip.DEPART_STATION ||'(' ||cursor_trip.DEPART_TIME || ')'||'-';
      vTemp1 := vTemp1 ||  cursor_trip.ARRIVE_STATION || '(' ||cursor_trip.ARRIVE_TIME || ')';
      --订单号
      vOrderNo := cursor_trip.TRAIN_ORDER_NO;
      --座位等级
      vTemp2 := getTrainSeatLevel(cursor_trip.SEAT_TYPE_CODE);
    end loop;

    --解析火车票订单参数
    for cursor_order in (select Create_User_Id,COMPANY_ID,CONTACT_PHONE from T_CC_TRAIN_ORDER WHERE TRAIN_ORDER_ID = cursor_refund.TRAIN_ORDER_ID ) loop
      --获得企业信息
      for cursor_company in (select company_name,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY WHERE COMPANY_ID = cursor_order.COMPANY_ID) loop
        vCompanyName := cursor_company.company_name;
        --判断该企业是否开启给预订人发送短信
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
          select mobilephone into vOrderPhone from t_base_user where user_id=cursor_order.CREATE_USER_ID;
        else
          vFlag1 := 0;
        end if;
      end loop;
      --获得联系人信息
      if cursor_order.Contact_Phone is not null then
        vContactPhone := cursor_order.Contact_Phone;
      end if;
      --订单价格
      --iNum12 := cursor_order.SALE_PRICE;
    end loop;

  end loop;
  if vTemp is null or vTemp1 is null or vTemp2 is null then
      vErrorMsg := vErrorMsg || '(行程信息未获取)';
  end if;

  --退票信息
  iNum4 := 0;
  for cursor_refund_ticket in (select A.SALE_PRICE,B.SALE_PRICE AS SALE_PRICE_SIDE,B.SUP_SERVICE_PRICE , B.IDC_NAME,B.PHONE from T_CC_TRAIN_REFUND_TICKET A,T_CC_TRAIN_TICKET B
                                  where TRAIN_REFUND_ID = vIdConvert AND A.TRAIN_TICKET_ID = B.TRAIN_TICKET_ID) loop
    iNum4 := iNum4 + 1;
    -----------联系人模板
    select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_REFUND_SUCCESS_PASS';
    --退票费
    iNum13 :=cursor_refund_ticket.SALE_PRICE_SIDE - cursor_refund_ticket.SUP_SERVICE_PRICE-cursor_refund_ticket.SALE_PRICE;
    --乘客姓名
    vTemp5 := vTemp5 || cursor_refund_ticket.IDC_NAME || ',';
    --乘客联系电话
    vUserPhone := cursor_refund_ticket.PHONE;

    iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

    if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 = 1 then  --补单不发送
      vObjectRole := 2; --乘客角色
        vTemplet := Replace(vTemplet, '#DATE#', vTemp);
        --vTemplet := Replace(vTemplet, '#NAME#',cursor_refund_ticket.IDC_NAME);
        vTemplet := Replace(vTemplet, '#TRIP#', vTemp1);
        --vTemplet := Replace(vTemplet, '#PRICE#', iNum13);
        --vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);
    end if;
  end loop;

  -----------联系人模板
  select TEXT1 INTO vTemplet2 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_REFUND_SUCCESS_LINK';

  --先判断该企业是否要给预订人发短信，若开启了配置则发送，若未配置，则只发送给乘客和联系人
  --若预订人不需要发短信，则只要判断联系人和乘客是否为同一人
  iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

  -----------------发送给预订人或联系人
  vTemplet2 := Replace(vTemplet2, '#DATE#', vTemp);
  vTemplet2 := Replace(vTemplet2, '#NAME#',vTemp5);
  vTemplet2 := Replace(vTemplet2, '#TRIP#', vTemp1);
  --vTemplet2 := Replace(vTemplet2, '#PRICE#', iNum13*iNum4);
  --vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);
  vTemplet2 := Replace(vTemplet2,'#TICKETS#',iNum4);

    if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
    vResult := smsGeneralInterface('MSG_TRAIN_OUT_FAIL_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,0);
    end if;

    if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
    vResult := smsGeneralInterface('MSG_TRAIN_OUT_FAIL_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
    end if;
end if;



--********************火车票退票失败  乘客*******************************
--1.MSG_TRAIN_REFUND_FAIL_PASS
-- 您好，**乘客 *月*号 苏州-上海1张，因**原因退票被拒绝，需要您亲临车站退票啦，罗盘建议您尽快去车站退票带好您的证件并在车站申请退票发票，祝您生活愉快！订单号：** 有问题请致电：4007239888
--2 您好，#NAME#乘客 #DATE# #TRIP#1张，因#REASON#原因退票被拒绝，需要您亲临车站退票啦，罗盘建议您尽快去车站退票带好您的证件并在车站申请退票发票，祝您生活愉快！订单号：#ORDERNO# 有问题请致电：4007239888
--3.传递参数：

--********************火车票退票失败  联系人或预订人*******************************
--1.MSG_TRAIN_REFUND_FAIL_LINK
-- 您好，为**乘客 *月*号 苏州-上海1张申请退票，因**原因退票被拒绝，需要您亲临车站退票啦，罗盘建议您尽快去车站退票带好乘车人的身份证件并在车站申请退票发票，祝您生活愉快！订单号：** 有问题请致电：4007239888
--2 您好，为#NAME#乘客 #DATE# #TRIP# #TICKETS#张申请退票，因#REASON#原因退票被拒绝，需要您亲临车站退票啦，罗盘建议您尽快去车站退票带好您的证件并在车站申请退票发票，祝您生活愉快！订单号：#ORDERNO# 有问题请致电：4007239888
--3.传递参数：
--*****************************************************
if vCode in ('MSG_TRAIN_REFUND_FAIL_PASS') then
  vOrderId := vId;
  vIdConvert := convertStrToInt(vId,-1);

  --解析火车票行程
  for cursor_refund in (select * from T_CC_TRAIN_REFUND WHERE TRAIN_REFUND_ID = vIdConvert) loop
    --拿到退票原因
    vTemp2 := cursor_refund.COMPLETE_REMARK;
    --根据退票id查询原订单信息
    for cursor_trip in (select * from t_cc_train_trip WHERE train_order_id = cursor_refund.TRAIN_ORDER_ID) loop
      --出发时间 月 日
      vTemp := to_char(cursor_trip.DEPART_DATE,'mm')||'月'||to_char(cursor_trip.DEPART_DATE,'dd')||'日';
      --生成行程信息
      vTemp1 := vTemp1 || cursor_trip.train_code || '次 '||  cursor_trip.DEPART_STATION || '('||cursor_trip.DEPART_TIME || ')'|| '-';
      vTemp1 := vTemp1 || cursor_trip.ARRIVE_TIME || cursor_trip.ARRIVE_STATION ;
      --订单号
      vOrderNo := cursor_trip.TRAIN_ORDER_NO;
    end loop;

    --解析火车票订单参数
    for cursor_order in (select Create_User_Id,COMPANY_ID,CONTACT_PHONE from T_CC_TRAIN_ORDER WHERE TRAIN_ORDER_ID = cursor_refund.TRAIN_ORDER_ID ) loop
      --获得企业信息
      for cursor_company in (select company_name,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY WHERE COMPANY_ID = cursor_order.COMPANY_ID) loop
        vCompanyName := cursor_company.company_name;
        --判断该企业是否开启给预订人发送短信
        if cursor_company.IS_NOTICE_TO_BOOKER = '1' then
          vFlag1 := 1;
          select mobilephone into vOrderPhone from t_base_user where user_id=cursor_order.CREATE_USER_ID;
        else
          vFlag1 := 0;
        end if;
      end loop;
      --获得联系人信息
      if cursor_order.Contact_Phone is not null then
        vContactPhone := cursor_order.Contact_Phone;
      end if;
    end loop;

  end loop;
  if vTemp is null or vTemp1 is null then
      vErrorMsg := vErrorMsg || '(行程信息未获取)';
  end if;



  --退票信息
  iNum4 := 0;
  for cursor_refund_ticket in (select A.SALE_PRICE, B.IDC_NAME,B.PHONE from T_CC_TRAIN_REFUND_TICKET A,T_CC_TRAIN_TICKET B
                                  where TRAIN_REFUND_ID = vIdConvert AND A.TRAIN_TICKET_ID = B.TRAIN_TICKET_ID) loop
    iNum4 := iNum4 + 1;
    -----------联系人模板
    select TEXT1 INTO vTemplet from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_REFUND_FAIL_PASS';
    --退票费
    vTemp4 := cursor_refund_ticket.SALE_PRICE;
    --乘客姓名
    vTemp5 := vTemp5 || ',' || cursor_refund_ticket.IDC_NAME ;
    --乘客联系电话
    vUserPhone := cursor_refund_ticket.PHONE;

    iNum1 := judgeSendUser(vUserPhone,vOrderPhone,vContactPhone);

    if vUserPhone is not null and length(vUserPhone) = 11 and iNum1 =1 then  --补单不发送
      vObjectRole := 2; --乘客角色
      --if iNum1 in (1,3,5,7,9) then  --乘机人模板
        vTemplet := Replace(vTemplet, '#DATE#', vTemp);
        vTemplet := Replace(vTemplet, '#NAME#',cursor_refund_ticket.IDC_NAME);
        vTemplet := Replace(vTemplet, '#TRIP#', vTemp1);
        --vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
        if vTemp2 is null or vTemp2 = '' then
          vTemplet := Replace(vTemplet,'因#REASON#原因','');
        else
          vTemplet := Replace(vTemplet,'#REASON#','('+ vTemp2+'）');
        end if;

        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,vObjectRole);

    end if;

  end loop;

  -----------联系人模板
  select TEXT1 INTO vTemplet2 from T_BASE_MSG_TEMPLATE WHERE MT_CODE = 'MSG_TRAIN_REFUND_FAIL_LINK';
  --先判断该企业是否要给预订人发短信，若开启了配置则发送，若未配置，则只发送给乘客和联系人
  --若预订人不需要发短信，则只要判断联系人和乘客是否为同一人
  iNum1 := judgeSendObject(vOrderPhone,vContactPhone);

  -----------------发送给预订人或联系人
  vTemplet2 := Replace(vTemplet2, '#DATE#', vTemp);
  vTemplet2 := Replace(vTemplet2, '#NAME#',vTemp5);
  vTemplet2 := Replace(vTemplet2, '#TRIP#', vTemp1);
  vTemplet2 := Replace(vTemplet2,'#REASON#',vTemp2);
  --vTemplet2 := Replace(vTemplet2,'#ORDERNO#',vOrderNo);
  vTemplet2 := Replace(vTemplet2,'#TICKETS#',iNum4);
  if vTemp2 is null or vTemp2 = '' then
    vTemplet2 := Replace(vTemplet2,'因#REASON#原因','');
  else
    vTemplet2 := Replace(vTemplet2,'#REASON#','('+vTemp2+')');
  end if;
    if iNum1 in (2,3) and vContactPhone is not null and length(vContactPhone) = 11 then  --给联系人发短信
    vResult := smsGeneralInterface('MSG_TRAIN_OUT_FAIL_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,0);
    end if;

    if iNum1 in (1,3) and vOrderPhone is not null and length(vOrderPhone) = 11 then --给预订人发短信
    vResult := smsGeneralInterface('MSG_TRAIN_OUT_FAIL_LINK',vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet2,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,1);
    end if;

end if;


--********************订单审批-国内机票*******************************
--1.MSG_ORDER_FOR_APPROVAL_PLANE_CIVIL
-- 您有新的国内机票订单需要审核 ，订单号：#ORDERNO#，航班信息：(#NAME#)#TIME##FLIGHTNO##AIRPORT#，订单金额：#TOTAL#，审核通过请回复：#PASSCODE#，不通过回复：#DECLINECODE#，折扣率：#DISCOUNT#。审核截止时间：#ENDTIME#，谢谢您！
--2 您有新的国内机票订单需要审核 ，订单号：#ORDERNO#，航班信息：(#NAME#)#TIME##FLIGHTNO##AIRPORT#，订单金额：#TOTAL#，审核通过请回复：#PASSCODE#，不通过回复：#DECLINECODE#，折扣率：#DISCOUNT#。审核截止时间：#ENDTIME#，谢谢您！
--3.传递参数：
--*****************************************************
if vCode in ('MSG_ORDER_FOR_APPROVAL_PLANE_CIVIL') then
  if vTemplet is null then
    vErrorMsg := vErrorMsg || '(国内机票审批模板未获取)';
  end if;
  if vId is null or vId = '' then
    vErrorMsg := vErrorMsg || '(订单id未获取)';
  end if;

  vOrderId := vId;
  vIdConvert := convertStrToInt(vId,-1);

  --行程信息
  for rs in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
    if NVL(vTemp3, 'N') != 'N' then
      vTemp3 := vTemp3 || '；';
    end if;
    vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"') ;

    vTemp3 := vTemp3 || rs.airline_name || rs.airline_code||rs.flight_no || ' ';

    vTemp3 := vTemp3 || rs.depart_airport_name || replace(rs.depart_airport_tower, '-', '') ||'('|| to_char(rs.take_off_time, 'HH24:FMMI') ||')' || '-';

    vTemp3 := vTemp3 || rs.arrive_airport_name || replace(rs.arrive_airport_tower, '-', '') || '('||to_char(rs.arrive_time, 'HH24:FMMI')||')';
  end loop;

  --订单信息
  for cursor_order in (select * from T_CC_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
      --订单编号
      vOrderNo := cursor_order.PLANE_ORDER_NO;
      --企业信息
      select COMPANY_NAME INTO vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = cursor_order.COMPANY_ID;
      --订单价格
      vTemp1 := cursor_order.SALE_PRICE;

      ---------------------------------------------
      --读企业配置 ，判断该企业是否开启最低价配置，若开启，再判断当前订单是否是最低价，若不是，则提示
      select value into vTemp9 from T_BASE_CONFIG_COMPANY WHERE KEY = 'isCivPlaneLowestJudge' AND COMPANY_ID = cursor_order.COMPANY_ID;
      if vTemp9 = 'true' then
        --OD信息
        for cusor_od in (select LOWEST_FLIGHT_ID from T_CC_PLANE_OD WHERE plane_order_id = vIdConvert) loop
            if cusor_od.LOWEST_FLIGHT_ID is not null then
               select FACE_PRICE into iNum12 from T_CC_PLANE_OD where plane_od_id = cusor_od.LOWEST_FLIGHT_ID;
              select value into vTemp8 from T_BASE_CONFIG_COMPANY WHERE KEY = 'isOneHourLowest' AND COMPANY_ID = cursor_order.COMPANY_ID;
               if vTemp8 = 'true' then
                 vTemp5 := '该价格非前后一小时最低价，最低价为：'|| iNum12;
               else
                 vTemp5 := '该价格非前后两小时最低价，最低价为：'|| iNum12;
               end if;
            end if;
        end loop;
      end if;

  end loop;
  if vOrderNo is null or vOrderNo = '' then
    vErrorMsg := vErrorMsg || '(订单编号为空)';
  end if;
  if vTemp1 is null or vTemp1 = '' then
    vErrorMsg := vErrorMsg || '(订单价格为空)';
  end if;

  --机票信息
  iNum4 := 0;
  iNum5 := 0;
  for cursor_ticket in (select Idc_Name,plane_ticket_id from T_CC_TICKET_PASSENGER where plane_order_id = vIdConvert ) loop
    if NVL(vTemp2, 'N') != 'N' then
      vTemp2 := vTemp2 || ',';
    end if;
    vTemp2 := vTemp2 || cursor_ticket.Idc_Name;

    --机票折扣率
    for cursor_ticket_od in (select plane_od_id from t_cc_ticket_od
                                where plane_ticket_id = cursor_ticket.plane_ticket_id) loop
      for cursor_od in (select FACE_PRICE,STANDARD_PRICE from t_cc_plane_od
                                where plane_od_id =cursor_ticket_od.plane_od_id) loop
          iNum4 := iNum4 + cursor_od.FACE_PRICE;
          iNum5 := iNum5 + cursor_od.STANDARD_PRICE;
      end loop;
    end loop;

  end loop;

  if vTemp2 is null or vTemp2 = '' then
    vErrorMsg := vErrorMsg || '(乘机人姓名未获取)';
  end if;
  --计算折扣率
  if iNum5 != 0 then
    if Round(iNum4/iNum5,2) = 1 then
      vTempLet := Replace(vTempLet,'#DISCOUNT#',0);
    else
      vTempLet := Replace(vTempLet,'#DISCOUNT#',Round(iNum4/iNum5,2)*10 ||'折');
    end if;
  else
    vTempLet := Replace(vTempLet,'，折扣率：#DISCOUNT#','');
  end if;

  --短信审批码
  for cursor_audit in (select * from t_cc_order_audit where order_id = vIdConvert and rownum <=1) loop
      vPassCode :=cursor_audit.Pass_Code;
      vDeclineCode :=cursor_audit.Decline_Code;
      vEndTime :=to_char(cursor_audit.Order_Endtime, 'HH24:MI:SS');
  end loop;
  if vPassCode is null or vDeclineCode is null then
    vErrorMsg := vErrorMsg || '(审批码获取异常)';
  end if;

  vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
  vTemplet := Replace(vTemplet, '#NAME#',vTemp2);
  vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);
  vTemplet := Replace(vTemplet, '#TOTAL#',vTemp1);
  vTemplet :=Replace(vTemplet,'#PASSCODE#',vPassCode);
  vTempLet :=Replace(vTemplet,'#DECLINECODE#',vDeclineCode);
  vTemplet :=Replace(vTemplet,'#ENDTIME#',vEndTime);
  if vTemp5 is not null then
      vTemplet :=Replace(vTemplet,'#LOWPRICE#',vTemp5);
  else
      vTemplet :=Replace(vTemplet,'，#LOWPRICE#','');
  end if;

  --发送给审核人
  if vPhone is not null and length(vPhone) = 11 then
    vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
  end if;

end if;



--********************差旅单审批请求*******************************
--1.MSG_TRAIN_BIZ_APPROVAL
-- 您有新的差旅申请单需要审核，申请单号：**  申请人：** 出差事由：** 出差人：** 预估费用：**，审核通过请回复 passcode 申请单号，审核不通过请回复decline_code 申请单号谢谢您！
--2 您有新的差旅申请单需要审核，申请单号：#ORDERNO#  申请人：#APP# 出差事由：#REASON# 出差人：#EVECTION# 预估费用：#PRICE#，审核通过请回复#PASSCODE#，审核不通过请回复#DECLINECODE#，谢谢！
--3.传递参数：
--*****************************************************
if vCode in ('MSG_TRAIN_BIZ_APPROVAL') then
if vTemplet is null then
  vErrorMsg := vErrorMsg || '(差旅单审批模板未获取)';
end if;

if vId is null or vId = '' then
  vErrorMsg := vErrorMsg || '(订单id未获取)';
end if;
vOrderId := vId;
vOrderNo := vId;
vIdConvert := convertStrToInt(vId,-1);
--申请单号
vTemplet := replace(vTemplet,'#ORDERNO#',vIdConvert);

  for rsBtrip in (select *
                    from t_cc_business_trip
                   where biz_trip_id = vIdConvert
                     and state = '1'
                     and rownum <= 1) loop
    vTemplet := replace(vTemplet, '#REASON#', rsBtrip.Reason);
    vTemplet := replace(vTemplet, '#PRICE#', rsBtrip.Budget);
    vTemplet := replace(vTemplet,'#PASSCODE#',rsBtrip.Pass_Code);
    vTemplet := replace(vTemplet,'#DECLINECODE#',rsBtrip.Decline_Code);
    vTemplet := replace(vTemplet,'#ENDTIME#',to_char(rsBtrip.Trip_Endtime, 'HH24:MI:SS'));

    if rsBtrip.Pass_Code is null or rsBtrip.Pass_Code = ''
        or rsBtrip.Decline_Code is null or rsBtrip.Decline_Code = '' then
        vErrorMsg := vErrorMsg || '(短信审批码异常未获取)';
    end if;
     --获取申请人姓名
    for rsUser in(select * from T_BASE_USER
                    where user_id = rsBtrip.Apply_User) loop
      vTemplet  := replace(vTemplet, '#APP#', rsUser.Name_Cn);
    end loop;
    if rsBtrip.Apply_User is null or rsBtrip.Apply_User = '' then
      vErrorMsg := vErrorMsg || '(差旅申请人未获取)';
    end if;

    --------------------------------------
    -- 获得所属模块+订单号+企业名称
    --------------------------------------
    for rsCompany in (select * from T_base_company where company_id = rsBtrip.company_id and rownum <= 1) loop
       vCompanyName := rsCompany.company_name;
    end loop;

  end loop;

  --??以后增加审批等级，则需要排序
  for rsBtripAuditUser in (select *
                        from T_CC_BIZTRIP_AUDIT_USER
                       where BIZ_TRIP_ID = vIdConvert ) loop
    for rsUser in (select *
                     from T_BASE_USER
                    where user_id = rsBtripAuditUser.Audit_User_Id
                      and state = '1'
                      and rownum <= 1) loop
      vUserPhone := rsUser.Mobilephone;
    end loop;
  end loop;
  --获得审批人手机号
  --获得申请人姓名
  --获得申请时间
  --获取出差人
  for cursor_user in (select user_id from T_CC_BIZTRIP_USER where BIZ_TRIP_ID = vIdConvert) loop
    select Name_Cn into vTemp4 from t_base_user where user_id = cursor_user.user_id ;
    vTemp3 := vTemp3 ||vTemp4 ||',';
  end loop;
  vTemplet := replace(vTemplet,'#EVECTION#',vTemp3);


  --发送短信
  if vUserPhone is not null and length(vUserPhone) = 11 then
    vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
      vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
  end if;
end if;


-----------------------------------------------------------------------------------

-- 出差申请单回复短信模 BIZ_TRIP_FOR_REPLY
-- 3.审核驳回-decline_code  审核通过--pass_code
-----------------------------------------------------------------------------------
if vCode in ('MSG_TRAIN_BIZ_APPROVAL_TO_ORDER') then
  if vTemplet is null then
    vErrorMsg := vErrorMsg || '(差旅单审批模板未获取)';
  end if;

  if vId is null or vId = '' then
    vErrorMsg := vErrorMsg || '(订单id未获取)';
  end if;
  vOrderId := vId;
  vIdConvert := convertStrToInt(vId,-1);

  for tripRs in(SELECT T.BIZ_TRIP_ID,T.APPLY_USER,U.MOBILEPHONE ,T.BOOKING_USER ,T.COMPANY_ID
                FROM T_CC_BUSINESS_TRIP T LEFT JOIN T_BASE_USER U ON T.APPLY_USER = U.USER_ID WHERE T.BIZ_TRIP_ID = vIdConvert) loop

    vUserPhone := tripRs.MOBILEPHONE;--申请人

    for rsCompany in (select * from T_base_company where company_id = tripRs.company_id and rownum <= 1) loop
       vCompanyName := rsCompany.company_name;
    end loop;

    vTemplet := Replace(vTemplet, '#BIZTRIPID#',vId);

    --比较审批码，若和pass_code相同 ，则通过
    if '1' = vRemark then --审批通过
      vTemplet := Replace(vTemplet, '#RESULT#', '通过');
    elsif '0' = vRemark then--审批驳回
      vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
    else
      vTemplet := Replace(vTemplet, '#RESULT#', '审批码不正确！');
    end if;
  end loop;

  ----发送短信给申请人
  if vUserPhone is not null and length(vUserPhone) = 11 then
  vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
    vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
  end if;

end if;


-----------------------------------------------------------------------------------

-- 火车票审批订单短信 ORDER_FOR_REPLY_TRAIN_CIVIL
 -- 2.remark ：pass_code 审核通过  decline_code 审核驳回  发送给apply_user 申请人
 -----------------------------------------------------------------------------------
 if vCode in ('MSG_ORDER_FOR_REPLY_TRAIN') then
   iNum1 := 0;
   if vTemplet is null then
     vErrorMsg := vErrorMsg || '(火车票审批回复模板未获取)';
   end if;

   if vId is null or vId = '' then
     vErrorMsg := vErrorMsg || '(订单id未获取)';
   end if;
   vOrderId := vId;
   vIdConvert := convertStrToInt(vId,-1);

   --获得行程信息，存入临时变量　vTemp3
   vTemp3 := '';
   for rs in (select * from t_cc_train_trip where train_order_id = vIdConvert) loop
     if NVL(vTemp3, 'N') != 'N' then
       vTemp3 := vTemp3 || '；';
     end if;
     vTemp3 := vTemp3 || to_char(rs.depart_date, 'FMMM"月"DD"日"HH24:FMMI');

     vTemp3 := vTemp3 || rs.train_code || '次';
     vTemp3 := vTemp3  || rs.depart_station || '('||rs.depart_time||')' || '-';
     vTemp3 := vTemp3  || rs.arrive_station || '('|| rs.arrive_time || ')';
   end loop;
   -------------------------------------------------------------------------------------------------
    iNum1 := 1;
   iNum2 := 0;
   iNum3 := 0;
   for rsTrainOrder in (select * from T_CC_TRAIN_ORDER where train_order_id = vIdConvert and rownum <= 1) loop
     vTemp2 := '';
     --------------------------------------
     -- 获得所属模块+订单号+企业名称
     --------------------------------------
     vOrderNo := rsTrainOrder.train_order_no;
     for rsCompany in (select * from T_base_company where company_id = rsTrainOrder.company_id and rownum <= 1) loop
        vCompanyName := rsCompany.company_name;
     end loop;

     --------------------------------------
     --申请人手机号
     for rsUser in (select *
                      from t_base_user
                     where user_id = rsTrainOrder.create_user_id and rownum <=1) loop
       vUserPhone := Trim(rsUser.Mobilephone);
     end loop;
      --------------------------------------
   end loop;

   --比较审批码，若和pass_code相同 ，则通过
   if '1' = vRemark then --审批通过
     vTemplet := Replace(vTemplet, '#RESULT#', '通过');
   elsif '0' = vRemark then--审批驳回
     vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
   else
     vTemplet := Replace(vTemplet, '#RESULT#', '审批码不正确！');
   end if;

   -------生成短信文本------------------------------

  vTemplet := Replace(vTemplet, '#DATE##CODE##TRIP#', vTemp3);
  vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);

  ----发送短信给申请人
  if vUserPhone is not null and length(vUserPhone) = 11 then
  vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
    vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
  end if;

 end if;


 --********************订单审批-国际机票*******************************
 --1.MSG_ORDER_FOR_APPROVAL_PLANE_CIVIL
 -- 您有新的国内机票订单需要审核 ，订单号：#ORDERNO#，航班信息：(#NAME#)#TIME##FLIGHTNO##AIRPORT#，订单金额：#TOTAL#，审核通过请回复：#PASSCODE#，不通过回复：#DECLINECODE#。审核截止时间：#ENDTIME#，谢谢您！
 --2 您有新的国内机票订单需要审核 ，订单号：#ORDERNO#，航班信息：(#NAME#)#TIME##FLIGHTNO##AIRPORT#，订单金额：#TOTAL#，审核通过请回复：#PASSCODE#，不通过回复：#DECLINECODE#。审核截止时间：#ENDTIME#，谢谢您！
 --3.传递参数：
 --*****************************************************
 if vCode in ('MSG_ORDER_FOR_APPROVAL_PLANE_INTER') then
   if vTemplet is null then
     vErrorMsg := vErrorMsg || '(国际机票审批模板未获取)';
   end if;
   if vId is null or vId = '' then
     vErrorMsg := vErrorMsg || '(订单id未获取)';
   end if;

   vOrderId := vId;
   vIdConvert := convertStrToInt(vId,-1);

   --行程信息
   for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
     if NVL(vTemp3, 'N') != 'N' then
       vTemp3 := vTemp3 || '；';
     end if;
     vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI');

     vTemp3 := vTemp3 || rs.airline_name || rs.airline_code||rs.flight_no || ' ';

     vTemp3 := vTemp3 || rs.depart_airport_name || replace(rs.depart_airport_tower, '-', '') ||'('||to_char(rs.take_off_time, 'HH24:FMMI')||')'|| '-';

     vTemp3 := vTemp3 || rs.arrive_airport_name || replace(rs.arrive_airport_tower, '-', '') || '('||to_char(rs.arrive_time, 'HH24:FMMI') || ')';
   end loop;

   --订单信息
   for cursor_order in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
       --订单编号
       vOrderNo := cursor_order.PLANE_ORDER_NO;
       --企业信息
       select COMPANY_NAME INTO vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = cursor_order.COMPANY_ID;
       --订单价格
       vTemp1 := cursor_order.SALE_PRICE;

   end loop;
   if vOrderNo is null or vOrderNo = '' then
     vErrorMsg := vErrorMsg || '(订单编号为空)';
   end if;
   if vTemp1 is null or vTemp1 = '' then
     vErrorMsg := vErrorMsg || '(订单价格为空)';
   end if;

   --机票信息
   for cursor_ticket in (select LAST_NAME,FIRST_NAME from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vIdConvert ) loop
     if NVL(vTemp2, 'N') != 'N' then
       vTemp2 := vTemp2 || ',';
     end if;
     vTemp2 := vTemp2 || cursor_ticket.LAST_NAME || '/' || cursor_ticket.FIRST_NAME;
   end loop;
   if vTemp2 is null or vTemp2 = '' then
     vErrorMsg := vErrorMsg || '(乘机人姓名未获取)';
   end if;

   --短信审批码
   for cursor_audit in (select * from t_cc_order_audit where order_id = vIdConvert and rownum <=1) loop
       vPassCode :=cursor_audit.Pass_Code;
       vDeclineCode :=cursor_audit.Decline_Code;
       vEndTime :=to_char(cursor_audit.Order_Endtime, 'HH24:MI:SS');
   end loop;
   if vPassCode is null or vDeclineCode is null then
     vErrorMsg := vErrorMsg || '(审批码获取异常)';
   end if;

   vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
   vTemplet := Replace(vTemplet, '#NAME#',vTemp2);
   vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);
   vTemplet := Replace(vTemplet, '#TOTAL#',vTemp1);
   vTemplet :=Replace(vTemplet,'#PASSCODE#',vPassCode);
   vTempLet :=Replace(vTemplet,'#DECLINECODE#',vDeclineCode);
   vTemplet :=Replace(vTemplet,'#ENDTIME#',vEndTime);

   --发送给审核人
   if vPhone is not null and length(vPhone) = 11 then
     vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
       vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
   end if;

 end if;


 --********************订单审批-火车票*******************************
 --1.MSG_ORDER_FOR_APPROVAL_TRAIN
 -- 您有新的火车票订单需要审核 ，订单号：#ORDERNO#，信息：(#NAME#)#DATE##CODE##TRIP#，订单金额：#TOTAL#，审核通过请回复#PASSCODE#，不通过回复#DECLINECODE#，审核截止时间：#ENDTIME#，谢谢您！
 --3.传递参数：
 --*****************************************************
 if vCode in ('MSG_ORDER_FOR_APPROVAL_TRAIN') then
   if vTemplet is null then
     vErrorMsg := vErrorMsg || '(火车票审批模板未获取)';
   end if;

   if vId is null or vId = '' then
     vErrorMsg := vErrorMsg || '(订单id未获取)';
   end if;
   vOrderId := vId;
   vIdConvert := convertStrToInt(vId,-1);

   --解析火车票行程
   vTemp3 := '';
   for cursor_trip in (select * from t_cc_train_trip where train_order_id = vIdConvert) loop
     if NVL(vTemp3, 'N') != 'N' then
       vTemp3 := vTemp3 || '；';
     end if;
     vTemp3 := vTemp3 || to_char(cursor_trip.depart_date, 'FMMM"月"DD"日"HH24:FMMI');
     if cursor_trip.depart_date is null then
       vErrorMsg := vErrorMsg || '(列车出发时间为空)';
     end if;
     vTemp3 := vTemp3 || cursor_trip.train_code || '次';
     if cursor_trip.train_code is null or cursor_trip.train_code = '' then
       vErrorMsg := vErrorMsg || '(列车编号为空)';
     end if;
     vTemp3 := vTemp3  || cursor_trip.depart_station || '('|| cursor_trip.depart_time||')'||'-';
     vTemp3 := vTemp3  || cursor_trip.arrive_station || '('|| cursor_trip.arrive_time||')';

     --订单号
     vOrderNo := cursor_trip.TRAIN_ORDER_NO;
     --企业信息
     select company_name into vCompanyName from t_base_company where company_id = cursor_trip.company_id and rownum <= 1;
   end loop;

   --解析火车票
   iNum4 := 0;
   for cursor_ticket in (select * from T_CC_TRAIN_TICKET where TRAIN_ORDER_ID = vIdConvert) loop
     --乘客姓名
     vTemp :=vTemp || cursor_ticket.IDC_NAME || ',';
     --票价
     --iNum11 :=  cursor_ticket.SALE_PRICE;

     iNum4 := iNum4 + 1;
   end loop;

   --火车票订单
   for cursor_order in (select SALE_PRICE from t_cc_train_order where TRAIN_ORDER_ID = vIdConvert and rownum <= 1) loop
      iNum11 := cursor_order.SALE_PRICE;
   end loop;

   --短信审批码
   for cursor_audit in (select * from t_cc_order_audit where order_id = vIdConvert and rownum <=1) loop
       vPassCode :=cursor_audit.Pass_Code;
       vDeclineCode :=cursor_audit.Decline_Code;
       vEndTime :=to_char(cursor_audit.Order_Endtime, 'HH24:MI:SS');
   end loop;
   if vPassCode is null or vDeclineCode is null then
     vErrorMsg := vErrorMsg || '(审批码获取异常)';
   end if;

   -------------------------------------------------------------------------------------
   -- 短信文本
   ----------
   vTemplet := Replace(vTemplet, '#DATE##CODE##TRIP#', vTemp3);
   vTemplet := Replace(vTemplet, '#NAME#',vTemp);
   vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);
   vTemplet := Replace(vTemplet, '#TOTAL#',iNum11);
   vTemplet :=Replace(vTemplet,'#PASSCODE#',vPassCode);
   vTempLet :=Replace(vTemplet,'#DECLINECODE#',vDeclineCode);
   vTemplet :=Replace(vTemplet,'#ENDTIME#',vEndTime);

   --发送给审核人
   if vPhone is not null and length(vPhone) = 11 then
     vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
       vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
   end if;

 end if;


 -----------------------------------------------------------------------------------

   -- 国际机票审批回复 ORDER_FOR_REPLY_PLANE_INTER
   -- 2.remark ：pass_code 审核驳回，decline_code 审核通过 发给申请人
   -----------------------------------------------------------------------------------
   if vCode in ('MSG_ORDER_FOR_REPLY_PLANE_INTER') then
     iNum1 := 0;
     if vTemplet is null then
       vErrorMsg := vErrorMsg || '(国际机票审批回复模板未获取)';
     end if;

     if vId is null or vId = '' then
       vErrorMsg := vErrorMsg || '(订单id未获取)';
     end if;
     vOrderId := vId;
     vIdConvert := convertStrToInt(vId,-1);

     --获得行程信息，存入临时变量　vTemp3
     vTemp3 := '';
     for rs in (select * from t_cc_inter_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
       if NVL(vTemp3, 'N') != 'N' then
         vTemp3 := vTemp3 || '；';
       end if;
       vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
       vTemp3 := vTemp3 || to_char(rs.arrive_time, 'FMHH24:FMMI');

       vTemp3 := vTemp3 || rs.airline_name || rs.airline_code||rs.flight_no || ' ';

       vTemp3 := vTemp3 || rs.depart_airport_name || replace(rs.depart_airport_tower, '-', '') ||'('|| to_char(rs.take_off_time, 'HH24:FMMI')||')'|| '-';

       vTemp3 := vTemp3 || rs.arrive_airport_name || replace(rs.arrive_airport_tower, '-', '') || '('||to_char(rs.arrive_time, 'HH24:FMMI') || ')';
     end loop;
     -------------------------------------------------------------------------------------------------
     iNum1 := 1;
     iNum2 := 0;
     iNum3 := 0;
     for rsPlaneOrder in (select * from T_CC_INTER_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
       vTemp2 := '';
       vOrderNo := rsPlaneOrder.plane_order_no;
       for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
          vCompanyName := rsCompany.company_name;
       end loop;
       ----------------------------------------------------------------
        --申请人手机号
       for rsUser in (select *
                        from t_base_user
                       where user_id = rsPlaneOrder.create_user and rownum <=1) loop
         vUserPhone := Trim(rsUser.Mobilephone);
       end loop;
        ----------------------------------------------------------------

     end loop;

     --------生成短信内容---------------

     vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
     vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);

     --比较审批码，若和pass_code相同 ，则通过
     if '1' = vRemark then --审批通过
       vTemplet := Replace(vTemplet, '#RESULT#', '通过');
     elsif '0' = vRemark then--审批驳回
       vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
     else
       vTemplet := Replace(vTemplet, '#RESULT#', '审批码不正确！');
     end if;

     ---发送短信给预订人----
     if vUserPhone is not null and length(vUserPhone) = 11 then
     vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
       vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
     end if;

   end if;


   -----------------------------------------------------------------------------------

     -- 国内机票审批回复 ORDER_FOR_REPLY_PLANE_CIVIL
     -- 2.remark ：pass_code 审核驳回，decline_code 审核通过 发给申请人
     -----------------------------------------------------------------------------------
     if vCode in ('MSG_ORDER_FOR_REPLY_PLANE_CIVIL') then
       iNum1 := 0;
       if vTemplet is null then
         vErrorMsg := vErrorMsg || '(国内机票审批回复模板未获取)';
       end if;

       if vId is null or vId = '' then
         vErrorMsg := vErrorMsg || '(订单id未获取)';
       end if;
       vOrderId := vId;
       vIdConvert := convertStrToInt(vId,-1);

       --获得行程信息，存入临时变量　vTemp3
       vTemp3 := '';
       for rs in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
         if NVL(vTemp3, 'N') != 'N' then
           vTemp3 := vTemp3 || '；';
         end if;
         vTemp3 := vTemp3 || to_char(rs.take_off_time, 'FMMM"月"DD"日"HH24:FMMI');

         vTemp3 := vTemp3 || nvl(rs.airline_name,'') || nvl(rs.airline_code,'') ||nvl(rs.flight_no ,'')|| ' ';

         vTemp3 := vTemp3 || nvl(rs.depart_airport_name,'') || replace(nvl(rs.depart_airport_tower,''), '-', '') ||'('||to_char(rs.take_off_time, 'HH24:FMMI') ||')'|| '-';

         vTemp3 := vTemp3 || nvl(rs.arrive_airport_name,'')|| replace(nvl(rs.arrive_airport_tower,''), '-', '') || '('||to_char(rs.arrive_time, 'HH24:FMMI') ||')' ;
       end loop;
       -------------------------------------------------------------------------------------------------
       iNum1 := 1;
       for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
         vTemp2 := '';
         vOrderNo := rsPlaneOrder.plane_order_no;
         for rsCompany in (select * from T_base_company where company_id = rsPlaneOrder.company_id and rownum <= 1) loop
            vCompanyName := rsCompany.company_name;
         end loop;
         ----------------------------------------------------------------
          --申请人手机号
         for rsUser in (select *
                          from t_base_user
                         where user_id = rsPlaneOrder.create_user and rownum <=1) loop
           vUserPhone := Trim(rsUser.Mobilephone);
         end loop;
          ----------------------------------------------------------------

       end loop;

       --------生成短信内容---------------

       vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);
       vTemplet := Replace(vTemplet, '#ORDERNO#',vOrderNo);

       --比较审批码，若和pass_code相同 ，则通过
       if '1' = vRemark then --审批通过
         vTemplet := Replace(vTemplet, '#RESULT#', '通过');
       elsif '0' = vRemark then--审批驳回
         vTemplet := Replace(vTemplet, '#RESULT#', '驳回');
       else
         vTemplet := Replace(vTemplet, '#RESULT#', '审批码不正确！');
       end if;

       if vUserPhone is null or vUserPhone = '' then
          vErrorMsg := vErrorMsg||'(申请人手机号为空)';
       end if;

       ---发送短信给预订人----
       if vUserPhone is not null and length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
       end if;

     end if;


     --********************接送机服务*******************************
     --1.MSG_PICK_UP_TRANSFER
     -- 您好，您预约的免费送机服务在出票成功后自动生效！ 机票订单号:#ORDERNO#。出发前一天，会与您短信确认，告知车牌号和司机联系方式，请您保持通讯畅通，方便我们与您联系。
     --3.传递参数：
     --*****************************************************
     if vCode in ('MSG_PICK_UP_TRANSFER') then
       --vOrderId := vId;
       vOrderId := convertStrToInt(vId,-1);

       vTemp3 := '';
       for rs in (select * from T_CC_AIRPORT_SHUTTLE where SERVICE_ID = vId) loop

        if rs.plane_order_no is null or rs.plane_order_no = '' then
          vErrorMsg := vErrorMsg || '(订单编号为空)';
        end if;

        vTemplet := Replace(vTemplet, '#ORDERNO#', rs.plane_order_no);
        vUserPhone := rs.PHONE;
        vOrderNo := rs.plane_order_no;

        for rsCompany in (select * from T_base_company where company_id = rs.company_id and rownum <= 1) loop
            vCompanyName := rsCompany.company_name;
         end loop;

         if vUserPhone is not null and length(vUserPhone) = 11 then
          vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
         end if;

       end loop;

       update T_CC_AIRPORT_SHUTTLE set notice_flag='1', notice_time = sysdate where SERVICE_ID = vId;
     end if;


     --********************国内机票 出票超时暂缓 提醒预订人或联系人*******************************
     --1.MSG_PLANE_CIVIL_TIMEOUT_TO_LINK
     --2.您好，您为(#NAME#)预订的#TIME##FLIGHTNO##AIRPORT#，目前还在为您的旅客全力火速出票中，麻烦您耐心等待，谢谢您！
     --3.传递参数：
     --*****************************************************
     if vCode in ('MSG_PLANE_CIVIL_TIMEOUT_TO_LINK') then
       --order_id
       vIdConvert := convertStrToInt(vId, -1);
       vOrderId := vId;

       --********开始解析短信参数***************
       --国内机票行程按起飞时间排序
       vTemp3 :='';
       for cursor_trip in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
         --先解析航程信息，存入vTemp3
         if NVL(vTemp3, 'N') != 'N' then
           vTemp3 := vTemp3 || '；';
         end if;
         vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
         vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
         --如果起飞时间为空，则直接错误短信
         if vTemp3 = '' or vTemp3 = 'N' then
           vErrorMsg := vErrorMsg || '(起飞时间未获取)';
         end if;
         --航司编码为空，直接进入错误信息列表
         if cursor_trip.airline_code is null then
           vErrorMsg := vErrorMsg || '(航司编码未获取)';
         else
           select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
           vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';
           vTemp4 := vTemp || '(' || cursor_trip.airline_code || ')';
           select nvl((select name_cn from T_BASE_AIRPORT where airport_code = cursor_trip.depart_airport_code and rownum <= 1),cursor_trip.depart_airport_code) into vTemp from dual;
           vTemp3 := vTemp3 || vTemp || replace(cursor_trip.depart_airport_tower, '-', '') || '-';
           select nvl((select name_cn from T_BASE_AIRPORT where airport_code = cursor_trip.arrive_airport_code and rownum <= 1),cursor_trip.arrive_airport_code) into vTemp from dual;
           vTemp3 := vTemp3 || vTemp || replace(cursor_trip.arrive_airport_tower, '-', '');
         end if;
       end loop;

       ---------------------------------------------------------------------------------------------------

       for rsPlaneOrder in (select * from T_CC_PLANE_ORDER where plane_order_id = vIdConvert and rownum <= 1) loop
         --订单编号
         vOrderNo := rsPlaneOrder.PLANE_ORDER_NO;
         --企业名称
         for rsCompany in (select COMPANY_NAME,IS_NOTICE_TO_BOOKER from T_BASE_COMPANY
                               WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1) loop
             vCompanyName := rsCompany.COMPANY_NAME;
             --判断是否要给预订人发短信
             if rsCompany.IS_NOTICE_TO_BOOKER = '1' then
               vFlag1 := 1;
             else
               vFlag1 := 0;
             end if;
         end loop;

         select COMPANY_NAME into vCompanyName from T_BASE_COMPANY WHERE COMPANY_ID = rsPlaneOrder.COMPANY_ID and rownum <= 1;
         -----------------------
         --解析短信发送对象
         -----------------------
         --联系人电话
         vContactPhone := rsPlaneOrder.Contact_Phone;
         --预订人电话
         vOrderPhone := '';
         if vFlag1 = 1 then
           select nvl((select mobilephone from t_base_user where user_id=rsPlaneOrder.Create_User and rownum<=1),'') into vOrderPhone from dual;
         end if;

         --乘客信息
         iNum3 := 0;
         for rsTicket in (select * from T_CC_TICKET_PASSENGER where plane_order_id = vIdConvert and state = '3') loop
           --记录一共有几个乘客
           iNum3 := iNum3 + 1;
           --乘机人电话
           vUserPhone := NVL(Trim(rsTicket.Phone),'');

           --将每次判断结果记录下来，如果有多个乘客，则后面给预订人或联系人发短信的时候，要判断是否已经给联系人或者预订人发过短信了
           --vTemp6 := vTemp6 || '-' || iNum1;

           ----------------------------------------------------------------
           -- 组合姓名和票号,格式:姓名010-0001,姓名010-0001，存入vTemp2
           ----------------------------------------------------------------
           if NVL(vTemp2, 'N') != 'N' then
             vTemp2 := vTemp2 || ',';
           end if;
           vTemp2 := vTemp2||rsTicket.Idc_Name;

         end loop;

         -------给预订人、联系人发送短信------------------------------------------------------
         vTemplet := Replace(vTemplet, '#NAME#',vTemp2);
         vTemplet := Replace(vTemplet, '#TIME##FLIGHTNO##AIRPORT#', vTemp3);

        if  length(vContactPhone) = 11 then  --给联系人发短信
          vResult := smsGeneralInterface(vTemp5,vDelay,1,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet1,vContactPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,0);
        end if;

        if length(vOrderPhone) = 11 and vOrderPhone<>vContactPhone then --给预订人发短信
          vResult := smsGeneralInterface(vTemp5,vDelay,1,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet1,vOrderPhone,vRemark,vId,vCompanyName,vErrorMsg1,vOrderNo,1);
        end if;
       end loop;
       --*******短信参数解析完毕******************
     end if;


     --********************客服改价短信*******************************
    --1.MSG_KFZG_MODIFY_PRICE
    -- 客服#EMPLOYEE#申请了#ORDERTYPE#订单改价，申请理由#REASON#，验证码#IDENTIFYCODE#
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_KFZG_MODIFY_PRICE') then
      iNum1 := 0;
      vIdConvert  := convertStrToInt(vId, -1);
      for msg in (select * from T_CS_APPLY_MODIFY_MSG where id = vId ) loop
        vTemplet := replace(vTemplet, '#EMPLOYEE#', msg.apply_name);
        if (msg.order_type = '1') then
          vTemp2 := '国内机票';
        else
          if(msg.order_type = '2') then
          vTemp2 := '国际机票';
          else
          vTemp2 := '订单类型';
          end if;
        end if;
        vTemplet := replace(vTemplet, '#ORDERTYPE#', vTemp2);
        vTemplet := replace(vTemplet, '#REASON#', msg.modify_Reason);
        vTemplet := replace(vTemplet, '#IDENTIFYCODE#', msg.IDENTIFY_CODE);
        if vPhone is not null and length(vPhone) = 11 then  --给联系人发短信
          vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
            vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,4);
        end if;

      end loop;
    end if;


    --********************国内机票紧急通道*******************************
    --1.MSG_ORDER_FOR_EMER_PLANE_CIVIL
    -- 您好，贵公司有国内机票订单已走紧急通道 ，订单号：#ORDERNO#，航班信息：(#NAME#) #TIME##FLIGHTNO##AIRPORT#，订单金额：#TOTAL#。
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_ORDER_FOR_EMER_PLANE_CIVIL') then
      --order_id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;
      --------------------------------------------------------
      --行程信息
      --------------------------------------------------------
      vTemp3 :='';
      for cursor_trip in (select * from t_cc_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
          --先解析航程信息，存入vTemp3
          if NVL(vTemp3, 'N') != 'N' then
            vTemp3 := vTemp3 || '；';
          end if;
          vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
          vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
          --如果起飞时间为空，则直接错误短信
          if vTemp3 = '' or vTemp3 = 'N' then
            vErrorMsg := vErrorMsg || '(起飞时间未获取)';
          end if;
          --航司编码为空，直接进入错误信息列表
          if cursor_trip.airline_code is null then
            vErrorMsg := vErrorMsg || '(航司编码未获取)';
          else
            select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
            vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';
            vTemp4 := vTemp || '(' || cursor_trip.airline_code || ')';
            vTemp3 := vTemp3 || cursor_trip.depart_airport_name || replace(cursor_trip.depart_airport_tower, '-', '') || '-';
            vTemp3 := vTemp3 || cursor_trip.arrive_airport_name || replace(cursor_trip.arrive_airport_tower, '-', '');
          end if;
      end loop;

      --------------------------------------------------------
      --订单详情
      --------------------------------------------------------
      vCompanyName := '';
      for cursor_order in (select plane_order_no,company_id,sale_price from t_cc_plane_order where plane_order_id = vIdConvert) loop
          --订单编号
          vOrderNo := cursor_order.plane_order_no;
          --企业名称
          select company_name into vCompanyName from t_base_company where company_id = cursor_order.company_id;
          --订单金额
          vTemplet := Replace(vTemplet,'#TOTAL#',cursor_order.sale_price);
      end loop;

      ---------乘客信息
      vTemp6 := '';
      for cursor_ticket in (select idc_name from t_cc_ticket_passenger where plane_order_id = vIdConvert) loop
          if vTemp6 <> '' then
            vTemp6 := vTemp6 || ',';
          end if ;
          vTemp6 := vTemp6 || cursor_ticket.idc_name;
      end loop;

      ----------生成短信内容
      vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
      vTemplet := Replace(vTemplet,'#NAME#',vTemp6);
      vTemplet := Replace(vTemplet,'#TIME##FLIGHTNO##AIRPORT#',vTemp3);

      if  length(vPhone) = 11 then  --给联系人发短信
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,4);
      end if;

    end if;

    --********************国际机票紧急通道*******************************
    --1.MSG_ORDER_FOR_EMER_PLANE_INTER
    -- 您好，贵公司有国际机票订单已走紧急通道 ，订单号：#ORDERNO#，航班信息：(#NAME#) #TIME##FLIGHTNO##AIRPORT#，订单金额：#TOTAL#。
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_ORDER_FOR_EMER_PLANE_INTER') then
      --order_id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;
      --------------------------------------------------
      ---行程信息
      --------------------------------------------------
      vTemp3 :='';
      for cursor_trip in (select * from t_cc_inter_plane_trip where plane_order_id = vIdConvert order by take_off_time) loop
        --先解析航程信息，存入vTemp3
        if NVL(vTemp3, 'N') != 'N' then
          vTemp3 := vTemp3 || '；';
        end if;
        vTemp3 := vTemp3 || to_char(cursor_trip.take_off_time, 'FMMM"月"DD"日"HH24:FMMI') || '-';
        vTemp3 := vTemp3 || to_char(cursor_trip.arrive_time, 'FMHH24:FMMI');
        --航司编码为空，直接进入错误信息列表
        if cursor_trip.airline_code is null then
          vErrorMsg := vErrorMsg || '(航司编码未获取)';
        else
          select nvl((select airline_name_abbr from T_BASE_AIRLINE where airline_code = cursor_trip.airline_code and rownum <= 1),cursor_trip.airline_code) into vTemp from dual;
          vTemp3 := vTemp3 || vTemp || cursor_trip.airline_code || cursor_trip.flight_no || ' ';
          vTemp4 := vTemp || '(' || cursor_trip.airline_code || ')';
          vTemp3 := vTemp3 || cursor_trip.depart_airport_name || replace(cursor_trip.depart_airport_tower, '-', '') || '-';
          vTemp3 := vTemp3 || cursor_trip.arrive_airport_name || replace(cursor_trip.arrive_airport_tower, '-', '');

        end if;

      end loop;

      -----------------------------------------------
      --订单详情
      ----------------------------------------------
      for cursor_order in (select plane_order_no,company_id,sale_price from t_cc_plane_order) loop
          --订单编号
          vOrderNo := cursor_order.plane_order_no;
          --企业名称
          select company_name into vCompanyName from T_base_company where company_id = cursor_order.company_id;
          --订单价格
          vTemplet := Replace(vTemplet,'#TOTAL#',cursor_order.sale_price);
      end loop;

      -------------------------------------------
      --乘客信息
      -------------------------------------------
      vTemp6 := '';
      for cursor_ticket in (select idc_name from T_CC_INTER_TICKET_PASSENGER where plane_order_id = vIdConvert) loop
          if vTemp6 <> '' then
              vTemp6 := vTemp6 || ',';
          end if;
          vTemp6 := vTemp6 || cursor_ticket.idc_name;
      end loop;

      -----生成短信内容
      vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
      vTemplet := Replace(vTemplet,'#NAME#',vTemp6);
      vTemplet := Replace(vTemplet,'#TIME##FLIGHTNO##AIRPORT#',vTemp3);

      if  length(vPhone) = 11 then  --给联系人发短信
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,4);
      end if;

    end if;

    --********************火车票紧急通道*******************************
    --1.MSG_ORDER_FOR_EMER_TRAIN
    -- 您好，贵公司有火车票订单已走紧急通道 ，订单号：#ORDERNO#，信息：(#NAME#) #DATE##CODE##TRIP#，订单金额：#TOTAL#！
    --3.传递参数：
    --*****************************************************
    if vCode in ('MSG_ORDER_FOR_EMER_TRAIN') then
      --order_id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;
      --------------------------------------------------
      --行程信息
      --------------------------------------------------
      --解析火车票行程
      for cursor_trip in (select * from t_cc_train_trip where train_order_id = vIdConvert) loop
        --出发时间 月 日
        vTemp := to_char(cursor_trip.DEPART_DATE,'mm')||'月'||to_char(cursor_trip.DEPART_DATE,'dd')||'日';
        --生成行程信息
        vTemp1 := vTemp1 || cursor_trip.train_code || '次 ' || cursor_trip.DEPART_TIME || cursor_trip.DEPART_STATION || '-';
        vTemp1 := vTemp1 || cursor_trip.ARRIVE_TIME || cursor_trip.ARRIVE_STATION ;
        --订单号
        vOrderNo := cursor_trip.TRAIN_ORDER_NO;
      end loop;
      if vTemp is null or vTemp1 is null then
          vErrorMsg := vErrorMsg || '(行程信息未获取)';
      end if;

      ------------------------------------------
      --火车票订单
      ------------------------------------------
      for cursor_order in (select TRAIN_ORDER_NO,COMPANY_ID,SALE_PRICE from t_cc_train_order where train_order_id = vIdConvert) loop
          --订单编号
          vOrderNo := cursor_order.TRAIN_ORDER_NO;
          --企业名称
          select company_name into vCompanyName from T_BASE_COMPANY where company_id = cursor_order.company_id;
          --订单销价
          vTemplet := Replace(vTemplet,'#TOTAL#',cursor_order.SALE_PRICE);
      end loop;

      ---------------------------------------
      --火车票乘客信息
      ---------------------------------------
      vTemp6 := '';
      for cusor_ticket in (select idc_name from T_CC_TRAIN_TICKET where train_order_id = vIdConvert) loop
          if vTemp6 <> '' then
            vTemp6 := vTemp6 || ',';
          end if;
          vTemp6 := vTemp6 || cusor_ticket.idc_name;
      end loop;

      --------------------------------------
      --生成短信内容
      --------------------------------------
      vTemplet := Replace(vTemplet,'#ORDERNO#',vOrderNo);
      vTemplet := Replace(vTemplet,'#NAME#',vTemp6);
      vTemplet := Replace(vTemplet,'#DATE#',vTemp);
      vTemplet := Replace(vTemplet,'#CODE##TRIP#',vTemp1);

      if  length(vPhone) = 11 then  --给联系人发短信
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,4);
      end if;
    end if;


    --********************紧急通道*******************************
    --1.ORDER_FOR_EMER_EXIT
    -- 尊敬的客户：您好！员工#APPLY#于#APPLYTIME#填写的 #ORDERTYPE# 申请单已走紧急通道流程。
    --3.传递参数：
    --*****************************************************
    if vCode in ('ORDER_FOR_EMER_EXIT') then
      --order_id
      vIdConvert := convertStrToInt(vId, -1);
      vOrderId := vId;
      vOrderNo := vId;

      for cusror_order in (select company_id ,apply_user,APPLY_TIME from t_cc_order_audit where audit_id = vIdConvert) loop
          ---申请人
          for cusror_app in (select name_cn,PINYIN_FULL,mobilephone from t_base_user where user_id = cusror_order.apply_user) loop
              if cusror_app.name_cn is not null then
                  vTemp1 := cusror_app.name_cn;
              else
                  vTemp1 := cusror_app.PINYIN_FULL;
              end if;
              --申请人接收号码
              vOrderPhone := cusror_app.mobilephone;

          end loop;

          --企业名称
          select company_name into vCompanyName from t_base_company where company_id = cusror_order.company_id;

          if cusror_order.APPLY_TIME is null then
            vErrorMsg := '(申请时间未获取)';
          end if;

          vTemplet := Replace(vTemplet,'#APPLYTIME#',cusror_order.APPLY_TIME);
          vTemplet := Replace(vTemplet,'#ORDERTYPE#',vRemark);

      end loop;

      vTemplet := Replace(vTemplet,'#APPLY#',vTemp1);
      if length(vUserPhone) = 11 then
        vResult := smsGeneralInterface(vCode,vDelay,vSwitch,vMaType,vPriority,vMsgType,
          vOrderId,vCompanyId,vTemplet,vUserPhone,vRemark,vId,vCompanyName,vErrorMsg,vOrderNo,3);
      end if;
    end if;




return vResult;
end;

END SMS_SEND_PACKAGE;