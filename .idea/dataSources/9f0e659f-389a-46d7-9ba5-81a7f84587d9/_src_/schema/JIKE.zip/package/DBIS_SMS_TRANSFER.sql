create PACKAGE DBIS_SMS_TRANSFER AS 

  
  --*********************************
  --短信发送业务 中转调度--
  --*********************************
  function smsSendingTransfer return varchar2;
  
  --**********************************
  --短信错误消息重新发送 中转调度--
  --**********************************
  function errsmsResendTransfer return varchar2;
  
  --**********************************
  --下行短信 审批--
  --**********************************
  function toCheckSmsReply return varchar2;
  
  --**********************************
  --短信错误消息重新发送 中转调度--
  --**********************************
  /*
  function solveSmsRecord return varchar2;
  */

END DBIS_SMS_TRANSFER;