create PACKAGE BODY LIST_JOBS IS
  ----------------------------------
  -- 国内酒店订单-取消，每分钟轮循
  -- 条件：
  -- 1.表名：T_CH_HOTEL_ORDER
  -- 2.条件：ORDER_ID IS NULL
  --         SYSDATE-CREATE_TIME>=28分钟
  --         LOCAL_STATUS NOT IN ('4')
  -- 3.结果：LOCAL_STATUS='4'
  -- 日期：2015-02-11
  ----------------------------------
  PROCEDURE CANCEL_HOTEL_ORDER(iiMinute IN INTEGER) AS
    iNum INTEGER;

    dtNow DATE;
    vsNow varchar2(50);
    errorResult EXCEPTION;
  BEGIN
    dtNow := SYSDATE;
    vsNow := TO_CHAR(dtNow, 'YYYY-MM-DD HH24:MI:SS');
    RAISE errorResult;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 机票订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_PLANE_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-03-12
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_PLANE_ORDER(currentDay IN DATE) AS
    v_purSettleState varchar2(4);
    v_supSettleState varchar2(4);
    v_purSettleTime  DATE;
    v_supSettleTime  DATE;
  BEGIN
    --删除
    delete from T_FIN_REPORT_PLANE_ORDER
     where (complete_time >= trunc(currentDay, 'dd') - 1000 and
           complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
        or complete_time is null;

    --更新未结算的结算状态
    for rs in (select *
                 from T_FIN_REPORT_PLANE_ORDER
                where complete_time <=
                      trunc(currentDay, 'dd') - 1 - 1 / 24 / 60 / 60
                  and (pur_settle_state = '0' or sup_settle_state = '0')) loop

      --1国内出票，2国际出票，3国内改签，4国际改签，5国内退票，6国际退票
      if rs.order_type = '1' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_plane_order
           where plane_order_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.order_type = '2' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_inter_plane_order
           where plane_order_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.order_type = '3' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_plane_change
           where change_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.order_type = '4' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_inter_plane_change
           where change_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.order_type = '5' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_plane_refund
           where refund_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.order_type = '6' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_inter_plane_refund
           where refund_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
        --else
        --v_purSettleState := null;
        --v_supSettleState := null;
      end if;
    end loop;

    --新增
    insert into T_FIN_REPORT_PLANE_ORDER
      (ORDER_ID,
       ORDER_NO,
       ORDER_TYPE,
       STATE,
       PNR,
       SEPARATE_PNR,
       COMPANY_ID,
       COST_CENTER_ID,
       SALE_PRICE,
       FLOOR_PRICE,
       SERVICE_PRICE,
       TICKET_SALE_PRICE,
       TICKET_FLOOR_PRICE,
       INSURANCE_SALE_PRICE,
       INSURANCE_FLOOR_PRICE,
       APPLY_USER,
       APPLY_USER_NAME,
       APPLY_USER_PHONE,
       APPLY_EMPLOYEE,
       APPLY_TIME,
       CANCEL_USER,
       CANCEL_USER_NAME,
       CANCEL_USER_PHONE,
       CANCEL_EMPLOYEE,
       CANCEL_TIME,
       HANDLING_TIME,
       HANDLING_EMPLOYEE,
       COMPLETE_TIME,
       COMPLETE_EMPLOYEE,
       PUR_ID,
       PUR_NAME,
       PUR_HANDLING_FEE,
       PUR_REBATE,
       PUR_REFUND_MONEY,
       PUR_PRICE_DIFFERENCE,
       PUR_PAY_TIME,
       PUR_PAY_TYPE,
       PUR_SETTLE_TYPE,
       PUR_SETTLE_STATE,
       PUR_SETTLE_TIME,
       PUR_SETTLE_DETAIL_ID,
       PUR_CHECK_STATE,
       PUR_CHECK_TIME,
       PUR_CHECK_EMPLOYEE,
       SUP_ID,
       SUP_NAME,
       SUP_HANDLING_FEE,
       SUP_REBATE,
       SUP_REFUND_MONEY,
       SUP_PRICE_DIFFERENCE,
       SUP_BILL_NO,
       SUP_PAY_TYPE,
       SUP_PAY_TIME,
       SUP_SETTLE_TYPE,
       SUP_SETTLE_STATE,
       SUP_SETTLE_TIME,
       SUP_SETTLE_DETAIL_ID,
       SUP_CHECK_STATE,
       SUP_CHECK_TIME,
       SUP_CHECK_EMPLOYEE,
       DEPT_ID,
       DEPT_NAME,
       PLANE_ORDER_ID,
       PLANE_ORDER_NO,
       REPORT_CREATE_TIME)
      select co.plane_order_id order_id,
             co.plane_order_no order_no,
             '1' order_type,
             co.state,
             co.pnr,
             null separate_pnr,
             co.company_id,
             co.cost_center_id,
             co.sale_price,
             co.floor_price,
             co.service_price,
             co.ticket_sale_price,
             co.ticket_floor_price,
             co.insurance_sale_price,
             co.insurance_floor_price,
             co.create_user apply_user,
             co.create_user_name apply_user_name,
             co.create_user_phone apply_user_phone,
             co.create_employee apply_employee,
             co.create_time apply_time,
             co.cancel_user,
             co.cancel_user_name,
             co.cancel_user_phone,
             co.cancel_employee,
             co.cancel_time,
             co.handling_time,
             co.handling_employee,
             co.ticketing_time complete_time,
             co.ticketing_employee complete_employee,
             co.pur_id,
             co.pur_name,
             co.pur_handling_fee,
             co.pur_rebate,
             null pur_refund_money,
             null pur_price_difference,
             co.pur_pay_time,
             co.pur_pay_type,
             co.pur_settle_type,
             co.pur_settle_state,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_id,
             co.sup_name,
             co.sup_handling_fee,
             co.sup_rebate,
             null sup_refund_money,
             null sup_price_difference,
             co.sup_bill_no,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_settle_type,
             co.sup_settle_state,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             getDeptIdByUserId(co.create_user) dept_id,
             null dept_name,
             null plane_order_id,
             null plane_order_no,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_plane_order co
       where co.ticketing_time >= trunc(currentDay, 'dd') - 1000
         and co.ticketing_time <=
             trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and (co.state = '4' or co.state = '5' or co.state = '6')
      union all
      select co.change_id order_id,
             co.change_no order_no,
             '3' order_type,
             co.state,
             co.pnr,
             co.separate_pnr,
             co.company_id,
             co.cost_center_id,
             co.sale_price,
             co.floor_price,
             co.service_price,
             co.ticket_sale_price,
             co.ticket_floor_price,
             co.insurance_sale_price,
             co.insurance_floor_price,
             co.apply_user,
             co.apply_user_name,
             co.apply_user_phone,
             co.apply_employee,
             co.apply_time,
             co.cancel_user,
             co.cancel_user_name,
             co.cancel_user_phone,
             co.cancel_employee,
             co.cancel_time,
             co.handling_time,
             co.handling_employee,
             co.complete_time,
             co.complete_employee,
             co.pur_id,
             co.pur_name,
             co.pur_handling_fee,
             null pur_rebate,
             null pur_refund_money,
             co.pur_price_difference,
             co.pur_pay_time,
             co.pur_pay_type,
             co.pur_settle_type,
             co.pur_settle_state,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_id,
             co.sup_name,
             co.sup_handling_fee,
             null sup_rebate,
             null sup_refund_money,
             co.sup_price_difference,
             co.sup_bill_no,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_settle_type,
             co.sup_settle_state,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             getDeptIdByUserId(co.apply_user) dept_id,
             null dept_name,
             co.plane_order_id,
             co.plane_order_no,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_plane_change co
       where co.complete_time >= trunc(currentDay, 'dd') - 1000
         and co.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and (co.state = '3' or co.state = '4')
      union all
      select co.refund_id order_id,
             co.refund_no order_no,
             '5' order_type,
             co.state,
             co.pnr,
             co.separate_pnr,
             co.company_id,
             co.cost_center_id,
             co.sale_price,
             co.floor_price,
             co.service_price,
             co.ticket_sale_price,
             co.ticket_floor_price,
             co.insurance_sale_price,
             co.insurance_floor_price,
             co.apply_user,
             co.apply_user_name,
             co.apply_user_phone,
             co.apply_employee,
             co.apply_time,
             co.cancel_user,
             co.cancel_user_name,
             co.cancel_user_phone,
             co.cancel_employee,
             co.cancel_time,
             co.handling_time,
             co.handling_employee,
             co.complete_time,
             co.complete_employee,
             co.pur_id,
             co.pur_name,
             co.pur_handling_fee,
             null pur_rebate,
             co.pur_refund_money,
             null pur_price_difference,
             null pur_pay_time,
             co.pur_pay_type,
             co.pur_settle_type,
             co.pur_settle_state,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_id,
             co.sup_name,
             co.sup_handling_fee,
             null sup_rebate,
             co.sup_refund_money,
             null sup_price_difference,
             co.sup_bill_no,
             co.sup_pay_type,
             null sup_pay_time,
             co.sup_settle_type,
             co.sup_settle_state,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             getDeptIdByUserId(co.apply_user) dept_id,
             null dept_name,
             co.plane_order_id,
             co.plane_order_no,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_plane_refund co
       where co.complete_time >= trunc(currentDay, 'dd') - 1000
         and co.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and (co.state = '3' or co.state = '4')
      union all
      select co.plane_order_id order_id,
             co.plane_order_no order_no,
             '2' order_type,
             co.state,
             co.pnr,
             null separate_pnr,
             co.company_id,
             co.cost_center_id,
             co.sale_price,
             co.floor_price,
             co.service_price,
             co.ticket_sale_price,
             co.ticket_floor_price,
             co.insurance_sale_price,
             co.insurance_floor_price,
             co.create_user apply_user,
             co.create_user_name apply_user_name,
             co.create_user_phone apply_user_phone,
             co.create_employee apply_employee,
             co.create_time apply_time,
             co.cancel_user,
             co.cancel_user_name,
             co.cancel_user_phone,
             co.cancel_employee,
             co.cancel_time,
             co.handling_time,
             co.handling_employee,
             co.ticketing_time complete_time,
             co.ticketing_employee complete_employee,
             co.pur_id,
             co.pur_name,
             co.pur_handling_fee,
             null pur_rebate,
             null pur_refund_money,
             null pur_price_difference,
             co.pur_pay_time,
             co.pur_pay_type,
             co.pur_settle_type,
             co.pur_settle_state,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_id,
             co.sup_name,
             co.sup_handling_fee,
             null sup_rebate,
             null sup_refund_money,
             null sup_price_difference,
             co.sup_bill_no,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_settle_type,
             co.sup_settle_state,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             getDeptIdByUserId(co.create_user) dept_id,
             null dept_name,
             null plane_order_id,
             null plane_order_no,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_inter_plane_order co
       where co.ticketing_time >= trunc(currentDay, 'dd') - 1000
         and co.ticketing_time <=
             trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and (co.state = '4' or co.state = '5' or co.state = '6')
      union all
      select co.change_id order_id,
             co.change_no order_no,
             '4' order_type,
             co.state,
             co.pnr,
             co.separate_pnr,
             co.company_id,
             co.cost_center_id,
             co.sale_price,
             co.floor_price,
             co.service_price,
             co.ticket_sale_price,
             co.ticket_floor_price,
             co.insurance_sale_price,
             co.insurance_floor_price,
             co.apply_user,
             co.apply_user_name,
             co.apply_user_phone,
             co.apply_employee,
             co.apply_time,
             co.cancel_user,
             co.cancel_user_name,
             co.cancel_user_phone,
             co.cancel_employee,
             co.cancel_time,
             co.handling_time,
             co.handling_employee,
             co.complete_time,
             co.complete_employee,
             co.pur_id,
             co.pur_name,
             co.pur_handling_fee,
             null pur_rebate,
             null pur_refund_money,
             co.pur_price_difference,
             co.pur_pay_time,
             co.pur_pay_type,
             co.pur_settle_type,
             co.pur_settle_state,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_id,
             co.sup_name,
             co.sup_handling_fee,
             null sup_rebate,
             null sup_refund_money,
             co.sup_price_difference,
             co.sup_bill_no,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_settle_type,
             co.sup_settle_state,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             getDeptIdByUserId(co.apply_user) dept_id,
             null dept_name,
             co.plane_order_id,
             co.plane_order_no,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_inter_plane_change co
       where co.complete_time >= trunc(currentDay, 'dd') - 1000
         and co.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and (co.state = '3' or co.state = '4')
      union all
      select co.refund_id order_id,
             co.refund_no order_no,
             '6' order_type,
             co.state,
             co.pnr,
             co.separate_pnr,
             co.company_id,
             co.cost_center_id,
             co.sale_price,
             co.floor_price,
             co.service_price,
             co.ticket_sale_price,
             co.ticket_floor_price,
             co.insurance_sale_price,
             co.insurance_floor_price,
             co.apply_user,
             co.apply_user_name,
             co.apply_user_phone,
             co.apply_employee,
             co.apply_time,
             co.cancel_user,
             co.cancel_user_name,
             co.cancel_user_phone,
             co.cancel_employee,
             co.cancel_time,
             co.handling_time,
             co.handling_employee,
             co.complete_time,
             co.complete_employee,
             co.pur_id,
             co.pur_name,
             co.pur_handling_fee,
             null pur_rebate,
             co.pur_refund_money,
             null pur_price_difference,
             null pur_pay_time,
             co.pur_pay_type,
             co.pur_settle_type,
             co.pur_settle_state,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_id,
             co.sup_name,
             co.sup_handling_fee,
             null sup_rebate,
             co.sup_refund_money,
             null sup_price_difference,
             co.sup_bill_no,
             co.sup_pay_type,
             null sup_pay_time,
             co.sup_settle_type,
             co.sup_settle_state,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             getDeptIdByUserId(co.apply_user) dept_id,
             null dept_name,
             co.plane_order_id,
             co.plane_order_no,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_inter_plane_refund co
       where co.complete_time >= trunc(currentDay, 'dd') - 1000
         and co.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and (co.state = '3' or co.state = '4');

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 机票报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_PLANE_TICKET
  -- 2.条件：查询前一天的机票数据
  -- 3.结果：
  -- 日期：2015-03-24
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_PLANE_TICKET(currentDay IN DATE) AS
    v_purSettleState varchar2(20);
    v_supSettleState varchar2(20);
    v_purSettleTime  DATE;
    v_supSettleTime  DATE;
  BEGIN
    --删除
    delete from T_FIN_REPORT_PLANE_TICKET
     where (TICKETING_TIME >= trunc(currentDay, 'dd') - 1000 and
           TICKETING_TIME <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
        or TICKETING_TIME is null;

    --更新未结算的结算状态
    for rs in (select *
                 from T_FIN_REPORT_PLANE_TICKET
                where TICKETING_TIME <=
                      trunc(currentDay, 'dd') - 1 - 1 / 24 / 60 / 60
                  and (pur_settle_state = '0' or sup_settle_state = '0')) loop

      --1国内出票，2国际出票，3国内改签，4国际改签，5国内退票，6国际退票
      if rs.plane_ticket_type = '1' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_plane_order
           where plane_order_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.plane_ticket_type = '2' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_inter_plane_order
           where plane_order_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.plane_ticket_type = '3' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_plane_change
           where change_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.plane_ticket_type = '4' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_inter_plane_change
           where change_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.plane_ticket_type = '5' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_plane_refund
           where refund_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.plane_ticket_type = '6' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_inter_plane_refund
           where refund_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_PLANE_TICKET
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
        --else
        --v_purSettleState := null;
        --v_supSettleState := null;
      end if;
    end loop;

    --新增
    insert into T_FIN_REPORT_PLANE_TICKET
      (PLANE_TICKET_ID,
       PLANE_TICKET_NO,
       PLANE_ORDER_ID,
       PLANE_ORDER_NO,
       PLANE_TICKET_TYPE,
       TICKETING_EMPLOYEE,
       TICKETING_TIME,
       STATE,
       PAX_ID,
       IDC_NAME,
       PHONE,
       BIRTHDAY,
       SEX,
       PERSON_TYPE,
       IDC_TYPE,
       IDC_NO,
       FACE_PRICE,
       SALE_PRICE,
       AIRPORT_CST_FEE,
       FUEL_FEE,
       FLOOR_PRICE,
       SALE_DISCOUNT,
       FLOOR_DISCOUNT,
       PREMIUM,
       REBATE,
       COMPANY_ID,
       CREATE_USER,
       CREATE_TIME,
       MODIFY_USER,
       MODIFY_TIME,
       COST_CENTER_ID,
       PAX_SOURCE,
       FLIGHT_TYPE,
       CREATE_EMPLOYEE,
       PREV_PLANE_TICKET_ID,
       PNR,
       PASSENGER_TYPE,
       EMAIL,
       TICKETING_FEE,
       DEPART_CITY,
       DEPART_CITY_CODE,
       DEPART_CITY_NAME,
       DEPART_AIRPORT_CODE,
       DEPART_AIRPORT_NAME,
       DEPART_AIRPORT_TOWER,
       DEPART_TIME,
       ARRIVE_CITY,
       ARRIVE_CITY_CODE,
       ARRIVE_CITY_NAME,
       ARRIVE_AIRPORT_CODE,
       ARRIVE_AIRPORT_NAME,
       ARRIVE_AIRPORT_TOWER,
       ARRIVE_TIME,
       PRICE,
       LOWEST_PRICE_CURRENT,
       LOWEST_PRICE_ONEHOUR,
       LOWEST_PRICE_TWOHOUR,
       LOSE_PRICE_CURRENT,
       LOSE_PRICE_ONEHOUR,
       LOSE_PRICE_TWOHOUR,
       TICKET_DISCOUNT,
       PUR_ID,
       PUR_NAME,
       PUR_SETTLE_STATE,
       SUP_ID,
       SUP_NAME,
       SUP_SETTLE_STATE,
       REPORT_CREATE_TIME,
       DEPT_ID,
       STANDARD_TICKET_ID,
       STANDARD_TICKET_PRICE,
       TICKET_DISCOUNT_ONEHOUR,
       TICKET_DISCOUNT_TWOHOUR,
       IS_USER,
       USER_ID,
       CONTACT_ID,
       TAX,
       ORIG_PLANE_TICKET_NO,
       SUP_PRICE_DIFFERENCE,
       SUP_HANDLING_FEE,
       SUP_FLOOR_PRICE,
       PUR_PRICE_DIFFERENCE,
       PUR_HANDLING_FEE,
       PUR_SALE_PRICE,
       SUP_REFUND_MONEY,
       PUR_REFUND_MONEY,
       CABIN_CLASS,
       AIRLINE_CODE,
       ORIG_PLANE_TICKET_ID,
       PUR_PAY_STATE,
       PUR_PAY_TIME,
       PUR_PAY_TYPE,
       ORDER_ID,
       ORDER_NO,
       PUR_SETTLE_TIME,
       PUR_SETTLE_DETAIL_ID,
       PUR_CHECK_STATE,
       PUR_CHECK_TIME,
       PUR_CHECK_EMPLOYEE,
       SUP_PAY_TIME,
       SUP_PAY_TYPE,
       SUP_SETTLE_TIME,
       SUP_SETTLE_DETAIL_ID,
       SUP_CHECK_STATE,
       SUP_CHECK_TIME,
       SUP_CHECK_EMPLOYEE,
       TRIP,
       CABIN,
       IS_LOWEST_FLIGHT,
       LOWEST_FLIGHT_ID,
       NOT_LOWEST_CODE,
       NOT_LOWEST_REASON)
      with t_order as
       (select ct.plane_ticket_id,
               ct.plane_ticket_no,
               ct.plane_order_id,
               ct.plane_order_no,
               '1' plane_ticket_type,
               ct.ticketing_employee,
               ct.ticketing_time,
               ct.state,
               ct.pax_id,
               ct.idc_name,
               ct.phone,
               ct.birthday,
               ct.sex,
               ct.person_type,
               ct.idc_type,
               ct.idc_no,
               ct.face_price,
               null tax,
               ct.sale_price,
               ct.airport_cst_fee,
               ct.fuel_fee,
               ct.floor_price,
               ct.sale_discount,
               ct.floor_discount,
               ct.premium,
               ct.rebate,
               ct.company_id,
               ct.create_user,
               ct.create_time,
               ct.modify_user,
               ct.modify_time,
               ct.cost_center_id,
               getDeptIdByUserId(ct.create_user) dept_id,
               ct.pax_source,
               ct.flight_type,
               ct.create_employee,
               ct.prev_plane_ticket_id,
               ct.pnr,
               ct.passenger_type,
               ct.email,
               ct.ticketing_fee,
               cod.depart_city,
               cod.depart_city_code,
               cod.depart_city_name,
               cod.depart_airport_code,
               cod.depart_airport_name,
               cod.depart_airport_tower,
               cod.depart_time,
               cod.arrive_city,
               cod.arrive_city_code,
               cod.arrive_city_name,
               cod.arrive_airport_code,
               cod.arrive_airport_name,
               cod.arrive_airport_tower,
               cod.arrive_time,
               cod.price,
               null standard_ticket_id,
               ct.standard_price standard_ticket_price,
               ct.lowest_price_current lowest_price_current,
               ct.lowest_price_one_hour lowest_price_onehour,
               ct.lowest_price_two_hour lowest_price_twohour,
               null lose_price_current,
               null lose_price_onehour,
               null lose_price_twohour,
               null ticket_discount,
               null ticket_discount_onehour,
               null ticket_discount_twohour,
               null is_user,
               null user_id,
               null contact_id,
               co.pur_id,
               co.pur_name,
               co.pur_settle_state,
               co.sup_id,
               co.sup_name,
               co.sup_settle_state,
               null pur_pay_state,
               co.pur_pay_time,
               co.pur_pay_type,
               co.plane_order_id order_id,
               co.plane_order_no order_no,
               co.pur_settle_time,
               co.pur_settle_detail_id,
               co.pur_check_state,
               co.pur_check_time,
               co.pur_check_employee,
               co.sup_pay_time,
               co.sup_pay_type,
               co.sup_settle_time,
               co.sup_settle_detail_id,
               co.sup_check_state,
               co.sup_check_time,
               co.sup_check_employee,
               cod.cabin,
               cod.is_lowest_flight,
               cod.lowest_flight_id,
               cod.not_lowest_code,
               cod.not_lowest_reason
          from t_cc_plane_order      co,
               t_cc_ticket_passenger ct,
               t_cc_plane_od         cod
         where co.ticketing_time >= trunc(currentDay, 'dd') - 1000
           and co.ticketing_time <=
               trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
           and co.plane_order_id = ct.plane_order_id
           and cod.plane_order_id = co.plane_order_id
           and ct.ticketing_time is not null
           and ct.prev_plane_ticket_id is null),
      t_refund as
       (select ct.plane_ticket_id,
               ct.plane_ticket_no,
               ct.plane_order_id,
               ct.plane_order_no,
               '5' plane_ticket_type,
               ct.ticketing_employee,
               ct.ticketing_time,
               ct.state,
               ct.pax_id,
               ct.idc_name,
               ct.phone,
               ct.birthday,
               ct.sex,
               ct.person_type,
               ct.idc_type,
               ct.idc_no,
               ct.face_price,
               null tax,
               ct.sale_price,
               ct.airport_cst_fee,
               ct.fuel_fee,
               ct.floor_price,
               ct.sale_discount,
               ct.floor_discount,
               ct.premium,
               ct.rebate,
               ct.company_id,
               ct.create_user,
               ct.create_time,
               ct.modify_user,
               ct.modify_time,
               ct.cost_center_id,
               getDeptIdByUserId(ct.create_user) dept_id,
               ct.pax_source,
               ct.flight_type,
               ct.create_employee,
               ct.prev_plane_ticket_id,
               ct.pnr,
               ct.passenger_type,
               ct.email,
               ct.ticketing_fee,
               cod.depart_city,
               cod.depart_city_code,
               cod.depart_city_name,
               cod.depart_airport_code,
               cod.depart_airport_name,
               cod.depart_airport_tower,
               cod.depart_time,
               cod.arrive_city,
               cod.arrive_city_code,
               cod.arrive_city_name,
               cod.arrive_airport_code,
               cod.arrive_airport_name,
               cod.arrive_airport_tower,
               cod.arrive_time,
               cod.price,
               null standard_ticket_id,
               ct.standard_price standard_ticket_price,
               ct.lowest_price_current lowest_price_current,
               ct.lowest_price_one_hour lowest_price_onehour,
               ct.lowest_price_two_hour lowest_price_twohour,
               null lose_price_current,
               null lose_price_onehour,
               null lose_price_twohour,
               null ticket_discount,
               null ticket_discount_onehour,
               null ticket_discount_twohour,
               null is_user,
               null user_id,
               null contact_id,
               cr.pur_id,
               cr.pur_name,
               cr.pur_settle_state,
               cr.sup_id,
               cr.sup_name,
               cr.sup_settle_state,
               crt.floor_price sup_floor_price,
               crt.sup_refund_money,
               crt.sup_handling_fee,
               crt.sale_price pur_sale_price,
               crt.pur_refund_money,
               crt.pur_handling_fee,
               null pur_pay_state,
               null pur_pay_time,
               cr.pur_pay_type,
               cr.refund_id order_id,
               cr.refund_no order_no,
               cr.pur_settle_time,
               cr.pur_settle_detail_id,
               cr.pur_check_state,
               cr.pur_check_time,
               cr.pur_check_employee,
               null sup_pay_time,
               cr.sup_pay_type,
               cr.sup_settle_time,
               cr.sup_settle_detail_id,
               cr.sup_check_state,
               cr.sup_check_time,
               cr.sup_check_employee,
               null cabin,
               null is_lowest_flight,
               null lowest_flight_id,
               null not_lowest_code,
               null not_lowest_reason
          from t_cc_plane_refund     cr,
               t_cc_refund_ticket    crt,
               t_cc_ticket_passenger ct,
               t_cc_plane_od         cod
         where cr.complete_time >= trunc(currentDay, 'dd') - 1000
           and cr.complete_time <=
               trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
           and cr.refund_id = crt.refund_id
           and crt.plane_ticket_id = ct.plane_ticket_id
           and cr.plane_order_id = cod.plane_order_id
           and ct.ticketing_time is not null),
      t_change as
       (select ct.plane_ticket_id,
               ct.plane_ticket_no,
               ct.plane_order_id,
               ct.plane_order_no,
               '3' plane_ticket_type,
               ct.ticketing_employee,
               ct.ticketing_time,
               ct.state,
               ct.pax_id,
               ct.idc_name,
               ct.phone,
               ct.birthday,
               ct.sex,
               ct.person_type,
               ct.idc_type,
               ct.idc_no,
               ct.face_price,
               null tax,
               ct.sale_price,
               ct.airport_cst_fee,
               ct.fuel_fee,
               ct.floor_price,
               ct.sale_discount,
               ct.floor_discount,
               ct.premium,
               ct.rebate,
               ct.company_id,
               ct.create_user,
               ct.create_time,
               ct.modify_user,
               ct.modify_time,
               ct.cost_center_id,
               getDeptIdByUserId(ct.create_user) dept_id,
               ct.pax_source,
               ct.flight_type,
               ct.create_employee,
               ct.prev_plane_ticket_id,
               ct.pnr,
               ct.passenger_type,
               ct.email,
               ct.ticketing_fee,
               cod.depart_city,
               cod.depart_city_code,
               cod.depart_city_name,
               cod.depart_airport_code,
               cod.depart_airport_name,
               cod.depart_airport_tower,
               cod.depart_time,
               cod.arrive_city,
               cod.arrive_city_code,
               cod.arrive_city_name,
               cod.arrive_airport_code,
               cod.arrive_airport_name,
               cod.arrive_airport_tower,
               cod.arrive_time,
               cod.price,
               null standard_ticket_id,
               ct.standard_price standard_ticket_price,
               ct.lowest_price_current lowest_price_current,
               ct.lowest_price_one_hour lowest_price_onehour,
               ct.lowest_price_two_hour lowest_price_twohour,
               null lose_price_current,
               null lose_price_onehour,
               null lose_price_twohour,
               null ticket_discount,
               null ticket_discount_onehour,
               null ticket_discount_twohour,
               null is_user,
               null user_id,
               null contact_id,
               cc.pur_id,
               cc.pur_name,
               cc.pur_settle_state,
               cc.sup_id,
               cc.sup_name,
               cc.sup_settle_state,
               cct.orig_plane_ticket_id,
               cct.orig_plane_ticket_no,
               cct.sup_price_difference,
               cct.sup_handling_fee,
               cct.floor_price sup_floor_price,
               cct.pur_price_difference,
               cct.pur_handling_fee,
               cct.sale_price pur_sale_price,
               null pur_pay_state,
               cc.pur_pay_time,
               cc.pur_pay_type,
               cc.change_id order_id,
               cc.change_no order_no,
               cc.pur_settle_time,
               cc.pur_settle_detail_id,
               cc.pur_check_state,
               cc.pur_check_time,
               cc.pur_check_employee,
               cc.sup_pay_time,
               cc.sup_pay_type,
               cc.sup_settle_time,
               cc.sup_settle_detail_id,
               cc.sup_check_state,
               cc.sup_check_time,
               cc.sup_check_employee,
               null cabin,
               null is_lowest_flight,
               null lowest_flight_id,
               null not_lowest_code,
               null not_lowest_reason
          from t_cc_plane_change     cc,
               t_cc_change_ticket    cct,
               t_cc_ticket_passenger ct,
               t_cc_change_od        ccod,
               t_cc_plane_od         cod
         where cc.complete_time >= trunc(currentDay, 'dd') - 1000
           and cc.complete_time <=
               trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
           and cc.change_id = cct.change_id
           and cct.plane_ticket_id = ct.plane_ticket_id
           and cc.change_id = ccod.change_id
           and ccod.od_id = cod.plane_od_id
           and ct.ticketing_time is not null),
      t_inter_order as
       (select it.plane_ticket_id,
               it.plane_ticket_no,
               it.plane_order_id,
               it.plane_order_no,
               '2' plane_ticket_type,
               it.ticketing_employee,
               it.ticketing_time,
               it.state,
               it.pax_id,
               concat(it.last_name,
                      nvl2(it.last_name, ' ' || it.first_name, it.first_name)) idc_name,
               it.phone,
               it.birthday,
               it.sex,
               null person_type,
               it.idc_type,
               it.idc_no,
               it.face_price,
               it.tax,
               it.sale_price,
               null airport_cst_fee,
               null fuel_fee,
               it.floor_price,
               it.sale_discount,
               it.floor_discount,
               it.premium,
               it.rebate,
               it.company_id,
               it.create_user,
               it.create_time,
               it.modify_user,
               it.modify_time,
               it.cost_center_id,
               getDeptIdByUserId(it.create_user) dept_id,
               it.pax_source,
               it.flight_type,
               it.create_employee,
               it.prev_plane_ticket_id,
               it.pnr,
               it.passenger_type,
               it.email,
               to_number(it.ticketing_fee) ticketing_fee,
               iod.depart_city,
               iod.depart_city_code,
               iod.depart_city_name,
               iod.depart_airport_code,
               iod.depart_airport_name,
               iod.depart_airport_tower,
               iod.depart_time,
               iod.arrive_city,
               iod.arrive_city_code,
               iod.arrive_city_name,
               iod.arrive_airport_code,
               iod.arrive_airport_name,
               iod.arrive_airport_tower,
               iod.arrive_time,
               iod.price,
               null standard_ticket_id,
               null standard_ticket_price,
               null lowest_price_current,
               null lowest_price_onehour,
               null lowest_price_twohour,
               null lose_price_current,
               null lose_price_onehour,
               null lose_price_twohour,
               null ticket_discount,
               null ticket_discount_onehour,
               null ticket_discount_twohour,
               null is_user,
               null user_id,
               null contact_id,
               io.pur_id,
               io.pur_name,
               io.pur_settle_state,
               io.sup_id,
               io.sup_name,
               io.sup_settle_state,
               null pur_pay_state,
               io.pur_pay_time,
               io.pur_pay_type,
               io.plane_order_id order_id,
               io.plane_order_no order_no,
               io.pur_settle_time,
               io.pur_settle_detail_id,
               io.pur_check_state,
               io.pur_check_time,
               io.pur_check_employee,
               io.sup_pay_time,
               io.sup_pay_type,
               io.sup_settle_time,
               io.sup_settle_detail_id,
               io.sup_check_state,
               io.sup_check_time,
               io.sup_check_employee,
               null cabin,
               null is_lowest_flight,
               null lowest_flight_id,
               null not_lowest_code,
               null not_lowest_reason
          from t_cc_inter_plane_order      io,
               t_cc_inter_ticket_passenger it,
               t_cc_inter_plane_od         iod
         where io.ticketing_time >= trunc(currentDay, 'dd') - 1000
           and io.ticketing_time <=
               trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
           and io.plane_order_id = it.plane_order_id
           and iod.plane_order_id = io.plane_order_id
           and it.ticketing_time is not null
           and it.prev_plane_ticket_id is null),
      t_inter_refund as
       (select it.plane_ticket_id,
               it.plane_ticket_no,
               it.plane_order_id,
               it.plane_order_no,
               '6' plane_ticket_type,
               it.ticketing_employee,
               it.ticketing_time,
               it.state,
               it.pax_id,
               concat(it.last_name,
                      nvl2(it.last_name, ' ' || it.first_name, it.first_name)) idc_name,
               it.phone,
               it.birthday,
               it.sex,
               null person_type,
               it.idc_type,
               it.idc_no,
               it.face_price,
               it.tax,
               it.sale_price,
               null airport_cst_fee,
               null fuel_fee,
               it.floor_price,
               it.sale_discount,
               it.floor_discount,
               it.premium,
               it.rebate,
               it.company_id,
               it.create_user,
               it.create_time,
               it.modify_user,
               it.modify_time,
               it.cost_center_id,
               getDeptIdByUserId(it.create_user) dept_id,
               it.pax_source,
               it.flight_type,
               it.create_employee,
               it.prev_plane_ticket_id,
               it.pnr,
               it.passenger_type,
               it.email,
               to_number(it.ticketing_fee) ticketing_fee,
               iod.depart_city,
               iod.depart_city_code,
               iod.depart_city_name,
               iod.depart_airport_code,
               iod.depart_airport_name,
               iod.depart_airport_tower,
               iod.depart_time,
               iod.arrive_city,
               iod.arrive_city_code,
               iod.arrive_city_name,
               iod.arrive_airport_code,
               iod.arrive_airport_name,
               iod.arrive_airport_tower,
               iod.arrive_time,
               iod.price,
               null standard_ticket_id,
               null standard_ticket_price,
               null lowest_price_current,
               null lowest_price_onehour,
               null lowest_price_twohour,
               null lose_price_current,
               null lose_price_onehour,
               null lose_price_twohour,
               null ticket_discount,
               null ticket_discount_onehour,
               null ticket_discount_twohour,
               null is_user,
               null user_id,
               null contact_id,
               ir.pur_id,
               ir.pur_name,
               ir.pur_settle_state,
               ir.sup_id,
               ir.sup_name,
               ir.sup_settle_state,
               irt.floor_price sup_floor_price,
               irt.sup_refund_money,
               irt.sup_handling_fee,
               irt.sale_price pur_sale_price,
               irt.pur_refund_money,
               irt.pur_handling_fee,
               null pur_pay_state,
               null pur_pay_time,
               ir.pur_pay_type,
               ir.refund_id order_id,
               ir.refund_no order_no,
               ir.pur_settle_time,
               ir.pur_settle_detail_id,
               ir.pur_check_state,
               ir.pur_check_time,
               ir.pur_check_employee,
               null sup_pay_time,
               ir.sup_pay_type,
               ir.sup_settle_time,
               ir.sup_settle_detail_id,
               ir.sup_check_state,
               ir.sup_check_time,
               ir.sup_check_employee,
               null cabin,
               null is_lowest_flight,
               null lowest_flight_id,
               null not_lowest_code,
               null not_lowest_reason
          from t_cc_inter_plane_refund     ir,
               t_cc_inter_refund_ticket    irt,
               t_cc_inter_ticket_passenger it,
               t_cc_inter_plane_od         iod
         where ir.complete_time >= trunc(currentDay, 'dd') - 1000
           and ir.complete_time <=
               trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
           and ir.refund_id = irt.refund_id
           and irt.plane_ticket_id = it.plane_ticket_id
           and ir.plane_order_id = iod.plane_order_id
           and it.ticketing_time is not null),
      t_inter_change as
       (select it.plane_ticket_id,
               it.plane_ticket_no,
               it.plane_order_id,
               it.plane_order_no,
               '4' plane_ticket_type,
               it.ticketing_employee,
               it.ticketing_time,
               it.state,
               it.pax_id,
               concat(it.last_name,
                      nvl2(it.last_name, ' ' || it.first_name, it.first_name)) idc_name,
               it.phone,
               it.birthday,
               it.sex,
               null person_type,
               it.idc_type,
               it.idc_no,
               it.face_price,
               it.tax,
               it.sale_price,
               null airport_cst_fee,
               null fuel_fee,
               it.floor_price,
               it.sale_discount,
               it.floor_discount,
               it.premium,
               it.rebate,
               it.company_id,
               it.create_user,
               it.create_time,
               it.modify_user,
               it.modify_time,
               it.cost_center_id,
               getDeptIdByUserId(it.create_user) dept_id,
               it.pax_source,
               it.flight_type,
               it.create_employee,
               it.prev_plane_ticket_id,
               it.pnr,
               it.passenger_type,
               it.email,
               to_number(it.ticketing_fee) ticketing_fee,
               iod.depart_city,
               iod.depart_city_code,
               iod.depart_city_name,
               iod.depart_airport_code,
               iod.depart_airport_name,
               iod.depart_airport_tower,
               iod.depart_time,
               iod.arrive_city,
               iod.arrive_city_code,
               iod.arrive_city_name,
               iod.arrive_airport_code,
               iod.arrive_airport_name,
               iod.arrive_airport_tower,
               iod.arrive_time,
               iod.price,
               null standard_ticket_id,
               null standard_ticket_price,
               null lowest_price_current,
               null lowest_price_onehour,
               null lowest_price_twohour,
               null lose_price_current,
               null lose_price_onehour,
               null lose_price_twohour,
               null ticket_discount,
               null ticket_discount_onehour,
               null ticket_discount_twohour,
               null is_user,
               null user_id,
               null contact_id,
               ic.pur_id,
               ic.pur_name,
               ic.pur_settle_state,
               ic.sup_id,
               ic.sup_name,
               ic.sup_settle_state,
               ict.orig_plane_ticket_id,
               ict.orig_plane_ticket_no,
               ict.sup_price_difference,
               ict.sup_handling_fee,
               ict.floor_price sup_floor_price,
               ict.pur_price_difference,
               ict.pur_handling_fee,
               ict.sale_price pur_sale_price,
               null pur_pay_state,
               ic.pur_pay_time,
               ic.pur_pay_type,
               ic.change_id order_id,
               ic.change_no order_no,
               ic.pur_settle_time,
               ic.pur_settle_detail_id,
               ic.pur_check_state,
               ic.pur_check_time,
               ic.pur_check_employee,
               ic.sup_pay_time,
               ic.sup_pay_type,
               ic.sup_settle_time,
               ic.sup_settle_detail_id,
               ic.sup_check_state,
               ic.sup_check_time,
               ic.sup_check_employee,
               null cabin,
               null is_lowest_flight,
               null lowest_flight_id,
               null not_lowest_code,
               null not_lowest_reason
          from t_cc_inter_plane_change     ic,
               t_cc_inter_change_ticket    ict,
               t_cc_inter_ticket_passenger it,
               t_cc_inter_change_od        icod,
               t_cc_inter_plane_od         iod
         where ic.complete_time >= trunc(currentDay, 'dd') - 1000
           and ic.complete_time <=
               trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
           and ic.change_id = ict.change_id
           and ict.plane_ticket_id = it.plane_ticket_id
           and ic.change_id = icod.change_id
           and icod.od_id = iod.plane_od_id
           and it.ticketing_time is not null)
      select E.plane_ticket_id,
             E.plane_ticket_no,
             E.plane_order_id,
             E.plane_order_no,
             E.plane_ticket_type,
             E.ticketing_employee,
             E.ticketing_time,
             E.state,
             E.pax_id,
             E.idc_name,
             E.phone,
             E.birthday,
             E.sex,
             E.person_type,
             E.idc_type,
             E.idc_no,
             E.face_price,
             E.sale_price,
             E.airport_cst_fee,
             E.fuel_fee,
             E.floor_price,
             E.sale_discount,
             E.floor_discount,
             E.premium,
             E.rebate,
             E.company_id,
             E.create_user,
             E.create_time,
             E.modify_user,
             E.modify_time,
             E.cost_center_id,
             E.pax_source,
             E.flight_type,
             E.create_employee,
             E.prev_plane_ticket_id,
             E.pnr,
             E.passenger_type,
             E.email,
             E.ticketing_fee,
             E.depart_city,
             E.depart_city_code,
             E.depart_city_name,
             E.depart_airport_code,
             E.depart_airport_name,
             E.depart_airport_tower,
             E.depart_time,
             F.arrive_city,
             F.arrive_city_code,
             F.arrive_city_name,
             F.arrive_airport_code,
             F.arrive_airport_name,
             F.arrive_airport_tower,
             F.arrive_time,
             E.price,
             E.lowest_price_current,
             E.lowest_price_onehour,
             E.lowest_price_twohour,
             E.lose_price_current,
             E.lose_price_onehour,
             E.lose_price_twohour,
             E.ticket_discount,
             E.pur_id,
             E.pur_name,
             E.pur_settle_state,
             E.sup_id,
             E.sup_name,
             E.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             E.dept_id,
             E.standard_ticket_id,
             E.standard_ticket_price,
             E.ticket_discount_onehour,
             E.ticket_discount_twohour,
             E.is_user,
             E.user_id,
             E.contact_id,
             E.tax,
             null ORIG_PLANE_TICKET_NO,
             null SUP_PRICE_DIFFERENCE,
             null SUP_HANDLING_FEE,
             null SUP_FLOOR_PRICE,
             null PUR_PRICE_DIFFERENCE,
             null PUR_HANDLING_FEE,
             null PUR_SALE_PRICE,
             null SUP_REFUND_MONEY,
             null PUR_REFUND_MONEY,
             getCabinClassByPlaneTicketId(E.plane_ticket_id, '1') CABIN_CLASS,
             getFlightNoByPlaneTicketId(E.plane_ticket_id, '1') AIRLINE_CODE,
             null ORIG_PLANE_TICKET_ID,
             E.PUR_PAY_STATE,
             E.PUR_PAY_TIME,
             E.PUR_PAY_TYPE,
             E.ORDER_ID,
             E.ORDER_NO,
             E.PUR_SETTLE_TIME,
             E.PUR_SETTLE_DETAIL_ID,
             E.PUR_CHECK_STATE,
             E.PUR_CHECK_TIME,
             E.PUR_CHECK_EMPLOYEE,
             E.SUP_PAY_TIME,
             E.SUP_PAY_TYPE,
             E.SUP_SETTLE_TIME,
             E.SUP_SETTLE_DETAIL_ID,
             E.SUP_CHECK_STATE,
             E.SUP_CHECK_TIME,
             E.SUP_CHECK_EMPLOYEE,
             getTripByPlaneTicketId(E.plane_ticket_id, '1') TRIP,
             E.cabin,
             E.is_lowest_flight,
             E.lowest_flight_id,
             E.not_lowest_code,
             E.not_lowest_reason
        from (select A.*
                from t_order A,
                     (select plane_ticket_id, min(depart_time) depart_time
                        from t_order
                       group by plane_ticket_id) B
               where A.plane_ticket_id = B.plane_ticket_id
                 and A.depart_time = B.depart_time) E,
             (select C.*
                from t_order C,
                     (select plane_ticket_id, max(arrive_time) arrive_time
                        from t_order
                       group by plane_ticket_id) D
               where C.plane_ticket_id = D.plane_ticket_id
                 and C.arrive_time = D.arrive_time) F
       where E.plane_ticket_id = F.plane_ticket_id
      union all
      select E.plane_ticket_id,
             E.plane_ticket_no,
             E.plane_order_id,
             E.plane_order_no,
             E.plane_ticket_type,
             E.ticketing_employee,
             E.ticketing_time,
             E.state,
             E.pax_id,
             E.idc_name,
             E.phone,
             E.birthday,
             E.sex,
             E.person_type,
             E.idc_type,
             E.idc_no,
             E.face_price,
             E.sale_price,
             E.airport_cst_fee,
             E.fuel_fee,
             E.floor_price,
             E.sale_discount,
             E.floor_discount,
             E.premium,
             E.rebate,
             E.company_id,
             E.create_user,
             E.create_time,
             E.modify_user,
             E.modify_time,
             E.cost_center_id,
             E.pax_source,
             E.flight_type,
             E.create_employee,
             E.prev_plane_ticket_id,
             E.pnr,
             E.passenger_type,
             E.email,
             E.ticketing_fee,
             E.depart_city,
             E.depart_city_code,
             E.depart_city_name,
             E.depart_airport_code,
             E.depart_airport_name,
             E.depart_airport_tower,
             E.depart_time,
             F.arrive_city,
             F.arrive_city_code,
             F.arrive_city_name,
             F.arrive_airport_code,
             F.arrive_airport_name,
             F.arrive_airport_tower,
             F.arrive_time,
             E.price,
             E.lowest_price_current,
             E.lowest_price_onehour,
             E.lowest_price_twohour,
             E.lose_price_current,
             E.lose_price_onehour,
             E.lose_price_twohour,
             E.ticket_discount,
             E.pur_id,
             E.pur_name,
             E.pur_settle_state,
             E.sup_id,
             E.sup_name,
             E.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             E.dept_id,
             E.standard_ticket_id,
             E.standard_ticket_price,
             E.ticket_discount_onehour,
             E.ticket_discount_twohour,
             E.is_user,
             E.user_id,
             E.contact_id,
             E.tax,
             null ORIG_PLANE_TICKET_NO,
             null SUP_PRICE_DIFFERENCE,
             E.SUP_HANDLING_FEE,
             E.SUP_FLOOR_PRICE,
             null PUR_PRICE_DIFFERENCE,
             E.PUR_HANDLING_FEE,
             E.PUR_SALE_PRICE,
             E.SUP_REFUND_MONEY,
             E.PUR_REFUND_MONEY,
             getCabinClassByPlaneTicketId(E.plane_ticket_id, '1') CABIN_CLASS,
             getFlightNoByPlaneTicketId(E.plane_ticket_id, '1') AIRLINE_CODE,
             null ORIG_PLANE_TICKET_ID,
             E.PUR_PAY_STATE,
             E.PUR_PAY_TIME,
             E.PUR_PAY_TYPE,
             E.ORDER_ID,
             E.ORDER_NO,
             E.PUR_SETTLE_TIME,
             E.PUR_SETTLE_DETAIL_ID,
             E.PUR_CHECK_STATE,
             E.PUR_CHECK_TIME,
             E.PUR_CHECK_EMPLOYEE,
             E.SUP_PAY_TIME,
             E.SUP_PAY_TYPE,
             E.SUP_SETTLE_TIME,
             E.SUP_SETTLE_DETAIL_ID,
             E.SUP_CHECK_STATE,
             E.SUP_CHECK_TIME,
             E.SUP_CHECK_EMPLOYEE,
             getTripByPlaneTicketId(E.plane_ticket_id, '1') TRIP,
             E.cabin,
             E.is_lowest_flight,
             E.lowest_flight_id,
             E.not_lowest_code,
             E.not_lowest_reason
        from (select A.*
                from t_refund A,
                     (select plane_ticket_id, min(depart_time) depart_time
                        from t_refund
                       group by plane_ticket_id) B
               where A.plane_ticket_id = B.plane_ticket_id
                 and A.depart_time = B.depart_time) E,
             (select C.*
                from t_refund C,
                     (select plane_ticket_id, max(arrive_time) arrive_time
                        from t_refund
                       group by plane_ticket_id) D
               where C.plane_ticket_id = D.plane_ticket_id
                 and C.arrive_time = D.arrive_time) F
       where E.plane_ticket_id = F.plane_ticket_id
      union all
      select E.plane_ticket_id,
             E.plane_ticket_no,
             E.plane_order_id,
             E.plane_order_no,
             E.plane_ticket_type,
             E.ticketing_employee,
             E.ticketing_time,
             E.state,
             E.pax_id,
             E.idc_name,
             E.phone,
             E.birthday,
             E.sex,
             E.person_type,
             E.idc_type,
             E.idc_no,
             E.face_price,
             E.sale_price,
             E.airport_cst_fee,
             E.fuel_fee,
             E.floor_price,
             E.sale_discount,
             E.floor_discount,
             E.premium,
             E.rebate,
             E.company_id,
             E.create_user,
             E.create_time,
             E.modify_user,
             E.modify_time,
             E.cost_center_id,
             E.pax_source,
             E.flight_type,
             E.create_employee,
             E.prev_plane_ticket_id,
             E.pnr,
             E.passenger_type,
             E.email,
             E.ticketing_fee,
             E.depart_city,
             E.depart_city_code,
             E.depart_city_name,
             E.depart_airport_code,
             E.depart_airport_name,
             E.depart_airport_tower,
             E.depart_time,
             F.arrive_city,
             F.arrive_city_code,
             F.arrive_city_name,
             F.arrive_airport_code,
             F.arrive_airport_name,
             F.arrive_airport_tower,
             F.arrive_time,
             E.price,
             E.lowest_price_current,
             E.lowest_price_onehour,
             E.lowest_price_twohour,
             E.lose_price_current,
             E.lose_price_onehour,
             E.lose_price_twohour,
             E.ticket_discount,
             E.pur_id,
             E.pur_name,
             E.pur_settle_state,
             E.sup_id,
             E.sup_name,
             E.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             E.dept_id,
             E.standard_ticket_id,
             E.standard_ticket_price,
             E.ticket_discount_onehour,
             E.ticket_discount_twohour,
             E.is_user,
             E.user_id,
             E.contact_id,
             E.tax,
             E.ORIG_PLANE_TICKET_NO,
             E.SUP_PRICE_DIFFERENCE,
             E.SUP_HANDLING_FEE,
             E.SUP_FLOOR_PRICE,
             E.PUR_PRICE_DIFFERENCE,
             E.PUR_HANDLING_FEE,
             E.PUR_SALE_PRICE,
             null SUP_REFUND_MONEY,
             null PUR_REFUND_MONEY,
             getCabinClassByPlaneTicketId(E.plane_ticket_id, '1') CABIN_CLASS,
             getFlightNoByPlaneTicketId(E.plane_ticket_id, '1') AIRLINE_CODE,
             E.ORIG_PLANE_TICKET_ID,
             E.PUR_PAY_STATE,
             E.PUR_PAY_TIME,
             E.PUR_PAY_TYPE,
             E.ORDER_ID,
             E.ORDER_NO,
             E.PUR_SETTLE_TIME,
             E.PUR_SETTLE_DETAIL_ID,
             E.PUR_CHECK_STATE,
             E.PUR_CHECK_TIME,
             E.PUR_CHECK_EMPLOYEE,
             E.SUP_PAY_TIME,
             E.SUP_PAY_TYPE,
             E.SUP_SETTLE_TIME,
             E.SUP_SETTLE_DETAIL_ID,
             E.SUP_CHECK_STATE,
             E.SUP_CHECK_TIME,
             E.SUP_CHECK_EMPLOYEE,
             getTripByPlaneTicketId(E.plane_ticket_id, '1') TRIP,
             E.cabin,
             E.is_lowest_flight,
             E.lowest_flight_id,
             E.not_lowest_code,
             E.not_lowest_reason
        from (select A.*
                from t_change A,
                     (select plane_ticket_id, min(depart_time) depart_time
                        from t_change
                       group by plane_ticket_id) B
               where A.plane_ticket_id = B.plane_ticket_id
                 and A.depart_time = B.depart_time) E,
             (select C.*
                from t_change C,
                     (select plane_ticket_id, max(arrive_time) arrive_time
                        from t_change
                       group by plane_ticket_id) D
               where C.plane_ticket_id = D.plane_ticket_id
                 and C.arrive_time = D.arrive_time) F
       where E.plane_ticket_id = F.plane_ticket_id
      union all
      select E.plane_ticket_id,
             E.plane_ticket_no,
             E.plane_order_id,
             E.plane_order_no,
             E.plane_ticket_type,
             E.ticketing_employee,
             E.ticketing_time,
             E.state,
             E.pax_id,
             E.idc_name,
             E.phone,
             E.birthday,
             E.sex,
             E.person_type,
             E.idc_type,
             E.idc_no,
             E.face_price,
             E.sale_price,
             E.airport_cst_fee,
             E.fuel_fee,
             E.floor_price,
             E.sale_discount,
             E.floor_discount,
             E.premium,
             E.rebate,
             E.company_id,
             E.create_user,
             E.create_time,
             E.modify_user,
             E.modify_time,
             E.cost_center_id,
             E.pax_source,
             E.flight_type,
             E.create_employee,
             E.prev_plane_ticket_id,
             E.pnr,
             E.passenger_type,
             E.email,
             E.ticketing_fee,
             E.depart_city,
             E.depart_city_code,
             E.depart_city_name,
             E.depart_airport_code,
             E.depart_airport_name,
             E.depart_airport_tower,
             E.depart_time,
             F.arrive_city,
             F.arrive_city_code,
             F.arrive_city_name,
             F.arrive_airport_code,
             F.arrive_airport_name,
             F.arrive_airport_tower,
             F.arrive_time,
             E.price,
             E.lowest_price_current,
             E.lowest_price_onehour,
             E.lowest_price_twohour,
             E.lose_price_current,
             E.lose_price_onehour,
             E.lose_price_twohour,
             E.ticket_discount,
             E.pur_id,
             E.pur_name,
             E.pur_settle_state,
             E.sup_id,
             E.sup_name,
             E.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             E.dept_id,
             E.standard_ticket_id,
             E.standard_ticket_price,
             E.ticket_discount_onehour,
             E.ticket_discount_twohour,
             E.is_user,
             E.user_id,
             E.contact_id,
             E.tax,
             null ORIG_PLANE_TICKET_NO,
             null SUP_PRICE_DIFFERENCE,
             null SUP_HANDLING_FEE,
             null SUP_FLOOR_PRICE,
             null PUR_PRICE_DIFFERENCE,
             null PUR_HANDLING_FEE,
             null PUR_SALE_PRICE,
             null SUP_REFUND_MONEY,
             null PUR_REFUND_MONEY,
             getCabinClassByPlaneTicketId(E.plane_ticket_id, '2') CABIN_CLASS,
             getFlightNoByPlaneTicketId(E.plane_ticket_id, '2') AIRLINE_CODE,
             null ORIG_PLANE_TICKET_ID,
             E.PUR_PAY_STATE,
             E.PUR_PAY_TIME,
             E.PUR_PAY_TYPE,
             E.ORDER_ID,
             E.ORDER_NO,
             E.PUR_SETTLE_TIME,
             E.PUR_SETTLE_DETAIL_ID,
             E.PUR_CHECK_STATE,
             E.PUR_CHECK_TIME,
             E.PUR_CHECK_EMPLOYEE,
             E.SUP_PAY_TIME,
             E.SUP_PAY_TYPE,
             E.SUP_SETTLE_TIME,
             E.SUP_SETTLE_DETAIL_ID,
             E.SUP_CHECK_STATE,
             E.SUP_CHECK_TIME,
             E.SUP_CHECK_EMPLOYEE,
             getTripByPlaneTicketId(E.plane_ticket_id, '2') TRIP,
             E.cabin,
             E.is_lowest_flight,
             E.lowest_flight_id,
             E.not_lowest_code,
             E.not_lowest_reason
        from (select A.*
                from t_inter_order A,
                     (select plane_ticket_id, min(depart_time) depart_time
                        from t_inter_order
                       group by plane_ticket_id) B
               where A.plane_ticket_id = B.plane_ticket_id
                 and A.depart_time = B.depart_time) E,
             (select C.*
                from t_inter_order C,
                     (select plane_ticket_id, max(arrive_time) arrive_time
                        from t_inter_order
                       group by plane_ticket_id) D
               where C.plane_ticket_id = D.plane_ticket_id
                 and C.arrive_time = D.arrive_time) F
       where E.plane_ticket_id = F.plane_ticket_id
      union all
      select E.plane_ticket_id,
             E.plane_ticket_no,
             E.plane_order_id,
             E.plane_order_no,
             E.plane_ticket_type,
             E.ticketing_employee,
             E.ticketing_time,
             E.state,
             E.pax_id,
             E.idc_name,
             E.phone,
             E.birthday,
             E.sex,
             E.person_type,
             E.idc_type,
             E.idc_no,
             E.face_price,
             E.sale_price,
             E.airport_cst_fee,
             E.fuel_fee,
             E.floor_price,
             E.sale_discount,
             E.floor_discount,
             E.premium,
             E.rebate,
             E.company_id,
             E.create_user,
             E.create_time,
             E.modify_user,
             E.modify_time,
             E.cost_center_id,
             E.pax_source,
             E.flight_type,
             E.create_employee,
             E.prev_plane_ticket_id,
             E.pnr,
             E.passenger_type,
             E.email,
             E.ticketing_fee,
             E.depart_city,
             E.depart_city_code,
             E.depart_city_name,
             E.depart_airport_code,
             E.depart_airport_name,
             E.depart_airport_tower,
             E.depart_time,
             F.arrive_city,
             F.arrive_city_code,
             F.arrive_city_name,
             F.arrive_airport_code,
             F.arrive_airport_name,
             F.arrive_airport_tower,
             F.arrive_time,
             E.price,
             E.lowest_price_current,
             E.lowest_price_onehour,
             E.lowest_price_twohour,
             E.lose_price_current,
             E.lose_price_onehour,
             E.lose_price_twohour,
             E.ticket_discount,
             E.pur_id,
             E.pur_name,
             E.pur_settle_state,
             E.sup_id,
             E.sup_name,
             E.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             E.dept_id,
             E.standard_ticket_id,
             E.standard_ticket_price,
             E.ticket_discount_onehour,
             E.ticket_discount_twohour,
             E.is_user,
             E.user_id,
             E.contact_id,
             E.tax,
             null ORIG_PLANE_TICKET_NO,
             null SUP_PRICE_DIFFERENCE,
             E.SUP_HANDLING_FEE,
             E.SUP_FLOOR_PRICE,
             null PUR_PRICE_DIFFERENCE,
             E.PUR_HANDLING_FEE,
             E.PUR_SALE_PRICE,
             E.SUP_REFUND_MONEY,
             E.PUR_REFUND_MONEY,
             getCabinClassByPlaneTicketId(E.plane_ticket_id, '2') CABIN_CLASS,
             getFlightNoByPlaneTicketId(E.plane_ticket_id, '2') AIRLINE_CODE,
             null ORIG_PLANE_TICKET_ID,
             E.PUR_PAY_STATE,
             E.PUR_PAY_TIME,
             E.PUR_PAY_TYPE,
             E.ORDER_ID,
             E.ORDER_NO,
             E.PUR_SETTLE_TIME,
             E.PUR_SETTLE_DETAIL_ID,
             E.PUR_CHECK_STATE,
             E.PUR_CHECK_TIME,
             E.PUR_CHECK_EMPLOYEE,
             E.SUP_PAY_TIME,
             E.SUP_PAY_TYPE,
             E.SUP_SETTLE_TIME,
             E.SUP_SETTLE_DETAIL_ID,
             E.SUP_CHECK_STATE,
             E.SUP_CHECK_TIME,
             E.SUP_CHECK_EMPLOYEE,
             getTripByPlaneTicketId(E.plane_ticket_id, '2') TRIP,
             E.cabin,
             E.is_lowest_flight,
             E.lowest_flight_id,
             E.not_lowest_code,
             E.not_lowest_reason
        from (select A.*
                from t_inter_refund A,
                     (select plane_ticket_id, min(depart_time) depart_time
                        from t_inter_refund
                       group by plane_ticket_id) B
               where A.plane_ticket_id = B.plane_ticket_id
                 and A.depart_time = B.depart_time) E,
             (select C.*
                from t_inter_refund C,
                     (select plane_ticket_id, max(arrive_time) arrive_time
                        from t_inter_refund
                       group by plane_ticket_id) D
               where C.plane_ticket_id = D.plane_ticket_id
                 and C.arrive_time = D.arrive_time) F
       where E.plane_ticket_id = F.plane_ticket_id
      union all
      select E.plane_ticket_id,
             E.plane_ticket_no,
             E.plane_order_id,
             E.plane_order_no,
             E.plane_ticket_type,
             E.ticketing_employee,
             E.ticketing_time,
             E.state,
             E.pax_id,
             E.idc_name,
             E.phone,
             E.birthday,
             E.sex,
             E.person_type,
             E.idc_type,
             E.idc_no,
             E.face_price,
             E.sale_price,
             E.airport_cst_fee,
             E.fuel_fee,
             E.floor_price,
             E.sale_discount,
             E.floor_discount,
             E.premium,
             E.rebate,
             E.company_id,
             E.create_user,
             E.create_time,
             E.modify_user,
             E.modify_time,
             E.cost_center_id,
             E.pax_source,
             E.flight_type,
             E.create_employee,
             E.prev_plane_ticket_id,
             E.pnr,
             E.passenger_type,
             E.email,
             E.ticketing_fee,
             E.depart_city,
             E.depart_city_code,
             E.depart_city_name,
             E.depart_airport_code,
             E.depart_airport_name,
             E.depart_airport_tower,
             E.depart_time,
             F.arrive_city,
             F.arrive_city_code,
             F.arrive_city_name,
             F.arrive_airport_code,
             F.arrive_airport_name,
             F.arrive_airport_tower,
             F.arrive_time,
             E.price,
             E.lowest_price_current,
             E.lowest_price_onehour,
             E.lowest_price_twohour,
             E.lose_price_current,
             E.lose_price_onehour,
             E.lose_price_twohour,
             E.ticket_discount,
             E.pur_id,
             E.pur_name,
             E.pur_settle_state,
             E.sup_id,
             E.sup_name,
             E.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             E.dept_id,
             E.standard_ticket_id,
             E.standard_ticket_price,
             E.ticket_discount_onehour,
             E.ticket_discount_twohour,
             E.is_user,
             E.user_id,
             E.contact_id,
             E.tax,
             E.ORIG_PLANE_TICKET_NO,
             E.SUP_PRICE_DIFFERENCE,
             E.SUP_HANDLING_FEE,
             E.SUP_FLOOR_PRICE,
             E.PUR_PRICE_DIFFERENCE,
             E.PUR_HANDLING_FEE,
             E.PUR_SALE_PRICE,
             null SUP_REFUND_MONEY,
             null PUR_REFUND_MONEY,
             getCabinClassByPlaneTicketId(E.plane_ticket_id, '2') CABIN_CLASS,
             getFlightNoByPlaneTicketId(E.plane_ticket_id, '2') AIRLINE_CODE,
             E.ORIG_PLANE_TICKET_ID,
             E.PUR_PAY_STATE,
             E.PUR_PAY_TIME,
             E.PUR_PAY_TYPE,
             E.ORDER_ID,
             E.ORDER_NO,
             E.PUR_SETTLE_TIME,
             E.PUR_SETTLE_DETAIL_ID,
             E.PUR_CHECK_STATE,
             E.PUR_CHECK_TIME,
             E.PUR_CHECK_EMPLOYEE,
             E.SUP_PAY_TIME,
             E.SUP_PAY_TYPE,
             E.SUP_SETTLE_TIME,
             E.SUP_SETTLE_DETAIL_ID,
             E.SUP_CHECK_STATE,
             E.SUP_CHECK_TIME,
             E.SUP_CHECK_EMPLOYEE,
             getTripByPlaneTicketId(E.plane_ticket_id, '2') TRIP,
             E.cabin,
             E.is_lowest_flight,
             E.lowest_flight_id,
             E.not_lowest_code,
             E.not_lowest_reason
        from (select A.*
                from t_inter_change A,
                     (select plane_ticket_id, min(depart_time) depart_time
                        from t_inter_change
                       group by plane_ticket_id) B
               where A.plane_ticket_id = B.plane_ticket_id
                 and A.depart_time = B.depart_time) E,
             (select C.*
                from t_inter_change C,
                     (select plane_ticket_id, max(arrive_time) arrive_time
                        from t_inter_change
                       group by plane_ticket_id) D
               where C.plane_ticket_id = D.plane_ticket_id
                 and C.arrive_time = D.arrive_time) F
       where E.plane_ticket_id = F.plane_ticket_id;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 酒店订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_HOTEL_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-03-25
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_HOTEL_ORDER(currentDay IN DATE) AS
    v_purSettleState varchar2(4);
    v_supSettleState varchar2(4);
    v_purSettleTime  date;
    v_supSettleTime  date;
  BEGIN
    --删除
    delete from T_FIN_REPORT_HOTEL_ORDER
     where (update_time >= trunc(currentDay, 'dd') - 1000 and
           update_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
        or update_time is null;

    --更新未结算的结算状态
    for rs in (select *
                 from T_FIN_REPORT_HOTEL_ORDER t
                where (pur_settle_state = '0' or sup_settle_state = '0')
                  and update_time <=
                      trunc(currentDay, 'dd') - 1 - 1 / 24 / 60 / 60) loop
      --8国内酒店预定，7国内酒店退订
      if rs.order_type = '8' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_ch_hotel_order
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_HOTEL_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_HOTEL_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
      elsif rs.order_type = '7' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_ch_hotel_order
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_HOTEL_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_HOTEL_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
        --else
        --v_purSettleState := null;
        --v_supSettleState := null;
      end if;
    end loop;

    --新增
    insert into T_FIN_REPORT_HOTEL_ORDER
      (AFFILIATE_CONFIRMATION_ID,
       ORDER_ID,
       ORDER_TYPE,
       ORDER_TIME,
       HOTEL_BIZTRIP_ID,
       HOTEL_BIZTRIP_STANDARD,
       HOTEL_GROUP_ID,
       HOTEL_GROUP_NAME,
       HOTEL_STAR,
       HOTEL_CITY_CODE,
       HOTEL_CITY_NAME,
       HOTEL_ID,
       ROOM_TYPE_ID,
       RATE_PLAN_ID,
       ARRIVAL_DATE,
       DEPARTURE_DATE,
       CUSTOMER_TYPE,
       PAYMENT_TYPE,
       NUMBER_OF_ROOMS,
       NUMBER_OF_CUSTOMERS,
       EARLIEST_ARRIVAL_TIME,
       LATEST_ARRIVAL_TIME,
       TOTAL_PRICE,
       CURRENCY_CODE,
       CUSTOMER_IP_ADDRESS,
       IS_GUARANTEE_OR_CHARGED,
       SUPPLIER_CARD_NO,
       CONFIRMATION_TYPE,
       NOTE_TO_HOTEL,
       NOTE_TO_ELONG,
       IS_NEED_INVOICE,
       CONTACT,
       IS_FORCE_GUARANTEE,
       GUARANTEE_AMOUNT,
       GUARANTEE_CURRENCY_CODE,
       CREATION_TIME,
       STATUS,
       SHOW_STATUS,
       CONFIRM_POINT,
       ELONG_CARD_NO,
       PENALTY_TO_CUSTOMER,
       PENALTY_CURRENCY_CODE,
       IS_CANCELABLE,
       HAS_INVOICE,
       VALUE_ADDS,
       CONTACT_NAME,
       CONTACT_MOBILE,
       CONTACT_GENDER,
       COOPERATE_TYPE,
       CREATE_USER,
       UPDATE_USER,
       UPDATE_TIME,
       CANCEL_CODE,
       REASON,
       HOTEL_NAME,
       HOTEL_PHONE,
       ROOM_TYPE_NAME,
       RATE_PLAN_NAME,
       HOTEL_ADDRESS,
       LAST_ID,
       LOCAL_STATUS,
       CREATE_EMPLOYEE,
       COMPANY_ID,
       CONTACT_EMAIL,
       IMG_URL,
       ENABLE_UPDATE,
       CANCEL_USER,
       PUR_ID,
       PUR_NAME,
       PUR_SETTLE_STATE,
       SUP_ID,
       SUP_NAME,
       SUP_SETTLE_STATE,
       REPORT_CREATE_TIME,
       DEPT_ID,
       CANCEL_EMPLOYEE,
       BED_TYPE,
       SPECIAL_REQUIREMENT,
       RESERVED_ITEM,
       CANCEL_STATUS,
       PAY_STATE,
       REFUND_STATE,
       CITY,
       DISTRIBUTOR_NOTES,
       PAY_METHOD,
       SALE_TOTAL_PRICE,
       TOTAL_PROFIT,
       REMARK_TO_FANGCANG,
       HOTEL_ORDER_TYPE,
       PUR_PAY_TYPE,
       PUR_PAY_TIME,
       PUR_SETTLE_TYPE,
       PUR_SETTLE_TIME,
       PUR_SETTLE_DETAIL_ID,
       PUR_PAY_STATE,
       IS_LOCK,
       SUP_SERVICE_PRICE,
       PUR_BILL_NO,
       PUR_BANK_NO,
       PUR_REBATE,
       PUR_CHECK_STATE,
       PUR_CHECK_TIME,
       PUR_CHECK_EMPLOYEE,
       SUP_BILL_NO,
       SUP_BANK_NO,
       SUP_REBATE,
       SUP_PAY_TYPE,
       SUP_PAY_TIME,
       SUP_CHECK_STATE,
       SUP_CHECK_TIME,
       SUP_CHECK_EMPLOYEE,
       SUP_SETTLE_TYPE,
       SUP_SETTLE_TIME,
       SUP_SETTLE_DETAIL_ID,
       TIMEOUT_STATE,
       TIMEOUT_TIME,
       CHECKIN_DAYS)
      select co.affiliate_confirmation_id,
             co.order_id,
             '8' order_type,
             co.create_time order_time,
             null hotel_biztrip_id,
             null hotel_biztrip_standard,
             null hotel_group_id,
             null hotel_group_name,
             co.hotel_star,
             null hotel_city_code,
             null hotel_city_name,
             co.hotel_id,
             co.room_type_id,
             co.rate_plan_id,
             co.arrival_date,
             co.departure_date,
             co.customer_type,
             co.payment_type,
             co.number_of_rooms,
             co.number_of_customers,
             co.earliest_arrival_time,
             co.latest_arrival_time,
             co.total_price,
             co.currency_code,
             co.customer_ip_address,
             co.is_guarantee_or_charged,
             co.supplier_card_no,
             co.confirmation_type,
             co.note_to_hotel,
             co.note_to_elong,
             co.Is_Need_Invoice,
             co.contact,
             co.is_force_guarantee,
             co.guarantee_amount,
             co.guarantee_currency_code,
             co.creation_time,
             co.status,
             co.show_status,
             co.confirm_point,
             co.elong_card_no,
             co.penalty_to_customer,
             co.penalty_currency_code,
             co.is_cancelable,
             co.has_invoice,
             co.value_adds,
             co.contact_name,
             co.contact_mobile,
             co.contact_gender,
             co.cooperate_type,
             co.create_user,
             co.update_user,
             co.update_time,
             co.cancel_code,
             co.reason,
             co.hotel_name,
             co.hotel_phone,
             co.room_type_name,
             co.rate_plan_name,
             co.hotel_address,
             co.last_id,
             co.local_status,
             co.create_employee,
             co.company_id,
             co.contact_email,
             co.img_url,
             co.enable_update,
             co.cancel_user,
             co.pur_id pur_id,
             co.pur_name pur_name,
             co.pur_settle_state pur_settle_state,
             co.sup_id sup_id,
             co.sup_name sup_name,
             co.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             getDeptIdByUserId(co.create_user) dept_id,
             co.cancel_employee,
             co.bed_type,
             co.special_requirement,
             co.reserved_item,
             co.cancel_status,
             co.pay_state,
             co.refund_state,
             co.city,
             co.distributor_notes,
             co.pay_method,
             co.sale_total_price,
             co.total_profit,
             co.remark_to_fangcang,
             co.order_type hotel_order_type,
             co.pur_pay_type,
             co.pur_pay_time,
             co.pur_settle_type,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_pay_state,
             co.is_lock,
             co.sup_service_price,
             co.pur_bill_no,
             co.pur_bank_no,
             co.pur_rebate,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_bill_no,
             co.sup_bank_no,
             co.sup_rebate,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             co.sup_settle_type,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.timeout_state,
             co.timeout_time,
             co.checkin_days
        from T_CH_HOTEL_ORDER co
       where ((order_type = '1' and
             (local_status = '3' or local_status = '10' or
             local_status = '5')) or
             ((order_type = '3' and
             (local_status = '3' or local_status = '10' or
             local_status = '5')) or
             (order_type = '2' and
             (local_status = '3' or
             (pur_pay_state = '1' and local_status = '4') or
             (pur_pay_type = '8' and local_status = '1'))))
         and update_time >= trunc(currentDay, 'dd') - 1000
         and update_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
      union all
      select co.affiliate_confirmation_id,
             co.order_id,
             '7' order_type,
             co.create_time order_time,
             null hotel_biztrip_id,
             null hotel_biztrip_standard,
             null hotel_group_id,
             null hotel_group_name,
             co.hotel_star,
             null hotel_city_code,
             null hotel_city_name,
             co.hotel_id,
             co.room_type_id,
             co.rate_plan_id,
             co.arrival_date,
             co.departure_date,
             co.customer_type,
             co.payment_type,
             co.number_of_rooms,
             co.number_of_customers,
             co.earliest_arrival_time,
             co.latest_arrival_time,
             co.total_price,
             co.currency_code,
             co.customer_ip_address,
             co.is_guarantee_or_charged,
             co.supplier_card_no,
             co.confirmation_type,
             co.note_to_hotel,
             co.note_to_elong,
             co.Is_Need_Invoice,
             co.contact,
             co.is_force_guarantee,
             co.guarantee_amount,
             co.guarantee_currency_code,
             co.creation_time,
             co.status,
             co.show_status,
             co.confirm_point,
             co.elong_card_no,
             co.penalty_to_customer,
             co.penalty_currency_code,
             co.is_cancelable,
             co.has_invoice,
             co.value_adds,
             co.contact_name,
             co.contact_mobile,
             co.contact_gender,
             co.cooperate_type,
             co.create_user,
             co.update_user,
             co.refund_time update_time,
             co.cancel_code,
             co.reason,
             co.hotel_name,
             co.hotel_phone,
             co.room_type_name,
             co.rate_plan_name,
             co.hotel_address,
             co.last_id,
             co.local_status,
             co.create_employee,
             co.company_id,
             co.contact_email,
             co.img_url,
             co.enable_update,
             co.cancel_user,
             co.pur_id pur_id,
             co.pur_name pur_name,
             co.pur_settle_state pur_settle_state,
             co.sup_id sup_id,
             co.sup_name sup_name,
             co.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             getDeptIdByUserId(co.create_user) dept_id,
             co.cancel_employee,
             co.bed_type,
             co.special_requirement,
             co.reserved_item,
             co.cancel_status,
             co.pay_state,
             co.refund_state,
             co.city,
             co.distributor_notes,
             co.pay_method,
             co.sale_total_price,
             co.total_profit,
             co.remark_to_fangcang,
             co.order_type hotel_order_type,
             co.pur_pay_type,
             co.pur_pay_time,
             co.pur_settle_type,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_pay_state,
             co.is_lock,
             co.sup_service_price,
             co.pur_bill_no,
             co.pur_bank_no,
             co.pur_rebate,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_bill_no,
             co.sup_bank_no,
             co.sup_rebate,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             co.sup_settle_type,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.timeout_state,
             co.timeout_time,
             co.checkin_days
        from T_CH_HOTEL_ORDER co
       where (order_type = '2' and refund_state = '2')
         and refund_time >= trunc(currentDay, 'dd') - 1000
         and refund_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  PROCEDURE CAL_REPORT_HOTEL_CUSTOMER(currentDay IN DATE) AS
    v_purSettleState varchar2(4);
    v_supSettleState varchar2(4);
    v_purSettleTime  date;
    v_supSettleTime  date;
  BEGIN
    --删除
    delete from T_FIN_REPORT_HOTEL_CUSTOMER
     where (ORDER_UPDATE_TIME >= trunc(currentDay, 'dd') - 1000 and
           ORDER_UPDATE_TIME <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
        or ORDER_UPDATE_TIME is null;

    --更新未结算的结算状态
    for rs in (select *
                 from t_fin_report_hotel_customer
                where (pur_settle_state = '0' or sup_settle_state = '0')
                  and order_update_time <=
                      trunc(currentDay, 'dd') - 1 - 1 / 24 / 60 / 60) loop
      --8国内酒店预订，7国内酒店退订
      if rs.order_type = '8' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_ch_hotel_order
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update t_fin_report_hotel_customer
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
        if v_supSettleState = '1' then
          update t_fin_report_hotel_customer
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
      elsif rs.order_type = '7' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_ch_hotel_order
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update t_fin_report_hotel_customer
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
        if v_supSettleState = '1' then
          update t_fin_report_hotel_customer
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where affiliate_confirmation_id = rs.affiliate_confirmation_id;
        end if;
        --else
        --v_purSettleState := null;
        --v_supSettleState := null;
      end if;
    end loop;

    --新增
    insert into T_FIN_REPORT_HOTEL_CUSTOMER
      (AFFILIATE_CONFIRMATION_ID,
       FRE_ID,
       IS_USER,
       COST_CENTER_ID,
       DEPT_ID,
       CREATE_USER,
       CREATE_TIME,
       ROOM_NO,
       ORDER_ID,
       HOTEL_CUSTOMER_TYPE,
       ORDER_TIME,
       HOTEL_BIZTRIP_ID,
       HOTEL_BIZTRIP_STANDARD,
       HOTEL_GROUP_ID,
       HOTEL_GROUP_NAME,
       HOTEL_STAR,
       HOTEL_CITY_CODE,
       HOTEL_CITY_NAME,
       HOTEL_ID,
       ROOM_TYPE_ID,
       RATE_PLAN_ID,
       ARRIVAL_DATE,
       DEPARTURE_DATE,
       CUSTOMER_TYPE,
       PAYMENT_TYPE,
       NUMBER_OF_ROOMS,
       NUMBER_OF_CUSTOMERS,
       EARLIEST_ARRIVAL_TIME,
       LATEST_ARRIVAL_TIME,
       TOTAL_PRICE,
       CURRENCY_CODE,
       CUSTOMER_IP_ADDRESS,
       IS_GUARANTEE_OR_CHARGED,
       SUPPLIER_CARD_NO,
       CONFIRMATION_TYPE,
       NOTE_TO_HOTEL,
       NOTE_TO_ELONG,
       IS_NEED_INVOICE,
       CONTACT,
       IS_FORCE_GUARANTEE,
       GUARANTEE_AMOUNT,
       GUARANTEE_CURRENCY_CODE,
       CREATION_TIME,
       STATUS,
       SHOW_STATUS,
       CONFIRM_POINT,
       ELONG_CARD_NO,
       PENALTY_TO_CUSTOMER,
       PENALTY_CURRENCY_CODE,
       IS_CANCELABLE,
       HAS_INVOICE,
       VALUE_ADDS,
       CONTACT_NAME,
       CONTACT_MOBILE,
       CONTACT_GENDER,
       COOPERATE_TYPE,
       ORDER_CREATE_USER,
       ORDER_CREATE_TIME,
       ORDER_UPDATE_USER,
       ORDER_UPDATE_TIME,
       CANCEL_CODE,
       REASON,
       HOTEL_NAME,
       HOTEL_PHONE,
       ROOM_TYPE_NAME,
       RATE_PLAN_NAME,
       HOTEL_ADDRESS,
       LAST_ID,
       LOCAL_STATUS,
       CREATE_EMPLOYEE,
       COMPANY_ID,
       CONTACT_EMAIL,
       IMG_URL,
       ENABLE_UPDATE,
       CANCEL_USER,
       PUR_ID,
       PUR_NAME,
       PUR_SETTLE_STATE,
       SUP_ID,
       SUP_NAME,
       SUP_SETTLE_STATE,
       REPORT_CREATE_TIME,
       CANCEL_TIME,
       CANCEL_EMPLOYEE,
       BED_TYPE,
       SPECIAL_REQUIREMENT,
       RESERVED_ITEM,
       CANCEL_STATUS,
       PAY_STATE,
       REFUND_STATE,
       CITY,
       DISTRIBUTOR_NOTES,
       PAY_METHOD,
       SALE_TOTAL_PRICE,
       TOTAL_PROFIT,
       REMARK_TO_FANGCANG,
       PUR_PAY_TYPE,
       PUR_PAY_TIME,
       PUR_SETTLE_TYPE,
       PUR_SETTLE_TIME,
       PUR_SETTLE_DETAIL_ID,
       PUR_PAY_STATE,
       IS_LOCK,
       SUP_SERVICE_PRICE,
       PUR_BILL_NO,
       PUR_BANK_NO,
       PUR_REBATE,
       PUR_CHECK_STATE,
       PUR_CHECK_TIME,
       PUR_CHECK_EMPLOYEE,
       SUP_BILL_NO,
       SUP_BANK_NO,
       SUP_REBATE,
       SUP_PAY_TYPE,
       SUP_PAY_TIME,
       SUP_CHECK_STATE,
       SUP_CHECK_TIME,
       SUP_CHECK_EMPLOYEE,
       SUP_SETTLE_TYPE,
       SUP_SETTLE_TIME,
       SUP_SETTLE_DETAIL_ID,
       TIMEOUT_STATE,
       TIMEOUT_TIME,
       ORDER_TYPE,
       ROOM_PRICE,
       CHECKIN_DAYS)
      select cc.affiliate_confirmation_id,
             cc.fre_id,
             cc.is_user,
             cc.cost_center_id,
             getDeptIdByUserId(cc.create_user) dept_id,
             cc.create_user,
             cc.create_time,
             null room_no,
             co.order_id,
             '8' hotel_customer_type,
             co.create_time order_time,
             null hotel_biztrip_id,
             null hotel_biztrip_standard,
             null hotel_group_id,
             null hotel_group_name,
             co.hotel_star,
             null hotel_city_code,
             null hotel_city_name,
             co.hotel_id,
             co.room_type_id,
             co.rate_plan_id,
             co.arrival_date,
             co.departure_date,
             co.customer_type,
             co.payment_type,
             co.number_of_rooms,
             co.number_of_customers,
             co.earliest_arrival_time,
             co.latest_arrival_time,
             co.total_price,
             co.currency_code,
             co.customer_ip_address,
             co.is_guarantee_or_charged,
             co.supplier_card_no,
             co.confirmation_type,
             co.note_to_hotel,
             co.note_to_elong,
             co.is_need_invoice， co.contact,
             co.is_force_guarantee,
             co.guarantee_amount,
             co.guarantee_currency_code,
             co.creation_time,
             co.status,
             co.show_status,
             co.confirm_point,
             co.elong_card_no,
             co.penalty_to_customer,
             co.penalty_currency_code,
             co.is_cancelable,
             co.has_invoice,
             co.value_adds,
             co.contact_name,
             co.contact_mobile,
             co.contact_gender,
             co.cooperate_type,
             co.create_user order_create_user,
             co.create_time order_create_time,
             co.update_user order_update_user,
             co.update_time order_update_time,
             co.cancel_code,
             co.reason,
             co.hotel_name,
             co.hotel_phone,
             co.room_type_name,
             co.rate_plan_name,
             co.hotel_address,
             co.last_id,
             co.local_status,
             co.create_employee,
             co.company_id,
             co.contact_email,
             co.img_url,
             co.enable_update,
             co.cancel_user,
             co.pur_id,
             co.pur_name,
             co.pur_settle_state,
             co.sup_id,
             co.sup_name,
             co.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             co.cancel_time,
             co.cancel_employee,
             co.bed_type,
             co.special_requirement,
             co.reserved_item,
             co.cancel_status,
             co.pay_state,
             co.refund_state,
             co.city,
             co.distributor_notes,
             co.pay_method,
             co.sale_total_price,
             co.total_profit,
             co.remark_to_fangcang,
             co.pur_pay_type,
             co.pur_pay_time,
             co.pur_settle_type,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_pay_state,
             co.is_lock,
             co.sup_service_price,
             co.pur_bill_no,
             co.pur_bank_no,
             co.pur_rebate,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_bill_no,
             co.sup_bank_no,
             co.sup_rebate,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             co.sup_settle_type,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.timeout_state,
             co.timeout_time,
             co.order_type,
             cc.room_price,
             cc.checkin_days
        from t_ch_order_customer cc, t_ch_hotel_order co
       where cc.affiliate_confirmation_id = co.affiliate_confirmation_id
         and ((co.order_type = '1' and
             (co.local_status = '3' or co.local_status = '10' or
             co.local_status = '5')) or
             (co.order_type = '2' and
             (co.local_status = '3' or co.local_status = '4')))
         and co.update_time >= trunc(currentDay, 'dd') - 1000
         and co.update_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
      union all
      select cc.affiliate_confirmation_id,
             cc.fre_id,
             cc.is_user,
             cc.cost_center_id,
             getDeptIdByUserId(cc.create_user) dept_id,
             cc.create_user,
             cc.create_time,
             null room_no,
             co.order_id,
             '7' hotel_customer_type,
             co.create_time order_time,
             null hotel_biztrip_id,
             null hotel_biztrip_standard,
             null hotel_group_id,
             null hotel_group_name,
             co.hotel_star,
             null hotel_city_code,
             null hotel_city_name,
             co.hotel_id,
             co.room_type_id,
             co.rate_plan_id,
             co.arrival_date,
             co.departure_date,
             co.customer_type,
             co.payment_type,
             co.number_of_rooms,
             co.number_of_customers,
             co.earliest_arrival_time,
             co.latest_arrival_time,
             co.total_price,
             co.currency_code,
             co.customer_ip_address,
             co.is_guarantee_or_charged,
             co.supplier_card_no,
             co.confirmation_type,
             co.note_to_hotel,
             co.note_to_elong,
             co.is_need_invoice， co.contact,
             co.is_force_guarantee,
             co.guarantee_amount,
             co.guarantee_currency_code,
             co.creation_time,
             co.status,
             co.show_status,
             co.confirm_point,
             co.elong_card_no,
             co.penalty_to_customer,
             co.penalty_currency_code,
             co.is_cancelable,
             co.has_invoice,
             co.value_adds,
             co.contact_name,
             co.contact_mobile,
             co.contact_gender,
             co.cooperate_type,
             co.create_user order_create_user,
             co.create_time order_create_time,
             co.update_user order_update_user,
             co.refund_time order_update_time,
             co.cancel_code,
             co.reason,
             co.hotel_name,
             co.hotel_phone,
             co.room_type_name,
             co.rate_plan_name,
             co.hotel_address,
             co.last_id,
             co.local_status,
             co.create_employee,
             co.company_id,
             co.contact_email,
             co.img_url,
             co.enable_update,
             co.cancel_user,
             co.pur_id,
             co.pur_name,
             co.pur_settle_state,
             co.sup_id,
             co.sup_name,
             co.sup_settle_state,
             trunc(sysdate, 'dd') report_create_time,
             co.cancel_time,
             co.cancel_employee,
             co.bed_type,
             co.special_requirement,
             co.reserved_item,
             co.cancel_status,
             co.pay_state,
             co.refund_state,
             co.city,
             co.distributor_notes,
             co.pay_method,
             co.sale_total_price,
             co.total_profit,
             co.remark_to_fangcang,
             co.pur_pay_type,
             co.pur_pay_time,
             co.pur_settle_type,
             co.pur_settle_time,
             co.pur_settle_detail_id,
             co.pur_pay_state,
             co.is_lock,
             co.sup_service_price,
             co.pur_bill_no,
             co.pur_bank_no,
             co.pur_rebate,
             co.pur_check_state,
             co.pur_check_time,
             co.pur_check_employee,
             co.sup_bill_no,
             co.sup_bank_no,
             co.sup_rebate,
             co.sup_pay_type,
             co.sup_pay_time,
             co.sup_check_state,
             co.sup_check_time,
             co.sup_check_employee,
             co.sup_settle_type,
             co.sup_settle_time,
             co.sup_settle_detail_id,
             co.timeout_state,
             co.timeout_time,
             co.order_type,
             cc.room_price,
             cc.checkin_days
        from t_ch_order_customer cc, t_ch_hotel_order co
       where cc.affiliate_confirmation_id = co.affiliate_confirmation_id
         and (co.order_type = '2' and co.refund_state = '2')
         and co.refund_time >= trunc(currentDay, 'dd') - 1000
         and co.refund_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 保险订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_INSURANCE_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-03-26
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_INS_ORDER(currentDay IN DATE) AS
  BEGIN
    --删除
    delete from T_FIN_REPORT_INSURANCE_ORDER
     where order_time >= trunc(currentDay, 'dd') - 1
       and order_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60;

    --新增
    insert into T_FIN_REPORT_INSURANCE_ORDER
      (order_detail_id,
       order_detail_no,
       order_id,
       plane_order_id,
       plane_ticket_id,
       plane_od_id,
       plane_trip_id,
       insurance_id,
       order_type,
       state,
       sale_price,
       floor_price,
       user_id,
       employee_id,
       order_time,
       company_id,
       cost_center_id,
       contract_name,
       idc_type,
       idc_no,
       ins_product_no,
       flight_no,
       pur_id,
       pur_name,
       pur_settle_state,
       sup_id,
       sup_name,
       sup_settle_state,
       sup_insurance_order_id,
       sup_print_no,
       sup_insurance_order_no,
       apply_time,
       create_time)
      select ins_order_detail_id order_detail_id,
             ins_order_detail_no order_detail_no,
             insurance_order_id order_id,
             plane_order_id,
             plane_ticket_id,
             plane_od_id,
             plane_trip_id,
             insurance_id,
             '11' order_type,
             state,
             sale_price,
             floor_price,
             create_user user_id,
             create_employee employee_id,
             ticketing_time order_time,
             company_id,
             cost_center_id,
             contract_name,
             idc_type,
             idc_no,
             ins_product_no,
             flight_no,
             pur_id,
             pur_name,
             pur_settle_state,
             sup_id,
             sup_name,
             sup_settle_state,
             sup_insurance_order_id,
             sup_print_no,
             sup_insurance_order_no,
             create_time apply_time,
             trunc(sysdate, 'dd') create_time
        from t_cc_insurance_order_detail
       where (state = '2' or state = '3')
         and ticketing_time is not null
         and ticketing_time >= trunc(currentDay, 'dd') - 1
         and ticketing_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
      union
      select ins_refund_detail_id ins_order_detail_id,
             ins_refund_detail_no ins_order_detail_no,
             insurance_order_id ins_order_id,
             plane_order_id,
             plane_ticket_id,
             plane_od_id,
             plane_trip_id,
             insurance_id,
             '12' ins_order_type,
             state,
             sale_price,
             floor_price,
             create_user user_id,
             create_employee employee_id,
             cancel_time order_time,
             company_id,
             cost_center_id,
             contract_name,
             idc_type,
             idc_no,
             ins_product_no,
             flight_no,
             pur_id,
             pur_name,
             pur_settle_state,
             sup_id,
             sup_name,
             sup_settle_state,
             sup_insurance_order_id,
             sup_print_no,
             sup_insurance_order_no,
             create_time apply_time,
             trunc(sysdate, 'dd') create_time
        from t_cc_insurance_refund_detail
       where (state = '5' or state = '6')
         and cancel_time is not null
         and cancel_time >= trunc(currentDay, 'dd') - 1
         and cancel_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 行程报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_PLANE_TRIP
  -- 2.条件：查询前一天的行程数据
  -- 3.结果：
  -- 日期：2015-04-22
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_PLANE_TRIP(currentDay IN DATE) AS
  BEGIN
    --删除
    delete from T_FIN_REPORT_PLANE_TRIP
     where create_time >= trunc(currentDay, 'dd') - 1
       and create_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60;

    --新增
    insert into T_FIN_REPORT_PLANE_TRIP
      (order_id,
       order_no,
       order_type,
       order_state,
       pnr,
       separate_pnr,
       company_id,
       cost_center_id,
       plane_od_id,
       depart_city,
       depart_city_code,
       depart_city_name,
       arrive_city,
       arrive_city_code,
       arrive_city_name,
       depart_airport,
       depart_airport_code,
       depart_airport_name,
       arrive_airport,
       arrive_airport_code,
       arrive_airport_name,
       depart_airport_tower,
       arrive_airport_tower,
       depart_time,
       arrive_time,
       cabin_class,
       cabin,
       airline,
       airline_code,
       airline_name,
       distance,
       flight_type,
       flight_index,
       flight_time,
       create_time,
       meal,
       price,
       face_price,
       airport_cst_fee,
       fuel_fee,
       service_price,
       tax,
       is_lowest_flight,
       lowest_flight_id,
       not_lowest_code,
       not_lowest_reason,
       lowest_flight_price,
       is_standard_flight,
       standard_flight_id,
       standard_filght_price,
       discount,
       plane_trip_id,
       take_off_time,
       land_time,
       flight_no,
       child_cabin,
       create_user,
       modify_user,
       modify_time,
       plane_type,
       cabin_left,
       stop_quantity,
       trip_flight_time,
       wait_time,
       od_resource,
       od_xml,
       marketing_airline,
       marketing_airline_code,
       marketing_airline_name,
       plane_ticket_id,
       plane_ticket_no,
       ticket_state,
       ticket_create_user,
       ticketing_employee,
       ticketing_time,
       is_user,
       user_id,
       contact_id,
       idc_name,
       idc_type,
       idc_no,
       phone,
       ticket_face_price,
       ticket_sale_price,
       dept_id,
       report_create_time)
      select co.plane_order_id order_id,
             co.plane_order_no order_no,
             '1' order_type,
             co.state order_state,
             co.pnr,
             null separate_pnr,
             co.company_id,
             co.cost_center_id,
             cod.plane_od_id,
             ctrip.depart_city,
             ctrip.depart_city_code,
             ctrip.depart_city_name,
             ctrip.arrive_city,
             ctrip.arrive_city_code,
             ctrip.arrive_city_name,
             ctrip.depart_airport,
             ctrip.depart_airport_code,
             ctrip.depart_airport_name,
             ctrip.arrive_airport,
             ctrip.arrive_airport_code,
             ctrip.arrive_airport_name,
             ctrip.depart_airport_tower,
             ctrip.arrive_airport_tower,
             cod.depart_time,
             cod.arrive_time,
             ctrip.cabin_class,
             ctrip.cabin,
             ctrip.airline,
             ctrip.airline_code,
             ctrip.airline_name,
             ctrip.distance,
             ctrip.flight_type,
             ctrip.flight_index,
             ctrip.flight_time,
             ctrip.create_time,
             ctrip.meal,
             cod.price,
             cod.face_price,
             cod.airport_cst_fee,
             cod.fuel_fee,
             cod.service_price,
             cod.tax,
             cod.is_lowest_flight,
             cod.lowest_flight_id,
             cod.not_lowest_code,
             cod.not_lowest_reason,
             null lowest_flight_price,
             null is_standard_flight,
             null standard_flight_id,
             null standard_flight_price,
             null discount,
             ctrip.plane_trip_id,
             ctrip.take_off_time,
             ctrip.arrive_time land_time,
             ctrip.flight_no,
             ctrip.child_cabin,
             ctrip.create_user,
             ctrip.modify_user,
             ctrip.modify_time,
             ctrip.plane_type,
             ctrip.cabin_left,
             ctrip.stop_quantity,
             ctrip.flight_time trip_flight_time,
             ctrip.wait_time,
             null od_resource,
             null od_xml,
             null marketing_airline,
             null marketing_airline_code,
             null marketing_airline_name,
             ct.plane_ticket_id,
             ct.plane_ticket_no,
             ct.state ticket_state,
             ct.create_user ticket_create_user,
             ct.ticketing_employee,
             ct.ticketing_time,
             null is_user,
             null user_id,
             null contact_id,
             ct.idc_name,
             ct.idc_type,
             ct.idc_no,
             ct.phone,
             ct.face_price ticket_face_price,
             ct.sale_price ticket_sale_price,
             getDeptIdByUserId(ctrip.create_user) dept_id,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_plane_order      co,
             t_cc_ticket_passenger ct,
             t_cc_plane_od         cod,
             t_cc_plane_trip       ctrip
       where co.ticketing_time >= currentDay - 1
         and co.ticketing_time <= currentDay - 1 / 24 / 60 / 60
         and co.plane_order_id = ct.plane_order_id
         and cod.plane_order_id = co.plane_order_id
         and ctrip.plane_od_id = cod.plane_od_id
         and ct.ticketing_time is not null
      union
      select cc.change_id order_id,
             cc.change_no order_no,
             '3' order_type,
             cc.state order_state,
             cc.pnr,
             cc.separate_pnr,
             cc.company_id,
             cc.cost_center_id,
             cod.plane_od_id,
             ctrip.depart_city,
             ctrip.depart_city_code,
             ctrip.depart_city_name,
             ctrip.arrive_city,
             ctrip.arrive_city_code,
             ctrip.arrive_city_name,
             ctrip.depart_airport,
             ctrip.depart_airport_code,
             ctrip.depart_airport_name,
             ctrip.arrive_airport,
             ctrip.arrive_airport_code,
             ctrip.arrive_airport_name,
             ctrip.depart_airport_tower,
             ctrip.arrive_airport_tower,
             cod.depart_time,
             cod.arrive_time,
             ctrip.cabin_class,
             ctrip.cabin,
             ctrip.airline,
             ctrip.airline_code,
             ctrip.airline_name,
             ctrip.distance,
             ctrip.flight_type,
             ctrip.flight_index,
             ctrip.flight_time,
             ctrip.create_time,
             ctrip.meal,
             cod.price,
             cod.face_price,
             cod.airport_cst_fee,
             cod.fuel_fee,
             cod.service_price,
             cod.tax,
             cod.is_lowest_flight,
             cod.lowest_flight_id,
             cod.not_lowest_code,
             cod.not_lowest_reason,
             null lowest_flight_price,
             null is_standard_flight,
             null standard_flight_id,
             null standard_flight_price,
             null discount,
             ctrip.plane_trip_id,
             ctrip.take_off_time,
             ctrip.arrive_time land_time,
             ctrip.flight_no,
             ctrip.child_cabin,
             ctrip.create_user,
             ctrip.modify_user,
             ctrip.modify_time,
             ctrip.plane_type,
             ctrip.cabin_left,
             ctrip.stop_quantity,
             ctrip.flight_time trip_flight_time,
             ctrip.wait_time,
             null od_resource,
             null od_xml,
             null marketing_airline,
             null marketing_airline_code,
             null marketing_airline_name,
             ct.plane_ticket_id,
             ct.plane_ticket_no,
             ct.state ticket_state,
             ct.create_user ticket_create_user,
             ct.ticketing_employee,
             ct.ticketing_time,
             null is_user,
             null user_id,
             null contact_id,
             ct.idc_name,
             ct.idc_type,
             ct.idc_no,
             ct.phone,
             ct.face_price ticket_face_price,
             ct.sale_price ticket_sale_price,
             getDeptIdByUserId(ctrip.create_user) dept_id,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_plane_change     cc,
             t_cc_change_ticket    cct,
             t_cc_ticket_passenger ct,
             t_cc_change_od        ccod,
             t_cc_plane_od         cod,
             t_cc_plane_trip       ctrip
       where cc.complete_time >= trunc(currentDay, 'dd') - 1
         and cc.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and cc.change_id = cct.change_id
         and cct.plane_ticket_id = ct.plane_ticket_id
         and cc.change_id = ccod.change_id
         and ccod.od_id = cod.plane_od_id
         and ctrip.plane_od_id = cod.plane_od_id
         and ct.ticketing_time is not null
      union
      select io.plane_order_id order_id,
             io.plane_order_no order_no,
             '2' order_type,
             io.state order_state,
             io.pnr,
             null separate_pnr,
             io.company_id,
             io.cost_center_id,
             iod.plane_od_id,
             itrip.depart_city,
             itrip.depart_city_code,
             itrip.depart_city_name,
             itrip.arrive_city,
             itrip.arrive_city_code,
             itrip.arrive_city_name,
             itrip.depart_airport,
             itrip.depart_airport_code,
             itrip.depart_airport_name,
             itrip.arrive_airport,
             itrip.arrive_airport_code,
             itrip.arrive_airport_name,
             itrip.depart_airport_tower,
             itrip.arrive_airport_tower,
             iod.depart_time,
             iod.arrive_time,
             itrip.cabin_class,
             itrip.cabin,
             itrip.airline,
             itrip.airline_code,
             itrip.airline_name,
             null distance,
             itrip.flight_type,
             itrip.flight_index,
             itrip.flight_time,
             itrip.create_time,
             itrip.meal,
             iod.price,
             null face_price,
             null airport_cst_fee,
             null fuel_fee,
             iod.service_price,
             iod.tax,
             null is_lowest_flight,
             null lowest_flight_id,
             null not_lowest_code,
             null not_lowest_reason,
             null lowest_flight_price,
             null is_standard_flight,
             null standard_flight_id,
             null standard_flight_price,
             null discount,
             itrip.plane_trip_id,
             itrip.take_off_time,
             itrip.arrive_time land_time,
             itrip.flight_no,
             itrip.child_cabin,
             itrip.create_user,
             itrip.modify_user,
             itrip.modify_time,
             itrip.plane_type,
             itrip.cabin_left,
             itrip.stop_quantity,
             itrip.flight_time trip_flight_time,
             itrip.wait_time,
             null od_resource,
             null od_xml,
             null marketing_airline,
             null marketing_airline_code,
             null marketing_airline_name,
             it.plane_ticket_id,
             it.plane_ticket_no,
             it.state ticket_state,
             it.create_user ticket_create_user,
             it.ticketing_employee,
             it.ticketing_time,
             null is_user,
             null user_id,
             null contact_id,
             it.idc_name,
             it.idc_type,
             it.idc_no,
             it.phone,
             it.face_price ticket_face_price,
             it.sale_price ticket_sale_price,
             getDeptIdByUserId(itrip.create_user) dept_id,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_inter_plane_order      io,
             t_cc_inter_ticket_passenger it,
             t_cc_inter_plane_od         iod,
             t_cc_inter_plane_trip       itrip
       where io.ticketing_time >= currentDay - 1
         and io.ticketing_time <= currentDay - 1 / 24 / 60 / 60
         and io.plane_order_id = it.plane_order_id
         and iod.plane_order_id = io.plane_order_id
         and itrip.plane_od_id = iod.plane_od_id
         and it.ticketing_time is not null
      union
      select ic.change_id order_id,
             ic.change_no order_no,
             '4' order_type,
             ic.state order_state,
             ic.pnr,
             ic.separate_pnr,
             ic.company_id,
             ic.cost_center_id,
             iod.plane_od_id,
             itrip.depart_city,
             itrip.depart_city_code,
             itrip.depart_city_name,
             itrip.arrive_city,
             itrip.arrive_city_code,
             itrip.arrive_city_name,
             itrip.depart_airport,
             itrip.depart_airport_code,
             itrip.depart_airport_name,
             itrip.arrive_airport,
             itrip.arrive_airport_code,
             itrip.arrive_airport_name,
             itrip.depart_airport_tower,
             itrip.arrive_airport_tower,
             iod.depart_time,
             iod.arrive_time,
             itrip.cabin_class,
             itrip.cabin,
             itrip.airline,
             itrip.airline_code,
             itrip.airline_name,
             null distance,
             itrip.flight_type,
             itrip.flight_index,
             itrip.flight_time,
             itrip.create_time,
             itrip.meal,
             iod.price,
             null face_price,
             null airport_cst_fee,
             null fuel_fee,
             iod.service_price,
             iod.tax,
             null is_lowest_flight,
             null lowest_flight_id,
             null not_lowest_code,
             null not_lowest_reason,
             null lowest_flight_price,
             null is_standard_flight,
             null standard_flight_id,
             null standard_flight_price,
             null discount,
             itrip.plane_trip_id,
             itrip.take_off_time,
             itrip.arrive_time land_time,
             itrip.flight_no,
             itrip.child_cabin,
             itrip.create_user,
             itrip.modify_user,
             itrip.modify_time,
             itrip.plane_type,
             itrip.cabin_left,
             itrip.stop_quantity,
             itrip.flight_time trip_flight_time,
             itrip.wait_time,
             null od_resource,
             null od_xml,
             null marketing_airline,
             null marketing_airline_code,
             null marketing_airline_name,
             it.plane_ticket_id,
             it.plane_ticket_no,
             it.state ticket_state,
             it.create_user ticket_create_user,
             it.ticketing_employee,
             it.ticketing_time,
             null is_user,
             null user_id,
             null contact_id,
             it.idc_name,
             it.idc_type,
             it.idc_no,
             it.phone,
             it.face_price ticket_face_price,
             it.sale_price ticket_sale_price,
             getDeptIdByUserId(itrip.create_user) dept_id,
             trunc(sysdate, 'dd') report_create_time
        from t_cc_inter_plane_change     ic,
             t_cc_inter_change_ticket    ict,
             t_cc_inter_ticket_passenger it,
             t_cc_inter_change_od        icod,
             t_cc_inter_plane_od         iod,
             t_cc_inter_plane_trip       itrip
       where ic.complete_time >= trunc(currentDay, 'dd') - 1
         and ic.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
         and ic.change_id = ict.change_id
         and ict.plane_ticket_id = it.plane_ticket_id
         and ic.change_id = icod.change_id
         and icod.od_id = iod.plane_od_id
         and itrip.plane_od_id = iod.plane_od_id
         and it.ticketing_time is not null;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 火车票订单报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_TRAIN_ORDER
  -- 2.条件：查询前一天的订单数据
  -- 3.结果：
  -- 日期：2015-07-11
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_TRAIN_ORDER(currentDay IN DATE) AS
    v_purSettleState varchar2(4);
    v_supSettleState varchar2(4);
    v_purSettleTime  date;
    v_supSettleTime  date;
  BEGIN
    --删除
    delete from T_FIN_REPORT_TRAIN_ORDER
     where (complete_time >= trunc(currentDay, 'dd') - 1000 and
           complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
        or complete_time is null;

    --更新未结算的结算状态
    for rs in (select *
                 from T_FIN_REPORT_TRAIN_ORDER
                where (pur_settle_state = '0' or sup_settle_state = '0')
                  and complete_time <=
                      trunc(currentDay, 'dd') - 1 - 1 / 24 / 60 / 60) loop
      --17国内火车票订票，18国内火车票退票
      if rs.order_type = '17' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_train_order
           where train_order_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_TRAIN_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_TRAIN_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.order_type = '18' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_train_refund
           where train_refund_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update T_FIN_REPORT_TRAIN_ORDER
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update T_FIN_REPORT_TRAIN_ORDER
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
        --else
        --v_purSettleState := null;
        --v_supSettleState := null;
      end if;
    end loop;

    --新增
    insert into t_fin_report_train_order
      (order_id,
       order_no,
       order_type,
       state,
       train_order_id,
       train_order_no,
       sup_train_order_no,
       biz_trip_id,
       source,
       audit_state,
       company_id,
       cost_center_id,
       type,
       remark,
       train_code,
       depart_date,
       arrive_date,
       depart_station,
       arrive_station,
       order_level,
       is_choose_no_seat,
       contact_name,
       contact_email,
       contact_phone,
       contact_address,
       sale_price,
       floor_price,
       service_price,
       ticket_sale_price,
       ticket_floor_price,
       insurance_sale_price,
       insurance_floor_price,
       apply_user_id,
       apply_user_name,
       apply_employee_id,
       apply_employee_name,
       apply_time,
       apply_remark,
       cancel_user_id,
       cancel_user_name,
       cancel_employee_id,
       cancel_employee_name,
       cancel_time,
       cancel_reason,
       handling_employee_id,
       handling_employee_name,
       handling_time,
       handling_remark,
       complete_employee_id,
       complete_employee_name,
       complete_time,
       complete_remark,
       pur_id,
       pur_name,
       pur_service_price,
       pur_pay_state,
       pur_handling_fee,
       pur_refund_money,
       pur_trade_no,
       pur_refund_state,
       pur_refund_time,
       pur_pay_time,
       pur_pay_type,
       pur_settle_type,
       pur_settle_state,
       pur_settle_time,
       pur_settle_detail_id,
       pur_check_state,
       pur_check_time,
       pur_check_employee_id,
       pur_check_employee_name,
       pur_bill_no,
       pur_bank_no,
       sup_id,
       sup_name,
       sup_order_no,
       sup_trade_no,
       sup_handling_fee,
       sup_refund_money,
       sup_refund_state,
       sup_refund_time,
       sup_refund_employee_id,
       sup_refund_employee_name,
       sup_refund_remark,
       sup_service_price,
       sup_pay_state,
       sup_pay_type,
       sup_pay_time,
       sup_settle_type,
       sup_settle_state,
       sup_settle_time,
       sup_settle_detail_id,
       sup_check_state,
       sup_check_time,
       sup_check_employee_id,
       sup_check_employee_name,
       sup_bill_no,
       sup_bank_no,
       report_create_time,
       dept_id,
       dept_name)
      select co.train_order_id order_id,
             co.train_order_no order_no,
             '17' order_type,
             co.state state,
             null train_order_id,
             null train_order_no,
             co.sup_train_order_no sup_train_order_no,
             co.biz_trip_id biz_trip_id,
             co.source source,
             co.audit_state audit_state,
             co.company_id company_id,
             co.cost_center_id cost_center_id,
             null type,
             co.remark remark,
             co.train_code train_code,
             co.depart_date depart_date,
             co.arrive_date arrive_date,
             co.depart_station depart_station,
             co.arrive_station arrive_station,
             co.order_level order_level,
             co.is_choose_no_seat is_choose_no_seat,
             co.contact_name contact_name,
             co.contact_email contact_email,
             co.contact_phone contact_phone,
             co.contact_address contact_address,
             co.sale_price sale_price,
             co.floor_price floor_price,
             null service_price,
             co.ticket_sale_price ticket_sale_price,
             co.ticket_floor_price ticket_floor_price,
             co.insurance_sale_price insurance_sale_price,
             co.insurance_floor_price insurance_floor_price,
             co.create_user_id apply_user_id,
             null apply_user_name,
             co.create_employee_id apply_employee_id,
             null apply_employee_name,
             co.create_time apply_time,
             co.create_remark apply_remark,
             co.cancel_user_id cancel_user_id,
             null cancel_user_name,
             co.cancel_employee_id cancel_employee_id,
             null cancel_employee_name,
             co.cancel_time cancel_time,
             co.cancel_reason cancel_reason,
             co.handling_employee_id handling_employee_id,
             null handling_employee_name,
             co.handling_time handling_time,
             co.handling_remark handling_remark,
             co.ticketing_employee_id complete_employee_id,
             null complete_employee_name,
             co.ticketing_time complete_time,
             co.ticketing_remark complete_remark,
             co.pur_id pur_id,
             co.pur_name pur_name,
             co.pur_service_price pur_service_price,
             co.pur_pay_type pur_pay_state,
             null pur_handling_fee,
             null pur_refund_money,
             null pur_trade_no,
             null pur_refund_state,
             null pur_refund_time,
             co.pur_pay_time pur_pay_time,
             co.pur_pay_type pur_pay_type,
             co.pur_settle_type pur_settle_type,
             co.pur_settle_state pur_settle_state,
             co.pur_settle_time pur_settle_time,
             co.pur_settle_detail_id pur_settle_detail_id,
             co.pur_check_state pur_check_state,
             co.pur_check_time pur_check_time,
             co.pur_check_employee_id pur_check_employee_id,
             null pur_check_employee_name,
             co.pur_bill_no pur_bill_no,
             co.pur_bank_no pur_bank_no,
             co.sup_id sup_id,
             co.sup_name sup_name,
             null sup_order_no,
             null sup_trade_no,
             null sup_handling_fee,
             null sup_refund_money,
             null sup_refund_state,
             null sup_refund_time,
             null sup_refund_employee_id,
             null sup_refund_employee_name,
             null sup_refund_remark,
             co.sup_service_price sup_service_price,
             co.sup_pay_state sup_pay_state,
             co.sup_pay_type sup_pay_type,
             co.sup_pay_time sup_pay_time,
             co.sup_settle_type sup_settle_type,
             co.sup_settle_state sup_settle_state,
             co.sup_settle_time sup_settle_time,
             co.sup_settle_detail_id sup_settle_detail_id,
             co.sup_check_state sup_check_state,
             co.sup_check_time sup_check_time,
             co.sup_check_employee_id sup_check_employee_id,
             null sup_check_employee_name,
             co.sup_bill_no sup_bill_no,
             co.sup_bank_no sup_bank_no,
             trunc(sysdate, 'dd') report_create_time,
             getDeptIdByUserId(co.create_user_id) dept_id,
             null dept_name
        from t_cc_train_order co
       where (co.state = '4' or co.state = '5' or co.state = '6')
         and co.ticketing_time >= trunc(currentday, 'dd') - 1000
         and co.ticketing_time <=
             trunc(currentday, 'dd') - 1 / 24 / 60 / 60
      union all
      select cr.train_refund_id order_id,
             cr.train_refund_no order_no,
             '18' order_type,
             cr.state state,
             cr.train_order_id train_order_id,
             cr.train_order_no train_order_no,
             ct.sup_train_order_no sup_train_order_no,
             null biz_trip_id,
             null source,
             null audit_state,
             cr.company_id company_id,
             cr.cost_center_id cost_center_id,
             cr.type type,
             cr.remark remark,
             ct.train_code train_code,
             ct.depart_date depart_date,
             ct.arrive_date arrive_date,
             ct.depart_station depart_station,
             ct.arrive_station arrive_station,
             null order_level,
             null is_choose_no_seat,
             null contact_name,
             null contact_email,
             null contact_phone,
             null contact_address,
             cr.sale_price sale_price,
             cr.floor_price floor_price,
             cr.service_price service_price,
             cr.ticket_sale_price ticket_sale_price,
             cr.ticket_floor_price ticket_floor_price,
             cr.insurance_sale_price insurance_sale_price,
             cr.insurance_floor_price insurance_floor_price,
             cr.apply_user_id apply_user_id,
             null apply_user_name,
             cr.apply_employee_id apply_employee_id,
             null apply_employee_name,
             cr.apply_time apply_time,
             cr.apply_remark apply_remark,
             cr.cancel_user_id cancel_user_id,
             null cancel_user_name,
             cr.cancel_employee_id cancel_employee_id,
             null cancel_employee_name,
             cr.cancel_time cancel_time,
             cr.cancel_reason cancel_reason,
             cr.handling_employee_id handling_employee_id,
             null handling_employee_name,
             cr.handling_time handling_time,
             null handling_remark,
             cr.complete_employee_id complete_employee_id,
             null complete_employee_name,
             cr.complete_time complete_time,
             cr.complete_remark complete_remark,
             cr.pur_id pur_id,
             cr.pur_name pur_name,
             null pur_service_price,
             null pur_pay_state,
             cr.pur_handling_fee pur_handling_fee,
             cr.pur_refund_money pur_refund_money,
             cr.pur_trade_no pur_trade_no,
             cr.pur_refund_state pur_refund_state,
             cr.pur_refund_time pur_refund_time,
             null pur_pay_time,
             cr.pur_pay_type pur_pay_type,
             cr.pur_settle_type pur_settle_type,
             cr.pur_settle_state pur_settle_state,
             cr.pur_settle_time pur_settle_time,
             cr.pur_settle_detail_id pur_settle_detail_id,
             cr.pur_check_state pur_check_state,
             cr.pur_check_time pur_check_time,
             cr.pur_check_employee_id pur_check_employee_id,
             null pur_check_employee_name,
             null pur_bill_no,
             cr.pur_bank_no pur_bank_no,
             cr.sup_id sup_id,
             cr.sup_name sup_name,
             cr.sup_order_no sup_order_no,
             cr.sup_trade_no sup_trade_no,
             cr.sup_handling_fee sup_handling_fee,
             cr.sup_refund_money sup_refund_money,
             cr.sup_refund_state sup_refund_state,
             cr.sup_refund_time sup_refund_time,
             cr.sup_refund_employee_id sup_refund_employee_id,
             null sup_refund_employee_name,
             cr.sup_refund_remark sup_refund_remark,
             null sup_service_price,
             null sup_pay_state,
             cr.sup_pay_type sup_pay_type,
             null sup_pay_time,
             cr.sup_settle_type sup_settle_type,
             cr.sup_settle_state sup_settle_state,
             cr.sup_settle_time sup_settle_time,
             cr.sup_settle_detail_id sup_settle_detail_id,
             cr.sup_check_state sup_check_state,
             cr.sup_check_time sup_check_time,
             cr.sup_check_employee_id sup_check_employee_id,
             null sup_check_employee_name,
             cr.sup_bill_no sup_bill_no,
             cr.sup_bank_no sup_bank_no,
             trunc(sysdate, 'dd') report_create_time,
             getDeptIdByUserId(cr.apply_user_id) dept_id,
             null dept_name
        from t_cc_train_trip ct, t_cc_train_refund cr
       where ct.train_order_id = cr.train_order_id
         and (cr.state = '3' or cr.state = '4' or cr.state = '5')
         and cr.complete_time >= trunc(currentday, 'dd') - 1000
         and cr.complete_time <= trunc(currentday, 'dd') - 1 / 24 / 60 / 60;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

  ----------------------------------
  -- 火车票报表，每天轮循
  -- 条件：
  -- 1.表名：T_FIN_REPORT_TRAIN_TICKET
  -- 2.条件：查询前一天的火车票数据
  -- 3.结果：
  -- 日期：2015-07-13
  ----------------------------------
  PROCEDURE CALCULATE_REPORT_TRAIN_TICKET(currentDay IN DATE) AS
    v_purSettleState varchar2(4);
    v_supSettleState varchar2(4);
    v_purSettleTime  date;
    v_supSettleTime  date;
  BEGIN
    --删除
    delete from T_FIN_REPORT_TRAIN_TICKET
     where (TICKETING_TIME >= trunc(currentDay, 'dd') - 1000 and
           TICKETING_TIME <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60)
        or TICKETING_TIME is null;

    --更新未结算的结算状态
    for rs in (select *
                 from t_fin_report_plane_ticket
                where (pur_settle_state = '0' or sup_settle_state = '0')
                  and ticketing_time <=
                      trunc(currentDay, 'dd') - 1 - 1 / 24 / 60 / 60) loop
      --17国内火车票订票，18国内火车票退票
      if rs.plane_ticket_type = '17' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_train_order
           where train_order_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update t_fin_report_plane_ticket
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update t_fin_report_plane_ticket
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
      elsif rs.plane_ticket_type = '18' then
        begin
          select pur_settle_state,
                 sup_settle_state,
                 pur_settle_time,
                 sup_settle_time
            into v_purSettleState,
                 v_supSettleState,
                 v_purSettleTime,
                 v_supSettleTime
            from t_cc_train_refund
           where train_refund_id = rs.order_id;
        exception
          when no_data_found then
            v_purSettleState := null;
            v_supSettleState := null;
        end;
        if v_purSettleState = '1' then
          update t_fin_report_plane_ticket
             set pur_settle_state = '1', pur_settle_time = v_purSettleTime
           where order_id = rs.order_id;
        end if;
        if v_supSettleState = '1' then
          update t_fin_report_plane_ticket
             set sup_settle_state = '1', sup_settle_time = v_supSettleTime
           where order_id = rs.order_id;
        end if;
        --else
        --v_purSettleState := null;
        --v_supSettleState := null;
      end if;
    end loop;

    --新增
    insert into T_FIN_REPORT_TRAIN_TICKET
      (TRAIN_TICKET_ID,
       TRAIN_TICKET_NO,
       TRAIN_ORDER_ID,
       TRAIN_ORDER_NO,
       TRAIN_TRIP_ID,
       PLANE_TICKET_TYPE,
       TICKETING_TIME,
       TICKETING_EMPLOYEE,
       STATE,
       PAX_ID,
       PAX_TYPE,
       PAX_SOURCE,
       IDC_TYPE,
       IDC_NO,
       IDC_NAME,
       PHONE,
       BIRTHDAY,
       SEX,
       PERSON_TYPE,
       FACE_PRICE,
       SALE_PRICE,
       PUR_SERVICE_PRICE,
       SUP_SERVICE_PRICE,
       FLOOR_PRICE,
       COMPANY_ID,
       CREATE_USER_ID,
       CREATE_EMPLOYEE_ID,
       CREATE_TIME,
       MODIFY_USER,
       MODIFY_TIME,
       COST_CENTER_ID,
       EMAIL,
       TRAIN_BOX,
       SEAT_NO,
       SEAT_TYPE_CODE,
       SUP_TRAIN_ORDER_NO,
       START_STATION,
       END_STATION,
       DEPART_STATION,
       DEPART_CITY_CODE,
       DEPART_CITY_NAME,
       ARRIVE_STATION,
       ARRIVE_CITY_CODE,
       ARRIVE_CITY_NAME,
       DEPART_DATE,
       ARRIVE_DATE,
       DEPART_TIME,
       ARRIVE_TIME,
       TRAIN_CODE,
       SEAT_TYPE_NAME,
       DEPT_ID,
       DEPT_NAME,
       IS_USER,
       USER_ID,
       CONTACT_ID,
       PUR_ID,
       PUR_NAME,
       PUR_SETTLE_STATE,
       PUR_SETTLE_TIME,
       PUR_REFUND_MONEY,
       PUR_HANDLING_FEE,
       PUR_CHECK_STATE,
       PUR_CHECK_TIME,
       PUR_BILL_NO,
       PUR_BANK_NO,
       SUP_ID,
       SUP_NAME,
       SUP_SETTLE_STATE,
       SUP_SETTLE_TIME,
       SUP_CHECK_STATE,
       SUP_CHECK_TIME,
       SUP_REFUND_MONEY,
       SUP_HANDLING_FEE,
       SUP_BILL_NO,
       SUP_BANK_NO,
       REPORT_CREATE_TIME,
       PUR_PAY_STATE,
       PUR_PAY_TIME,
       PUR_PAY_TYPE,
       ORDER_ID,
       ORDER_NO,
       SUP_PAY_STATE,
       SUP_PAY_TYPE,
       SUP_PAY_TIME)
      select ct.train_ticket_id TRAIN_TICKET_ID,
             ct.train_ticket_no TRAIN_TICKET_NO,
             co.train_order_id TRAIN_ORDER_ID,
             co.train_order_no TRAIN_ORDER_NO,
             ct.train_trip_id TRAIN_TRIP_ID,
             '17' PLANE_TICKET_TYPE,
             co.ticketing_time TICKETING_TIME,
             co.ticketing_employee_id TICKETING_EMPLOYEE,
             ct.state STATE,
             ct.pax_id PAX_ID,
             ct.pax_type PAX_TYPE,
             ct.pax_source PAX_SOURCE,
             ct.idc_type IDC_TYPE,
             ct.idc_no IDC_NO,
             ct.idc_name IDC_NAME,
             ct.phone PHONE,
             ct.birthday BIRTHDAY,
             ct.sex SEX,
             ct.person_type PERSON_TYPE,
             ct.face_price FACE_PRICE,
             ct.sale_price SALE_PRICE,
             ct.pur_service_price PUR_SERVICE_PRICE,
             ct.sup_service_price SUP_SERVICE_PRICE,
             ct.floor_price FLOOR_PRICE,
             ct.company_id COMPANY_ID,
             ct.create_user_id CREATE_USER_ID,
             ct.create_employee_id CREATE_EMPLOYEE_ID,
             co.create_time CREATE_TIME,
             ct.modify_user_id MODIFY_USER,
             ct.modify_time MODIFY_TIME,
             ct.cost_center_id COST_CENTER_ID,
             ct.email EMAIL,
             ct.train_box TRAIN_BOX,
             ct.seat_no SEAT_NO,
             ct.seat_type_code SEAT_TYPE_CODE,
             co.sup_train_order_no SUP_TRAIN_ORDER_NO,
             cti.start_station START_STATION,
             cti.end_station END_STATION,
             cti.depart_station DEPART_STATION,
             cti.depart_city_code DEPART_CITY_CODE,
             cti.depart_city_name DEPART_CITY_NAME,
             cti.arrive_station ARRIVE_STATION,
             cti.arrive_city_code ARRIVE_CITY_CODE,
             cti.arrive_city_name ARRIVE_CITY_NAME,
             cti.depart_date DEPART_DATE,
             cti.arrive_date ARRIVE_DATE,
             cti.depart_time DEPART_TIME,
             cti.arrive_time ARRIVE_TIME,
             cti.train_code TRAIN_CODE,
             cti.seat_type_name SEAT_TYPE_NAME,
             getDeptIdByUserId(co.create_user_id) DEPT_ID,
             null DEPT_NAME,
             null IS_USER,
             null USER_ID,
             null CONTACT_ID,
             co.pur_id PUR_ID,
             co.pur_name PUR_NAME,
             co.pur_settle_state PUR_SETTLE_STATE,
             co.pur_settle_time PUR_SETTLE_TIME,
             null PUR_REFUND_MONEY,
             null PUR_HANDLING_FEE,
             co.pur_check_state PUR_CHECK_STATE,
             co.pur_check_time PUR_CHECK_TIME,
             co.pur_bill_no PUR_BILL_NO,
             co.pur_bank_no PUR_BANK_NO,
             co.sup_id SUP_ID,
             co.sup_name SUP_NAME,
             co.sup_settle_state SUP_SETTLE_STATE,
             co.sup_settle_time SUP_SETTLE_TIME,
             co.sup_check_state SUP_CHECK_STATE,
             co.sup_check_time SUP_CHECK_TIME,
             null SUP_REFUND_MONEY,
             null SUP_HANDLING_FEE,
             co.sup_bill_no SUP_BILL_NO,
             co.sup_bank_no SUP_BANK_NO,
             trunc(sysdate, 'dd') REPORT_CREATE_TIME,
             co.pur_pay_state,
             co.pur_pay_time,
             co.pur_pay_type,
             co.train_order_id ORDER_ID,
             co.train_order_no ORDER_NO,
             co.sup_pay_state,
             co.sup_pay_type,
             co.sup_pay_time
        from t_cc_train_ticket ct, t_cc_train_order co, t_cc_train_trip cti
       where co.train_order_id = ct.train_order_id
         and cti.train_order_id = co.train_order_id
         and co.ticketing_time >= trunc(currentDay, 'dd') - 1000
         and co.ticketing_time <=
             trunc(currentDay, 'dd') - 1 / 24 / 60 / 60
      union all
      select ct.train_ticket_id TRAIN_TICKET_ID,
             ct.train_ticket_no TRAIN_TICKET_NO,
             cr.train_order_id TRAIN_ORDER_ID,
             cr.train_order_no TRAIN_ORDER_NO,
             ct.train_trip_id TRAIN_TRIP_ID,
             '18' PLANE_TICKET_TYPE,
             ct.ticketing_time TICKETING_TIME,
             ct.ticketing_employee TICKETING_EMPLOYEE,
             ct.state STATE,
             ct.pax_id PAX_ID,
             ct.pax_type PAX_TYPE,
             ct.pax_source PAX_SOURCE,
             ct.idc_type IDC_TYPE,
             ct.idc_no IDC_NO,
             ct.idc_name IDC_NAME,
             ct.phone PHONE,
             ct.birthday BIRTHDAY,
             ct.sex SEX,
             ct.person_type PERSON_TYPE,
             ct.face_price FACE_PRICE,
             ct.sale_price SALE_PRICE,
             ct.pur_service_price PUR_SERVICE_PRICE,
             ct.sup_service_price SUP_SERVICE_PRICE,
             ct.floor_price FLOOR_PRICE,
             ct.company_id COMPANY_ID,
             ct.create_user_id CREATE_USER_ID,
             ct.create_employee_id CREATE_EMPLOYEE_ID,
             cr.apply_time CREATE_TIME,
             ct.modify_user_id MODIFY_USER,
             ct.modify_time MODIFY_TIME,
             ct.cost_center_id COST_CENTER_ID,
             ct.email EMAIL,
             ct.train_box TRAIN_BOX,
             ct.seat_no SEAT_NO,
             ct.seat_type_code SEAT_TYPE_CODE,
             null SUP_TRAIN_ORDER_NO,
             cti.start_station START_STATION,
             cti.end_station END_STATION,
             cti.depart_station DEPART_STATION,
             cti.depart_city_code DEPART_CITY_CODE,
             cti.depart_city_name DEPART_CITY_NAME,
             cti.arrive_station ARRIVE_STATION,
             cti.arrive_city_code ARRIVE_CITY_CODE,
             cti.arrive_city_name ARRIVE_CITY_NAME,
             cti.depart_date DEPART_DATE,
             cti.arrive_date ARRIVE_DATE,
             cti.depart_time DEPART_TIME,
             cti.arrive_time ARRIVE_TIME,
             cti.train_code TRAIN_CODE,
             cti.seat_type_name SEAT_TYPE_NAME,
             getDeptIdByUserId(cr.apply_user_id) DEPT_ID,
             null DEPT_NAME,
             null IS_USER,
             null USER_ID,
             null CONTACT_ID,
             cr.pur_id PUR_ID,
             cr.pur_name PUR_NAME,
             cr.pur_settle_type PUR_SETTLE_STATE,
             cr.pur_settle_time PUR_SETTLE_TIME,
             crt.pur_refund_money PUR_REFUND_MONEY,
             crt.pur_handling_fee PUR_HANDLING_FEE,
             cr.pur_check_state PUR_CHECK_STATE,
             cr.pur_check_time PUR_CHECK_TIME,
             null PUR_BILL_NO,
             cr.pur_bank_no PUR_BANK_NO,
             cr.sup_id SUP_ID,
             cr.sup_name SUP_NAME,
             cr.sup_settle_state SUP_SETTLE_STATE,
             cr.sup_settle_time SUP_SETTLE_TIME,
             cr.sup_check_state SUP_CHECK_STATE,
             cr.sup_check_time SUP_CHECK_TIME,
             cr.sup_refund_money SUP_REFUND_MONEY,
             cr.sup_handling_fee SUP_HANDLING_FEE,
             cr.sup_bill_no SUP_BILL_NO,
             cr.sup_bank_no SUP_BANK_NO,
             trunc(sysdate, 'dd') REPORT_CREATE_TIME,
             null pur_pay_state,
             null pur_pay_time,
             cr.pur_pay_type,
             cr.train_refund_id ORDER_ID,
             cr.train_refund_no ORDER_NO,
             null sup_pay_state,
             cr.sup_pay_type,
             null sup_pay_time
        from t_cc_train_ticket        ct,
             t_cc_train_refund_ticket crt,
             t_cc_train_refund        cr,
             t_cc_train_trip          cti
       where ct.train_ticket_id = crt.train_ticket_id
         and cr.train_refund_id = crt.train_refund_id
         and cti.train_order_id = cr.train_order_id
         and cr.complete_time >= trunc(currentDay, 'dd') - 1000
         and cr.complete_time <= trunc(currentDay, 'dd') - 1 / 24 / 60 / 60;

    commit;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(SQLERRM);
  END;

END;
