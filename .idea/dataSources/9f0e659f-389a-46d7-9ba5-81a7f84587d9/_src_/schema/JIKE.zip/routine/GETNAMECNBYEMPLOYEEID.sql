create function getNameCnByEmployeeId(v_employeeId IN number) RETURN VARCHAR2
IS
  v_nameCn VARCHAR2(50); 
BEGIN
    select name_cn into v_nameCn from T_CS_EMPLOYEE where employee_id = v_employeeId; 
    return v_nameCn; 
END;