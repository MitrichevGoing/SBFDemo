create function searchDeptID(nCompanyID IN number,vParentFullName in varchar2,vSep in varchar2) return number
as
  numParentDeptID number;
  vcParentDeptFullName varchar2(8000);
  vcFullName varchar2(4000);

  iNum integer ;
  res number;

  errorResult EXCEPTION;
begin
  res := 0;

  vcParentDeptFullName := upper(trim(vParentFullName));
  vcParentDeptFullName := replace(vcParentDeptFullName,vSep,'/');

  if vcParentDeptFullName is not null then
    for rs in (select * from t_base_department a where a.company_id=nCompanyID and a.state!=-1) loop
      numParentDeptID := rs.parent_dept_id;
      if numParentDeptID is null then
        vcFullName := upper(trim(rs.dept_name));
      else
        vcFullName := upper(trim(rs.dept_name));
        loop
          iNum := 0;
          for rsDept in (select * from t_base_department where dept_id=numParentDeptID) loop
              numParentDeptID :=  rsDept.Parent_Dept_Id;
              iNum := 1;
              vcFullName := upper(trim(rsDept.dept_name))||'/'||vcFullName;
          end loop ;
          if (numParentDeptID is null) or (iNum=0)then
            Exit;
          end if ;
        end loop;
      end if ;

      --update t_base_department aa set aa.dept_full_name=vcFullName where dept_id=rs.dept_id;
      --commit;

      if vcParentDeptFullName=vcFullName then
        res := rs.dept_id;
        raise errorResult;
      end if ;
    end loop ;
  else
    raise errorResult;
  end if ;
  return res;
EXCEPTION
  WHEN errorResult THEN
    return res;
  WHEN OTHERS THEN
    return res;
end;
