create procedure T_CHECK as
  num1 number(16,0);
  num2 number(16,0);
  num3 number(16,0);
  num4 number(16,0);
  num5 number(16,0);
  num6 number(16,2);
  num7 number(16,2);
  vTemp varchar2(50);
begin

  for cursor_user in (select * from jike.t_base_integral_user) loop
      --all times
      select count(*) into num1 from jike.t_base_integral_record where user_id = cursor_user.user_id where ig_type !=2;
      --have times
      select count(*) into num2 from jike.t_base_integral_record where user_id = cursor_user.user_id where ig_type = 0;
      --no times
      selct count(*) into num3 from jike.t_base_integral_record where user_id = cursor_user.user_id where ig_type = 3;
      --命中次数
      selct count(*) into num4 from jike.t_base_integral_record where user_id = cursor_user.user_id where ig_type = 0 and score != 0;
      --积分数
      select sum(score) into num5 from jike.t_base_integral_record where user_id = cursor_user.user_id where ig_type !=3;

      num6 := 0;
      num7 := 0;
      for cursor_records in (select * from jike.t_base_integral_record where user_id = cusor_user.user_id) loop
          if substr(cursor_records.ORDER_NO,0,1) = '1' then
              select sale_price into num7 from jike.t_cc_plane_order where plane_order_no = cursor_records.ORDER_NO;
          elsif substr(cursor_records.ORDER_NO,0,1) = '2' then
              select sale_price into num7 from jike.t_cc_inter_plane_order where plane_order_no = cursor_records.ORDER_NO;
          elsif substr(cursor_records.ORDER_NO,0,1) = 'S'
              select SALE_TOTAL_PRICE into num7 from jike.T_CH_HOTEL_ORDER where plane_order_no = cursor_records.ORDER_NO;
          end if;
          num6 := num6 + num7;
      end loop;

      update jike.t_base_integral_user set user_all_score= num5,draw_times = num2,draw_able = num3,hit_times = num4,total_orders=num1
        ,amount = num6 where user_id = cursor_user.user_id;

  end loop;

end ;