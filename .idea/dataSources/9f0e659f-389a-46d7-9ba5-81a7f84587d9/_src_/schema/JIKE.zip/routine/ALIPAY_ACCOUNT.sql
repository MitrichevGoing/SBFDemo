create PROCEDURE alipay_account(
    v_FOREIGN_ORDER_NO IN VARCHAR2,
    v_CREATE_TIME      IN TIMESTAMP,
    v_flow_no          IN VARCHAR2,
    v_trade_no         IN VARCHAR2,
    v_sup              IN VARCHAR2,
    v_user_no          IN VARCHAR2,
    v_receive          IN FLOAT,
    v_pay              IN FLOAT,
    v_trade_place      IN VARCHAR2)
IS
  v_id VARCHAR2(20);--序列
  v_no VARCHAR2(20);--编号
  v_price FLOAT;--手续费
  CURSOR c1_cursor
  IS
    SELECT * FROM T_FIN_FLOW_SUP_PAYABLE t3 WHERE t3.TRADE_NO = v_TRADE_NO;
  CURSOR c2_cursor
  IS
    SELECT *
    FROM t_fin_flow_sup_receivable t4
    WHERE t4.TRADE_NO = v_TRADE_NO;
BEGIN
--当交易号(trade_no)不存在时
--1、插入T_FIN_SUP_ACCOUNT表
--2、判断是应收还是应付
--3、若为应付，更新T_FIN_FLOW_SUP_PAYABLE表acural_price
--   v_price与v_pay比较，若在千分之2内，则添加手续费流水
--4、若为应收，更新T_FIN_FLOW_SUP_RECEIVABLE表acural_price
--   v_price与v_receive比较，若在千分之2内，则添加手续费流水
  merge INTO T_FIN_SUP_ACCOUNT t1 USING
  (SELECT v_trade_no trade_no FROM dual
  ) t2 ON (t1.trade_no = t2.trade_no)
WHEN NOT matched THEN
  INSERT
    (
      t1.FOREIGN_ORDER_NO,
      t1.CREATE_TIME,
      t1.FLOW_NO,
      t1.SUP,
      t1.USER_NO,
      t1.RECEIVE,
      t1.PAY,
      t1.TRADE_NO,
      t1.TRADE_PLACE
    )
    VALUES
    (
      v_FOREIGN_ORDER_NO,
      v_CREATE_TIME,
      v_FLOW_NO,
      v_SUP,
      v_USER_NO,
      v_RECEIVE,
      v_PAY,
      v_TRADE_NO,
      v_TRADE_PLACE
    );
  IF v_PAY IS NOT NULL THEN
    UPDATE T_FIN_FLOW_SUP_PAYABLE t3
    SET t3.actual_price = v_pay
    WHERE t3.TRADE_NO   = v_TRADE_NO;
    FOR c_row IN c1_cursor
    LOOP
      IF c_row.price IS NOT NULL AND v_pay < c_row.price * 1.002 AND v_pay > c_row.price * 0.998 THEN
        v_id         := seq_fin_flow_sup_payable_id.nextval;
        v_no         := 'F22'||REPLACE(lpad(v_id,6),' ','0')||'0';
        v_price      := v_pay - c_row.price;
        IF v_price != 0 THEN
        INSERT
        INTO T_FIN_FLOW_SUP_PAYABLE
          (
            SUP_PAYABLE_ID ,
            SUP_PAYABLE_NO ,
            ORDER_ID ,
            ORDER_NO ,
            ORDER_TIME ,
            FLOW_ORDER_TYPE ,
            FLOW_ADD_TYPE ,
            PRICE ,
            SETTLE_TYPE ,
            SETTLE_STATE ,
            SUP_ID ,
            COMPANY_ID ,
            CREATE_TIME
          )
          VALUES
          (
            v_id ,
            v_no ,
            c_row.ORDER_ID ,
            c_row.ORDER_NO ,
            c_row.ORDER_TIME ,
            c_row.FLOW_ORDER_TYPE ,
            '3' ,
            v_PRICE ,
            c_row.SETTLE_TYPE ,
            '0' ,
            c_row.SUP_ID ,
            c_row.COMPANY_ID ,
            sysdate
          );
          END IF;
      END IF;
    END LOOP;
  elsif v_receive IS NOT NULL THEN
    UPDATE t_fin_flow_sup_receivable t4
    SET t4.actual_price = v_RECEIVE
    WHERE t4.TRADE_NO   = v_TRADE_NO;
    FOR c_row IN c2_cursor
    LOOP
      IF c_row.price IS NOT NULL AND v_receive < c_row.price * 1.002 AND v_receive > c_row.price * 0.998 THEN
        v_id         := seq_fin_flow_sup_receivable_id.nextval;
        v_no         := 'F21'||REPLACE(lpad(v_id,6),' ','0')||'0';
        v_price      := v_receive - c_row.price;
        IF v_price != 0 THEN
        INSERT
        INTO t_fin_flow_sup_receivable
          (
            SUP_RECEIVABLE_ID ,
            SUP_RECEIVABLE_NO,
            ORDER_ID ,
            ORDER_NO ,
            ORDER_TIME ,
            FLOW_ORDER_TYPE ,
            FLOW_ADD_TYPE ,
            PRICE ,
            SETTLE_TYPE ,
            SETTLE_STATE ,
            SUP_ID ,
            COMPANY_ID ,
            CREATE_TIME
          )
          VALUES
          (
            v_id ,
            v_no,
            c_row.ORDER_ID ,
            c_row.ORDER_NO ,
            c_row.ORDER_TIME ,
            c_row.FLOW_ORDER_TYPE ,
            '3' ,
            v_PRICE ,
            c_row.SETTLE_TYPE ,
            '0' ,
            c_row.SUP_ID ,
            c_row.COMPANY_ID ,
            sysdate
          );
          END IF;
      END IF;
    END LOOP;
  END IF ;
END alipay_account;
