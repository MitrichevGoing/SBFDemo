create procedure JobCheckSmsReply
as
  iNum integer;
  vsCode varchar2(4000);
  vsRes  varchar2(4000);
  dtNow date;
BEGIN
  dtNow := sysdate;
  for rs in (select * from T_BASE_MESSAGE_RECEIVE where state='0') loop
    vsCode := trim(rs.msg);
    --自动验证通过(现由JOB实现，准备放到此处)

    --是否匹配到：０-未匹配，１-找到匹配
    iNum := 0;
    --1.0订单验证未通过
    for rsOrder0 in (select a.order_endtime,a.audit_id, a.order_id,a.order_type,nvl((select mobilephone from t_base_user where user_id=a.audit_user and state='1' and rownum<=1),'0') phone from T_CC_ORDER_AUDIT a where decline_code=vsCode and state='1') loo      for rsOrderUser in (select Audit_Id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_order_audit_user where Audit_Id=rsOrder0.Audit_Id) loop 
        --手机号相同,匹配到
        if rsOrderUser.Phone in (rs.mobile) then
          iNum := 1;
          if dtNow>rsOrder0.Order_Endtime then
            update T_CC_ORDER_AUDIT set state='4',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核码过期' where Audit_Id=rsOrderUser.Audit_Id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批码过期',dotime=dtNow where id=rs.id;
          else
            update T_CC_ORDER_AUDIT set state='4',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核未通过' where Audit_Id=rsOrderUser.Audit_Id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批未通过',dotime=dtNow where id=rs.id;
          end if ;
        end if ;   
        --根据国内和国际机票类型进行判断
        if rsOrder0.Order_Type='1' then
           update t_cc_plane_order set audit_state='3' where plane_order_id=rsOrder0.Order_Id and audit_state in ('1');
           --发短信
           vsRes := dbis_sms_json.tocreate('{"templetid":"ORDER_FOR_REPLY_PLANE_CIVIL","id":"'||rsOrder0.Order_Id||'","remark":"0","telphone":"N"}','');
      end if ;
        if rsOrder0.Order_Type='2' then
           update T_CC_INTER_PLANE_ORDER set audit_state='3' where plane_order_id=rsOrder0.Order_Id and audit_state in ('1');
           --发短信
           vsRes := dbis_sms_json.tocreate('{"templetid":"ORDER_FOR_REPLY_PLANE_INTER","id":"'||rsOrder0.Order_Id||'","remark":"0","telphone":"N"}','');
        end if ;           
      end loop ;
    end loop ;

    --1.1订单验证通过
    for rsOrder1 in (select a.order_endtime, a.audit_id, a.order_id,a.order_type,nvl((select mobilephone from t_base_user where user_id=a.audit_user and state='1' and rownum<=1),'0') phone from T_CC_ORDER_AUDIT a where PASS_CODE=vsCode and state='1') loop
      for rsOrderUser in (select Audit_Id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_order_audit_user where Audit_Id=rsOrder1.Audit_Id) loop 
        --手机号相同,匹配到
        if rsOrderUser.Phone in (rs.mobile) then
          iNum := 1;
          if dtNow>rsOrder1.Order_Endtime then
            update T_CC_ORDER_AUDIT set state='4',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核码过期' where Audit_Id=rsOrderUser.Audit_Id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批码过期',dotime=dtNow where id=rs.id;
            if rsOrder1.Order_Type='1' then
               update t_cc_plane_order set audit_state='3' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
               --发短信
               vsRes := dbis_sms_json.tocreate('{"templetid":"ORDER_FOR_REPLY_PLANE_CIVIL","id":"'||rsOrder1.Order_Id||'","remark":"0","telphone":"N"}','');
            end if ;
            if rsOrder1.Order_Type='2' then
               update T_CC_INTER_PLANE_ORDER set audit_state='3' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
               --发短信
               vsRes := dbis_sms_json.tocreate('{"templetid":"ORDER_FOR_REPLY_PLANE_INTER","id":"'||rsOrder1.Order_Id||'","remark":"0","telphone":"N"}','');
            end if ;
          else
            update T_CC_ORDER_AUDIT set state='3',audit_user=rsOrderUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审核已通过' where Audit_Id=rsOrderUser.Audit_Id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='订单审批已通过',dotime=dtNow where id=rs.id;
            if rsOrder1.Order_Type='1' then
               update t_cc_plane_order set audit_state='2' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
               --发短信
               vsRes := dbis_sms_json.tocreate('{"templetid":"ORDER_FOR_REPLY_PLANE_CIVIL","id":"'||rsOrder1.Order_Id||'","remark":"1","telphone":"N"}','');
            end if ;
            if rsOrder1.Order_Type='2' then
               update T_CC_INTER_PLANE_ORDER set audit_state='2' where plane_order_id=rsOrder1.Order_Id and audit_state in ('1');
               --发短信
               vsRes := dbis_sms_json.tocreate('{"templetid":"ORDER_FOR_REPLY_PLANE_INTER","id":"'||rsOrder1.Order_Id||'","remark":"1","telphone":"N"}','');
            end if ;
          end if ;
        end if ;            
      end loop ;
    end loop ;

    --2.0行程单的验证未通过　状态=4
    for rsXcd0 in (select a.trip_endtime, a.biz_trip_id from T_CC_BUSINESS_TRIP a where decline_code=vsCode and state='1') loop
      --通过子表去查询手机号
      for rsBizTripUser in (select biz_trip_id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_biztrip_audit_user where biz_trip_id=rsXcd0.Biz_Trip_Id) loop 
        --手机号相同,匹配到
        if rsBizTripUser.Phone in (rs.mobile) then
          iNum := 1;
          if dtNow>rsXcd0.trip_endtime then
            update T_CC_BUSINESS_TRIP set state='4',audit_state='3',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批码过期' where biz_trip_id=rsBizTripUser.biz_trip_id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批码过期',dotime=dtNow where id=rs.id;
            --发短信
            vsRes := dbis_sms_json.tocreate('{"templetid":"BIZ_TRIP_FOR_REPLY","id":"'||rsBizTripUser.Biz_Trip_Id||'","remark":"0","telphone":"N"}','');
          else
            update T_CC_BUSINESS_TRIP set state='4',audit_state='3',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批未通过' where biz_trip_id=rsBizTripUser.biz_trip_id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批未通过',dotime=dtNow where id=rs.id;
            --发短信
            vsRes := dbis_sms_json.tocreate('{"templetid":"BIZ_TRIP_FOR_REPLY","id":"'||rsBizTripUser.Biz_Trip_Id||'","remark":"0","telphone":"N"}','');
          end if ;
        end if ;
      end loop ;
    end loop ;

    --2.1行程单的验证已通过　状态=3
    for rsXcd1 in (select a.trip_endtime,a.biz_trip_id,nvl((select mobilephone from t_base_user where user_id=a.audit_user and state='1' and rownum<=1),'0') phone from T_CC_BUSINESS_TRIP a where pass_code=vsCode and state='1') loop
      --通过子表去查询手机号
      for rsBizTripUser in (select biz_trip_id,audit_user_id,nvl((select mobilephone from t_base_user where user_id=audit_user_id and state='1' and rownum<=1),'0') phone from t_cc_biztrip_audit_user where biz_trip_id=rsXcd1.Biz_Trip_Id) loop 
        --手机号相同,匹配到
        if rsBizTripUser.Phone in (rs.mobile) then
          iNum := 1;
          if dtNow>rsXcd1.trip_endtime then
            update T_CC_BUSINESS_TRIP set state='4',audit_state='3',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批码过期' where biz_trip_id=rsBizTripUser.biz_trip_id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批码过期',dotime=dtNow where id=rs.id;
            --发短信
            vsRes := dbis_sms_json.tocreate('{"templetid":"BIZ_TRIP_FOR_REPLY","id":"'||rsBizTripUser.Biz_Trip_Id||'","remark":"0","telphone":"N"}','');
          else
            update T_CC_BUSINESS_TRIP set state='3',audit_state='2',audit_user=rsBizTripUser.Audit_User_Id,AUDIT_TIME=dtNow,AUDIT_REASON='短信审批已通过' where biz_trip_id=rsBizTripUser.biz_trip_id;
            update T_BASE_MESSAGE_RECEIVE set state='1',res='行程审批已通过',dotime=dtNow where id=rs.id;
            --发短信
            vsRes := dbis_sms_json.tocreate('{"templetid":"BIZ_TRIP_FOR_REPLY","id":"'||rsBizTripUser.Biz_Trip_Id||'","remark":"1","telphone":"N"}','');
          end if ;
        end if ;
      end loop ;
    end loop ;

    --未找到匹配的数据
    if iNum=0 then
      update T_BASE_MESSAGE_RECEIVE set state='2',res='无需处理',dotime=dtNow where id=rs.id;
    end if ;

    commit;
  end loop ;
END;

