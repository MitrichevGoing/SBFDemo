create function getDeptIdByUserId(v_userId IN number)
  return number is
  v_deptId number;
begin
  if v_userId is null then
    return null;
  end if;

  select dept_id into v_deptId from T_BASE_USER where user_id = v_userId;
  return v_deptId;
end getDeptIdByUserId;
