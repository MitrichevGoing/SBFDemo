create function getCabinClassByPlaneTicketId(v_planeTicketId IN number,
                                                        v_orderType     IN VARCHAR2)
  return VARCHAR2 is
  v_cabinClass VARCHAR2(1000);
begin
  if v_planeTicketId is null or v_orderType is null then
    return null;
  end if;

  if v_orderType = '1' then
    for rs in (select t2.*
                 from t_cc_plane_od   t1,
                      t_cc_plane_trip t2,
                      t_cc_ticket_od  t3
                where t1.plane_od_id = t2.plane_od_id
                  and t1.plane_od_id = t3.plane_od_id
                  and t3.plane_ticket_id = v_planeTicketId) loop
      if v_cabinClass is null then
        v_cabinClass := rs.cabin_class;
      else
        v_cabinClass := v_cabinClass || ',' || rs.cabin_class;
      end if;
    end loop;
  end if;

  if v_orderType = '2' then
    for rs in (select t2.*
                 from t_cc_inter_plane_od   t1,
                      t_cc_inter_plane_trip t2,
                      t_cc_inter_ticket_od  t3
                where t1.plane_od_id = t2.plane_od_id
                  and t1.plane_od_id = t3.plane_od_id
                  and t3.plane_ticket_id = v_planeTicketId) loop
      if v_cabinClass is null then
        v_cabinClass := rs.cabin_class;
      else
        v_cabinClass := v_cabinClass || ',' || rs.cabin_class;
      end if;
    end loop;
  end if;

  return v_cabinClass;
end getCabinClassByPlaneTicketId;
