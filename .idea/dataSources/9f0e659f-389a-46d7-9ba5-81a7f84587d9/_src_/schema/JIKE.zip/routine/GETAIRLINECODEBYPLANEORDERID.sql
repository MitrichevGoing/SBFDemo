create function getAirlineCodeByPlaneOrderId(v_planeOrderId IN number)
  return VARCHAR2 is
  v_airlineCode VARCHAR2(1000);
begin
  if v_planeOrderId is null then
    return null;
  end if;

  for rs in (select t2.*
               from t_cc_plane_od t1, t_cc_plane_trip t2
              where t1.plane_od_id = t2.plane_od_id
                and t1.plane_order_id = v_planeOrderId) loop
    if v_airlineCode is null then
      v_airlineCode := rs.airline_code;
    else
      v_airlineCode := v_airlineCode || ',' || rs.airline_code;
    end if;
  end loop;

  return v_airlineCode;
end getAirlineCodeByPlaneOrderId;
