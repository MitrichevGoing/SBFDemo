create Function GET_SEQUENCE(v_seq_name in varchar2)
  
  Return number Is
  v_seq number;
  v_sqlstr varchar2(128);
begin
   v_sqlstr:='select '||v_seq_name||'.nextval '||' from '||' dual';
   execute immediate v_sqlstr into v_seq;
   return v_seq; 
END;