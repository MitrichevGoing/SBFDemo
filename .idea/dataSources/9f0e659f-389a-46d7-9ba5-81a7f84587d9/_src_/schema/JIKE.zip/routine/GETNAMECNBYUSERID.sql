create function getNameCnByUserId(v_userId IN number) RETURN VARCHAR2
IS
  v_nameCn VARCHAR2(50); 
BEGIN
    select name_cn into v_nameCn from T_BASE_USER where user_id = v_userId; 
    return v_nameCn; 
END;
