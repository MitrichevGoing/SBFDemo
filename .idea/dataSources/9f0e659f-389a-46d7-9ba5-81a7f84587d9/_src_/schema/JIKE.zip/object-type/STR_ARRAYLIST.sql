create type str_arraylist as VARRAY(20) of VARCHAR2(500);

set serveroutput on;

begin 

end;